# paraforge/afo_zone_reader.py - Reads AFO clinical zone names from the bundled
# reference .blend at runtime, mirroring zone_reader.py/tlso_zone_reader.py's
# role for the TT/TLSO workflows.
#
# Deviations vs. SPEC_parafly_afo_complete.md Section 3, found by checking
# against the real codebase rather than the spec's own code (same class of
# corrections already documented once for TLSO - see tlso_zone_reader.py's
# module docstring, tlso_alignment.py's module docstring):
#
# 1. The spec's fallback path (reference blend missing) returned ZONE_ORDER
#    itself - a list of raw zone ids with no actual vertex groups behind
#    them. Every consumer (mapping wizard, slider engine) assumes a zone
#    name in this list has a real vertex group to look up on the active
#    object; silently returning names with nothing behind them would just
#    move the crash one step later instead of preventing it. Matches
#    zone_reader.py/tlso_zone_reader.py instead: return an empty list so
#    callers' existing "no zones found" empty-state handling applies.
#
# 2. Added find_afo_vertex_group() - the spec's Section 3 never defined this,
#    but the mapping wizard and slider engine (ported from the TLSO pattern)
#    both need a case-insensitive vertex-group lookup, exactly like
#    zone_reader.find_vertex_group()/tlso_zone_reader.find_tlso_vertex_group().

import bpy
import os

# This file sits at dynax_addon/paraforge/afo_zone_reader.py, the same
# nesting depth as zone_reader.py/tlso_zone_reader.py, so it needs the same
# dirname(dirname(...)) to reach dynax_addon/reference_models/.
AFO_REFERENCE_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "reference_models",
    "afo_reference.blend"
)

# Explicit clinical order for the Clinical Mapping wizard - matches
# afo_zone_definitions.py's AFO_ZONE_METADATA ordering. Any zone found in the
# blend but not listed here is appended alphabetically at the end rather than
# silently dropped (same fallback zone_reader.py/tlso_zone_reader.py use).
ZONE_ORDER = [
    "zone_afo_calf_band",
    "zone_afo_ankle_medial",
    "zone_afo_ankle_lateral",
    "zone_afo_heel_relief",
    "zone_afo_footplate",
    "zone_afo_anterior_trim",
]

_cached_afo_zones = None


def get_afo_zone_names():
    """
    Read all vertex group names beginning with "zone_afo_" (case-insensitive)
    from afo_reference.blend, scanning every mesh object in the file for the
    first one that actually has any. Cached after first load - call
    invalidate_afo_zone_cache() to force a re-read.
    """
    global _cached_afo_zones
    if _cached_afo_zones is not None:
        return _cached_afo_zones

    zone_names = []

    if not os.path.exists(AFO_REFERENCE_PATH):
        print(f"[ParaFly AFO] WARNING: Reference blend not found at {AFO_REFERENCE_PATH}")
        _cached_afo_zones = zone_names
        return zone_names

    loaded_object_names = []
    try:
        with bpy.data.libraries.load(AFO_REFERENCE_PATH, link=False) as (data_from, data_to):
            data_to.objects = list(data_from.objects)
        loaded_object_names = [o.name for o in data_to.objects if o is not None]

        for obj in data_to.objects:
            if obj is not None and obj.type == 'MESH':
                found = [vg.name.lower() for vg in obj.vertex_groups if vg.name.lower().startswith("zone_afo_")]
                if found:
                    zone_names = found
                    break
    finally:
        removed_meshes = []
        for name in loaded_object_names:
            obj = bpy.data.objects.get(name)
            if obj is not None:
                if obj.type == 'MESH' and obj.data is not None:
                    removed_meshes.append(obj.data)
                bpy.data.objects.remove(obj, do_unlink=True)
        for mesh in removed_meshes:
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)

    found = set(zone_names)
    zone_names = [z for z in ZONE_ORDER if z in found]
    zone_names += sorted(z for z in found if z not in ZONE_ORDER)

    _cached_afo_zones = zone_names
    print(f"[ParaFly AFO] Loaded {len(zone_names)} zones: {zone_names}")
    return zone_names


def invalidate_afo_zone_cache():
    global _cached_afo_zones
    _cached_afo_zones = None


def find_afo_vertex_group(obj, zone_id):
    """Case-insensitive vertex-group lookup, same rationale as
    zone_reader.find_vertex_group()/tlso_zone_reader.find_tlso_vertex_group()."""
    target = zone_id.lower()
    for vg in obj.vertex_groups:
        if vg.name.lower() == target:
            return vg
    return None


def afo_zone_id_to_display_name(zone_id):
    """'zone_afo_ankle_medial' -> 'Ankle (Medial)'. Kept from the spec's own
    Section 3 implementation - it already handles the medial/lateral suffix
    correctly."""
    name = zone_id.replace("zone_afo_", "").replace("_", " ")
    for suffix in ["medial", "lateral"]:
        if name.endswith(f" {suffix}"):
            name = name[:-len(f" {suffix}")] + f" ({suffix.capitalize()})"
            break
    return name.title()
