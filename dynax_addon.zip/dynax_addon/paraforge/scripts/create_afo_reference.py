"""
One-time setup script.
Run inside Blender (Text Editor -> Run Script), or headlessly via
`blender --background --python create_afo_reference.py`, to (re)create
afo_reference.blend in the reference_models folder.

Starts from a fully empty file (bpy.ops.wm.read_factory_settings(use_empty=True)),
matching create_tlso_reference.py's established pattern - SPEC_parafly_afo_complete.md's
own version of this script skipped that step and just added the placeholder sphere
into whatever scene happened to already be open, which would bundle any unrelated
session objects (e.g. a patient scan) into the shipped reference file if someone
ran it from a live working session instead of a fresh Blender instance.
"""

import bpy
import os

# -- Zone names --------------------------------------------------------
AFO_ZONE_IDS = [
    "zone_afo_calf_band",
    "zone_afo_ankle_medial",
    "zone_afo_ankle_lateral",
    "zone_afo_heel_relief",
    "zone_afo_footplate",
    "zone_afo_anterior_trim",
]

# -- Output path ---------------------------------------------------------
# paraforge/scripts/create_afo_reference.py -> up 2 levels -> dynax_addon/ ->
# reference_models/afo_reference.blend
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_PATH = os.path.normpath(
    os.path.join(SCRIPT_DIR, "..", "..", "reference_models", "afo_reference.blend")
)

# -- Create a simple placeholder mesh -------------------------------------
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.object.select_all(action='DESELECT')

# Add a UV Sphere as the placeholder mesh object (never shown to users - only
# its vertex group NAMES matter, read by afo_zone_reader.get_afo_zone_names())
bpy.ops.mesh.primitive_uv_sphere_add(radius=1, location=(0, 0, 0))
ref_obj = bpy.context.active_object
ref_obj.name = "afo_reference"

# -- Add all vertex groups ------------------------------------------------
for zone_id in AFO_ZONE_IDS:
    ref_obj.vertex_groups.new(name=zone_id)
    print(f"[AFO Setup] Created vertex group: {zone_id}")

print(f"[AFO Setup] {len(AFO_ZONE_IDS)} vertex groups created on '{ref_obj.name}'")

# -- Save to reference_models folder --------------------------------------
os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
bpy.ops.wm.save_as_mainfile(filepath=OUTPUT_PATH)
print(f"[AFO Setup] Saved: {OUTPUT_PATH}")
