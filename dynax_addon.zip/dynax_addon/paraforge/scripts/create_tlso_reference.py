"""
One-time setup script.
Run inside Blender (Text Editor -> Run Script) to (re)create tlso_reference.blend
in the reference_models folder. Re-run whenever the zone list below changes -
most recently SPEC_parafly_slider_and_zone_corrections.md, which split
zone_tlso_waist_area and zone_tlso_trochanter_pad (previously auto-mirrored
bilateral zones - see tlso_zone_definitions.py's module docstring) into four
explicit zone_tlso_waist_area_left/_right and
zone_tlso_trochanter_pad_left/_right zones, painted independently with no
runtime mirroring. 9 zones total.
"""

import bpy
import os

# ── Zone names ────────────────────────────────────────────────────
# Trochanter Pad (left/right) removed from the workflow (2026-07-13). 7 zones.
TLSO_ZONE_IDS = [
    "zone_tlso_thoracic_pad",
    "zone_tlso_lumbar_pad",
    "zone_tlso_waist_area_left",
    "zone_tlso_waist_area_right",
    "zone_tlso_thoracic_relief",
    "zone_tlso_lumbar_relief",
    "zone_tlso_abdominal_relief",
]

# ── Output path ───────────────────────────────────────────────────
# paraforge/scripts/create_tlso_reference.py -> up 2 levels -> dynax_addon/ ->
# reference_models/tlso_reference.blend
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_PATH = os.path.normpath(
    os.path.join(SCRIPT_DIR, "..", "..", "reference_models", "tlso_reference.blend")
)

# ── Create a simple placeholder mesh ─────────────────────────────
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.object.select_all(action='DESELECT')

# Add a UV Sphere as the placeholder mesh object (never shown to users - only
# its vertex group NAMES matter, read by tlso_zone_reader.get_tlso_zone_names())
bpy.ops.mesh.primitive_uv_sphere_add(radius=1, location=(0, 0, 0))
ref_obj = bpy.context.active_object
ref_obj.name = "tlso_reference"

# ── Add all vertex groups ─────────────────────────────────────────
for zone_id in TLSO_ZONE_IDS:
    vg = ref_obj.vertex_groups.new(name=zone_id)
    print(f"[TLSO Setup] Created vertex group: {zone_id}")

print(f"[TLSO Setup] {len(TLSO_ZONE_IDS)} vertex groups created on '{ref_obj.name}'")

# ── Save to reference_models folder ──────────────────────────────
os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
bpy.ops.wm.save_as_mainfile(filepath=OUTPUT_PATH)
print(f"[TLSO Setup] Saved: {OUTPUT_PATH}")
