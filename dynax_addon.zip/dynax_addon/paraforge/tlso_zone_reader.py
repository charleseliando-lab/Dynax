# paraforge/tlso_zone_reader.py - Reads TLSO clinical zone names from the bundled
# reference .blend at runtime, mirroring zone_reader.py's role for the TT workflow.
#
# Path/import deviations vs. SPEC_parafly_tlso_complete.md: the spec assumes a
# top-level `parafly` package (`from parafly.tlso_zone_reader import ...`) - this
# addon's actual package is `dynax_addon.paraforge` (kept stable rather than
# renamed - see the ParaFly/ParaForm menu-restructure conversation), so this file
# lives at paraforge/tlso_zone_reader.py and everything that needs it uses proper
# relative imports (`from ..tlso_zone_reader import ...` /
# `from .tlso_zone_reader import ...` depending on nesting depth), not the spec's
# bare `from parafly...` form, which would raise ModuleNotFoundError as an addon
# submodule.

import bpy
import os

# This file sits at dynax_addon/paraforge/tlso_zone_reader.py, the same nesting
# depth as zone_reader.py (dynax_addon/paraforge/zone_reader.py), so it needs the
# same dirname(dirname(...)) to reach dynax_addon/reference_models/.
TLSO_REFERENCE_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "reference_models",
    "tlso_reference.blend"
)

# Clinical workflow order for the Clinical Mapping wizard (see
# get_tlso_zone_names' Fix 1 comment) - matches
# tlso_zone_definitions.py's own PRESSURE ZONES / RELIEF ZONES section order.
# SPEC_parafly_slider_and_zone_corrections.md Section 3: waist_area and
# trochanter_pad split into explicit _left/_right zones (9 total, was 7) -
# see tlso_zone_definitions.py's module docstring.
ZONE_ORDER = [
    "zone_tlso_thoracic_pad",
    "zone_tlso_lumbar_pad",
    "zone_tlso_waist_area_left",
    "zone_tlso_waist_area_right",
    "zone_tlso_thoracic_relief",
    "zone_tlso_lumbar_relief",
    "zone_tlso_abdominal_relief",
]

# Zones removed from the clinical workflow but still baked into the existing
# tlso_reference.blend as vertex groups. get_tlso_zone_names() drops these so
# they never surface in the mapping wizard / adjustment sliders, without
# needing to regenerate the reference blend. The Trochanter Pad zones (both
# sides) were removed per clinical request (2026-07-13).
TLSO_EXCLUDED_ZONES = {
    "zone_tlso_trochanter_pad_left",
    "zone_tlso_trochanter_pad_right",
}

_cached_tlso_zones = None


def get_tlso_zone_names():
    """
    Read all vertex group names beginning with "zone_tlso_" (case-insensitive)
    from tlso_reference.blend, scanning every mesh object in the file for the
    first one that actually has any (same robustness fix as zone_reader.py's
    get_zone_names(), applied here defensively even though the file this addon
    generates only ever has one object). Cached after first load - call
    invalidate_tlso_zone_cache() to force a re-read.
    """
    global _cached_tlso_zones
    if _cached_tlso_zones is not None:
        return _cached_tlso_zones

    zone_names = []

    if not os.path.exists(TLSO_REFERENCE_PATH):
        print(f"[ParaFly TLSO] WARNING: Reference blend not found at {TLSO_REFERENCE_PATH}")
        _cached_tlso_zones = zone_names
        return zone_names

    loaded_object_names = []
    try:
        with bpy.data.libraries.load(TLSO_REFERENCE_PATH, link=False) as (data_from, data_to):
            data_to.objects = list(data_from.objects)
        loaded_object_names = [o.name for o in data_to.objects if o is not None]

        for obj in data_to.objects:
            if obj is not None and obj.type == 'MESH':
                found = [vg.name.lower() for vg in obj.vertex_groups
                         if vg.name.lower().startswith("zone_tlso_")
                         and vg.name.lower() not in TLSO_EXCLUDED_ZONES]
                if found:
                    zone_names = found
                    break
    finally:
        removed_meshes = []
        for name in loaded_object_names:
            obj = bpy.data.objects.get(name)
            if obj is not None:
                if obj.type == 'MESH' and obj.data is not None:
                    removed_meshes.append(obj.data)
                bpy.data.objects.remove(obj, do_unlink=True)
        for mesh in removed_meshes:
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)

    # SPEC_tlso_mapping_combined_fix.md Fix 1: alphabetical sort put
    # zone_tlso_abdominal_relief (alphabetically first) as Step 1 instead of
    # the intended clinical workflow order (Thoracic Pad first). ZONE_ORDER
    # matches tlso_zone_definitions.py's own section ordering (pressure zones
    # thoracic->lumbar->trochanter->waist, then relief zones thoracic->lumbar
    # ->abdominal). Any zone not in ZONE_ORDER (e.g. a future addition to the
    # reference blend before this list is updated) is appended alphabetically
    # at the end rather than silently dropped.
    found = set(zone_names)
    zone_names = [z for z in ZONE_ORDER if z in found]
    zone_names += sorted(z for z in found if z not in ZONE_ORDER)

    _cached_tlso_zones = zone_names
    print(f"[ParaFly TLSO] Loaded {len(zone_names)} zones: {zone_names}")
    return zone_names


def invalidate_tlso_zone_cache():
    global _cached_tlso_zones
    _cached_tlso_zones = None


def find_tlso_vertex_group(obj, zone_id):
    """Case-insensitive vertex-group lookup, same rationale as
    zone_reader.find_vertex_group()."""
    target = zone_id.lower()
    for vg in obj.vertex_groups:
        if vg.name.lower() == target:
            return vg
    return None


def tlso_zone_id_to_display_name(zone_id):
    """'zone_tlso_thoracic_pad' -> 'Thoracic Pad' (still handles a
    '_right'/'_left' suffix if one is ever present, e.g. for a future
    single-sided zone, but none of the current 7 zones use one)."""
    name = zone_id
    if name.lower().startswith("zone_tlso_"):
        name = name[len("zone_tlso_"):]
    name = name.replace("_", " ")
    for suffix in ("right", "left"):
        if name.lower().endswith(f" {suffix}"):
            name = name[: -len(f" {suffix}")] + f" ({suffix.capitalize()})"
            break
    return name.title()
