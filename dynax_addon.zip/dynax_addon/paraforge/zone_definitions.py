# paraforge/zone_definitions.py - Clinical metadata per zone (v2).
#
# Zone IDs are NOT hardcoded here - they come from zone_reader.get_zone_names(),
# read from the real vertex groups on tt_reference_rigged.blend. This dict only
# supplies clinical description/range metadata, keyed by the lowercase-normalized
# real zone names found in that file (zone_tibia_crest, zone_patella_tendon, etc.
# - see zone_reader.py's module docstring for why these differ from the original
# 6 hardcoded names this project started with, and for why they're lowercase).
# Any zone present in the blend but not listed here falls back to ZONE_DEFAULTS
# via get_zone_meta() - so the file can gain/lose zones without this dict needing
# to stay in lockstep.
#
# Ranges for the 6 zones with a clear anatomical match to the original clinical
# brief are carried over from that brief; the remaining zones in the real file
# (Tibia_Head, Medial/Lateral_Shaft, Medial/Lateral_Condyle, Posterior_Popliteal,
# Distal_Tibia_Head) don't have an authored clinical range yet and
# deliberately fall back to ZONE_DEFAULTS rather than guessed numbers - a
# prosthetist should review and add real ranges for these before clinical use.
# (Brim was removed from the reference blend entirely - it never had authored
# metadata here and no longer needs a fallback either.)
#
# SPEC_parafly_slider_and_zone_corrections.md Section 1 ("remove all min/max
# limits, allow unlimited user input"): slider_engine.py's
# register_slider_properties() no longer passes ANY hard min/max to the
# registered FloatProperty at all, so typing any value is never clamped.
# "minimum"/"maximum" here now only set soft_min/soft_max - the comfortable
# default DRAG range shown by the slider widget, widened from the previous
# +/-10.0 to +/-20.0 per the corrections spec's own explicit UI-range value.

ZONE_METADATA = {
    "zone_patella_tendon": {
        "display_name": "Patella Tendon",
        "description": "Primary weight-bearing region. Push out to increase relief.",
        "category": "Pressure Tolerant",
        "minimum": -20.0,
        "maximum": 20.0,
        "default": 0.0,
    },
    "zone_tibia_crest": {
        "display_name": "Tibia Crest",
        "description": "Pressure sensitive anterior ridge. Pull in with caution.",
        "category": "Pressure Sensitive",
        "minimum": -20.0,
        "maximum": 20.0,
        "default": 0.0,
    },
    "zone_fibula_head": {
        "display_name": "Fibula Head",
        "description": "Lateral bony prominence. Relieve pressure by pushing outward.",
        "category": "Pressure Sensitive",
        "minimum": -20.0,
        "maximum": 20.0,
        "default": 0.0,
    },
    "zone_medial_shaft": {
        "display_name": "Medial Shaft",
        "description": "Medial flare of the tibial shaft.",
        "category": "Pressure Tolerant",
        "minimum": -20.0,
        "maximum": 20.0,
        "default": 0.0,
    },
    "zone_distal_end": {
        "display_name": "Distal End",
        "description": "End-bearing sensitive distal region.",
        "category": "Pressure Sensitive",
        "minimum": -20.0,
        "maximum": 20.0,
        "default": 0.0,
    },
    "zone_posterior_popliteal": {
        "display_name": "Posterior Popliteal",
        "description": "Posterior calf/popliteal muscle bulk.",
        "category": "Pressure Tolerant",
        "minimum": -20.0,
        "maximum": 20.0,
        "default": 0.0,
    },
}

ZONE_DEFAULTS = {
    "display_name": None,   # None -> fall back to zone_reader.zone_id_to_display_name()
    "description": "Adjust this clinical region.",
    "category": "General",
    "minimum": -20.0,
    "maximum": 20.0,
    "default": 0.0,
}


def get_zone_meta(zone_id):
    """Return metadata for a zone, falling back to safe defaults for any zone
    that exists in the reference blend but has no authored entry above.
    Looked up case-insensitively (zone_id.lower()) for the same reason
    zone_reader.find_vertex_group() is - defends against any zone id that
    isn't already lowercase-normalized reaching this far."""
    meta = ZONE_METADATA.get(zone_id.lower())
    if meta is not None:
        return meta
    from .zone_reader import zone_id_to_display_name
    fallback = dict(ZONE_DEFAULTS)
    fallback["display_name"] = zone_id_to_display_name(zone_id)
    return fallback
