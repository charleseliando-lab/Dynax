# paraforge/operators/device_select.py - ParaFly device picker (TT vs TLSO).

from bpy.types import Operator
from bpy.props import StringProperty


class PARAFORGE_OT_set_device_type(Operator):
    """Choose which ParaFly device workflow to use for this session"""
    bl_idname = "paraforge.set_device_type"
    bl_label = "Set ParaFly Device Type"
    bl_options = {'REGISTER'}

    device_type: StringProperty()

    def execute(self, context):
        context.scene.parafly_device_type = self.device_type
        return {'FINISHED'}
