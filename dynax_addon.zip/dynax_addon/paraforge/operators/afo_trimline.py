import bpy
import bmesh
from collections import defaultdict, deque

PREVIEW_NAME = "ParaFly_AFO_Trimline_Preview"
KEEP_NAME = "ParaFly_AFO_Keep"
REMOVE_NAME = "ParaFly_AFO_Remove"
SOURCE_KEY = "parafly_afo_trim_source"
TRIMLINE_MASK_GROUP = "AFO_TRIMLINE_MASK"
TRIMLINE_BOUNDARY_GROUP = "AFO_TRIMLINE_BOUNDARY"


def _group_indices(obj):
    group = obj.vertex_groups.get(TRIMLINE_MASK_GROUP)
    if group is None:
        return set()
    return {
        vert.index for vert in obj.data.vertices
        if any(item.group == group.index and item.weight > 0.5
               for item in vert.groups)
    }


def _face_partition(obj):
    selected_verts = _group_indices(obj)
    selected_faces = {
        poly.index for poly in obj.data.polygons
        if sum(index in selected_verts for index in poly.vertices) > len(poly.vertices) / 2
    }
    remainder_faces = set(range(len(obj.data.polygons))) - selected_faces
    return selected_faces, remainder_faces


def _component_count(face_indices, edge_faces):
    if not face_indices:
        return 0
    neighbours = defaultdict(set)
    for linked in edge_faces.values():
        relevant = [face for face in linked if face in face_indices]
        for face in relevant:
            neighbours[face].update(other for other in relevant if other != face)
    unseen = set(face_indices)
    count = 0
    while unseen:
        count += 1
        queue = deque([unseen.pop()])
        while queue:
            for other in neighbours[queue.popleft()]:
                if other in unseen:
                    unseen.remove(other)
                    queue.append(other)
    return count


def _validate_partition(obj):
    """Validate a painted face partition for separation.

    Mirrors Creator's native Paint & Separate exactly: the painted faces are the
    region to keep, the rest are split off. ANY painted selection separates -
    disconnected islands, open interfaces, and selections touching the shell's
    existing open rims are all fine, just like bpy.ops.mesh.separate(
    type='SELECTED'). Only genuinely impossible cases are rejected: nothing
    painted, or everything painted (nothing left to separate).
    """
    selected, remainder = _face_partition(obj)
    if not selected:
        return None, "Paint the AFO region you want to keep before separating"
    if not remainder:
        return None, "The whole mesh is painted; leave the part to remove unpainted"

    edge_faces = defaultdict(list)
    for poly in obj.data.polygons:
        for edge in poly.edge_keys:
            edge_faces[tuple(sorted(edge))].append(poly.index)

    # The new trimline = manifold interior edges (len == 2) whose two faces
    # differ in membership. Pre-existing open rims (len == 1) are never
    # collected here, so AFO_TRIMLINE_BOUNDARY stays limited to the newly
    # created cut. It may be empty (e.g. a fully separate painted component);
    # that still separates cleanly and the boundary smoother simply no-ops.
    boundary = [edge for edge, linked in edge_faces.items()
                if len(linked) == 2 and ((linked[0] in selected) != (linked[1] in selected))]

    return {
        "selected": selected,
        "remainder": remainder,
        "boundary": boundary,
        "edge_faces": edge_faces,
    }, None


def _remove_preview():
    preview = bpy.data.objects.get(PREVIEW_NAME)
    if preview:
        bpy.data.objects.remove(preview, do_unlink=True)


def _activate(context, obj):
    bpy.ops.object.select_all(action='DESELECT')
    obj.hide_set(False)
    obj.hide_viewport = False
    obj.select_set(True)
    context.view_layer.objects.active = obj
    context.scene.paraforge_active_object = obj


class PARAFORGE_OT_afo_trimline_paint(bpy.types.Operator):
    """Set up the scan for a SOLID trimline paint selection: vertex-select mode
    with X-ray on, so the circle brush grabs every vertex under it (front and
    back) instead of the scattered face-centre pick that face-select mode gives
    on a dense scan."""
    bl_idname = "paraforge.afo_trimline_paint"
    bl_label = "Paint Trimline Region"
    bl_options = {'REGISTER'}

    tool: bpy.props.StringProperty(default='CIRCLE')

    _TOOL_IDS = {
        'BOX': 'builtin.select_box',
        'LASSO': 'builtin.select_lasso',
        'CIRCLE': 'builtin.select_circle',
    }

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "No AFO scan loaded")
            return {'CANCELLED'}

        bpy.ops.object.select_all(action='DESELECT')
        obj.hide_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        if context.mode != 'EDIT':
            if context.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')

        # VERTEX mode + X-ray = a solid pick. Face mode only selects faces whose
        # centre lands under the brush, and without X-ray occluded/back-facing
        # geometry is skipped — together that is the "scattered selection".
        bpy.ops.mesh.select_mode(type='VERT')
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        try:
                            space.shading.show_xray = True
                        except Exception:
                            pass

        tool_id = self._TOOL_IDS.get(self.tool, 'builtin.select_circle')
        try:
            bpy.ops.wm.tool_set_by_id(name=tool_id)
        except Exception:
            pass

        if self.tool == 'CIRCLE':
            radius = getattr(context.scene.dynax_props, "select_brush_radius", 40)
            try:
                t = context.workspace.tools.from_space_view3d_mode(
                    context.mode, create=False)
                if t and t.idname == 'builtin.select_circle':
                    op_props = t.operator_properties("view3d.select_circle")
                    if op_props:
                        op_props.radius = radius
            except Exception:
                pass
            self.report(
                {'INFO'},
                "Paint the region to KEEP — every vertex under the brush is "
                "selected. Scroll to resize, then Lock.")
        else:
            self.report({'INFO'}, "Drag over the region to KEEP, then Lock.")
        return {'FINISHED'}


class PARAFORGE_OT_afo_trimline_lock(bpy.types.Operator):
    bl_idname = "paraforge.afo_trimline_lock"
    bl_label = "Lock AFO Trimline Paint"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if obj is None or obj.type != 'MESH':
            return {'CANCELLED'}
        if obj.mode == 'EDIT':
            obj.update_from_editmode()
        selected = [vert.index for vert in obj.data.vertices if vert.select]
        if not selected:
            self.report({'WARNING'}, "Paint a trimline region first")
            return {'CANCELLED'}
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        old = obj.vertex_groups.get(TRIMLINE_MASK_GROUP)
        if old is not None:
            obj.vertex_groups.remove(old)
        group = obj.vertex_groups.new(name=TRIMLINE_MASK_GROUP)
        group.add(selected, 1.0, 'REPLACE')
        context.scene["parafly_afo_trimline_selection_count"] = len(selected)
        self.report({'INFO'}, f"Locked {len(selected):,} AFO trimline vertices")
        return {'FINISHED'}


class PARAFORGE_OT_afo_trimline_clear(bpy.types.Operator):
    bl_idname = "paraforge.afo_trimline_clear"
    bl_label = "Clear AFO Trimline Paint"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if obj is None or obj.type != 'MESH':
            return {'CANCELLED'}
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        group = obj.vertex_groups.get(TRIMLINE_MASK_GROUP)
        if group is not None:
            obj.vertex_groups.remove(group)
        for vert in obj.data.vertices:
            vert.select = False
        context.scene["parafly_afo_trimline_selection_count"] = 0
        _remove_preview()
        self.report({'INFO'}, "AFO trimline paint cleared")
        return {'FINISHED'}


class PARAFORGE_OT_afo_trimline_preview(bpy.types.Operator):
    bl_idname = "paraforge.afo_trimline_preview"
    bl_label = "Preview AFO Trimline"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if obj is None or obj.type != 'MESH':
            return {'CANCELLED'}
        if obj.mode == 'EDIT':
            obj.update_from_editmode()
            bpy.ops.object.mode_set(mode='OBJECT')
        result, error = _validate_partition(obj)
        if error:
            self.report({'WARNING'}, error)
            return {'CANCELLED'}

        _remove_preview()
        used = sorted({index for edge in result["boundary"] for index in edge})
        remap = {old: new for new, old in enumerate(used)}
        vertices = [obj.data.vertices[index].co.copy() for index in used]
        edges = [(remap[a], remap[b]) for a, b in result["boundary"]]
        mesh = bpy.data.meshes.new(PREVIEW_NAME)
        mesh.from_pydata(vertices, edges, [])
        preview = bpy.data.objects.new(PREVIEW_NAME, mesh)
        context.collection.objects.link(preview)
        preview.matrix_world = obj.matrix_world.copy()
        preview.display_type = 'WIRE'
        preview.color = (0.1, 1.0, 0.1, 1.0)
        preview.show_in_front = True
        self.report({'INFO'}, f"Closed trimline preview: {len(edges)} boundary edges")
        return {'FINISHED'}


def _copy_face_partition(context, source, name, faces_to_keep, boundary_indices):
    obj = source.copy()
    obj.data = source.data.copy()
    obj.name = name
    collection = source.users_collection[0] if source.users_collection else context.collection
    collection.objects.link(obj)
    boundary_group = obj.vertex_groups.new(name=TRIMLINE_BOUNDARY_GROUP)
    boundary_group.add(sorted(boundary_indices), 1.0, 'REPLACE')
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.faces.ensure_lookup_table()
    remove = [face for face in bm.faces if face.index not in faces_to_keep]
    bmesh.ops.delete(bm, geom=remove, context='FACES')
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    return obj


class PARAFORGE_OT_afo_trimline_separate(bpy.types.Operator):
    bl_idname = "paraforge.afo_trimline_separate"
    bl_label = "Separate AFO Trimline"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        source = context.scene.paraforge_active_object
        if source is None or source.type != 'MESH':
            return {'CANCELLED'}
        if bpy.data.objects.get(KEEP_NAME) or bpy.data.objects.get(REMOVE_NAME):
            self.report({'WARNING'}, "Reset the previous AFO trimline before separating again")
            return {'CANCELLED'}
        if source.mode == 'EDIT':
            source.update_from_editmode()
            bpy.ops.object.mode_set(mode='OBJECT')
        result, error = _validate_partition(source)
        if error:
            self.report({'WARNING'}, error)
            return {'CANCELLED'}

        # Like Creator's Paint & Separate: the painted region is the part to
        # keep; the remainder is split off (tinted red) so the user can discard
        # it. Both objects are kept, so a mis-paint is never destructive.
        keep_faces = result["selected"]
        remove_faces = result["remainder"]
        boundary_indices = {
            index for edge in result["boundary"] for index in edge
        }
        keep = _copy_face_partition(
            context, source, KEEP_NAME, keep_faces, boundary_indices
        )
        remove = _copy_face_partition(
            context, source, REMOVE_NAME, remove_faces, boundary_indices
        )
        context.scene[SOURCE_KEY] = source.name
        source.hide_set(True)
        source.hide_render = True
        remove.color = (0.8, 0.15, 0.15, 0.5)
        _remove_preview()
        _activate(context, keep)
        self.report({'INFO'}, "Created ParaFly_AFO_Keep and ParaFly_AFO_Remove")
        return {'FINISHED'}


def _order_boundary_loops(bm, allowed_indices=None):
    """Walk the mesh's open (1-face) boundary edges into ordered vertex loops.
    If allowed_indices is given, only boundary edges whose BOTH endpoints are in
    that set are considered — so smoothing stays on the freshly-cut trimline and
    never touches the scan's own natural openings (top of leg, sole)."""
    adj = defaultdict(list)
    for edge in bm.edges:
        if not edge.is_boundary:
            continue
        a, b = edge.verts
        if allowed_indices is not None and (
                a.index not in allowed_indices or b.index not in allowed_indices):
            continue
        adj[a].append(b)
        adj[b].append(a)

    loops = []
    visited = set()
    for start in list(adj.keys()):
        if start in visited:
            continue
        loop = [start]
        visited.add(start)
        prev, cur = None, start
        while True:
            nxt = None
            for nb in adj[cur]:
                if nb is not prev and nb not in visited:
                    nxt = nb
                    break
            if nxt is None:
                break
            loop.append(nxt)
            visited.add(nxt)
            prev, cur = cur, nxt
        if len(loop) >= 6:
            loops.append(loop)
    return loops


def _taubin_smooth_loop(loop, cycles, lam, mu):
    """λ|μ (Taubin) low-pass on a closed vertex loop: removes the stair-steps a
    face-based cut leaves while NOT shrinking the rim the way a plain
    moving-average would (the positive λ pass shrinks, the negative μ pass
    re-inflates by a hair more)."""
    n = len(loop)
    coords = [v.co.copy() for v in loop]

    def one_pass(src, factor):
        out = []
        for i in range(n):
            a = src[(i - 1) % n]
            b = src[i]
            c = src[(i + 1) % n]
            laplacian = (a + c) * 0.5 - b
            out.append(b + laplacian * factor)
        return out

    for _ in range(cycles):
        coords = one_pass(coords, lam)
        coords = one_pass(coords, mu)
    for vert, co in zip(loop, coords):
        vert.co = co


class PARAFORGE_OT_afo_trimline_smooth(bpy.types.Operator):
    """Smooth the cut trimline into a genuine flowing curve.

    Orders the cut boundary into a closed loop and runs a Taubin low-pass on it
    (removes the stair-stepping of the face-based cut without shrinking the rim),
    then relaxes the adjacent interior ring so the faces attached to the moved
    rim stay well-shaped (no spike-producing normals for a later Solidify)."""
    bl_idname = "paraforge.afo_trimline_smooth"
    bl_label = "Smooth AFO Trimline"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if obj is None or obj.type != 'MESH':
            self.report({'WARNING'}, "Cut the trimline first")
            return {'CANCELLED'}
        if obj.mode == 'EDIT':
            obj.update_from_editmode()
            bpy.ops.object.mode_set(mode='OBJECT')

        # Prefer scoping to the recorded cut boundary so we never smooth the
        # scan's own natural openings; fall back to all open edges if the group
        # isn't present (e.g. a manually-opened mesh).
        allowed = None
        group = obj.vertex_groups.get(TRIMLINE_BOUNDARY_GROUP)
        if group is not None:
            gi = group.index
            allowed = {
                v.index for v in obj.data.vertices
                if any(g.group == gi and g.weight > 0.5 for g in v.groups)
            }
            if len(allowed) < 6:
                allowed = None

        passes = context.scene.parafly_afo_trimline_smooth_passes
        strength = context.scene.parafly_afo_trimline_smooth_strength

        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()

        loops = _order_boundary_loops(bm, allowed)
        if not loops:
            bm.free()
            self.report({'WARNING'}, "No cut boundary found to smooth")
            return {'CANCELLED'}

        # Taubin params: λ from the strength slider, μ slightly larger negative
        # so the curve doesn't creep inward across passes. More passes = a
        # smoother curve. cycles scale with passes for a visible effect.
        lam = max(0.1, min(0.6, strength))
        mu = -(lam + 0.03)
        cycles = max(2, passes * 3)

        ring = set()
        for loop in loops:
            _taubin_smooth_loop(loop, cycles, lam, mu)
            for vert in loop:
                for edge in vert.link_edges:
                    other = edge.other_vert(vert)
                    if not other.is_boundary:
                        ring.add(other)

        # Relax the first interior ring so the faces bridging it to the moved rim
        # stay clean (prevents the sliver-normal spikes on later thickening).
        if ring:
            bmesh.ops.smooth_vert(
                bm, verts=list(ring), factor=strength * 0.5,
                use_axis_x=True, use_axis_y=True, use_axis_z=True,
            )

        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.05)  # 0.05 mm
        bmesh.ops.dissolve_degenerate(bm, dist=0.05, edges=bm.edges[:])
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
        self.report(
            {'INFO'},
            f"Smoothed trimline curve ({len(loops)} loop(s), {passes} passes)")
        return {'FINISHED'}


class PARAFORGE_OT_afo_trimline_delete_removed(bpy.types.Operator):
    """Delete the split-off remainder (ParaFly_AFO_Remove) once the clinician is
    happy with the cut, leaving only the kept AFO region."""
    bl_idname = "paraforge.afo_trimline_delete_removed"
    bl_label = "Delete Removed Part"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        remove = bpy.data.objects.get(REMOVE_NAME)
        if remove is None:
            self.report({'WARNING'}, "Nothing to delete — cut the trimline first")
            return {'CANCELLED'}
        bpy.data.objects.remove(remove, do_unlink=True)
        # The kept part is now the definitive working object; make sure it's the
        # active AFO scan so downstream steps operate on it.
        keep = bpy.data.objects.get(KEEP_NAME)
        if keep is not None:
            _activate(context, keep)
        self.report({'INFO'}, "Removed part deleted")
        return {'FINISHED'}


class PARAFORGE_OT_afo_trimline_reset(bpy.types.Operator):
    bl_idname = "paraforge.afo_trimline_reset"
    bl_label = "Reset AFO Trimline"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        source_name = context.scene.get(SOURCE_KEY, "")
        source = bpy.data.objects.get(source_name)
        for name in (KEEP_NAME, REMOVE_NAME, PREVIEW_NAME):
            obj = bpy.data.objects.get(name)
            if obj:
                bpy.data.objects.remove(obj, do_unlink=True)
        if source:
            source.hide_render = False
            _activate(context, source)
        if SOURCE_KEY in context.scene:
            del context.scene[SOURCE_KEY]
        context.scene["parafly_afo_trimline_selection_count"] = 0
        self.report({'INFO'}, "AFO trimline reset")
        return {'FINISHED'}
