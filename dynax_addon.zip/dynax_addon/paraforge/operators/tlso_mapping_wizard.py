# paraforge/operators/tlso_mapping_wizard.py - Clinical Mapping stage for TLSO:
# same guided one-zone-at-a-time wizard as TT (mapping_wizard.py), plus a Skip
# Zone button for zones marked "skippable" in tlso_zone_definitions.py.
#
# Deviation vs. SPEC_parafly_tlso_complete.md's confirm_zone: the spec converts
# the sculpt mask via bpy.ops.sculpt.mask_to_selection() + edit-mode
# vertex_group_assign(), which only ever produces a binary (weight=1.0)
# membership - it discards the smooth per-vertex mask gradient entirely, and
# the deformation math (tlso_slider_engine.py) multiplies displacement by each
# vertex's *weight* for smooth blending at zone boundaries, so a binary-only
# group would make every zone edge a hard, unblended crease. Reused this
# addon's own already-proven technique instead (mapping_wizard.py's
# confirm_zone): read the ".sculpt_mask" mesh attribute directly and build a
# real per-vertex-weighted vertex group from it - verified correct across 12
# zones on a real scan in the TT workflow already.
#
# SPEC_tlso_zone_update_7zones.md's Fix 3 ("Start Painting not initiating mask
# brush"): two real, distinct problems here, both found and fixed via actual
# testing in a real (non-headless) Blender GUI session - see
# _force_mask_brush's docstring for the mechanism fix and
# PARAFORGE_OT_tlso_start_painting.execute()'s comment for the ordering fix:
# (1) tool_set_by_id, this codebase's previously-believed "proven" mechanism
# for forcing a sculpt brush, does not actually work when driven
# programmatically in this Blender build at all; (2) the brush must be
# activated BEFORE mask_flood_fill runs, not after (the order every version
# of this code used until now) - mask_flood_fill's undo-push silently blocks
# a brush change immediately afterward, verified directly.
#
# SPEC_parafly_slider_and_zone_corrections.md Section 2/3: the automatic
# bilateral-mirroring step that used to run here after confirming
# zone_tlso_waist_area/zone_tlso_trochanter_pad was removed entirely - it
# caused zone deletion bugs. Waist Area and Trochanter Pad are now explicit
# _left/_right zones (zone_tlso_waist_area_left/_right,
# zone_tlso_trochanter_pad_left/_right) painted separately like every other
# zone, with no runtime mirroring step at all.

import bpy
from bpy.types import Operator

from ..tlso_zone_reader import get_tlso_zone_names, find_tlso_vertex_group
from ..tlso_zone_definitions import get_tlso_zone_meta
from .tlso_slider_engine import store_tlso_original_positions

MASK_THRESHOLD = 0.02

# ── Persistent zone visualisation (issue: "areas painted before must stay
# showing so users know the boundaries and don't clash zones") ─────────────
# Confirming a zone removes its sculpt mask, so by the time the next zone is
# painted there was no on-screen memory of the earlier ones. Blender's Face
# Sets are exactly the right tool: a per-face integer attribute
# (".sculpt_face_set") that Sculpt Mode renders as distinctly-coloured regions.
# On confirm we stamp each zone's faces with its own face-set id; those colours
# persist across every following zone's painting session (the mask flood-fill
# clears only the mask, never the face sets), so the clinician always sees the
# outline of everything mapped so far. This is purely visual - it never touches
# the mask or the per-vertex weight capture that drives the deformation.
TLSO_FACE_SET_ATTR = ".sculpt_face_set"
_FACE_SET_ID_BASE = 2   # ids 0/1 are Blender's default set; start zones above it


def _tlso_zone_face_set_id(zone_id):
    """Stable, distinct face-set integer for a zone (by its workflow index)."""
    names = get_tlso_zone_names()
    try:
        return _FACE_SET_ID_BASE + names.index(zone_id)
    except ValueError:
        return _FACE_SET_ID_BASE + len(names)


def _stamp_zone_face_set(obj, zone_id, vert_indices):
    """Mark the faces of a zone with its own face-set id so Sculpt Mode shows it
    as a coloured region in later painting sessions. A face joins the zone when
    the majority of its vertices were painted (keeps boundaries crisp rather
    than bleeding a whole face in off a single painted corner)."""
    mesh = obj.data
    fs_id = _tlso_zone_face_set_id(zone_id)

    attr = mesh.attributes.get(TLSO_FACE_SET_ATTR)
    if attr is not None and (attr.domain != 'FACE' or attr.data_type != 'INT'):
        mesh.attributes.remove(attr)
        attr = None
    if attr is None:
        attr = mesh.attributes.new(TLSO_FACE_SET_ATTR, 'INT', 'FACE')

    painted = set(vert_indices)
    for poly in mesh.polygons:
        verts = poly.vertices
        hit = sum(1 for vi in verts if vi in painted)
        item = attr.data[poly.index]
        if hit * 2 >= len(verts):
            item.value = fs_id
        elif item.value == fs_id:
            # This face used to belong to the zone but the zone was re-painted
            # smaller - release it back to the default set so no stale colour
            # lingers outside the new boundary.
            item.value = 0
    mesh.update()


def _show_face_sets_overlay(context):
    """Make sure the Sculpt Mode Face Sets overlay is visible so previously
    mapped zones actually show while painting the next one."""
    for area in context.screen.areas:
        if area.type != 'VIEW_3D':
            continue
        for space in area.spaces:
            if space.type != 'VIEW_3D':
                continue
            try:
                space.overlay.show_sculpt_face_sets = True
                if space.overlay.sculpt_mode_face_sets_opacity <= 0.0:
                    space.overlay.sculpt_mode_face_sets_opacity = 1.0
            except Exception:
                pass


def _current_tlso_zone_id(context):
    step = context.scene.parafly_tlso_mapping_step
    zone_names = get_tlso_zone_names()
    if 0 <= step < len(zone_names):
        return zone_names[step]
    return None


def _enter_tlso_adjustment_stage(context, obj):
    if obj.get("parafly_tlso_original_positions") is None:
        store_tlso_original_positions(obj)
    context.scene.parafly_tlso_stage = 'ADJUSTMENT'


def _check_tlso_completion(context, obj, zone_names):
    """All non-skippable zones must have a vertex group before Adjustment
    unlocks. In normal use this is already guaranteed (Skip Zone refuses
    non-skippable zones), but verified defensively anyway - matches the
    reference spec's own belt-and-suspenders design."""
    all_required = all(
        find_tlso_vertex_group(obj, z) is not None
        for z in zone_names
        if not get_tlso_zone_meta(z).get("skippable", True)
    )
    if all_required:
        _enter_tlso_adjustment_stage(context, obj)
        return True
    return False


# Relative path of the bundled "Mask" brush inside Blender's own essentials
# brush-asset library (verified to exist on disk at
# <blender install>/5.1/datafiles/assets/brushes/essentials_brushes-mesh_sculpt.blend,
# containing a Brush named "Mask" among ~90 others).
MASK_BRUSH_ASSET_PATH = "brushes/essentials_brushes-mesh_sculpt.blend/Brush/Mask"


def _force_mask_brush(context):
    """Activate the Mask brush so Start Painting genuinely enters mask-paint
    mode, not just Sculpt Mode with whatever brush was last active.

    Real bug found and fixed here (not caught by any prior headless test,
    since bpy.ops.wm.tool_set_by_id can't be driven at all in --background
    mode - see module docstring): a manually-constructed Brush datablock +
    `brush.sculpt_tool = 'MASK'` raises AttributeError on this project's
    actual Blender 5.1 build (Blender's 4.3+ brush-asset refactor removed
    sculpt_tool from the Brush ID entirely - see smooth_brush.py's module
    docstring for the same finding). The previous fix for that used
    `bpy.ops.wm.tool_set_by_id(name='builtin_brush.Mask')` instead, believing
    it to be this codebase's "already-proven" mechanism (per
    sculpt_helpers.py's _set_brush) - but verified directly, in a REAL
    (non-headless) Blender GUI session, that tool_set_by_id's poll() passes
    (returns True) while its execute() still silently returns {'CANCELLED'}
    and leaves the brush unchanged, regardless of: which region/area is
    overridden (WINDOW vs a panel's own UI region), EXEC vs INVOKE_DEFAULT,
    an immediate call vs one deferred to a later event-loop tick, or whether
    the toolbar region is visible. None of those fixed it. Also verified
    directly that `context.tool_settings.sculpt.brush = ...` (the other
    tempting direct-assignment fix) raises `AttributeError: attribute
    "brush" from "Sculpt" is read-only` in this Blender build - not usable
    either.

    The actual working mechanism, verified directly in a real GUI session
    (Draw -> Mask, {'FINISHED'}): Blender 4.3+ sculpt brushes are Asset
    datablocks, activated via `bpy.ops.brush.asset_activate(...)` against
    Blender's bundled ESSENTIALS asset library, not via the tool system.
    tool_set_by_id is kept as a fallback in case a future Blender version
    changes this path, but asset_activate is what actually works today.

    Self-contained VIEW_3D area/region override: Start Painting is invoked
    from the DynaX sidebar (an N-panel button), so context.region here is
    the PANEL's own UI region, not the viewport's WINDOW region (the same
    "a panel button gives context.region == panel" gotcha already
    documented in trimline.py's _find_view3d_under_cursor). Matches the
    exact override used during verification."""
    view3d_area = None
    window_region = None
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            view3d_area = area
            for region in area.regions:
                if region.type == 'WINDOW':
                    window_region = region
            break

    def _try_activate():
        try:
            res = bpy.ops.brush.asset_activate(
                asset_library_type='ESSENTIALS',
                asset_library_identifier="",
                relative_asset_identifier=MASK_BRUSH_ASSET_PATH,
            )
            if 'FINISHED' in res:
                return True
        except Exception:
            pass
        try:
            bpy.ops.wm.tool_set_by_id(name='builtin_brush.Mask')
        except Exception:
            pass
        return False

    if view3d_area is not None and window_region is not None:
        with context.temp_override(area=view3d_area, region=window_region):
            _try_activate()
    else:
        _try_activate()


class PARAFORGE_OT_tlso_start_painting(Operator):
    """Enter Sculpt Mode with the Mask brush active to paint this TLSO zone"""
    bl_idname = "paraforge.tlso_start_painting"
    bl_label = "▶ Start Painting"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No TLSO scan is loaded")
            return {'CANCELLED'}
        zone_id = _current_tlso_zone_id(context)
        if zone_id is None:
            self.report({'ERROR'}, "No clinical zone is active")
            return {'CANCELLED'}
        zone_name = get_tlso_zone_meta(zone_id)["display_name"]

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='SCULPT')

        try:
            ts = context.tool_settings.sculpt
            ts.use_symmetry_x = False
            ts.use_symmetry_y = False
            ts.use_symmetry_z = False
            ts.show_mask = True
        except Exception:
            pass

        # Keep every previously-confirmed zone visible (as its face-set colour)
        # while this one is painted, so the clinician can see and avoid the
        # boundaries already mapped.
        _show_face_sets_overlay(context)

        # Order matters here, verified directly in a real GUI session: the
        # brush must be activated BEFORE mask_flood_fill, not after.
        # mask_flood_fill begins a sculpt undo step tied to whatever brush is
        # CURRENTLY active - activating a different brush immediately
        # afterward (the previous order) silently fails (brush.asset_activate
        # itself still reports {'FINISHED'} with no exception, but
        # tool_settings.sculpt.brush never actually changes). Activating
        # first, then flood-filling with the correct brush already active,
        # verified to work: Draw -> Mask succeeds, and stays Mask through the
        # flood fill.
        _force_mask_brush(context)

        try:
            bpy.ops.paint.mask_flood_fill(mode='VALUE', value=0.0)
        except Exception:
            pass

        self.report({'INFO'}, f"Paint the {zone_name} area, then click Confirm Zone")
        return {'FINISHED'}


class PARAFORGE_OT_tlso_confirm_zone(Operator):
    """Convert the painted sculpt mask into this TLSO zone's vertex group"""
    bl_idname = "paraforge.tlso_confirm_zone"
    bl_label = "✓ Confirm Zone"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No TLSO scan is loaded")
            return {'CANCELLED'}
        zone_id = _current_tlso_zone_id(context)
        if zone_id is None:
            self.report({'ERROR'}, "No clinical zone is active")
            return {'CANCELLED'}
        zone_name = get_tlso_zone_meta(zone_id)["display_name"]

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        mesh = obj.data
        mask_attr = mesh.attributes.get(".sculpt_mask")

        weights = {}
        if mask_attr is not None:
            for i, item in enumerate(mask_attr.data):
                if item.value > MASK_THRESHOLD:
                    weights[i] = item.value

        if not weights:
            self.report({'ERROR'},
                f"Nothing painted for {zone_name} — paint at least part of the zone before confirming")
            return {'CANCELLED'}

        existing = find_tlso_vertex_group(obj, zone_id)
        if existing is not None:
            obj.vertex_groups.remove(existing)
        vg = obj.vertex_groups.new(name=zone_id)
        for idx, weight in weights.items():
            vg.add([idx], weight, 'REPLACE')

        # Stamp this zone as a coloured face set BEFORE clearing the mask, so it
        # stays visible while later zones are painted (prevents zone clashing).
        _stamp_zone_face_set(obj, zone_id, weights.keys())

        if mask_attr and mask_attr.name:
            mesh.attributes.remove(mask_attr)
            mesh.update()

        zone_names = get_tlso_zone_names()
        context.scene.parafly_tlso_mapping_step += 1

        if context.scene.parafly_tlso_mapping_step >= len(zone_names):
            if _check_tlso_completion(context, obj, zone_names):
                self.report({'INFO'}, "All required zones mapped. Clinical Adjustment is now available.")
            else:
                self.report({'WARNING'}, "Some required zones are missing. Please go back and complete them.")
        else:
            self.report({'INFO'}, f"✓ {zone_name} mapped ({len(weights)} verts)")
        return {'FINISHED'}


class PARAFORGE_OT_tlso_skip_zone(Operator):
    """Skip this zone (only allowed for zones marked skippable)"""
    bl_idname = "paraforge.tlso_skip_zone"
    bl_label = "↷ Skip Zone"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        zone_names = get_tlso_zone_names()
        step = context.scene.parafly_tlso_mapping_step
        if step < len(zone_names):
            zone_id = zone_names[step]
            meta = get_tlso_zone_meta(zone_id)
            if not meta.get("skippable", True):
                self.report({'WARNING'}, f"{meta['display_name']} is required and cannot be skipped.")
                return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        context.scene.parafly_tlso_mapping_step = step + 1
        if context.scene.parafly_tlso_mapping_step >= len(zone_names) and obj is not None:
            if _check_tlso_completion(context, obj, zone_names):
                self.report({'INFO'}, "All required zones mapped. Clinical Adjustment is now available.")
            else:
                self.report({'WARNING'}, "Some required zones are missing. Please go back and complete them.")
        return {'FINISHED'}


class PARAFORGE_OT_tlso_back_zone(Operator):
    """Go back to the previous TLSO zone (does not delete its vertex group)"""
    bl_idname = "paraforge.tlso_back_zone"
    bl_label = "← Back"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.parafly_tlso_mapping_step = max(0, context.scene.parafly_tlso_mapping_step - 1)
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        return {'FINISHED'}


class PARAFORGE_OT_tlso_skip_all_dev(Operator):
    """Developer only: create empty vertex groups for all TLSO zones and jump to Clinical Adjustment"""
    bl_idname = "paraforge.tlso_skip_all_dev"
    bl_label = "Skip All (Dev)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from ...preferences import get_dev_mode
        if not get_dev_mode():
            self.report({'ERROR'}, "Developer Mode is off")
            return {'CANCELLED'}

        obj = context.scene.paraforge_active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No TLSO scan is loaded")
            return {'CANCELLED'}

        zone_names = get_tlso_zone_names()
        for zone_id in zone_names:
            if find_tlso_vertex_group(obj, zone_id) is None:
                obj.vertex_groups.new(name=zone_id)

        context.scene.parafly_tlso_mapping_step = len(zone_names)
        _enter_tlso_adjustment_stage(context, obj)
        self.report({'WARNING'}, "Dev skip: all zones created empty (testing only)")
        return {'FINISHED'}
