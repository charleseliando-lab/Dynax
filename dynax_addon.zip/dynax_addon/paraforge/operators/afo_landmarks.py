# paraforge/operators/afo_landmarks.py - Landmarks stage for AFO: a modal
# operator that intercepts viewport clicks to place 6 anatomical landmarks in
# sequence via ray casting, mirroring compare_overlay.py/trimline.py's already-
# proven "modal operator + region_2d_to_vector_3d/origin_3d + object.ray_cast in
# local space" pattern.
#
# Corrections vs. SPEC_parafly_afo_complete.md Section 6, found by checking
# against the real codebase rather than trusting the spec's code (same class
# of bugs already documented once for TLSO - see tlso_alignment.py's module
# docstring):
#
# 1. scene.parafly_active_object doesn't exist in this addon. The real shared
#    "current ParaFly working object" property is scene.paraforge_active_object
#    (used by TT, TLSO, and now AFO - only one device workflow is ever active
#    at a time, so there's no need for a fourth parallel property).
#
# 2. The spec routed region_2d_to_vector_3d/region_2d_to_origin_3d through two
#    pointless module-level wrapper functions
#    (bpy_extras_view3d_utils_region_2d_to_vector_3d/_origin_3d) that just
#    import-and-call the real bpy_extras function inline - removed in favor of
#    importing both directly at module level, matching how afo_measurement.py's
#    own spec code already does it.
#
# 3. Real resource leak fixed: _place_marker_sphere removed the old marker
#    OBJECT when re-placing a landmark (Backspace + re-click) but never removed
#    its MATERIAL datablock, so bpy.data.materials accumulated
#    "afo_lm_mat_mt1", "afo_lm_mat_mt1.001", "afo_lm_mat_mt1.002", ... forever
#    across a session. Fixed to remove the old material too, matching the
#    "remove the object then its owned datablock" cleanup pattern already
#    established elsewhere in this addon (zone_reader.py's get_zone_names,
#    compare_overlay.py's snapshot cleanup).

import bpy
import json
from mathutils import Vector
from bpy_extras.view3d_utils import region_2d_to_vector_3d, region_2d_to_origin_3d

# 6 landmarks in placement order
LANDMARK_SEQUENCE = [
    {
        "id": "mt1",
        "display_name": "MT1 — First Metatarsal Head",
        "description": (
            "Click the tip of the first metatarsal head "
            "(base of the big toe) on the scan."
        ),
        "color": (0.90, 0.20, 0.20),   # red
    },
    {
        "id": "mt5",
        "display_name": "MT5 — Fifth Metatarsal Head",
        "description": (
            "Click the tip of the fifth metatarsal head "
            "(base of the little toe) on the scan."
        ),
        "color": (0.95, 0.55, 0.10),   # orange
    },
    {
        "id": "lat_mal",
        "display_name": "Lateral Malleolus",
        "description": (
            "Click the most prominent point of the "
            "lateral malleolus (outer ankle bone)."
        ),
        "color": (0.10, 0.70, 0.90),   # cyan
    },
    {
        "id": "med_mal",
        "display_name": "Medial Malleolus",
        "description": (
            "Click the most prominent point of the "
            "medial malleolus (inner ankle bone)."
        ),
        "color": (0.30, 0.50, 0.95),   # blue
    },
    {
        "id": "calf",
        "display_name": "Calf",
        "description": (
            "Click the centre of the calf on the posterior lower leg."
        ),
        "color": (0.70, 0.30, 0.90),   # purple
    },
    {
        "id": "heel",
        "display_name": "Heel (Calcaneus)",
        "description": (
            "Click the most posterior point of the heel. "
            "This landmark aligns the scan to standard pose."
        ),
        "color": (0.20, 0.80, 0.30),   # green
    },
]

LANDMARK_MARKER_SIZE = 5.0   # mm radius for the visual sphere marker
LEGACY_LANDMARK_IDS = {"fib_head": "calf"}


def normalize_landmarks(lm_dict):
    """Return canonical AFO landmark keys without mutating the input."""
    normalized = dict(lm_dict) if isinstance(lm_dict, dict) else {}
    for legacy_id, canonical_id in LEGACY_LANDMARK_IDS.items():
        if canonical_id not in normalized and legacy_id in normalized:
            normalized[canonical_id] = normalized[legacy_id]
        normalized.pop(legacy_id, None)
    return normalized


def _migrate_legacy_markers():
    for legacy_id, canonical_id in LEGACY_LANDMARK_IDS.items():
        legacy_obj = bpy.data.objects.get(f"afo_lm_{legacy_id}")
        canonical_obj = bpy.data.objects.get(f"afo_lm_{canonical_id}")
        if legacy_obj is not None:
            if canonical_obj is None:
                legacy_obj.name = f"afo_lm_{canonical_id}"
            else:
                bpy.data.objects.remove(legacy_obj, do_unlink=True)

        legacy_mat = bpy.data.materials.get(f"afo_lm_mat_{legacy_id}")
        canonical_mat = bpy.data.materials.get(f"afo_lm_mat_{canonical_id}")
        if legacy_mat is not None:
            if canonical_mat is None:
                legacy_mat.name = f"afo_lm_mat_{canonical_id}"
            elif legacy_mat.users == 0:
                bpy.data.materials.remove(legacy_mat)


def _get_landmarks(scene):
    """Load landmarks dict from JSON scene property."""
    try:
        landmarks = normalize_landmarks(json.loads(scene.parafly_afo_landmarks))
        canonical_json = json.dumps(landmarks)
        if canonical_json != scene.parafly_afo_landmarks:
            scene.parafly_afo_landmarks = canonical_json
        _migrate_legacy_markers()
        return landmarks
    except Exception:
        return {}


def _set_landmarks(scene, lm_dict):
    scene.parafly_afo_landmarks = json.dumps(normalize_landmarks(lm_dict))


def _get_current_landmark_index(scene):
    lm = _get_landmarks(scene)
    for i, ldef in enumerate(LANDMARK_SEQUENCE):
        if ldef["id"] not in lm:
            return i
    return len(LANDMARK_SEQUENCE)


def _place_marker_sphere(context, location, landmark_id, color):
    """Place a small labeled sphere at the landmark position, replacing any
    existing marker (object AND material) for this same landmark id."""
    existing = bpy.data.objects.get(f"afo_lm_{landmark_id}")
    if existing is not None:
        bpy.data.objects.remove(existing, do_unlink=True)

    existing_mat = bpy.data.materials.get(f"afo_lm_mat_{landmark_id}")
    if existing_mat is not None:
        bpy.data.materials.remove(existing_mat, do_unlink=True)

    bpy.ops.mesh.primitive_uv_sphere_add(
        radius=LANDMARK_MARKER_SIZE,
        location=location
    )
    marker = context.view_layer.objects.active
    marker.name = f"afo_lm_{landmark_id}"
    marker.display_type = 'SOLID'
    marker.hide_select = True

    mat = bpy.data.materials.new(name=f"afo_lm_mat_{landmark_id}")
    mat.use_nodes = False
    mat.diffuse_color = (*color, 1.0)
    marker.data.materials.append(mat)

    # Parent the marker to the scan so it moves WITH the mesh — if the clinician
    # grabs/rotates the scan (native G/R, or any tool that moves the object),
    # the landmark sphere follows instead of being left floating in space. The
    # parent-inverse keeps the sphere exactly at `location` right now; alignment
    # ops re-sync it after their transform_apply via _attach_marker_to_scan.
    scan = context.scene.paraforge_active_object
    if scan is not None and scan is not marker:
        marker.parent = scan
        marker.matrix_parent_inverse = scan.matrix_world.inverted()

    return marker


def _remove_all_markers(context):
    """Remove all landmark marker spheres and their materials."""
    for ldef in LANDMARK_SEQUENCE:
        obj = bpy.data.objects.get(f"afo_lm_{ldef['id']}")
        if obj is not None:
            bpy.data.objects.remove(obj, do_unlink=True)
        mat = bpy.data.materials.get(f"afo_lm_mat_{ldef['id']}")
        if mat is not None:
            bpy.data.materials.remove(mat, do_unlink=True)
    for legacy_id in LEGACY_LANDMARK_IDS:
        obj = bpy.data.objects.get(f"afo_lm_{legacy_id}")
        if obj is not None:
            bpy.data.objects.remove(obj, do_unlink=True)
        mat = bpy.data.materials.get(f"afo_lm_mat_{legacy_id}")
        if mat is not None:
            bpy.data.materials.remove(mat, do_unlink=True)


_NAVIGATION_EVENTS = {
    'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE',
    'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE', 'MOUSESMARTZOOM',
    'NDOF_MOTION', 'NDOF_BUTTON_MENU', 'NDOF_BUTTON_FIT',
    'NUMPAD_1', 'NUMPAD_2', 'NUMPAD_3', 'NUMPAD_4',
    'NUMPAD_5', 'NUMPAD_6', 'NUMPAD_7', 'NUMPAD_8',
    'NUMPAD_9', 'NUMPAD_0',
}


def _is_navigation_event(event):
    if event.type in _NAVIGATION_EVENTS or event.type.startswith('NDOF_BUTTON_'):
        return True
    # Alt+LMB is orbit when Emulate 3 Button Mouse is enabled. Modified
    # left-clicks are reserved for viewport navigation, never placement.
    return event.type == 'LEFTMOUSE' and (event.alt or event.ctrl or event.shift or event.oskey)


class PARAFORGE_OT_afo_place_landmarks(bpy.types.Operator):
    """
    Modal operator: click on the mesh surface to place each
    AFO landmark in sequence. Press Escape to cancel.
    Press Backspace to undo the last placed landmark.
    """
    bl_idname = "paraforge.afo_place_landmarks"
    bl_label = "Place Landmarks"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        scene = context.scene
        obj = scene.paraforge_active_object

        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "No AFO scan object loaded.")
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        idx = _get_current_landmark_index(scene)
        if idx >= len(LANDMARK_SEQUENCE):
            self.report({'INFO'}, "All landmarks already placed.")
            return {'CANCELLED'}

        self._current_idx = idx
        self._target_obj_name = obj.name
        scene.parafly_afo_current_landmark = LANDMARK_SEQUENCE[idx]["id"]

        context.window_manager.modal_handler_add(self)
        self.report(
            {'INFO'},
            f"Click to place: {LANDMARK_SEQUENCE[idx]['display_name']}. "
            f"Backspace = undo last. Escape = cancel."
        )
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        scene = context.scene
        obj = bpy.data.objects.get(self._target_obj_name)
        if obj is None:
            self.report({'ERROR'}, "AFO scan object no longer exists.")
            return {'CANCELLED'}

        if _is_navigation_event(event):
            return {'PASS_THROUGH'}

        if event.type == 'ESC':
            self.report({'INFO'}, "Landmark placement cancelled.")
            return {'CANCELLED'}

        if event.type == 'BACK_SPACE' and event.value == 'PRESS':
            lm = _get_landmarks(scene)
            if lm:
                last_id = list(lm.keys())[-1]
                del lm[last_id]
                _set_landmarks(scene, lm)
                marker = bpy.data.objects.get(f"afo_lm_{last_id}")
                if marker:
                    bpy.data.objects.remove(marker, do_unlink=True)
                mat = bpy.data.materials.get(f"afo_lm_mat_{last_id}")
                if mat:
                    bpy.data.materials.remove(mat, do_unlink=True)
                self._current_idx = _get_current_landmark_index(scene)
                scene.parafly_afo_current_landmark = (
                    LANDMARK_SEQUENCE[self._current_idx]["id"]
                    if self._current_idx < len(LANDMARK_SEQUENCE) else ""
                )
                self.report(
                    {'INFO'},
                    f"Undone. Now place: "
                    f"{LANDMARK_SEQUENCE[self._current_idx]['display_name']}"
                )
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            region = context.region
            rv3d = context.region_data
            if region is None or rv3d is None or region.type != 'WINDOW':
                return {'PASS_THROUGH'}
            coord = (event.mouse_region_x, event.mouse_region_y)

            view_vector = region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = region_2d_to_origin_3d(region, rv3d, coord)

            mat_inv = obj.matrix_world.inverted()
            ray_origin_local = mat_inv @ ray_origin
            ray_dir_local = mat_inv.to_3x3() @ view_vector

            success, location_local, normal, face_idx = obj.ray_cast(
                ray_origin_local, ray_dir_local
            )

            if not success:
                return {'RUNNING_MODAL'}

            location_world = obj.matrix_world @ location_local

            lm = _get_landmarks(scene)
            ldef = LANDMARK_SEQUENCE[self._current_idx]
            lm[ldef["id"]] = list(location_world)
            _set_landmarks(scene, lm)

            _place_marker_sphere(
                context,
                location_world,
                ldef["id"],
                ldef["color"]
            )

            self._current_idx += 1

            if self._current_idx >= len(LANDMARK_SEQUENCE):
                scene.parafly_afo_current_landmark = ""
                scene.parafly_afo_stage = 'ALIGNMENT'
                self.report({'INFO'}, "All 6 landmarks placed. Ready to align.")
                return {'FINISHED'}

            next_ldef = LANDMARK_SEQUENCE[self._current_idx]
            scene.parafly_afo_current_landmark = next_ldef["id"]
            self.report(
                {'INFO'},
                f"✓ {ldef['display_name']} placed. "
                f"Now click: {next_ldef['display_name']}"
            )
            return {'RUNNING_MODAL'}

        return {'RUNNING_MODAL'}


class PARAFORGE_OT_afo_clear_landmarks(bpy.types.Operator):
    bl_idname = "paraforge.afo_clear_landmarks"
    bl_label = "Clear All Landmarks"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        _set_landmarks(context.scene, {})
        _remove_all_markers(context)
        context.scene.parafly_afo_stage = 'LANDMARKS'
        context.scene.parafly_afo_current_landmark = ""
        self.report({'INFO'}, "All landmarks cleared.")
        return {'FINISHED'}
