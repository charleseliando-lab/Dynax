# paraforge/operators/afo_slider_engine.py - Clinical Adjustment stage for AFO:
# the parametric slider engine, written in full from tlso_slider_engine.py's
# already-proven pattern (SPEC_parafly_afo_complete.md Section 10 only says
# "reuse the TLSO pattern" - no code given).
#
# Same corrections already proven necessary for TT/TLSO, applied here too:
# 1. UNITS: no /1000.0 anywhere - DynaX is mm-space (1 Blender unit = 1 mm).
# 2. CROSS-ZONE CORRUPTION: apply_afo_zone_deformation always recomputes the
#    FULL mesh from the stored baseline across every zone's current slider
#    value, not just the triggering one - moving one slider can never wipe
#    out another zone's already-applied offset.
# 3. Each zone is pushed along ONE average normal for the whole zone, not
#    each vertex's own normal (per-vertex normals are unreliable across a
#    large curved surface - see tlso_slider_engine.py's module docstring for
#    the original finding on a real torso scan).
# 4. direction-aware push (inward/outward/boundary, from
#    afo_zone_definitions.py), same as TLSO's zones.
#
# PERFORMANCE (2026-07-13): on a real ~240k-vertex scan the original engine
# made the whole workflow feel like it was hanging. Two fixes, both matching
# patterns already used elsewhere in this addon:
#  A. The baseline is stored as a mesh FLOAT_VECTOR attribute, NOT a JSON
#     object ID-property. A 240k-vertex baseline is ~11 MB of JSON text; as an
#     ID-property Blender copies it into EVERY global-undo snapshot, so every
#     action in the workflow lagged, and every zone-slider tick re-parsed it
#     (~1s). A mesh attribute is a packed float array read/written with
#     foreach_get/set in milliseconds and never JSON-parsed. Same technique
#     afo_push_pull.py already uses for its own baseline.
#  B. Zone sliders are DEBOUNCED (afo_correction.py's _schedule_* pattern) and
#     apply_afo_zone_deformation is numpy-vectorised with the baseline,
#     baseline normals and per-zone weights all cached - so a slider drag runs
#     one bounded recompute on release instead of a ~2.7s full rebuild on every
#     tick.
#
# Baseline storage key is AFO's OWN "parafly_afo_original_positions" - each
# device namespaces its own baseline. store_afo_original_positions() is defined
# HERE and imported by afo_correction.py (Apply Corrections) and
# afo_mapping_wizard.py (stage-transition guard), so the call sites never
# disagree on the key string / storage format.

import bpy
import bmesh
from mathutils import Vector

try:
    import numpy as np
except ImportError:  # Blender bundles NumPy; keep a safe fallback.
    np = None

from ..afo_zone_reader import get_afo_zone_names, find_afo_vertex_group
from ..afo_zone_definitions import get_afo_zone_meta

AFO_BASELINE_KEY = "parafly_afo_original_positions"   # mesh attribute name
_BASELINE_REV_KEY = "parafly_afo_baseline_rev"        # small int ID-prop, cache token

ZONE_PREVIEW_DEBOUNCE_SECONDS = 0.08

_baseline_cache = {}       # key -> np (N,3) float64
_normals_cache = {}        # key -> np (N,3) float64 (baseline surface normals)
_zone_weights_cache = {}   # key + (vg_index,) -> (idx, weights)


def _baseline_key(obj):
    mesh = obj.data
    return (mesh.as_pointer(), len(mesh.vertices), int(obj.get(_BASELINE_REV_KEY, 0)))


def _clear_afo_baseline_caches():
    _baseline_cache.clear()
    _normals_cache.clear()
    _zone_weights_cache.clear()


def store_afo_original_positions(obj):
    """Snapshot obj's current local vertex positions as the deformation
    baseline, in a mesh FLOAT_VECTOR attribute (NOT a JSON ID-property - see the
    module docstring's performance note). Idempotent call sites guard with
    has_afo_baseline() so whichever runs first wins and the second is a no-op."""
    mesh = obj.data
    n = len(mesh.vertices)

    # Drop any legacy JSON ID-property baseline left by an older build / project
    # so it stops bloating this object's undo snapshots.
    if AFO_BASELINE_KEY in obj:
        del obj[AFO_BASELINE_KEY]

    attr = mesh.attributes.get(AFO_BASELINE_KEY)
    if attr is not None and (attr.domain != 'POINT' or attr.data_type != 'FLOAT_VECTOR'):
        mesh.attributes.remove(attr)
        attr = None
    if attr is None:
        attr = mesh.attributes.new(AFO_BASELINE_KEY, 'FLOAT_VECTOR', 'POINT')

    if np is not None:
        co = np.empty(n * 3, dtype=np.float32)
        mesh.vertices.foreach_get("co", co)
        attr.data.foreach_set("vector", co)
    else:
        for item, v in zip(attr.data, mesh.vertices):
            item.vector = v.co

    _clear_afo_baseline_caches()
    obj[_BASELINE_REV_KEY] = int(obj.get(_BASELINE_REV_KEY, 0)) + 1

    # At store time the mesh IS at the baseline, so its current vertex normals
    # ARE the baseline normals. Cache them now (cheap) so the first zone-slider
    # move doesn't pay a full bmesh normal rebuild (~2.5s on a 240k scan).
    if np is not None:
        try:
            nrm = np.empty(n * 3, dtype=np.float32)
            mesh.vertex_normals.foreach_get("vector", nrm)
            _normals_cache[_baseline_key(obj)] = nrm.reshape(n, 3).astype(np.float64)
        except Exception:
            pass  # _baseline_normals() rebuilds via bmesh on a cache miss

    print(f"[ParaFly AFO] Stored {n} original positions on '{obj.name}'")


def has_afo_baseline(obj):
    return (obj is not None and obj.type == 'MESH'
            and obj.data.attributes.get(AFO_BASELINE_KEY) is not None)


def get_afo_baseline(obj):
    """Return the baseline as an (N,3) float64 numpy array (cached), or None."""
    if np is None:
        return None
    mesh = obj.data
    n = len(mesh.vertices)
    key = _baseline_key(obj)
    cached = _baseline_cache.get(key)
    if cached is not None and len(cached) == n:
        return cached
    attr = mesh.attributes.get(AFO_BASELINE_KEY)
    if attr is None:
        return None
    flat = np.empty(n * 3, dtype=np.float32)
    attr.data.foreach_get("vector", flat)
    arr = flat.reshape(n, 3).astype(np.float64)
    _baseline_cache.clear()
    _baseline_cache[key] = arr
    return arr


def get_afo_baseline_vectors(obj):
    """Return the baseline as a tuple of Vectors (cached via get_afo_baseline),
    for callers working in mathutils (afo_correction.py)."""
    attr = obj.data.attributes.get(AFO_BASELINE_KEY)
    if attr is None:
        return None
    arr = get_afo_baseline(obj)
    if arr is not None:
        return tuple(Vector(row) for row in arr)
    return tuple(Vector(item.vector) for item in attr.data)


def transform_afo_baseline(obj, matrix):
    """Rigidly transform the stored deformation baseline by a 4x4 matrix.

    The baseline is a snapshot of LOCAL vertex positions in a mesh attribute
    (see store_afo_original_positions). When the scan is manually re-posed
    (afo_alignment._apply_manual_transform bakes a new world matrix into the
    mesh via transform_apply), Blender does NOT transform this custom attribute
    with it, so the baseline is left in the OLD frame. Angular Correction and
    the zone engine both always recompute from the baseline, so without this
    they snap the scan straight back to its pre-nudge pose - the exact "my
    manual adjustment didn't save" bug. Applying the SAME bake matrix here keeps
    the baseline, the live mesh and the anatomical axes all in one frame.

    `matrix` is the object's new world matrix, i.e. the one transform_apply
    bakes (new_local = matrix @ old_local), so baseline' = matrix @ baseline.
    """
    if not has_afo_baseline(obj):
        return
    attr = obj.data.attributes.get(AFO_BASELINE_KEY)
    if attr is None:
        return

    if np is not None:
        arr = get_afo_baseline(obj)
        if arr is None:
            return
        m = np.array([list(row) for row in matrix], dtype=np.float64)  # 4x4
        rot = m[:3, :3]
        trans = m[:3, 3]
        new = arr @ rot.T + trans
        attr.data.foreach_set("vector", new.astype(np.float32).ravel())
    else:
        for item in attr.data:
            item.vector = (matrix @ Vector(item.vector)).to_3d()

    _clear_afo_baseline_caches()
    obj[_BASELINE_REV_KEY] = int(obj.get(_BASELINE_REV_KEY, 0)) + 1


def _baseline_normals(obj):
    """Per-vertex normals of the BASELINE geometry (cached). The zone push
    direction must come from the original surface, not the already-deformed
    current mesh, so this is computed from the baseline once per baseline."""
    key = _baseline_key(obj)
    cached = _normals_cache.get(key)
    if cached is not None:
        return cached
    baseline = get_afo_baseline(obj)
    if baseline is None:
        return None
    mesh = obj.data
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()
        for i, v in enumerate(bm.verts):
            v.co = Vector(baseline[i])
        bm.normal_update()
        normals = np.array([tuple(v.normal) for v in bm.verts], dtype=np.float64)
    finally:
        bm.free()
    _normals_cache.clear()
    _normals_cache[key] = normals
    return normals


def _afo_zone_weights(mesh, vg_index):
    weights = {}
    for v in mesh.vertices:
        for g in v.groups:
            if g.group == vg_index:
                weights[v.index] = g.weight
                break
    return weights


def _zone_weight_arrays(obj, vg_index):
    """(indices, weights) numpy arrays for a zone vertex group, cached - the
    painted weights don't change during Clinical Adjustment."""
    key = _baseline_key(obj) + (vg_index,)
    cached = _zone_weights_cache.get(key)
    if cached is not None:
        return cached
    weights = _afo_zone_weights(obj.data, vg_index)
    idx = np.fromiter(weights.keys(), dtype=np.int64, count=len(weights))
    wt = np.fromiter(weights.values(), dtype=np.float64, count=len(weights))
    result = (idx, wt)
    _zone_weights_cache[key] = result
    return result


def apply_afo_zone_deformation(context, zone_id=None):
    """Recompute the WHOLE mesh from the cached baseline, applying every AFO
    zone's current slider value (zone_id accepted for API parity with each
    slider's update callback - a partial per-zone update is unsafe, see
    slider_engine.py). Numpy-vectorised; the baseline, its normals and each
    zone's weights are all cached, so this stays fast when called repeatedly."""
    obj = context.scene.paraforge_active_object
    if obj is None or obj.type != 'MESH' or not has_afo_baseline(obj):
        return

    mesh = obj.data
    n = len(mesh.vertices)

    if np is None:
        _apply_afo_zone_deformation_slow(context, obj)
        return

    baseline = get_afo_baseline(obj)
    normals = _baseline_normals(obj)
    if baseline is None or normals is None or len(baseline) != n:
        return  # topology changed since the baseline was stored

    out = baseline.copy()
    for zid in get_afo_zone_names():
        vg = find_afo_vertex_group(obj, zid)
        if vg is None:
            continue
        slider_value = getattr(context.scene, f"parafly_afo_slider_{zid}", 0.0)
        if slider_value == 0.0:
            continue
        idx, weights = _zone_weight_arrays(obj, vg.index)
        if idx.size == 0:
            continue
        avg = normals[idx].sum(axis=0)
        length = float(np.linalg.norm(avg))
        if length == 0.0:
            continue
        avg = avg / length
        meta = get_afo_zone_meta(zid)
        # Inward zones push against the average normal (into the limb);
        # outward/boundary zones push along it (away from the limb).
        move = -avg if meta.get("direction", "inward") == "inward" else avg
        out[idx] += move[None, :] * (slider_value * weights)[:, None]

    mesh.vertices.foreach_set("co", out.astype(np.float32).ravel())
    mesh.update()


def _apply_afo_zone_deformation_slow(context, obj):
    """NumPy-free fallback (Blender normally bundles NumPy; this rarely runs)."""
    vectors = get_afo_baseline_vectors(obj)
    mesh = obj.data
    if vectors is None or len(vectors) != len(mesh.vertices):
        return
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()
        for i, v in enumerate(bm.verts):
            v.co = vectors[i]
        bm.normal_update()
        normals = [v.normal.copy() for v in bm.verts]
        for zid in get_afo_zone_names():
            vg = find_afo_vertex_group(obj, zid)
            if vg is None:
                continue
            slider_value = getattr(context.scene, f"parafly_afo_slider_{zid}", 0.0)
            if slider_value == 0.0:
                continue
            weights = _afo_zone_weights(mesh, vg.index)
            if not weights:
                continue
            avg = sum((normals[i] for i in weights), Vector())
            if avg.length_squared == 0.0:
                continue
            avg = avg.normalized()
            meta = get_afo_zone_meta(zid)
            move = -avg if meta.get("direction", "inward") == "inward" else avg
            for i, w in weights.items():
                bm.verts[i].co += move * (slider_value * w)
        bm.to_mesh(mesh)
    finally:
        bm.free()
    mesh.update()


# ── Debounced live preview ────────────────────────────────────────────────
# Collapse a burst of slider updates into one full-mesh recompute, exactly like
# afo_correction._schedule_afo_corrections.

def _flush_afo_zone_deformation():
    apply_afo_zone_deformation(bpy.context)
    return None


def _cancel_pending_afo_zone_deformation():
    if bpy.app.timers.is_registered(_flush_afo_zone_deformation):
        bpy.app.timers.unregister(_flush_afo_zone_deformation)


def _schedule_afo_zone_deformation(context):
    _cancel_pending_afo_zone_deformation()
    bpy.app.timers.register(
        _flush_afo_zone_deformation,
        first_interval=ZONE_PREVIEW_DEBOUNCE_SECONDS,
    )


def _afo_slider_prop_name(zone_id):
    return f"parafly_afo_slider_{zone_id}"


def _make_afo_update_callback(zone_id):
    """Fresh 2-arg closure per zone - see slider_engine._make_update_callback
    for why (Blender's update-callback signature check, and the per-loop
    closure-capture bug if one lambda were reused across zones). Debounced so a
    slider drag runs one recompute on release, not one per tick."""
    def _update(self, context):
        _schedule_afo_zone_deformation(context)
    return _update


def register_afo_slider_properties():
    unregister_afo_slider_properties()
    for zone_id in get_afo_zone_names():
        meta = get_afo_zone_meta(zone_id)
        attr = _afo_slider_prop_name(zone_id)
        setattr(bpy.types.Scene, attr, bpy.props.FloatProperty(
            name=meta["display_name"],
            description=meta["description"],
            soft_min=meta["minimum"],
            soft_max=meta["maximum"],
            default=meta["default"],
            precision=1,
            subtype='DISTANCE',
            unit='LENGTH',
            update=_make_afo_update_callback(zone_id),
        ))


def unregister_afo_slider_properties():
    for zone_id in get_afo_zone_names():
        attr = _afo_slider_prop_name(zone_id)
        if hasattr(bpy.types.Scene, attr):
            try:
                delattr(bpy.types.Scene, attr)
            except Exception:
                pass


class PARAFORGE_OT_afo_reset_zone(bpy.types.Operator):
    """Reset this AFO zone's slider to 0"""
    bl_idname = "paraforge.afo_reset_zone"
    bl_label = "Reset Zone"
    bl_options = {'REGISTER', 'UNDO'}
    zone_id: bpy.props.StringProperty()

    def execute(self, context):
        prop_name = _afo_slider_prop_name(self.zone_id)
        if not hasattr(context.scene, prop_name):
            self.report({'ERROR'}, "Slider properties aren't registered yet — try again in a moment")
            return {'CANCELLED'}
        setattr(context.scene, prop_name, 0.0)
        # Apply immediately so Reset feels instant rather than debounce-delayed.
        _cancel_pending_afo_zone_deformation()
        apply_afo_zone_deformation(context)
        return {'FINISHED'}


class PARAFORGE_OT_afo_reset_all(bpy.types.Operator):
    """Reset every AFO zone's slider to 0"""
    bl_idname = "paraforge.afo_reset_all"
    bl_label = "Reset All Zones"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for zone_id in get_afo_zone_names():
            prop_name = _afo_slider_prop_name(zone_id)
            if hasattr(context.scene, prop_name):
                setattr(context.scene, prop_name, 0.0)
        _cancel_pending_afo_zone_deformation()
        apply_afo_zone_deformation(context)
        return {'FINISHED'}
