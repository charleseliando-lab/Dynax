# paraforge/operators/afo_alignment.py - Auto-alignment stage for AFO: rotates
# the scan to a standard pose (heel at world origin, toes toward -Y, sole flat
# on Z=0) using the 6 landmarks placed in afo_landmarks.py.
#
# Real correctness issue found and fixed vs. SPEC_parafly_afo_complete.md
# Section 7, not just a naming/property fix: the spec's own auto-align does
# two SEQUENTIAL ad-hoc rotations (first "rotate so toes point toward -Y"
# using a signed angle-between + cross.z sign check, then "rotate so sole is
# flat" using an atan2 derived from the ALREADY-rotated forefoot midpoint) and
# has one genuinely dead variable (`flat_target = Vector((0,0,0))`, computed,
# never read by anything). Two sequential partial rotations like this are
# easy to get subtly wrong (each one only nails ONE constraint and can perturb
# the other), and the dead variable is a real signal the derivation was never
# fully worked through.
#
# Replaced with a single rotation built directly from an orthonormal basis
# derived from the landmarks, verified independently rather than trusted:
#
#   up      = normalized normal of the sole plane (heel, mt1, mt5 - all three
#             touch the ground on a flat foot), sign-corrected to point toward
#             the ankle/leg (so the leg goes "up" away from the sole)
#   forward = (forefoot_mid - heel) with its "up" component removed, so it's
#             exactly horizontal once "up" is exactly vertical (guarantees the
#             sole-flat constraint and the toes-direction constraint can't
#             fight each other, unlike two independent sequential rotations)
#   right   = forward x up (the only remaining orthonormal choice - fully
#             determined, no leftover ambiguity)
#
# Mapping this source basis (right, forward, up) onto the target basis
# ((-1,0,0), (0,-1,0), (0,0,1)) - so toes point -Y and the sole normal points
# +Z - gives one rotation matrix R = target_basis @ source_basis.transposed()
# (valid since an orthonormal matrix's inverse is its transpose), applied once
# as new_p = R @ (p_world - heel_world) for every landmark AND baked into the
# mesh via a single obj.matrix_world reassignment + transform_apply. Verified
# headlessly against a synthetic, arbitrarily rotated/translated 6-point
# landmark set before wiring into this operator (heel -> origin, mt1/mt5/heel
# all land at Z ~ 0, forefoot direction ~ (0,-1,0)).

import bpy
import json
import math
from mathutils import Vector, Matrix

from .afo_landmarks import normalize_landmarks


def _get_landmarks(scene):
    try:
        return normalize_landmarks(json.loads(scene.parafly_afo_landmarks))
    except Exception:
        return {}


def _rebuild_axes_and_markers(scene, new_lm):
    """Recompute the anatomical `_axes` dict from a landmark dict (world coords),
    persist it in scene.parafly_afo_landmarks, and move the on-screen landmark
    markers to match.

    Angular Correction (afo_correction.py) reads `_axes` for every rotation
    pivot/axis, so ANY operation that re-poses the scan — auto-align OR the
    manual nudges below — must call this afterwards, or correction silently
    does nothing (empty axes -> early return).
    """
    heel_new = Vector(new_lm["heel"])
    mt1_new = Vector(new_lm["mt1"])
    mt5_new = Vector(new_lm["mt5"])
    lat_mal_new = Vector(new_lm["lat_mal"])
    med_mal_new = Vector(new_lm["med_mal"])
    calf_new = Vector(new_lm["calf"])

    mt_mid_new = (mt1_new + mt5_new) / 2.0
    ankle_mid_new = (lat_mal_new + med_mal_new) / 2.0
    ankle_axis_new = (lat_mal_new - med_mal_new).normalized()
    shank_axis_new = (calf_new - ankle_mid_new).normalized()
    foot_axis_new = (mt_mid_new - heel_new).normalized()

    new_lm = dict(new_lm)
    new_lm["_axes"] = {
        "ankle_mid": list(ankle_mid_new),
        "ankle_axis": list(ankle_axis_new),
        "shank_axis": list(shank_axis_new),
        "foot_axis": list(foot_axis_new),
        "heel": list(heel_new),
        "mt_mid": list(mt_mid_new),
    }
    scene.parafly_afo_landmarks = json.dumps(new_lm)

    from .afo_landmarks import LANDMARK_SEQUENCE
    scan = scene.paraforge_active_object
    for ldef in LANDMARK_SEQUENCE:
        marker = bpy.data.objects.get(f"afo_lm_{ldef['id']}")
        if marker is not None and ldef["id"] in new_lm:
            _attach_marker_to_scan(marker, scan, Vector(new_lm[ldef["id"]]))
    return new_lm


def _attach_marker_to_scan(marker, scan, world_pos):
    """Place a landmark marker at world_pos and (re)parent it to the scan so it
    follows the mesh. Re-derives matrix_parent_inverse from the scan's CURRENT
    transform, so this stays correct even right after a transform_apply baked the
    scan back to an identity matrix (the marker's old parent-inverse would
    otherwise leave it jumped)."""
    if scan is not None and scan is not marker:
        marker.parent = scan
        marker.matrix_parent_inverse = scan.matrix_world.inverted()
    marker.matrix_world = Matrix.Translation(world_pos)


def _bake_object_world(context, obj, new_world):
    """Assign a new world matrix to obj and bake it into the mesh (local == world
    afterwards), matching this addon's established alignment pattern."""
    obj.matrix_world = new_world
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    context.view_layer.objects.active = obj
    if context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)


def compute_afo_alignment_rotation(heel, mt1, mt5, lat_mal, med_mal, calf):
    """
    Pure function (no bpy/context dependency) so this can be verified
    directly against a synthetic landmark set. Returns (R, forefoot_mid) where
    R is a 3x3 mathutils.Matrix such that new_p = R @ (p - heel) puts heel at
    the origin, the sole flat on Z=0, and the forefoot direction toward -Y.
    Raises ValueError if the landmarks are too degenerate to derive a stable
    basis from (e.g. all three sole points collinear/coincident).
    """
    forefoot_mid = (mt1 + mt5) / 2.0
    ankle_mid = (lat_mal + med_mal) / 2.0

    up_raw = (mt1 - heel).cross(mt5 - heel)
    if up_raw.length_squared < 1e-9:
        raise ValueError("MT1, MT5, and Heel are collinear or coincident - cannot derive a sole plane.")
    if up_raw.dot(ankle_mid - heel) < 0:
        up_raw = -up_raw
    up = up_raw.normalized()

    forward_raw = forefoot_mid - heel
    forward_raw = forward_raw - forward_raw.dot(up) * up
    if forward_raw.length_squared < 1e-9:
        raise ValueError("Forefoot midpoint is directly above/below the heel - cannot derive a forward direction.")
    forward = forward_raw.normalized()

    right = forward.cross(up)
    if right.length_squared < 1e-9:
        raise ValueError("Forward and up directions are parallel - cannot derive a stable basis.")
    right = right.normalized()
    # Re-orthogonalize up from the final right/forward pair (guards against
    # tiny floating-point drift from the two normalize() calls above).
    up = right.cross(forward).normalized()

    source_basis = Matrix((right, forward, up)).transposed()

    target_right = Vector((-1.0, 0.0, 0.0))
    target_forward = Vector((0.0, -1.0, 0.0))
    target_up = Vector((0.0, 0.0, 1.0))
    target_basis = Matrix((target_right, target_forward, target_up)).transposed()

    rotation = target_basis @ source_basis.transposed()
    return rotation, forefoot_mid


class PARAFORGE_OT_afo_auto_align(bpy.types.Operator):
    """
    Align the AFO scan to standard anatomical pose using placed landmarks.

    Standard pose:
    - Heel at world origin (0, 0, 0)
    - Toes pointing toward -Y (anterior = -Y)
    - Sole flat on Z=0 plane
    """
    bl_idname = "paraforge.afo_auto_align"
    bl_label = "Align Scan to Standard Pose"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        obj = scene.paraforge_active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "No AFO scan is loaded")
            return {'CANCELLED'}

        lm = _get_landmarks(scene)
        required = ["mt1", "mt5", "lat_mal", "med_mal", "calf", "heel"]
        missing = [r for r in required if r not in lm]
        if missing:
            self.report(
                {'ERROR'},
                f"Missing landmarks: {', '.join(missing)}. Place all 6 first."
            )
            return {'CANCELLED'}

        heel = Vector(lm["heel"])
        mt1 = Vector(lm["mt1"])
        mt5 = Vector(lm["mt5"])
        lat_mal = Vector(lm["lat_mal"])
        med_mal = Vector(lm["med_mal"])
        calf = Vector(lm["calf"])

        try:
            rotation, _ = compute_afo_alignment_rotation(heel, mt1, mt5, lat_mal, med_mal, calf)
        except ValueError as e:
            self.report({'ERROR'}, f"Could not align: {e}")
            return {'CANCELLED'}

        rotation_4x4 = rotation.to_4x4()

        # Apply the single combined rotation-about-heel to the object's world
        # matrix, then bake it into the mesh so local space == world space
        # afterward (matches this addon's established alignment pattern -
        # tlso_alignment.py's Apply Alignment also bakes via transform_apply).
        new_world = Matrix.Translation(-(rotation_4x4 @ heel)) @ rotation_4x4 @ obj.matrix_world
        _bake_object_world(context, obj, new_world)

        def _transform(p):
            return rotation @ (p - heel)

        new_lm = {
            "heel": [0.0, 0.0, 0.0],
            "mt1": list(_transform(mt1)),
            "mt5": list(_transform(mt5)),
            "lat_mal": list(_transform(lat_mal)),
            "med_mal": list(_transform(med_mal)),
            "calf": list(_transform(calf)),
        }
        _rebuild_axes_and_markers(scene, new_lm)

        scene.parafly_afo_stage = 'CORRECTION'
        self.report({'INFO'}, "Scan aligned to standard pose.")
        return {'FINISHED'}


# ── Manual pose adjustment ────────────────────────────────────────────
# Auto-align derives the pose purely from the 6 landmarks; on a noisy scan
# (or an unusual deformity) the clinician may still want to nudge the result
# by hand. These operators re-pose the baked mesh AND transform the stored
# landmarks so the anatomical axes (and therefore Angular Correction) stay
# consistent with what's on screen.

_AXIS_VECTORS = {'X': (1.0, 0.0, 0.0), 'Y': (0.0, 1.0, 0.0), 'Z': (0.0, 0.0, 1.0)}


def _apply_manual_transform(context, scene, obj, rotation=None, translation=None,
                            pivot=None):
    """Apply an optional rotation (3x3, about pivot) and/or translation to the
    scan, baking it into the mesh, then re-derive landmarks + axes so the
    correction stage keeps working. Landmarks are stored in the aligned world
    frame, so they get the same transform."""
    lm = _get_landmarks(scene)
    world = obj.matrix_world
    if pivot is None:
        pivot = Vector(lm["heel"]) if "heel" in lm else Vector((0.0, 0.0, 0.0))

    if rotation is not None:
        rot4 = rotation.to_4x4()
        world = Matrix.Translation(pivot - (rotation @ pivot)) @ rot4 @ world
    if translation is not None:
        world = Matrix.Translation(translation) @ world

    _bake_object_world(context, obj, world)

    # transform_apply above baked `world` into the mesh but leaves the stored
    # correction/zone baseline (a custom mesh attribute) in the old frame. Both
    # Angular Correction and the zone engine ALWAYS recompute from that baseline,
    # so it must ride the same transform or the next slider move snaps the scan
    # back to its pre-nudge pose.
    from .afo_slider_engine import has_afo_baseline, transform_afo_baseline
    if has_afo_baseline(obj):
        transform_afo_baseline(obj, world)

    def _pt(p):
        v = Vector(p)
        if rotation is not None:
            v = pivot + (rotation @ (v - pivot))
        if translation is not None:
            v = v + translation
        return list(v)

    new_lm = {k: _pt(v) for k, v in lm.items() if k != "_axes"}
    _rebuild_axes_and_markers(scene, new_lm)


class PARAFORGE_OT_afo_manual_nudge(bpy.types.Operator):
    """Rotate the scan by a fixed step about a world axis (through the heel),
    then re-derive the anatomical axes so correction stays in sync."""
    bl_idname = "paraforge.afo_manual_nudge"
    bl_label = "Nudge Alignment"
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.EnumProperty(
        items=[('X', 'X', ''), ('Y', 'Y', ''), ('Z', 'Z', '')],
        default='X',
    )
    direction: bpy.props.FloatProperty(default=1.0)

    def execute(self, context):
        scene = context.scene
        obj = scene.paraforge_active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "No AFO scan is loaded")
            return {'CANCELLED'}
        lm = _get_landmarks(scene)
        if "heel" not in lm:
            self.report({'ERROR'}, "Place the landmarks first")
            return {'CANCELLED'}

        step = getattr(scene, "parafly_afo_manual_rotate_step", 2.0)
        angle = math.radians(step * (1.0 if self.direction >= 0 else -1.0))
        rotation = Matrix.Rotation(angle, 3, Vector(_AXIS_VECTORS[self.axis]))
        _apply_manual_transform(context, scene, obj, rotation=rotation)
        self.report({'INFO'}, f"Rotated {step:.1f}° about {self.axis}")
        return {'FINISHED'}


class PARAFORGE_OT_afo_snap_heel_origin(bpy.types.Operator):
    """Translate the scan so the heel landmark sits exactly at the world origin
    (keeps orientation; only shifts position)."""
    bl_idname = "paraforge.afo_snap_heel_origin"
    bl_label = "Snap Heel to Origin"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        obj = scene.paraforge_active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "No AFO scan is loaded")
            return {'CANCELLED'}
        lm = _get_landmarks(scene)
        if "heel" not in lm:
            self.report({'ERROR'}, "Place the landmarks first")
            return {'CANCELLED'}
        translation = -Vector(lm["heel"])
        _apply_manual_transform(context, scene, obj, translation=translation)
        self.report({'INFO'}, "Heel snapped to origin")
        return {'FINISHED'}


class PARAFORGE_OT_afo_ui_set_stage(bpy.types.Operator):
    """Expand one AFO workflow stage in the accordion panel, collapsing the
    others. Clicking the already-open stage collapses it."""
    bl_idname = "paraforge.afo_ui_set_stage"
    bl_label = "Expand Stage"
    bl_options = {'INTERNAL'}

    stage: bpy.props.StringProperty()

    def execute(self, context):
        cur = context.scene.parafly_afo_ui_stage
        context.scene.parafly_afo_ui_stage = "" if cur == self.stage else self.stage
        return {'FINISHED'}


class PARAFORGE_OT_afo_drop_sole_flat(bpy.types.Operator):
    """Re-level the sole plane (heel/MT1/MT5) flat on Z=0 without touching the
    toe direction — a targeted manual fix for a scan that reads slightly tilted
    after auto-align."""
    bl_idname = "paraforge.afo_drop_sole_flat"
    bl_label = "Drop Sole Flat"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        obj = scene.paraforge_active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "No AFO scan is loaded")
            return {'CANCELLED'}
        lm = _get_landmarks(scene)
        needed = ("heel", "mt1", "mt5")
        if not all(k in lm for k in needed):
            self.report({'ERROR'}, "Place the landmarks first")
            return {'CANCELLED'}

        heel = Vector(lm["heel"])
        up = (Vector(lm["mt1"]) - heel).cross(Vector(lm["mt5"]) - heel)
        if up.length_squared < 1e-9:
            self.report({'ERROR'}, "Sole landmarks are collinear — can't level")
            return {'CANCELLED'}
        up.normalize()
        ankle_mid = (Vector(lm.get("lat_mal", heel)) + Vector(lm.get("med_mal", heel))) / 2.0
        if up.dot(ankle_mid - heel) < 0:
            up = -up
        target = Vector((0.0, 0.0, 1.0))
        rotation = up.rotation_difference(target).to_matrix()
        _apply_manual_transform(context, scene, obj, rotation=rotation, pivot=heel)
        self.report({'INFO'}, "Sole leveled to Z=0")
        return {'FINISHED'}
