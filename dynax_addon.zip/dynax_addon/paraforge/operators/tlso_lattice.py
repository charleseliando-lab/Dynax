# paraforge/operators/tlso_lattice.py - ParaFly TLSO "Spine Curve Adjustment"
# stage: a Lattice-modifier overlay letting the clinician bend the TLSO to
# follow the patient's real spinal curve, labelled with anatomical levels.
#
# Path note: the ParaMold spec's Workstream C sketch named this file
# `operators/parafly_tlso/tlso_lattice.py`, but no such folder exists in this
# add-on - the existing TLSO operators (tlso_alignment.py, tlso_mapping_
# wizard.py, tlso_slider_engine.py) all live in paraforge/operators/ with
# `paraforge.*` bl_idnames (see CLAUDE.md's "naming trap" section). Placed
# here instead, following that same convention, so this device's operators
# stay in one place.

import bpy
from mathutils import Vector

LEVEL_NAMES = ["T8", "T10", "T12", "L1", "L3", "L5", "S1", "Pelvis"]


class PARAFORGE_OT_tlso_lattice_create(bpy.types.Operator):
    """Overlay an anatomically labelled lattice for spine curve adjustment"""
    bl_idname = "dynax.tlso_lattice_create"
    bl_label = "Add Spine Curve Lattice"
    bl_description = (
        "Overlay an anatomically labelled lattice for spine curve adjustment"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select the TLSO mesh first")
            return {'CANCELLED'}

        # 1. TLSO bounding box (world space, + 10mm padding on every side).
        corners = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
        min_x = min(c.x for c in corners) - 10.0
        max_x = max(c.x for c in corners) + 10.0
        min_y = min(c.y for c in corners) - 10.0
        max_y = max(c.y for c in corners) + 10.0
        min_z = min(c.z for c in corners) - 10.0
        max_z = max(c.z for c in corners) + 10.0
        centre = Vector((
            (min_x + max_x) / 2.0, (min_y + max_y) / 2.0, (min_z + max_z) / 2.0,
        ))

        # 2. Create the lattice object covering the TLSO bounds.
        # A freshly-added LATTICE's own points span exactly -0.5..0.5 in
        # local space (verified headless: co_deform range is -0.5..0.5 on
        # every axis, NOT -1..1) - so the object's scale must equal the
        # FULL world-space extent, not half of it. The previous half-extent
        # scale made the lattice exactly half the required size, so it sat
        # INSIDE the TLSO mesh instead of enclosing it - the root cause of
        # "the lattice doesn't actually work."
        bpy.ops.object.add(type='LATTICE', location=centre)
        lattice_obj = context.active_object
        lattice_obj.name = "DynaX_SpineLattice"
        lattice_obj.scale = (
            (max_x - min_x), (max_y - min_y), (max_z - min_z),
        )

        # 3. Lattice resolution: 2 (width) x 2 (depth) x 8 (spinal levels).
        # Clinical-testing fix: Blender's lattice point ordering is
        # index = w*(points_u*points_v) + v*points_u + u, i.e. `u` maps to
        # the object's local X axis, `v` to local Y, and `w` to local Z -
        # verified headless (co_deform component 2, the Z one, only changes
        # every points_u*points_v points, matching `w`). The previous code
        # put the 8 spinal levels on `points_v` under the assumption that
        # `v` was the height axis; it isn't - that distributed the 8 levels
        # across the TLSO's shallow front-back DEPTH instead of its actual
        # superior-inferior HEIGHT, so a "spinal level" never corresponded
        # to a real horizontal row of lattice points at all (only 2 height
        # divisions existed). Levels now correctly live on `points_w`,
        # giving exactly 4 points per level (u=0,1 x v=0,1) forming a real
        # horizontal ring - verified headless (32 points still total, each
        # consecutive group of 4 sharing one world Z).
        lattice = lattice_obj.data
        lattice.points_u = 2
        lattice.points_v = 2
        lattice.points_w = 8

        # 5. Add a Lattice modifier to the TLSO mesh.
        mod = obj.modifiers.new(name="SpineCurve", type='LATTICE')
        mod.object = lattice_obj

        # 6. Select the lattice for editing.
        bpy.ops.object.select_all(action='DESELECT')
        lattice_obj.select_set(True)
        context.view_layer.objects.active = lattice_obj

        # 7. Mark active.
        context.scene.dynax_tlso_lattice_active = True

        # Anatomical level labels as empty objects at each lattice row.
        # Row 0 = top (max Z) -> T8 ... Row 7 = bottom (min Z) -> Pelvis.
        front_y = max_y
        for row, level in enumerate(LEVEL_NAMES):
            frac = row / (len(LEVEL_NAMES) - 1)
            z = max_z - frac * (max_z - min_z)
            bpy.ops.object.add(type='EMPTY', location=(0.0, front_y, z))
            empty = context.active_object
            empty.name = f"DynaX_Level_{level}"
            empty.empty_display_size = 5.0
            empty.empty_display_type = 'PLAIN_AXES'

        bpy.ops.object.select_all(action='DESELECT')
        lattice_obj.select_set(True)
        context.view_layer.objects.active = lattice_obj

        self.report(
            {'INFO'},
            "Spine lattice added. Enter Edit Mode on the lattice to move "
            "control points. Anatomical levels are labelled.",
        )
        return {'FINISHED'}


class DynaxTLSOSelectLevel(bpy.types.Operator):
    """Select every lattice control point at one anatomical level (a full
    horizontal ring), so the clinician can move the whole level at once"""
    bl_idname = "dynax.tlso_select_level"
    bl_label = "Select Level"
    bl_options = {'REGISTER', 'UNDO'}

    level: bpy.props.IntProperty(
        name="Level index", default=0, min=0, max=7,
    )

    def execute(self, context):
        lattice_obj = bpy.data.objects.get("DynaX_SpineLattice")
        if not lattice_obj:
            self.report({'ERROR'}, "No spine lattice found")
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        context.view_layer.objects.active = lattice_obj
        bpy.ops.object.select_all(action='DESELECT')
        lattice_obj.select_set(True)

        total_u = lattice_obj.data.points_u
        total_v = lattice_obj.data.points_v
        total_w = lattice_obj.data.points_w
        points_per_level = total_u * total_v

        # LEVEL_NAMES is ordered top-to-bottom (T8=level 0 ... Pelvis=level
        # 7), but Blender's own w-index counts bottom-to-top (w=0 is the
        # lattice's local -Z / world min-Z end - verified headless) - so
        # the requested anatomical level must be inverted to the matching
        # w-index.
        target_w = (total_w - 1) - self.level

        for i, point in enumerate(lattice_obj.data.points):
            w_idx = i // points_per_level
            point.select = (w_idx == target_w)

        bpy.ops.object.mode_set(mode='EDIT')
        level_name = LEVEL_NAMES[self.level] if self.level < len(LEVEL_NAMES) else str(self.level)
        self.report({'INFO'}, f"Selected {level_name} ({points_per_level} points)")
        return {'FINISHED'}


class PARAFORGE_OT_tlso_lattice_apply(bpy.types.Operator):
    """Bake the lattice deformation into the TLSO mesh and remove the lattice"""
    bl_idname = "dynax.tlso_lattice_apply"
    bl_label = "Apply Spine Curve"
    bl_description = (
        "Bake the lattice deformation into the TLSO mesh and remove the lattice"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or obj.modifiers.get("SpineCurve") is None:
            self.report({'ERROR'}, "No active spine lattice on the selected TLSO mesh")
            return {'CANCELLED'}

        # 1. Apply the Lattice modifier.
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        try:
            bpy.ops.object.modifier_apply(modifier="SpineCurve")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to apply spine curve: {e}")
            return {'CANCELLED'}

        # 2. Delete the lattice object.
        lattice_obj = bpy.data.objects.get("DynaX_SpineLattice")
        if lattice_obj is not None:
            bpy.data.objects.remove(lattice_obj, do_unlink=True)

        # 3. Delete all level-marker empties.
        for level in LEVEL_NAMES:
            empty = bpy.data.objects.get(f"DynaX_Level_{level}")
            if empty is not None:
                bpy.data.objects.remove(empty, do_unlink=True)

        # 4. Clear the active flag.
        context.scene.dynax_tlso_lattice_active = False

        self.report(
            {'INFO'},
            "Spine curve applied to TLSO mesh. Continue with trimline and export.",
        )
        return {'FINISHED'}


class PARAFORGE_OT_tlso_lattice_reset(bpy.types.Operator):
    """Reset all control points to flat (no deformation)"""
    bl_idname = "dynax.tlso_lattice_reset"
    bl_label = "Reset Lattice"
    bl_description = "Reset all control points to flat (no deformation)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        lattice_obj = bpy.data.objects.get("DynaX_SpineLattice")
        if lattice_obj is None or lattice_obj.type != 'LATTICE':
            self.report({'ERROR'}, "No active spine lattice found")
            return {'CANCELLED'}

        bpy.ops.object.select_all(action='DESELECT')
        lattice_obj.select_set(True)
        context.view_layer.objects.active = lattice_obj
        prev_mode = context.mode
        if prev_mode != 'EDIT_LATTICE':
            bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.lattice.select_all(action='SELECT')
        bpy.ops.lattice.make_regular()
        bpy.ops.object.mode_set(mode='OBJECT')

        self.report({'INFO'}, "Spine lattice reset to flat")
        return {'FINISHED'}
