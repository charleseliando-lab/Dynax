# paraforge/operators/import_scan.py - Input stage: import + export wrappers.
#
# Both wrap Creator's own operators directly (dynax.import_stl / dynax.export_stl)
# rather than duplicating their logic — this file only adds the ParaForge-specific
# bookkeeping (scene.paraforge_active_object / scene.paraforge_stage) around them.
#
# Shared by both ParaFly device workflows (TT and TLSO, scene.parafly_device_type)
# since import/export are identical regardless of device - only which "stage"
# property gets advanced afterward differs (TT goes to Preparation; TLSO goes
# straight to Alignment, since it has no Preparation/Remesh step of its own).

import os
import bpy
from bpy.types import Operator
from bpy.props import StringProperty
from bpy_extras.io_utils import ImportHelper, ExportHelper


class PARAFORGE_OT_import_scan(Operator, ImportHelper):
    """Import an STL scan for ParaForge (reuses Creator's Smart Import)"""
    bl_idname = "paraforge.import_scan"
    bl_label = "Import STL Scan"
    bl_options = {'REGISTER', 'UNDO'}

    filename_ext = ".stl"
    filter_glob: StringProperty(default="*.stl", options={'HIDDEN'})

    def execute(self, context):
        result = bpy.ops.dynax.import_stl('EXEC_DEFAULT', filepath=self.filepath)
        if 'FINISHED' not in result:
            return {'CANCELLED'}

        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Import succeeded but no mesh object is active")
            return {'CANCELLED'}

        context.scene.paraforge_active_object = obj
        # SPEC_parafly_trimline_thickness_borrow_creator.md Section 4: keep
        # Creator's own trimline target (operators/trimline.py's TARGET_KEY)
        # pointed at the freshly-imported object immediately, so ParaFly's
        # Advanced-section Trimline tool (which calls Creator's real
        # dynax.trimline_* operators directly) targets the right mesh even
        # before the Advanced section is ever drawn (panels/paraforge_panel.py's
        # _draw_trimline_section also keeps this in sync on every redraw,
        # this is belt-and-suspenders for the moment right after import).
        context.scene["dynax_trimline_target"] = obj.name

        device_type = getattr(context.scene, "parafly_device_type", 'TT')
        if device_type == 'TLSO':
            context.scene.parafly_tlso_stage = 'ALIGNMENT'
            context.scene.parafly_tlso_mapping_step = 0
        elif device_type == 'AFO':
            # AFO has no Preparation/Remesh step of its own (like TLSO) - it
            # goes straight to guided landmark placement, resetting any
            # landmarks/mapping progress left over from a previous scan.
            context.scene.parafly_afo_stage = 'LANDMARKS'
            context.scene.parafly_afo_mapping_step = 0
            context.scene.parafly_afo_landmarks = "{}"
            context.scene.parafly_afo_current_landmark = ""
        else:
            context.scene.paraforge_stage = 'PREPARATION'
            context.scene.paraforge_mapping_step = 0
        return {'FINISHED'}


class PARAFORGE_OT_export(Operator, ExportHelper):
    """Export the ParaForge object as STL (reuses Creator's exporter)"""
    bl_idname = "paraforge.export"
    bl_label = "Export STL"
    bl_options = {'REGISTER', 'UNDO'}

    # User request: ParaFly's export previously always went straight to the
    # OS Downloads folder with a fixed filename (Creator's own established
    # behavior - see export_stl.py's get_downloads_folder) with no way to
    # choose where/what to name it. ExportHelper gives ParaFly its own file
    # browser (name + folder) without touching Creator's export at all -
    # Creator's own "Export STL" button still behaves exactly as before.
    filename_ext = ".stl"
    filter_glob: StringProperty(default="*.stl", options={'HIDDEN'})

    def invoke(self, context, event):
        obj = context.scene.paraforge_active_object or context.active_object
        self.filepath = (obj.name if obj else "DynaX_Export") + self.filename_ext
        return ExportHelper.invoke(self, context, event)

    def execute(self, context):
        # Real bug found and fixed: scene.paraforge_active_object is a
        # PointerProperty to the ORIGINALLY-imported object. Creator's
        # trimline Separate/Cut tools don't always create a brand new object
        # for every resulting part - Method A's "Separate Selected" keeps
        # the ORIGINAL object alive under a new name (DynaX_Remainder), so
        # paraforge_active_object still resolves fine right after a
        # separate/cut. But once the user deletes whichever part they don't
        # want (Method A's "Remainder" trash button, or just manually) and
        # that happens to be the part paraforge_active_object still points
        # to, the PointerProperty auto-clears to None - even though
        # context.active_object is still correctly the kept part (dynax.
        # pick_part / DynaxSeparateSelected already made sure of that).
        # Falling back to context.active_object here means Export always
        # targets whatever's actually the current working object, matching
        # what Thickness's own dispatch (skip_if_parts_exist) already does.
        obj = context.scene.paraforge_active_object or context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No object to export - select or pick a part first")
            return {'CANCELLED'}
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        # Point Creator's real exporter (operators/export_stl.py) at the
        # folder/filename the user just chose via ExportHelper's browser -
        # dynax_export_path/export_filename are the same two settings its
        # own path-resolution already reads, so this is not a duplicate
        # write path, just supplying different values than the Downloads
        # default.
        folder, filename = os.path.split(self.filepath)
        if filename.lower().endswith(".stl"):
            filename = filename[:-4]
        context.scene.dynax_export_path = folder
        context.scene.dynax_props.export_filename = filename

        return bpy.ops.dynax.export_stl('EXEC_DEFAULT')
