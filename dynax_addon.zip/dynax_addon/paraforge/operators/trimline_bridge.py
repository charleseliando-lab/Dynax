# paraforge/operators/trimline_bridge.py - Safe activation bridge between
# ParaFly's panel and Creator's real Trimline/select-tools operators
# (operators/trimline.py, operators/select_tools.py).
#
# ROOT CAUSE FIX for "Trimline/Thickness/Export all silently vanish": the
# panel previously wrote `scene["dynax_trimline_target"] = obj.name` and set
# `context.view_layer.objects.active` / `obj.select_set(True)` directly
# inside _draw_trimline_section()'s DRAW-TIME code. Verified directly against
# a real (non-headless) GUI session's own error console: Blender raises
# `AttributeError: Writing to ID classes in this context is not allowed`
# the moment a panel's draw() call writes ANY ID data (a scene custom
# property, the active object, a selection state) - this is a real, hard
# Blender restriction that headless mock-layout tests can't catch (they never
# exercise Blender's actual "currently drawing UI" restricted-context flag).
# The exception aborted the rest of _draw_advanced()'s draw() call entirely,
# which is why Thickness and Export (drawn right after Trimline) vanished
# too, not just Trimline's own buttons.
#
# FIX: never write scene/view-layer state from panel draw again. Every
# Trimline entry-point button that depends on `context.active_object` (both
# Creator's spline-cut "Method B" AND its paint-select "Method A") now goes
# through PARAFORGE_OT_trimline_dispatch, which does the activation as part
# of a REAL operator call (execute()/invoke() are not "currently drawing UI",
# so the same writes are explicitly allowed there) and then invokes the real
# Creator operator by bl_idname.

import bpy
from bpy.types import Operator
from bpy.props import StringProperty, BoolProperty

TARGET_KEY = "dynax_trimline_target"  # matches operators/trimline.py's TARGET_KEY


_PART_PREFIXES = ("DynaX_Proximal", "DynaX_Distal", "DynaX_Part_",
                  "DynaX_Selected", "DynaX_Remainder")


def _any_parts_exist():
    return any(o.name.startswith(_PART_PREFIXES) for o in bpy.data.objects)


def activate_paraforge_target(context):
    """Make the ParaFly active object the real Blender active/selected
    object and set Creator's trimline TARGET_KEY, from inside a real
    operator call. Returns the object, or None if nothing is loaded yet."""
    scene = context.scene
    obj = scene.paraforge_active_object
    if obj is None:
        return None
    scene[TARGET_KEY] = obj.name
    if context.view_layer.objects.get(obj.name):
        context.view_layer.objects.active = obj
        obj.select_set(True)
    return obj


class PARAFORGE_OT_trimline_dispatch(Operator):
    """Activate the ParaFly object, then invoke a real Creator trimline/
    select-tools operator by id - the only place that operator ever gets
    called from ParaFly, so the activation can never be skipped."""
    bl_idname = "paraforge.trimline_dispatch"
    bl_label = "Trimline Action"
    bl_options = {'REGISTER', 'UNDO'}

    real_op: StringProperty()
    use_invoke: BoolProperty(default=False)
    # Thickness's Preview/Confirm/Remove buttons must NOT re-activate the
    # original ParaFly object once a trimline cut/separate has produced real
    # parts - dynax.pick_part is the established way to choose which part is
    # active after that point, and re-forcing the pre-cut object here would
    # silently undo the user's Pick Part choice on every redraw.
    skip_if_parts_exist: BoolProperty(default=False)

    def _dispatch(self, context):
        if self.skip_if_parts_exist and _any_parts_exist():
            obj = context.active_object
        else:
            obj = activate_paraforge_target(context)
        if obj is None:
            self.report({'ERROR'}, "Import a scan first")
            return {'CANCELLED'}
        category, name = self.real_op.split(".", 1)
        op = getattr(getattr(bpy.ops, category), name)
        return op('INVOKE_DEFAULT' if self.use_invoke else 'EXEC_DEFAULT')

    def invoke(self, context, event):
        if self.use_invoke:
            return self._dispatch(context)
        return self.execute(context)

    def execute(self, context):
        return self._dispatch(context)
