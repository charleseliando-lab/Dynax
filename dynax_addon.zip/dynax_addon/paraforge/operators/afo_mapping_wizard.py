# paraforge/operators/afo_mapping_wizard.py - Clinical Mapping stage for AFO:
# written in full from tlso_mapping_wizard.py's already-proven pattern
# (SPEC_parafly_afo_complete.md Section 10 only says "reuse the TLSO pattern,
# replace tlso with afo" - no code given).
#
# Carries forward every real fix already proven necessary for this exact
# pattern (see tlso_mapping_wizard.py's own module docstring for the original
# investigation writeups):
#
# 1. Reads the sculpt mask directly (".sculpt_mask" mesh attribute) into a
#    real per-vertex-weighted vertex group, instead of a binary
#    mask_to_selection + vertex_group_assign conversion - preserves the
#    smooth mask gradient the deformation math needs for blended zone edges.
#
# 2. _force_mask_brush uses bpy.ops.brush.asset_activate against Blender's
#    ESSENTIALS brush-asset library (verified directly in a real GUI session
#    - tool_set_by_id's poll() passes while its execute() silently no-ops in
#    this Blender build), activated BEFORE mask_flood_fill (mask_flood_fill's
#    undo-push silently blocks a brush change immediately afterward).
#
# 3. scene.paraforge_active_object (not scene.parafly_active_object - see
#    tlso_alignment.py's module docstring) and paraforge.afo_* bl_idnames
#    (not parafly.afo_*).

import bpy
from bpy.types import Operator

from ..afo_zone_reader import get_afo_zone_names, find_afo_vertex_group
from ..afo_zone_definitions import get_afo_zone_meta
from .afo_slider_engine import store_afo_original_positions, has_afo_baseline

MASK_THRESHOLD = 0.02


def _current_afo_zone_id(context):
    step = context.scene.parafly_afo_mapping_step
    zone_names = get_afo_zone_names()
    if 0 <= step < len(zone_names):
        return zone_names[step]
    return None


def _enter_afo_adjustment_stage(context, obj):
    if not has_afo_baseline(obj):
        store_afo_original_positions(obj)
    context.scene.parafly_afo_stage = 'ADJUSTMENT'


def _check_afo_completion(context, obj, zone_names):
    """All non-skippable zones must have a vertex group before Adjustment
    unlocks - matches tlso_mapping_wizard.py's own belt-and-suspenders
    completion guard."""
    all_required = all(
        find_afo_vertex_group(obj, z) is not None
        for z in zone_names
        if not get_afo_zone_meta(z).get("skippable", True)
    )
    if all_required:
        _enter_afo_adjustment_stage(context, obj)
        return True
    return False


# Relative path of the bundled "Mask" brush inside Blender's own essentials
# brush-asset library - see mapping_wizard.py / tlso_mapping_wizard.py's
# matching constant and module docstrings for the full investigation.
MASK_BRUSH_ASSET_PATH = "brushes/essentials_brushes-mesh_sculpt.blend/Brush/Mask"


def _force_mask_brush(context):
    """Activate the Mask brush so Start Painting genuinely enters mask-paint
    mode - see mapping_wizard.py/tlso_mapping_wizard.py's matching function
    for the full investigation of why this specific mechanism (not
    tool_set_by_id, not a direct brush assignment) is what actually works."""
    view3d_area = None
    window_region = None
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            view3d_area = area
            for region in area.regions:
                if region.type == 'WINDOW':
                    window_region = region
            break

    def _try_activate():
        try:
            res = bpy.ops.brush.asset_activate(
                asset_library_type='ESSENTIALS',
                asset_library_identifier="",
                relative_asset_identifier=MASK_BRUSH_ASSET_PATH,
            )
            if 'FINISHED' in res:
                return True
        except Exception:
            pass
        try:
            bpy.ops.wm.tool_set_by_id(name='builtin_brush.Mask')
        except Exception:
            pass
        return False

    if view3d_area is not None and window_region is not None:
        with context.temp_override(area=view3d_area, region=window_region):
            _try_activate()
    else:
        _try_activate()


class PARAFORGE_OT_afo_start_painting(Operator):
    """Enter Sculpt Mode with the Mask brush active to paint this AFO zone"""
    bl_idname = "paraforge.afo_start_painting"
    bl_label = "▶ Start Painting"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No AFO scan is loaded")
            return {'CANCELLED'}
        zone_id = _current_afo_zone_id(context)
        if zone_id is None:
            self.report({'ERROR'}, "No clinical zone is active")
            return {'CANCELLED'}
        zone_name = get_afo_zone_meta(zone_id)["display_name"]

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='SCULPT')

        try:
            ts = context.tool_settings.sculpt
            ts.use_symmetry_x = False
            ts.use_symmetry_y = False
            ts.use_symmetry_z = False
            ts.show_mask = True
        except Exception:
            pass

        # Order matters - see tlso_mapping_wizard.py's matching comment: the
        # brush must be activated BEFORE mask_flood_fill, not after.
        _force_mask_brush(context)

        try:
            bpy.ops.paint.mask_flood_fill(mode='VALUE', value=0.0)
        except Exception:
            pass

        self.report({'INFO'}, f"Paint the {zone_name} area, then click Confirm Zone")
        return {'FINISHED'}


class PARAFORGE_OT_afo_confirm_zone(Operator):
    """Convert the painted sculpt mask into this AFO zone's vertex group"""
    bl_idname = "paraforge.afo_confirm_zone"
    bl_label = "✓ Confirm Zone"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No AFO scan is loaded")
            return {'CANCELLED'}
        zone_id = _current_afo_zone_id(context)
        if zone_id is None:
            self.report({'ERROR'}, "No clinical zone is active")
            return {'CANCELLED'}
        zone_name = get_afo_zone_meta(zone_id)["display_name"]

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        mesh = obj.data
        mask_attr = mesh.attributes.get(".sculpt_mask")

        weights = {}
        if mask_attr is not None:
            for i, item in enumerate(mask_attr.data):
                if item.value > MASK_THRESHOLD:
                    weights[i] = item.value

        if not weights:
            self.report({'ERROR'},
                f"Nothing painted for {zone_name} — paint at least part of the zone before confirming")
            return {'CANCELLED'}

        existing = find_afo_vertex_group(obj, zone_id)
        if existing is not None:
            obj.vertex_groups.remove(existing)
        vg = obj.vertex_groups.new(name=zone_id)
        for idx, weight in weights.items():
            vg.add([idx], weight, 'REPLACE')

        if mask_attr is not None:
            mesh.attributes.remove(mask_attr)
            mesh.update()

        zone_names = get_afo_zone_names()
        context.scene.parafly_afo_mapping_step += 1

        if context.scene.parafly_afo_mapping_step >= len(zone_names):
            if _check_afo_completion(context, obj, zone_names):
                self.report({'INFO'}, "All required zones mapped. Clinical Adjustment is now available.")
            else:
                self.report({'WARNING'}, "Some required zones are missing. Please go back and complete them.")
        else:
            self.report({'INFO'}, f"✓ {zone_name} mapped ({len(weights)} verts)")
        return {'FINISHED'}


class PARAFORGE_OT_afo_skip_zone(Operator):
    """Skip this zone (only allowed for zones marked skippable)"""
    bl_idname = "paraforge.afo_skip_zone"
    bl_label = "↷ Skip Zone"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        zone_names = get_afo_zone_names()
        step = context.scene.parafly_afo_mapping_step
        if step < len(zone_names):
            zone_id = zone_names[step]
            meta = get_afo_zone_meta(zone_id)
            if not meta.get("skippable", True):
                self.report({'WARNING'}, f"{meta['display_name']} is required and cannot be skipped.")
                return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        context.scene.parafly_afo_mapping_step = step + 1
        if context.scene.parafly_afo_mapping_step >= len(zone_names) and obj is not None:
            if _check_afo_completion(context, obj, zone_names):
                self.report({'INFO'}, "All required zones mapped. Clinical Adjustment is now available.")
            else:
                self.report({'WARNING'}, "Some required zones are missing. Please go back and complete them.")
        return {'FINISHED'}


class PARAFORGE_OT_afo_back_zone(Operator):
    """Go back to the previous AFO zone (does not delete its vertex group)"""
    bl_idname = "paraforge.afo_back_zone"
    bl_label = "← Back"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.parafly_afo_mapping_step = max(0, context.scene.parafly_afo_mapping_step - 1)
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        return {'FINISHED'}


class PARAFORGE_OT_afo_skip_all_dev(Operator):
    """Developer only: create empty vertex groups for all AFO zones and jump to Clinical Adjustment"""
    bl_idname = "paraforge.afo_skip_all_dev"
    bl_label = "Skip All (Dev)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from ...preferences import get_dev_mode
        if not get_dev_mode():
            self.report({'ERROR'}, "Developer Mode is off")
            return {'CANCELLED'}

        obj = context.scene.paraforge_active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No AFO scan is loaded")
            return {'CANCELLED'}

        zone_names = get_afo_zone_names()
        for zone_id in zone_names:
            if find_afo_vertex_group(obj, zone_id) is None:
                obj.vertex_groups.new(name=zone_id)

        context.scene.parafly_afo_mapping_step = len(zone_names)
        _enter_afo_adjustment_stage(context, obj)
        self.report({'WARNING'}, "Dev skip: all zones created empty (testing only)")
        return {'FINISHED'}
