# paraforge/operators/afo_measurement.py - Measurement stage for AFO:
# click-to-measure circumference (bmesh plane cross-section) and length
# (two-point distance).
#
# Corrections vs. SPEC_parafly_afo_complete.md Section 9, found by checking
# against the real codebase rather than trusting the spec's code:
#
# 1. scene.parafly_active_object -> scene.paraforge_active_object (see
#    tlso_alignment.py's module docstring).
#
# 2. Real resource leak fixed: the spec's _draw_ring only ever cleaned up the
#    PREVIOUS ring via self._ring_object, an operator-INSTANCE attribute. In
#    CIRCUMFERENCE mode the operator returns {'FINISHED'} after a single
#    click, so the next measurement is a brand new operator instance that has
#    never heard of the old self._ring_object - _cleanup_ring's only call
#    site (ESC) never runs on the normal completion path either. Every
#    circumference click therefore left an orphaned "afo_measure_ring" object
#    + curve datablock + material behind forever. Fixed by tagging each ring
#    object with a custom property (dynax_is_afo_measure_ring) and removing
#    ANY existing tagged ring (not just one instance's own) before creating a
#    new one - a lookup that survives across separate operator invocations,
#    unlike an instance attribute.
#
# 3. bl_idname prefix parafly.* -> paraforge.afo_*; classes renamed
#    PARAFLY_OT_afo_* -> PARAFORGE_OT_afo_* to match the established
#    PARAFORGE_OT_tlso_* convention.
#
# 4. CSV export switched from a raw filepath + window_manager.fileselect_add
#    to bpy_extras.io_utils.ExportHelper, matching this codebase's own
#    established export pattern (PARAFORGE_OT_export, PARAFORGE_OT_save_project)
#    - gets automatic ".csv" extension handling and a proper filter for free
#    instead of a hand-rolled file browser invocation.
#
# 5. Real bug fixed in _draw_ring: a fresh POLY spline (splines.new('POLY'))
#    already has 1 point at index 0 before anything is added.
#    spline.points.add(len(ring_pts)) - what the spec did - therefore creates
#    len(ring_pts) + 1 total points, one more than the loop below it ever
#    assigns a position to; that last, never-set point sits at the spline's
#    default (0,0,0,1) origin, and with use_cyclic_u=True the closed ring
#    would visibly spike through the world origin on every measurement.
#    Fixed to spline.points.add(len(ordered) - 1) so the point count matches
#    exactly (1 existing + (N-1) added = N, one per ring point).

# 6. v1.20.8 (Creator Stabilization Sprint): the cross-section maths and the
#    tagged marker ring were EXTRACTED, unchanged, into
#    utils/measurement_helpers.py so Creator's new Click-to-Measure and this
#    AFO tool share ONE measurement engine rather than growing a second,
#    divergent implementation. Everything Codex authored here is preserved -
#    the operators, their paraforge.afo_* idnames, the parafly_afo_* scene
#    state, the CSV export, the modal's click/finish behaviour and every
#    report string are untouched. The methods below are now thin delegates
#    with identical behaviour: corrections #2 (tag-based ring cleanup across
#    operator instances) and #5 (points.add(len-1), no origin spike) live on
#    inside the shared helper.

import bpy
import json
import math
from mathutils import Vector
from bpy.props import StringProperty
from bpy_extras.io_utils import ExportHelper
from bpy_extras.view3d_utils import region_2d_to_origin_3d, region_2d_to_vector_3d

from ...utils import measurement_helpers as mh

# Re-exported so any existing reference to these names keeps working; the tag
# string itself is unchanged, so rings created by the pre-refactor build are
# still found and cleaned up.
MEASURE_RING_TAG = mh.MEASURE_RING_TAG


def _remove_existing_ring():
    """Remove any existing AFO measurement ring object (+ its curve and
    material datablocks), regardless of which operator instance created it -
    see module docstring #2 for why this can't rely on an instance attribute.
    Delegates to the shared engine (docstring #6)."""
    mh.remove_existing_ring()


class PARAFORGE_OT_afo_measure_click(bpy.types.Operator):
    """
    Modal operator: click on mesh to place a measurement point.
    For circumference: calculates cross-section at clicked Z height.
    For length: two clicks, calculates 3D distance.
    """
    bl_idname = "paraforge.afo_measure_click"
    bl_label = "Click to Measure"
    bl_options = {'REGISTER', 'UNDO'}

    _first_point = None

    def invoke(self, context, event):
        self._first_point = None
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        context.window_manager.modal_handler_add(self)
        mode = context.scene.parafly_afo_measure_mode
        self.report(
            {'INFO'},
            f"Click to measure {mode} — keep clicking for more. "
            f"Enter/right-click or Esc to finish."
        )
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        # The tool stays live so the clinician can take as many measurements as
        # they like in one session; Esc / Enter / right-click ends it.
        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            return {'FINISHED'}
        if event.type in {'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            return {'FINISHED'}

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            obj = context.scene.paraforge_active_object
            if obj is None:
                return {'RUNNING_MODAL'}

            region = context.region
            rv3d = context.region_data
            if region is None or rv3d is None or region.type != 'WINDOW':
                return {'PASS_THROUGH'}
            coord = (event.mouse_region_x, event.mouse_region_y)

            ray_dir = region_2d_to_vector_3d(region, rv3d, coord)
            ray_orig = region_2d_to_origin_3d(region, rv3d, coord)

            mat_inv = obj.matrix_world.inverted()
            hit, loc_local, normal, face_idx = obj.ray_cast(
                mat_inv @ ray_orig,
                mat_inv.to_3x3() @ ray_dir
            )

            if not hit:
                return {'RUNNING_MODAL'}

            loc_world = obj.matrix_world @ loc_local
            mode = context.scene.parafly_afo_measure_mode

            if mode == 'CIRCUMFERENCE':
                circ = self._measure_circumference(obj, loc_world.z)
                if circ <= 0.0:
                    self.report({'WARNING'}, "No closed cross-section there — click again.")
                    return {'RUNNING_MODAL'}
                self._draw_ring(context, obj, loc_world.z)
                self._save_measurement(
                    context,
                    f"Circumference at Z={loc_world.z:.1f}mm",
                    circ
                )
                self.report({'INFO'}, f"Circumference: {circ:.1f} mm — click for more, Enter/Esc to finish")
                # Stay live so the next click adds another measurement.
                return {'RUNNING_MODAL'}

            elif mode == 'LENGTH':
                if self._first_point is None:
                    self._first_point = loc_world.copy()
                    self.report({'INFO'}, "First point set. Click second point.")
                    return {'RUNNING_MODAL'}
                else:
                    dist = (loc_world - self._first_point).length
                    self._save_measurement(context, "Length", dist)
                    self.report({'INFO'}, f"Length: {dist:.1f} mm — click a new pair, Enter/Esc to finish")
                    self._first_point = None
                    return {'RUNNING_MODAL'}

        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            return {'PASS_THROUGH'}

        return {'RUNNING_MODAL'}

    def _cross_section_points(self, obj, z_world):
        """Delegate to the shared engine (module docstring #6)."""
        return mh.cross_section_points(obj, z_world)

    def _sort_ring_by_angle(self, points):
        """Delegate to the shared engine (module docstring #6)."""
        return mh.sort_ring_by_angle(points)

    def _measure_circumference(self, obj, z_world):
        """Calculate circumference of the mesh cross-section at z_world height
        via a plane-mesh edge intersection, ordered by angle around the
        cross-section's own centroid. Delegates to the shared engine."""
        return mh.measure_circumference(obj, z_world)

    def _draw_ring(self, context, obj, z_world):
        """Draw a visible ring at the measurement Z height, replacing any
        existing AFO measurement ring (see module docstring #2). Delegates to
        the shared engine, keeping this tool's own blue ring colour and name."""
        mh.draw_measurement_ring(context, obj, z_world,
                                 color=(0.1, 0.5, 1.0, 1.0),
                                 name="afo_measure_ring")

    def _save_measurement(self, context, label, value_mm):
        scene = context.scene
        try:
            measurements = json.loads(scene.parafly_afo_measurements)
        except Exception:
            measurements = []
        measurements.append({
            "label": label,
            "value_mm": round(value_mm, 1)
        })
        scene.parafly_afo_measurements = json.dumps(measurements)


class PARAFORGE_OT_afo_clear_measurements(bpy.types.Operator):
    bl_idname = "paraforge.afo_clear_measurements"
    bl_label = "Clear All"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.parafly_afo_measurements = "[]"
        _remove_existing_ring()
        return {'FINISHED'}


class PARAFORGE_OT_afo_export_measurements_csv(bpy.types.Operator, ExportHelper):
    bl_idname = "paraforge.afo_export_csv"
    bl_label = "Export CSV"
    bl_description = "Export saved measurements to CSV file"
    bl_options = {'REGISTER'}

    filename_ext = ".csv"
    filter_glob: StringProperty(default="*.csv", options={'HIDDEN'})

    def invoke(self, context, event):
        self.filepath = "afo_measurements.csv"
        return ExportHelper.invoke(self, context, event)

    def execute(self, context):
        import csv
        try:
            measurements = json.loads(context.scene.parafly_afo_measurements)
        except Exception:
            measurements = []

        try:
            with open(self.filepath, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(["#", "Label", "Value (mm)"])
                for i, m in enumerate(measurements, 1):
                    writer.writerow([i, m["label"], m["value_mm"]])
        except OSError as e:
            self.report({'ERROR'}, f"Could not write CSV file: {e}")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Measurements exported: {self.filepath}")
        return {'FINISHED'}
