# paraforge/operators/mapping_wizard.py - Clinical Mapping stage: guided zone painting.
#
# v2 (SPEC_paraforge_v2_full_rebuild.md): zone ids now come from
# zone_reader.get_zone_names() instead of the hardcoded TRANSTIBIAL_ZONES list.
#
# SPEC_tlso_zone_update_7zones.md's Fix 3 ("Start Painting not initiating mask
# brush", found on the TLSO wizard, same code pattern here): _force_mask_brush
# below no longer relies on tool_set_by_id alone - verified directly in a real
# (non-headless) Blender GUI session that tool_set_by_id's poll() passes while
# its execute() still silently returns {'CANCELLED'} and leaves the brush
# unchanged, regardless of region/area override, EXEC vs INVOKE_DEFAULT,
# immediate vs deferred timing, or toolbar visibility - i.e. the "already-
# proven" claim this docstring used to make about tool_set_by_id (and
# sculpt_helpers.py's _set_brush) was never actually verified against a
# genuinely programmatic (non-mouse-click) call path. The real working
# mechanism is bpy.ops.brush.asset_activate against Blender's bundled
# ESSENTIALS brush-asset library (Blender 4.3+ sculpt brushes are Asset
# datablocks, not tool-system items) - see tlso_mapping_wizard.py's
# _force_mask_brush for the full investigation.

import bpy
from bpy.types import Operator

from ..zone_reader import get_zone_names, find_vertex_group
from ..zone_definitions import get_zone_meta
from .slider_engine import store_original_positions

# Sculpt mask values below this are treated as "not painted" — avoids picking up
# float noise and keeps confirmed vertex groups meaningfully sparse.
MASK_THRESHOLD = 0.02


def _current_zone_id(context):
    step = context.scene.paraforge_mapping_step
    zone_names = get_zone_names()
    if 0 <= step < len(zone_names):
        return zone_names[step]
    return None


def _enter_adjustment_stage(context, obj):
    """Transition into Clinical Adjustment, storing the pre-adjustment baseline
    exactly once (never again — apply_zone_deformation always measures from it)."""
    if obj.get("paraforge_original_positions") is None:
        store_original_positions(obj)
    context.scene.paraforge_stage = 'ADJUSTMENT'


# Relative path of the bundled "Mask" brush inside Blender's own essentials
# brush-asset library - see the module docstring / tlso_mapping_wizard.py's
# _force_mask_brush for how this was found and verified.
MASK_BRUSH_ASSET_PATH = "brushes/essentials_brushes-mesh_sculpt.blend/Brush/Mask"


def _force_mask_brush(context):
    """Activate the Mask brush so Start Painting genuinely enters mask-paint
    mode. See the module docstring and tlso_mapping_wizard.py's
    _force_mask_brush (same fix, same investigation) for why tool_set_by_id
    alone - despite being previously believed "already-proven" via
    sculpt_helpers.py's _set_brush - does not reliably work, and why
    `context.tool_settings.sculpt.brush = ...` isn't usable either (raises
    AttributeError: read-only, in this Blender build)."""
    view3d_area = None
    window_region = None
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            view3d_area = area
            for region in area.regions:
                if region.type == 'WINDOW':
                    window_region = region
            break

    def _try_activate():
        try:
            res = bpy.ops.brush.asset_activate(
                asset_library_type='ESSENTIALS',
                asset_library_identifier="",
                relative_asset_identifier=MASK_BRUSH_ASSET_PATH,
            )
            if 'FINISHED' in res:
                return True
        except Exception:
            pass
        try:
            bpy.ops.wm.tool_set_by_id(name='builtin_brush.Mask')
        except Exception:
            pass
        return False

    if view3d_area is not None and window_region is not None:
        with context.temp_override(area=view3d_area, region=window_region):
            _try_activate()
    else:
        _try_activate()


class PARAFORGE_OT_start_painting(Operator):
    """Enter Sculpt Mode with the Mask brush active to paint this clinical zone"""
    bl_idname = "paraforge.start_painting"
    bl_label = "▶ Start Painting"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No ParaForge scan is loaded")
            return {'CANCELLED'}
        zone_id = _current_zone_id(context)
        if zone_id is None:
            self.report({'ERROR'}, "No clinical zone is active")
            return {'CANCELLED'}
        zone_name = get_zone_meta(zone_id)["display_name"]

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='SCULPT')

        try:
            ts = context.tool_settings.sculpt
            ts.use_symmetry_x = False
            ts.use_symmetry_y = False
            ts.use_symmetry_z = False
            ts.show_mask = True
        except Exception:
            pass

        # Order matters, verified directly in a real GUI session (see
        # tlso_mapping_wizard.py's matching fix for the full investigation):
        # activate the brush BEFORE mask_flood_fill, not after.
        # mask_flood_fill's undo-push silently blocks a brush change
        # immediately afterward.
        _force_mask_brush(context)

        try:
            bpy.ops.paint.mask_flood_fill(mode='VALUE', value=0.0)
        except Exception:
            pass

        self.report({'INFO'}, f"Paint the {zone_name} area, then click Confirm Zone")
        return {'FINISHED'}


class PARAFORGE_OT_confirm_zone(Operator):
    """Convert the painted sculpt mask into this zone's vertex group"""
    bl_idname = "paraforge.confirm_zone"
    bl_label = "✓ Confirm Zone"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No ParaForge scan is loaded")
            return {'CANCELLED'}
        zone_id = _current_zone_id(context)
        if zone_id is None:
            self.report({'ERROR'}, "No clinical zone is active")
            return {'CANCELLED'}
        zone_name = get_zone_meta(zone_id)["display_name"]

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        mesh = obj.data
        mask_attr = mesh.attributes.get(".sculpt_mask")

        weights = {}
        if mask_attr is not None:
            for i, item in enumerate(mask_attr.data):
                if item.value > MASK_THRESHOLD:
                    weights[i] = item.value

        if not weights:
            self.report({'ERROR'},
                f"Nothing painted for {zone_name} — paint at least part of the zone before confirming")
            return {'CANCELLED'}

        existing = find_vertex_group(obj, zone_id)
        if existing is not None:
            obj.vertex_groups.remove(existing)
        vg = obj.vertex_groups.new(name=zone_id)
        for idx, weight in weights.items():
            vg.add([idx], weight, 'REPLACE')

        # Clear the mask so the next zone starts from a blank slate.
        if mask_attr is not None:
            mesh.attributes.remove(mask_attr)
            mesh.update()

        context.scene.paraforge_mapping_step += 1

        if context.scene.paraforge_mapping_step >= len(get_zone_names()):
            _enter_adjustment_stage(context, obj)
            self.report({'INFO'}, "All clinical regions mapped. Clinical Adjustment is now available.")
        else:
            self.report({'INFO'}, f"✓ {zone_name} mapped ({len(weights)} verts)")
        return {'FINISHED'}


class PARAFORGE_OT_wizard_back(Operator):
    """Go back to the previous clinical zone (does not delete its vertex group)"""
    bl_idname = "paraforge.wizard_back"
    bl_label = "← Back"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.paraforge_mapping_step = max(0, context.scene.paraforge_mapping_step - 1)
        return {'FINISHED'}


class PARAFORGE_OT_skip_all_dev(Operator):
    """Developer only: create empty vertex groups for all zones and jump to Clinical Adjustment"""
    bl_idname = "paraforge.skip_all_dev"
    bl_label = "Skip All (Dev)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No ParaForge scan is loaded")
            return {'CANCELLED'}

        zone_names = get_zone_names()
        for zone_id in zone_names:
            if find_vertex_group(obj, zone_id) is None:
                obj.vertex_groups.new(name=zone_id)

        context.scene.paraforge_mapping_step = len(zone_names)
        _enter_adjustment_stage(context, obj)
        self.report({'WARNING'}, "Dev skip: all zones created empty (testing only)")
        return {'FINISHED'}
