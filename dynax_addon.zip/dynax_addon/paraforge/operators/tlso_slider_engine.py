# paraforge/operators/tlso_slider_engine.py - Clinical Adjustment stage for TLSO:
# the parametric slider engine, mirroring slider_engine.py's TT implementation
# with the same two real bugs already found and fixed there, both present again
# in SPEC_parafly_tlso_complete.md's Section 8 code (see slider_engine.py's
# module docstring for the original discovery/writeup):
#
# 1. UNITS: the spec divided by 1000 ("mm to Blender units / metres"). DynaX is
#    mm-space (1 Blender unit = 1 mm) - removed the /1000.0.
# 2. CROSS-ZONE CORRUPTION: the spec's apply_tlso_zone_deformation(zone_id)
#    reset every vertex NOT in the triggering zone back to ORIGINAL on every
#    call, silently wiping out any other zone's already-applied offset the
#    moment a second slider moves. Fixed the same way as the TT engine: always
#    recompute the full mesh from the stored baseline across every zone's
#    current slider value, not just the triggering one.
#
# TLSO-specific addition (genuinely new, not a TT bug carryover): each zone has
# a "direction" (inward/outward/boundary) in tlso_zone_definitions.py - the
# direction determines which way the zone's average normal is pushed (see
# apply_tlso_zone_deformation below), so "increase the slider" always means
# "more of this zone's intended clinical effect" regardless of which way that
# pushes the surface.
#
# Slider ranges: every zone (TT and TLSO alike) uses a uniform -10.0/+10.0 mm
# range (zone_definitions.py / tlso_zone_definitions.py) - the earlier
# per-zone curated ranges and "almost unlimited" soft/hard split were replaced
# with this uniform clamp per explicit request.
#
# Deformation direction fix: per-vertex normals are unreliable across a large
# curved surface like a torso - normals within one zone point in many
# different directions, so pushing each vertex along its OWN normal produced
# a deformation that looked correct on some vertices and inverted on others
# (found on real TLSO zones, not a TT bug carryover). Fixed by computing ONE
# average normal for the whole zone and moving every vertex in that zone
# along that single consistent direction instead of each vertex's individual
# normal - see apply_tlso_zone_deformation.

import bpy
import json
import bmesh
from mathutils import Vector

try:
    import numpy as np
except ImportError:  # Blender bundles NumPy; keep a safe fallback.
    np = None

from ..tlso_zone_reader import get_tlso_zone_names, find_tlso_vertex_group
from ..tlso_zone_definitions import get_tlso_zone_meta


# Auto-save of manual edits (smoothing) - see apply_tlso_zone_deformation's
# "fold" step. LAST_APPLIED_KEY is a mesh FLOAT_VECTOR attribute holding the
# exact positions this engine last wrote; comparing it against the live mesh
# tells us whether the clinician has manually edited (smoothed) the surface
# since, so that edit can be folded into the baseline instead of being wiped
# out by the next slider recompute.
LAST_APPLIED_KEY = "parafly_tlso_last_applied"
FOLD_EPS = 1e-4   # mm; live-vs-last-applied drift above this is a real edit


def _write_positions_attr(mesh, name, positions_flat):
    """Write a flat float32 (n*3) array into a POINT FLOAT_VECTOR attribute."""
    attr = mesh.attributes.get(name)
    if attr is not None and (attr.domain != 'POINT' or attr.data_type != 'FLOAT_VECTOR'):
        mesh.attributes.remove(attr)
        attr = None
    if attr is None:
        attr = mesh.attributes.new(name, 'FLOAT_VECTOR', 'POINT')
    attr.data.foreach_set("vector", positions_flat)


def _read_positions_attr(mesh, name):
    """Return a (n,3) float64 numpy array from a POINT FLOAT_VECTOR attribute,
    or None if it's missing / numpy is unavailable."""
    if np is None:
        return None
    attr = mesh.attributes.get(name)
    if attr is None:
        return None
    n = len(mesh.vertices)
    flat = np.empty(n * 3, dtype=np.float32)
    attr.data.foreach_get("vector", flat)
    return flat.reshape(n, 3).astype(np.float64)


def _record_last_applied(mesh):
    """Snapshot the mesh's current local positions as the last-applied state."""
    if np is None:
        return
    n = len(mesh.vertices)
    co = np.empty(n * 3, dtype=np.float32)
    mesh.vertices.foreach_get("co", co)
    _write_positions_attr(mesh, LAST_APPLIED_KEY, co)


def store_tlso_original_positions(obj):
    """Store the local-space vertex positions of obj as the deformation
    baseline. Called at TLSO Clinical Adjustment entry
    (tlso_mapping_wizard._enter_tlso_adjustment_stage) and again whenever the
    current shape is (re)baked as the baseline (smooth_brush.done_smooth). Also
    seeds the last-applied snapshot so the auto-save fold in
    apply_tlso_zone_deformation starts from a matching reference and never
    mistakes the freshly-baked shape for a pending manual edit."""
    mesh = obj.data
    positions = [list(v.co) for v in mesh.vertices]
    obj["parafly_tlso_original_positions"] = json.dumps(positions)
    _record_last_applied(mesh)
    print(f"[ParaFly TLSO] Stored {len(positions)} original positions on '{obj.name}'")


def _tlso_zone_weights(mesh, vg_index):
    weights = {}
    for v in mesh.vertices:
        for g in v.groups:
            if g.group == vg_index:
                weights[v.index] = g.weight
                break
    return weights


def apply_tlso_zone_deformation(context, zone_id=None):
    """Recompute the WHOLE mesh from the stored baseline, applying every TLSO
    zone's current slider value (see module docstring for why a partial
    per-zone update is unsafe - `zone_id` is accepted for API parity with each
    slider's update callback but every zone is still recomputed).

    Each zone is pushed along ONE average normal for that zone, not each
    vertex's own normal. Per-vertex normals are unreliable across a large
    curved surface like a torso - they point in enough different directions
    within a single zone that some vertices moved correctly while others
    moved backwards. Averaging the zone's normals into one direction and
    moving every vertex in the zone along that same direction gives a clean,
    predictable push/pull that matches clinical intent."""
    obj = context.scene.paraforge_active_object
    if obj is None or obj.type != 'MESH':
        return

    raw = obj.get("parafly_tlso_original_positions")
    if raw is None:
        return
    original_positions = json.loads(raw)

    mesh = obj.data
    n = len(mesh.vertices)
    if len(original_positions) != n:
        return  # topology changed since the baseline was stored

    # ── Auto-save fold ────────────────────────────────────────────────
    # Every slider move rebuilds the whole mesh from the baseline, so any
    # manual edit made in between (a Smooth-brush pass) would silently be
    # thrown away - the "I smoothed, re-adjusted, and lost all my work" bug.
    # Before rebuilding, detect that edit as the difference between the live
    # mesh and the positions we last wrote, and fold it permanently into the
    # baseline so it survives this and every future recompute. No explicit
    # "Done Smoothing" click required. (done_smooth still exists to also zero
    # the sliders; this just makes the SAVE automatic.)
    last_applied = _read_positions_attr(mesh, LAST_APPLIED_KEY)
    if last_applied is not None and len(last_applied) == n:
        live = np.empty(n * 3, dtype=np.float32)
        mesh.vertices.foreach_get("co", live)
        delta = live.reshape(n, 3).astype(np.float64) - last_applied
        if np.abs(delta).max() > FOLD_EPS:
            base = np.asarray(original_positions, dtype=np.float64) + delta
            original_positions = base.tolist()
            obj["parafly_tlso_original_positions"] = json.dumps(original_positions)

    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()

    for v in bm.verts:
        v.co = Vector(original_positions[v.index])
    bm.normal_update()
    original_normals = [v.normal.copy() for v in bm.verts]

    for zid in get_tlso_zone_names():
        vg = find_tlso_vertex_group(obj, zid)
        if vg is None:
            continue
        slider_value = getattr(context.scene, f"parafly_tlso_slider_{zid}", 0.0)
        if slider_value == 0.0:
            continue
        weights = _tlso_zone_weights(mesh, vg.index)
        if not weights:
            continue

        zone_normals = [original_normals[idx] for idx in weights.keys()]
        avg_normal = sum(zone_normals, Vector()).normalized()
        if avg_normal.length_squared == 0.0:
            continue

        meta = get_tlso_zone_meta(zid)
        direction = meta.get("direction", "inward")
        # Inward zones push against the average normal (into the body);
        # outward/boundary zones push along it (away from the body).
        move_dir = -avg_normal if direction == "inward" else avg_normal

        for idx, weight in weights.items():
            bm.verts[idx].co += move_dir * (slider_value * weight)

    bm.to_mesh(mesh)
    bm.free()
    mesh.update()

    # Remember exactly what we just wrote, so the next call's fold step can tell
    # a real manual edit apart from this engine's own output.
    _record_last_applied(mesh)


def _tlso_slider_prop_name(zone_id):
    return f"parafly_tlso_slider_{zone_id}"


def _make_tlso_update_callback(zone_id):
    """Fresh 2-arg closure per zone - see slider_engine._make_update_callback
    for why (Blender's update-callback signature check, and the per-loop
    closure-capture bug if one lambda were reused across zones)."""
    def _update(self, context):
        apply_tlso_zone_deformation(context, zone_id)
    return _update


# SPEC_parafly_slider_and_zone_corrections.md Section 1 ("remove all
# min/max limits, allow unlimited user input") - same reasoning and same fix
# as slider_engine.py's register_slider_properties: no min/max kwargs at all
# (Blender's own default float range applies, effectively unbounded), only
# soft_min/soft_max (from the zone's curated metadata) for the comfortable
# default drag range.
def register_tlso_slider_properties():
    unregister_tlso_slider_properties()
    for zone_id in get_tlso_zone_names():
        meta = get_tlso_zone_meta(zone_id)
        attr = _tlso_slider_prop_name(zone_id)
        setattr(bpy.types.Scene, attr, bpy.props.FloatProperty(
            name=meta["display_name"],
            description=meta["description"],
            soft_min=meta["minimum"],
            soft_max=meta["maximum"],
            default=meta["default"],
            precision=1,
            subtype='DISTANCE',
            unit='LENGTH',
            update=_make_tlso_update_callback(zone_id),
        ))


def unregister_tlso_slider_properties():
    for zone_id in get_tlso_zone_names():
        attr = _tlso_slider_prop_name(zone_id)
        if hasattr(bpy.types.Scene, attr):
            try:
                delattr(bpy.types.Scene, attr)
            except Exception:
                pass


class PARAFORGE_OT_tlso_reset_zone(bpy.types.Operator):
    """Reset this TLSO zone's slider to 0"""
    bl_idname = "paraforge.tlso_reset_zone"
    bl_label = "Reset Zone"
    bl_options = {'REGISTER', 'UNDO'}
    zone_id: bpy.props.StringProperty()

    def execute(self, context):
        prop_name = _tlso_slider_prop_name(self.zone_id)
        if not hasattr(context.scene, prop_name):
            self.report({'ERROR'}, "Slider properties aren't registered yet — try again in a moment")
            return {'CANCELLED'}
        setattr(context.scene, prop_name, 0.0)
        return {'FINISHED'}


class PARAFORGE_OT_tlso_reset_all(bpy.types.Operator):
    """Reset every TLSO zone's slider to 0"""
    bl_idname = "paraforge.tlso_reset_all"
    bl_label = "Reset All Zones"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for zone_id in get_tlso_zone_names():
            prop_name = _tlso_slider_prop_name(zone_id)
            if hasattr(context.scene, prop_name):
                setattr(context.scene, prop_name, 0.0)
        return {'FINISHED'}
