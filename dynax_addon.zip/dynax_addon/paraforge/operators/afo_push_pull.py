import bpy
import bmesh
from mathutils import Vector

from ...utils.mask_utils import get_mask_layer, clear_mask
from .tlso_mapping_wizard import _force_mask_brush


BASELINE_ATTR = "parafly_afo_pushpull_baseline"
PUSH_PULL_MASK_ATTR = "AFO_PUSH_PULL_MASK"
SOURCE_KEY = "parafly_afo_pushpull_source"
WORKING_NAME = "ParaFly_AFO_PushPull_Working"
PREVIEW_DEBOUNCE_SECONDS = 0.08

_baseline_cache = {}
_mask_cache = {}


def _activate(context, obj):
    if context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    obj.hide_set(False)
    obj.hide_viewport = False
    obj.select_set(True)
    context.view_layer.objects.active = obj
    context.scene.paraforge_active_object = obj


def _ensure_working_copy(context):
    obj = context.scene.paraforge_active_object
    if obj is None or obj.type != 'MESH':
        return None
    if obj.get(SOURCE_KEY):
        return obj

    working = obj.copy()
    working.data = obj.data.copy()
    working.name = WORKING_NAME
    collection = obj.users_collection[0] if obj.users_collection else context.collection
    collection.objects.link(working)
    working[SOURCE_KEY] = obj.name
    obj.hide_set(True)
    obj.hide_render = True
    _activate(context, working)
    return working


def _baseline_attribute(mesh, create=False):
    attr = mesh.attributes.get(BASELINE_ATTR)
    if attr is None and create:
        attr = mesh.attributes.new(BASELINE_ATTR, 'FLOAT_VECTOR', 'POINT')
        for item, vert in zip(attr.data, mesh.vertices):
            item.vector = vert.co
    return attr


def _baseline_data(obj):
    mesh = obj.data
    attr = _baseline_attribute(mesh, create=True)
    key = (mesh.as_pointer(), len(mesh.vertices))
    cached = _baseline_cache.get(key)
    if cached is not None:
        return cached

    coords = tuple(Vector(item.vector) for item in attr.data)
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    for vert, co in zip(bm.verts, coords):
        vert.co = co
    bm.normal_update()
    normals = tuple(vert.normal.copy() for vert in bm.verts)
    bm.free()
    cached = (coords, normals)
    _baseline_cache[key] = cached
    return cached


def _mask_values(obj):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    layer = get_mask_layer(bm)
    if layer is None:
        bm.free()
        return None
    values = tuple(max(0.0, min(1.0, vert[layer])) for vert in bm.verts)
    bm.free()
    return values


def _pushpull_mask_attribute(mesh, create=False):
    attr = mesh.attributes.get(PUSH_PULL_MASK_ATTR)
    if attr is None and create:
        attr = mesh.attributes.new(PUSH_PULL_MASK_ATTR, 'FLOAT', 'POINT')
    return attr


def _affected_data(obj):
    revision = int(obj.get("parafly_afo_pushpull_mask_revision", 0))
    key = (obj.data.as_pointer(), len(obj.data.vertices), revision)
    cached = _mask_cache.get(key)
    if cached is not None:
        return cached
    attr = _pushpull_mask_attribute(obj.data)
    if attr is None:
        return ()
    affected = tuple(
        (index, max(0.0, min(1.0, item.value)))
        for index, item in enumerate(attr.data)
        if item.value > 1e-4
    )
    _mask_cache.clear()
    _mask_cache[key] = affected
    return affected


def _restore_affected_to_baseline(obj, affected=None):
    coords, _normals = _baseline_data(obj)
    affected = _affected_data(obj) if affected is None else affected
    for index, _weight in affected:
        obj.data.vertices[index].co = coords[index]


def _capture_pushpull_mask(obj):
    """Copy Blender's transient sculpt mask into AFO-owned mask storage."""
    values = _mask_values(obj)
    if values is None:
        return False
    previous = _affected_data(obj)
    if previous:
        _restore_affected_to_baseline(obj, previous)
    attr = _pushpull_mask_attribute(obj.data, create=True)
    for item, value in zip(attr.data, values):
        item.value = value
    obj["parafly_afo_pushpull_mask_revision"] = int(
        obj.get("parafly_afo_pushpull_mask_revision", 0)
    ) + 1
    _mask_cache.clear()
    return max(values, default=0.0) > 1e-4


def _restore_mask_for_painting(obj):
    dedicated = _pushpull_mask_attribute(obj.data)
    if dedicated is None:
        return
    sculpt_mask = obj.data.attributes.get('.sculpt_mask')
    if sculpt_mask is None:
        sculpt_mask = obj.data.attributes.new('.sculpt_mask', 'FLOAT', 'POINT')
    for target, source in zip(sculpt_mask.data, dedicated.data):
        target.value = source.value


def _cancel_pending_pushpull_preview():
    if bpy.app.timers.is_registered(_flush_pushpull_preview):
        bpy.app.timers.unregister(_flush_pushpull_preview)


def _schedule_pushpull_preview(context):
    _cancel_pending_pushpull_preview()
    bpy.app.timers.register(
        _flush_pushpull_preview,
        first_interval=PREVIEW_DEBOUNCE_SECONDS,
    )


def _flush_pushpull_preview():
    context = bpy.context
    obj = context.scene.paraforge_active_object
    if obj is None or obj.type != 'MESH' or not obj.get(SOURCE_KEY):
        return None
    if obj.mode == 'SCULPT':
        _capture_pushpull_mask(obj)
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except RuntimeError:
            return None
    _apply_preview(context)
    return None


def _apply_preview(context):
    scene = context.scene
    obj = scene.paraforge_active_object
    if obj is None or obj.type != 'MESH' or not obj.get(SOURCE_KEY):
        return False, "Click Paint Region first to create the protected AFO working copy"

    affected = _affected_data(obj)
    if not affected and obj.data.attributes.get('.sculpt_mask') is not None:
        _capture_pushpull_mask(obj)
        affected = _affected_data(obj)
    if not affected:
        return False, "The mask is empty. Paint a region first"

    coords, normals = _baseline_data(obj)
    if len(coords) != len(obj.data.vertices):
        return False, "Mesh topology changed after Push/Pull was initialised"

    amount = abs(scene.parafly_afo_pushpull_amount)
    sign = 1.0 if scene.parafly_afo_pushpull_direction == 'PULL' else -1.0
    # The painted mask already contains Blender's brush falloff. This exponent
    # controls how far its soft edge contributes without ever moving mask=0.
    exponent = 2.0 - 1.8 * scene.parafly_afo_pushpull_falloff
    for index, mask_value in affected:
        vert = obj.data.vertices[index]
        base = coords[index]
        normal = normals[index]
        weight = mask_value ** exponent
        vert.co = base + normal * (amount * sign * weight)
    obj.data.update()
    return True, f"Previewed {scene.parafly_afo_pushpull_direction.lower()} at {amount:.1f} mm"


class PARAFORGE_OT_afo_pushpull_paint(bpy.types.Operator):
    bl_idname = "paraforge.afo_pushpull_paint"
    bl_label = "Paint Push/Pull Region"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = _ensure_working_copy(context)
        if obj is None:
            self.report({'ERROR'}, "No AFO mesh is loaded")
            return {'CANCELLED'}
        _baseline_attribute(obj.data, create=True)
        _restore_mask_for_painting(obj)
        if context.mode != 'SCULPT':
            bpy.ops.object.mode_set(mode='SCULPT')
        # Blender 4.3+ uses brush assets; this helper is already verified
        # against the bundled Blender 5.1 Mask asset.
        _force_mask_brush(context)
        sculpt = context.tool_settings.sculpt
        if sculpt:
            sculpt.use_symmetry_x = False
            sculpt.use_symmetry_y = False
            sculpt.use_symmetry_z = False
            # Blender 5.1 removed Sculpt.show_mask; masks remain visible in
            # Sculpt mode, while older versions still expose the toggle.
            if hasattr(sculpt, "show_mask"):
                sculpt.show_mask = True
        unified = getattr(sculpt, "unified_paint_settings", None)
        if unified is not None:
            unified.use_unified_size = True
            unified.size = context.scene.parafly_afo_pushpull_brush_size
            unified.use_unified_strength = True
            unified.strength = context.scene.parafly_afo_pushpull_brush_strength
        else:
            brush = getattr(sculpt, "brush", None)
            if brush is not None:
                brush.size = context.scene.parafly_afo_pushpull_brush_size
                brush.strength = context.scene.parafly_afo_pushpull_brush_strength
        self.report({'INFO'}, "Paint the Push/Pull region with Blender's Mask brush")
        return {'FINISHED'}


class PARAFORGE_OT_afo_pushpull_preview(bpy.types.Operator):
    bl_idname = "paraforge.afo_pushpull_preview"
    bl_label = "Preview Push/Pull"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        ok, message = _apply_preview(context)
        self.report({'INFO'} if ok else {'WARNING'}, message)
        return {'FINISHED'} if ok else {'CANCELLED'}


class PARAFORGE_OT_afo_pushpull_apply(bpy.types.Operator):
    bl_idname = "paraforge.afo_pushpull_apply"
    bl_label = "Apply Push/Pull"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        ok, message = _apply_preview(context)
        if not ok:
            self.report({'WARNING'}, message)
            return {'CANCELLED'}
        context.scene.paraforge_active_object["parafly_afo_pushpull_applied"] = True
        self.report({'INFO'}, "Push/Pull applied; Reset still restores the exact baseline")
        return {'FINISHED'}


class PARAFORGE_OT_afo_pushpull_reset(bpy.types.Operator):
    bl_idname = "paraforge.afo_pushpull_reset"
    bl_label = "Reset Push/Pull"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if obj is None or not obj.get(SOURCE_KEY):
            self.report({'WARNING'}, "Push/Pull has not been initialised")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        _cancel_pending_pushpull_preview()
        _restore_affected_to_baseline(obj)
        obj.data.update()
        obj["parafly_afo_pushpull_applied"] = False
        self.report({'INFO'}, "Push/Pull reset to the exact stored baseline")
        return {'FINISHED'}


class PARAFORGE_OT_afo_pushpull_clear_mask(bpy.types.Operator):
    bl_idname = "paraforge.afo_pushpull_clear_mask"
    bl_label = "Clear Push/Pull Mask"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if obj is None or obj.type != 'MESH':
            return {'CANCELLED'}
        _cancel_pending_pushpull_preview()
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        if obj.get(SOURCE_KEY):
            _restore_affected_to_baseline(obj)
        dedicated = _pushpull_mask_attribute(obj.data)
        if dedicated is not None:
            obj.data.attributes.remove(dedicated)
        obj["parafly_afo_pushpull_mask_revision"] = int(
            obj.get("parafly_afo_pushpull_mask_revision", 0)
        ) + 1
        _mask_cache.clear()
        clear_mask(obj)
        obj.data.update()
        self.report({'INFO'}, "Push/Pull mask cleared")
        return {'FINISHED'}
