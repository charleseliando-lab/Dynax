# paraforge/operators/mesh_prep.py - Preparation stage: remesh, align + manual
# rotation fine-tune, ready-to-map.
#
# Rotate & Align reuse Creator's operators (dynax.align_scan / dynax.rotate_x90 /
# dynax.rotate_y90 / dynax.rotate_z90) directly from the panel — no wrapper needed,
# they already operate on context.active_object with no ParaForge-specific state.
#
# v2 (SPEC_paraforge_v2_full_rebuild.md Section 3): Clean Mesh removed from
# Preparation, replaced by the Smooth Brush section (paraforge/operators/
# smooth_brush.py) — PARAFORGE_OT_clean_mesh and its bmesh remove_doubles/
# recalc_normals pass are gone.
#
# v2 Section 4: manual XYZ rotation fine-tune after Auto Align, via
# apply_manual_rotation() (live, called from each rotation slider's update
# callback) and PARAFORGE_OT_apply_rotation (bakes it with transform_apply and
# resets the three sliders back to 0 — matches the reference spec's own design:
# the sliders are an ephemeral live offset, not a running total).
#
# Remesh is NOT a call to Creator's dynax.auto_remesh either: that operator only
# exposes LOW/MEDIUM/HIGH face-count presets, not a raw voxel-size float, and the
# spec explicitly wants scene.paraforge_remesh_voxel_size as an adjustable slider.
# The underlying technique (REMESH modifier, mode='VOXEL', modifier_apply) mirrors
# auto_remesh.py's own established, crash-safe approach.
#
# NOTE on units: the reference spec's scene.paraforge_remesh_voxel_size defaulted
# to 0.003 assuming 1 Blender unit = 1 metre. DynaX runs in mm-space instead
# (scale_length = 0.001, so 1 Blender unit = 1 mm — see CLAUDE.md "Unit System
# Architecture"); the property is defined in __init__.py with an mm-scale
# default/range (default 3.0 mm, matching auto_remesh.py's MIN_VOXEL = 1.5 mm
# floor) instead of the metre-scale value the spec's own example used, which would
# have produced a near-zero voxel size and an unusably dense (or crashing) remesh.

import bpy
import math
from bpy.types import Operator


class PARAFORGE_OT_remesh(Operator):
    """Voxel remesh the scan at the configured resolution"""
    bl_idname = "paraforge.remesh"
    bl_label = "Remesh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No ParaForge scan to remesh")
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        voxel_size = max(0.1, context.scene.paraforge_remesh_voxel_size)

        remesh_mod = obj.modifiers.new(name="ParaForge_Remesh", type='REMESH')
        remesh_mod.mode = 'VOXEL'
        remesh_mod.voxel_size = voxel_size
        remesh_mod.adaptivity = 0.0
        remesh_mod.use_smooth_shade = True

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        try:
            bpy.ops.object.modifier_apply(modifier=remesh_mod.name)
        except Exception as e:
            if remesh_mod.name in obj.modifiers:
                obj.modifiers.remove(remesh_mod)
            self.report({'ERROR'}, f"Remesh failed: {e}")
            return {'CANCELLED'}

        verts = len(obj.data.vertices)
        faces = len(obj.data.polygons)
        self.report({'INFO'}, f"✓ Remeshed at {voxel_size:.2f} mm: {verts:,} verts / {faces:,} faces")
        return {'FINISHED'}


class PARAFORGE_OT_ready_begin_mapping(Operator):
    """Preparation complete — unlock Clinical Mapping"""
    bl_idname = "paraforge.ready_begin_mapping"
    bl_label = "✓ Ready — Begin Clinical Mapping"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No ParaForge scan is loaded")
            return {'CANCELLED'}
        context.scene.paraforge_stage = 'MAPPING'
        context.scene.paraforge_mapping_step = 0
        return {'FINISHED'}


def apply_manual_rotation(context):
    """Live preview: set the object's rotation_euler directly from the three
    fine-tune sliders. Ephemeral until PARAFORGE_OT_apply_rotation bakes it —
    the sliders are an absolute offset from 0, not additive, so re-entering this
    with all three at 0 is always a no-op."""
    obj = context.scene.paraforge_active_object
    if obj is None:
        return
    rx = math.radians(context.scene.paraforge_manual_rot_x)
    ry = math.radians(context.scene.paraforge_manual_rot_y)
    rz = math.radians(context.scene.paraforge_manual_rot_z)
    obj.rotation_euler = (rx, ry, rz)


class PARAFORGE_OT_apply_rotation(Operator):
    """Bake the fine-tune rotation into the mesh and reset the sliders to 0"""
    bl_idname = "paraforge.apply_rotation"
    bl_label = "Apply Rotation"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No ParaForge scan is loaded")
            return {'CANCELLED'}

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.transform_apply(rotation=True, location=False, scale=False)

        # Reset the sliders without re-triggering apply_manual_rotation's live
        # preview against an already-baked (now-zero) rotation — harmless either
        # way since it would just set rotation_euler back to (0,0,0), which is
        # already true post-bake, but assigning the scene props directly (not
        # through the operator) is what actually resets the widgets.
        context.scene.paraforge_manual_rot_x = 0.0
        context.scene.paraforge_manual_rot_y = 0.0
        context.scene.paraforge_manual_rot_z = 0.0

        self.report({'INFO'}, "Rotation applied")
        return {'FINISHED'}
