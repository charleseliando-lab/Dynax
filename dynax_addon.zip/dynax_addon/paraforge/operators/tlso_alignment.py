# paraforge/operators/tlso_alignment.py - Orientation & Alignment stage for TLSO:
# three fixed reference planes (axial/sagittal/coronal) the clinician aligns the
# torso scan against using live position/rotation sliders, then bakes.
#
# Three real bugs fixed vs. SPEC_parafly_tlso_complete.md, found by actually
# checking rather than trusting the spec's code:
#
# 1. UNITS (the same class of bug already found twice in this addon's history -
#    voxel remesh size, slider deformation /1000): the spec's PLANE_SIZE = 0.5
#    was commented "metres", then used directly as a raw primitive_plane_add
#    size with no conversion. DynaX is mm-space (1 Blender unit = 1 mm), so a
#    raw value of 0.5 produces a 0.5 mm plane - literally invisible next to a
#    torso scan that's hundreds of mm across. Fixed to an explicit mm value
#    generously larger than a typical torso scan.
#
# 2. SAGITTAL/CORONAL ROTATIONS SWAPPED: verified independently with
#    mathutils.Euler rather than trusting the spec's rotation tuples. The
#    spec's "SAGITTAL" rotation (90,0,0) actually rotates the plane's normal
#    (starting at +Z) to -Y (front-back axis) - that's a plane whose face
#    divides anterior/posterior, i.e. anatomically a CORONAL plane, not
#    sagittal. Its "CORONAL" rotation (90,0,90) rotates the normal to +X
#    (left-right axis) - a plane dividing left/right, i.e. actually SAGITTAL.
#    The two rotation values were swapped between the two labels; fixed here.
#
# 3. scene.parafly_active_object doesn't exist in this addon - there's already
#    a single shared "current ParaFly working object" property,
#    scene.paraforge_active_object (used by both the existing TT workflow and
#    now TLSO, since only one device workflow is ever active at a time). Not
#    introducing a second, parallel active-object property for TLSO alone.
#
# Also: this addon's existing ParaFly (TT) operators are all under the
# "paraforge.*" bl_idname namespace (paraforge.confirm_zone, paraforge.remesh,
# etc.) - not "parafly.*" as the spec assumes (this addon's internal package is
# dynax_addon.paraforge, not a top-level parafly package; see
# tlso_zone_reader.py's docstring for the same path deviation). TLSO's new
# operators stay under that same "paraforge.tlso_*" namespace for consistency
# rather than introducing a third operator-naming scheme alongside dynax.* and
# paraforge.*.

import bpy
import math

PLANE_NAMES = {
    'AXIAL': 'parafly_tlso_plane_axial',
    'SAGITTAL': 'parafly_tlso_plane_sagittal',
    'CORONAL': 'parafly_tlso_plane_coronal',
}

PLANE_COLORS = {
    'AXIAL': (1.0, 0.2, 0.2, 0.25),      # Red, semi-transparent
    'SAGITTAL': (0.2, 0.8, 0.2, 0.25),   # Green
    'CORONAL': (0.2, 0.4, 1.0, 0.25),    # Blue
}

# mm-space (see module docstring #1) - edge length is PLANE_HALF_SIZE_MM * 2,
# generously larger than a typical torso scan (roughly 300-600 mm across) so
# the planes are visibly useful reference guides, not lost against the mesh.
PLANE_HALF_SIZE_MM = 500.0

# Rotations verified with mathutils.Euler against the actual resulting plane
# normal (see module docstring #2) - AXIAL needs no rotation (default plane
# normal +Z already = vertical/waist-level), SAGITTAL's normal must end up
# along X (left-right), CORONAL's along Y (front-back).
PLANE_ROTATIONS = {
    'AXIAL': (0, 0, 0),
    'SAGITTAL': (math.radians(90), 0, math.radians(90)),
    'CORONAL': (math.radians(90), 0, 0),
}


def create_reference_plane(name, rotation_euler, color):
    """Create a single semi-transparent reference plane."""
    bpy.ops.mesh.primitive_plane_add(size=PLANE_HALF_SIZE_MM * 2, location=(0, 0, 0))
    plane = bpy.context.active_object
    plane.name = name
    plane.rotation_euler = rotation_euler
    plane.display_type = 'WIRE'
    plane.hide_select = True
    plane.hide_render = True

    mat = bpy.data.materials.new(name=f"{name}_mat")
    mat.use_nodes = True
    mat.blend_method = 'BLEND'
    bsdf = mat.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = color
        bsdf.inputs["Alpha"].default_value = color[3]
    plane.data.materials.append(mat)
    return plane


class PARAFORGE_OT_tlso_add_alignment_planes(bpy.types.Operator):
    """Add axial, sagittal, and coronal reference planes"""
    bl_idname = "paraforge.tlso_add_alignment_planes"
    bl_label = "Add Alignment Planes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.paraforge.tlso_remove_alignment_planes()
        for key in ('AXIAL', 'SAGITTAL', 'CORONAL'):
            create_reference_plane(PLANE_NAMES[key], PLANE_ROTATIONS[key], PLANE_COLORS[key])

        context.scene.parafly_tlso_planes_active = True
        self.report({'INFO'}, "Alignment planes added. Move the mesh to align with the planes.")
        return {'FINISHED'}


class PARAFORGE_OT_tlso_remove_alignment_planes(bpy.types.Operator):
    """Remove the alignment reference planes without applying anything"""
    bl_idname = "paraforge.tlso_remove_alignment_planes"
    bl_label = "Remove Alignment Planes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for name in PLANE_NAMES.values():
            obj = bpy.data.objects.get(name)
            if obj:
                bpy.data.objects.remove(obj, do_unlink=True)
        context.scene.parafly_tlso_planes_active = False
        return {'FINISHED'}


class PARAFORGE_OT_tlso_apply_alignment(bpy.types.Operator):
    """Bake the alignment transform, remove the planes, and unlock Clinical Mapping"""
    bl_idname = "paraforge.tlso_apply_alignment"
    bl_label = "Apply Alignment"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if obj is None:
            self.report({'ERROR'}, "No TLSO scan is loaded")
            return {'CANCELLED'}

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

        bpy.ops.paraforge.tlso_remove_alignment_planes()

        # Reset the fine-tune sliders now that their offset is baked in, same
        # pattern as TT's paraforge.apply_rotation.
        context.scene.parafly_tlso_pos_x = 0.0
        context.scene.parafly_tlso_pos_y = 0.0
        context.scene.parafly_tlso_pos_z = 0.0
        context.scene.parafly_tlso_rot_x = 0.0
        context.scene.parafly_tlso_rot_y = 0.0
        context.scene.parafly_tlso_rot_z = 0.0

        context.scene.parafly_tlso_stage = 'MAPPING'
        context.scene.parafly_tlso_mapping_step = 0
        self.report({'INFO'}, "Alignment applied. Ready for Clinical Mapping.")
        return {'FINISHED'}


def apply_tlso_alignment_transform(context):
    """Live preview: set the object's location/rotation directly from the six
    fine-tune sliders. Ephemeral until Apply Alignment bakes it - mirrors TT's
    apply_manual_rotation (mesh_prep.py), extended to also cover position."""
    obj = context.scene.paraforge_active_object
    if obj is None:
        return
    scene = context.scene
    obj.location = (scene.parafly_tlso_pos_x, scene.parafly_tlso_pos_y, scene.parafly_tlso_pos_z)
    obj.rotation_euler = (
        math.radians(scene.parafly_tlso_rot_x),
        math.radians(scene.parafly_tlso_rot_y),
        math.radians(scene.parafly_tlso_rot_z),
    )
