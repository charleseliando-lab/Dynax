# paraforge/operators/project_io.py - Save/Load a ParaFly session as a .paraforge
# JSON sidecar next to the saved .blend (SPEC_paraforge_v2_full_rebuild.md Section 6).
#
# Deviation from the reference spec: it stores/restores scene.dynax_active_workflow,
# which is part of this spec's startup-menu rebuild (Section 1) that was NOT
# implemented as originally speced — the actual menu restructure this project
# ended up with instead is dynax_panel.py's Start Menu -> New Case -> ParaForge
# sub-menu -> ParaForm/ParaFly. This stores/restores props.dynax_mode instead
# (the nav property this addon actually uses), targeting 'PARAFORGE_ZONES' so a
# loaded project lands back on this same panel.
#
# Slider values are stored/restored under "parafly_slider_" property names
# (renamed from "paraforge_slider_"), matched case-insensitively against the
# saved zone id so a project saved before zone ids were lowercase-normalized
# still restores correctly.
#
# Extended for TLSO (SPEC_parafly_tlso_complete.md): the saved JSON always
# includes both device workflows' state (parafly_device_type plus TT and TLSO
# stage/step/slider fields) rather than a conditional per-device schema, so a
# project always round-trips regardless of which device was active — simpler
# than branching the file format, and the unused half is just a few small
# always-zero/default fields when the other device was in use.
#
# Extended again for AFO (SPEC_parafly_afo_complete.md, format version bumped
# to 1.2): not in that spec at all, but its own AFO panel
# (panels/parafly_afo_panel.py) reuses this same "Save Project" button - a
# clinician clicking it partway through AFO's landmark/correction/mapping/
# measurement workflow would silently lose all of that progress every single
# save without this. Same pattern as the TLSO extension above: stage,
# mapping step, landmarks JSON, the 4 correction angles, measurements JSON,
# and slider values always round-trip alongside TT/TLSO's own fields.

import bpy
import json
import os
from bpy.types import Operator
from bpy.props import StringProperty
from bpy_extras.io_utils import ExportHelper, ImportHelper

from ..zone_reader import get_zone_names
from ..tlso_zone_reader import get_tlso_zone_names
from ..afo_zone_reader import get_afo_zone_names

PROJECT_FORMAT_VERSION = "1.4"


class PARAFORGE_OT_save_project(Operator, ExportHelper):
    """Save the current ParaForge session (stage, slider values, rotation) as a
    .paraforge file, and save the .blend alongside it"""
    bl_idname = "paraforge.save_project"
    bl_label = "Save Project"
    bl_options = {'REGISTER'}

    filename_ext = ".paraforge"
    filter_glob: StringProperty(default="*.paraforge", options={'HIDDEN'})

    def execute(self, context):
        scene = context.scene
        obj = scene.paraforge_active_object

        # Real bug found and fixed (round 2): the .blend (which actually
        # holds the scan/cut mesh - .paraforge is just a JSON sidecar of
        # scene properties, never mesh data) previously only got a fresh
        # save-as-next-to-the-.paraforge treatment when NO .blend had ever
        # been saved before. If the .blend HAD already been saved earlier -
        # to any folder, e.g. from a much earlier session - this just
        # resaved it in that ORIGINAL location via save_mainfile(), even
        # though the user had just chosen a totally different folder for the
        # .paraforge via this operator's own file browser. Result: the two
        # files end up in different folders, and the .blend is easy to miss
        # sitting somewhere else entirely (exactly the reported "the folder
        # wasn't showing the .blend file" confusion) - the code silently
        # trusted stale save history over the destination the user had just
        # picked. Fixed: the .blend is now ALWAYS placed next to the chosen
        # .paraforge path with the same base name (project.paraforge +
        # project.blend, always paired, every save) - a real save-as to that
        # exact location whenever the current .blend isn't already there,
        # not just when there was never a previous save.
        blend_path = os.path.splitext(self.filepath)[0] + ".blend"
        try:
            if bpy.data.filepath != blend_path:
                bpy.ops.wm.save_as_mainfile(filepath=blend_path)
            else:
                bpy.ops.wm.save_mainfile()
        except Exception as e:
            self.report({'ERROR'}, f"Could not save the .blend file: {e}")
            return {'CANCELLED'}

        slider_values = {}
        for zone_id in get_zone_names():
            prop_name = f"parafly_slider_{zone_id}"
            slider_values[zone_id] = getattr(scene, prop_name, 0.0)

        tlso_slider_values = {}
        for zone_id in get_tlso_zone_names():
            prop_name = f"parafly_tlso_slider_{zone_id}"
            tlso_slider_values[zone_id] = getattr(scene, prop_name, 0.0)

        afo_slider_values = {}
        for zone_id in get_afo_zone_names():
            prop_name = f"parafly_afo_slider_{zone_id}"
            afo_slider_values[zone_id] = getattr(scene, prop_name, 0.0)

        try:
            afo_landmarks = json.loads(getattr(scene, "parafly_afo_landmarks", "{}"))
        except Exception:
            afo_landmarks = {}
        from .afo_landmarks import normalize_landmarks
        afo_landmarks = normalize_landmarks(afo_landmarks)
        try:
            afo_measurements = json.loads(getattr(scene, "parafly_afo_measurements", "[]"))
        except Exception:
            afo_measurements = []

        data = {
            "version": PROJECT_FORMAT_VERSION,
            "workflow": "PARAFORGE_ZONES",
            "device_type": getattr(scene, "parafly_device_type", 'TT'),
            "stage": scene.paraforge_stage,
            "mapping_step": scene.paraforge_mapping_step,
            "object_name": obj.name if obj else "",
            "blend_file": blend_path,
            "slider_values": slider_values,
            "smooth_strength": scene.paraforge_smooth_strength,
            "rotation": list(obj.rotation_euler) if obj else [0.0, 0.0, 0.0],
            # TLSO-specific state — harmless no-ops when device_type == 'TT'.
            "tlso_stage": getattr(scene, "parafly_tlso_stage", 'INPUT'),
            "tlso_mapping_step": getattr(scene, "parafly_tlso_mapping_step", 0),
            "tlso_slider_values": tlso_slider_values,
            # AFO-specific state — harmless no-ops when a different device
            # was active.
            "afo_stage": getattr(scene, "parafly_afo_stage", 'INPUT'),
            "afo_mapping_step": getattr(scene, "parafly_afo_mapping_step", 0),
            "afo_landmarks": afo_landmarks,
            "afo_ankle_angle": getattr(scene, "parafly_afo_ankle_angle", 0.0),
            "afo_footroll_angle": getattr(scene, "parafly_afo_footroll_angle", 0.0),
            "afo_forefoot_angle": getattr(scene, "parafly_afo_forefoot_angle", 0.0),
            "afo_forefoot_vertical_angle": getattr(
                scene, "parafly_afo_forefoot_vertical_angle", 0.0
            ),
            "afo_pushpull_direction": getattr(
                scene, "parafly_afo_pushpull_direction", 'PULL'
            ),
            "afo_pushpull_amount": getattr(
                scene, "parafly_afo_pushpull_amount", 2.0
            ),
            "afo_pushpull_falloff": getattr(
                scene, "parafly_afo_pushpull_falloff", 0.65
            ),
            "afo_trimline_mode": getattr(
                scene, "parafly_afo_trimline_mode", 'KEEP'
            ),
            "afo_trimline_smooth_passes": getattr(
                scene, "parafly_afo_trimline_smooth_passes", 4
            ),
            "afo_trimline_smooth_strength": getattr(
                scene, "parafly_afo_trimline_smooth_strength", 0.35
            ),
            "afo_heeltilt_angle": getattr(scene, "parafly_afo_heeltilt_angle", 0.0),
            "afo_measurements": afo_measurements,
            "afo_slider_values": afo_slider_values,
        }

        try:
            with open(self.filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
        except OSError as e:
            self.report({'ERROR'}, f"Could not write project file: {e}")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Project saved: {self.filepath}")
        return {'FINISHED'}


class PARAFORGE_OT_load_project(Operator, ImportHelper):
    """Load a previously saved ParaForge session (pick either the .paraforge
    or its paired .blend - they're always saved side by side, same name)"""
    bl_idname = "paraforge.load_project"
    bl_label = "Load Saved Project"
    bl_options = {'REGISTER'}

    filename_ext = ".paraforge"
    # User request: the browser previously only showed .paraforge files, so
    # the paired .blend PARAFORGE_OT_save_project always creates right next
    # to it (same base name) was invisible/unselectable here even though
    # it's sitting in the same folder - confusing since the two are always
    # saved as a pair. Now shows both; whichever one is picked, the actual
    # project state always comes from the .paraforge JSON (the .blend has no
    # ParaFly-specific data of its own to read) - see the extension check
    # below.
    filter_glob: StringProperty(default="*.paraforge;*.blend", options={'HIDDEN'})

    def execute(self, context):
        # Resolve to the actual .paraforge JSON regardless of which paired
        # file the user picked - PARAFORGE_OT_save_project always names them
        # identically except for extension, in the same folder.
        if self.filepath.lower().endswith(".blend"):
            json_path = os.path.splitext(self.filepath)[0] + ".paraforge"
            if not os.path.exists(json_path):
                self.report({'ERROR'},
                    f"No matching .paraforge project file found next to "
                    f"{os.path.basename(self.filepath)} - looked for "
                    f"{os.path.basename(json_path)} in the same folder.")
                return {'CANCELLED'}
        else:
            json_path = self.filepath

        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            self.report({'ERROR'}, f"Could not read project file: {e}")
            return {'CANCELLED'}

        # Real bug found and fixed: bpy.ops.wm.open_mainfile() fully replaces
        # bpy.data (every scene/object Python reference from before the call
        # is invalidated - a well-documented Blender pitfall). The previous
        # code called it, then kept using `scene = context.scene` and every
        # `obj = bpy.data.objects[...]` captured/resolved from that SAME
        # execute() call - all of which silently applied to the freed OLD
        # scene, never the newly-loaded one. That's exactly why the report
        # said "Project loaded successfully" while nothing visibly changed:
        # the report always ran, but every state-restoring write before it
        # landed nowhere. Fixed by only doing the state-restore synchronously
        # when NO reload happens (blend_file matches what's already open);
        # when a reload is needed, the restore is deferred to a bpy.app.timers
        # callback that re-fetches bpy.context.scene fresh AFTER the new file
        # has finished loading - the same deferred-callback technique this
        # addon already uses elsewhere for "must run after state settles"
        # cases (see __init__.py's _register_sliders_deferred).
        blend_path = data.get("blend_file", "")

        # Real bug found and fixed: this used to always report "loaded
        # successfully" regardless of whether a .blend was ever actually
        # available to reload - a project saved before PARAFORGE_OT_save_project's
        # own "always save-as if never saved before" fix has an EMPTY
        # blend_file, meaning there is genuinely no mesh anywhere to bring
        # back; a project whose blend_file was later moved/deleted has a
        # non-empty but non-existent path. Both cases now report clearly
        # instead of a false-positive success message.
        if not blend_path:
            self.report({'WARNING'},
                "Project state loaded, but this project has no saved .blend "
                "file - the scan/cut mesh can't be restored. Re-save the "
                "project to fix this for next time.")
            _restore_project_state(data)
            return {'FINISHED'}

        if not os.path.exists(blend_path):
            self.report({'ERROR'},
                f"Project state loaded, but the .blend file is missing: {blend_path}")
            _restore_project_state(data)
            return {'FINISHED'}

        if bpy.data.filepath != blend_path:
            bpy.ops.wm.open_mainfile(filepath=blend_path)
            bpy.app.timers.register(lambda: _restore_project_state(data), first_interval=0.1)
        else:
            _restore_project_state(data)

        self.report({'INFO'}, "Project loaded successfully")
        return {'FINISHED'}


def _restore_project_state(data):
    """Apply saved ParaFly state to whatever scene is ACTUALLY current right
    now - always re-fetches bpy.context.scene fresh rather than trusting any
    context/scene reference captured before a possible file reload (see
    PARAFORGE_OT_load_project.execute()'s note on why that's unsafe)."""
    scene = bpy.context.scene
    scene.dynax_props.dynax_mode = 'PARAFORGE_ZONES'
    if hasattr(scene, "parafly_device_type"):
        scene.parafly_device_type = data.get("device_type", 'TT')
    scene.paraforge_stage = data.get("stage", "INPUT")
    scene.paraforge_mapping_step = data.get("mapping_step", 0)
    scene.paraforge_smooth_strength = data.get("smooth_strength", 0.5)
    if hasattr(scene, "parafly_tlso_stage"):
        scene.parafly_tlso_stage = data.get("tlso_stage", "INPUT")
    if hasattr(scene, "parafly_tlso_mapping_step"):
        scene.parafly_tlso_mapping_step = data.get("tlso_mapping_step", 0)
    if hasattr(scene, "parafly_afo_stage"):
        scene.parafly_afo_stage = data.get("afo_stage", "INPUT")
    if hasattr(scene, "parafly_afo_mapping_step"):
        scene.parafly_afo_mapping_step = data.get("afo_mapping_step", 0)
    if hasattr(scene, "parafly_afo_landmarks"):
        from .afo_landmarks import normalize_landmarks
        scene.parafly_afo_landmarks = json.dumps(
            normalize_landmarks(data.get("afo_landmarks", {}))
        )
    if hasattr(scene, "parafly_afo_measurements"):
        scene.parafly_afo_measurements = json.dumps(data.get("afo_measurements", []))

    obj_name = data.get("object_name", "")
    if obj_name and obj_name in bpy.data.objects:
        obj = bpy.data.objects[obj_name]
        scene.paraforge_active_object = obj
        rotation = data.get("rotation")
        if rotation and len(rotation) == 3:
            obj.rotation_euler = rotation
    else:
        scene.paraforge_active_object = None
        if obj_name:
            # The .blend loaded fine but doesn't contain the object this
            # project expects (e.g. renamed/deleted after the project was
            # saved) - printed to console since this runs from a deferred
            # timer callback with no operator `self` to self.report() from.
            print(f"[ParaFly] Project load: object '{obj_name}' not found "
                  f"in the loaded .blend - workflow state restored, but no "
                  f"scan is active.")

    # AFO's 4 correction-angle FloatProperties have update= callbacks
    # (afo_correction._apply_afo_corrections) that read
    # scene.paraforge_active_object - restored AFTER the object resolution
    # block above so the live re-deformation they trigger actually has an
    # object to act on, instead of silently no-op'ing against a still-None
    # PointerProperty.
    if hasattr(scene, "parafly_afo_ankle_angle"):
        scene.parafly_afo_ankle_angle = data.get("afo_ankle_angle", 0.0)
    if hasattr(scene, "parafly_afo_footroll_angle"):
        scene.parafly_afo_footroll_angle = data.get("afo_footroll_angle", 0.0)
    if hasattr(scene, "parafly_afo_forefoot_angle"):
        scene.parafly_afo_forefoot_angle = data.get("afo_forefoot_angle", 0.0)
    if hasattr(scene, "parafly_afo_forefoot_vertical_angle"):
        scene.parafly_afo_forefoot_vertical_angle = data.get(
            "afo_forefoot_vertical_angle", 0.0
        )
    if hasattr(scene, "parafly_afo_pushpull_direction"):
        scene.parafly_afo_pushpull_direction = data.get(
            "afo_pushpull_direction", 'PULL'
        )
    if hasattr(scene, "parafly_afo_pushpull_amount"):
        scene.parafly_afo_pushpull_amount = data.get(
            "afo_pushpull_amount", 2.0
        )
    if hasattr(scene, "parafly_afo_pushpull_falloff"):
        scene.parafly_afo_pushpull_falloff = data.get(
            "afo_pushpull_falloff", 0.65
        )
    if hasattr(scene, "parafly_afo_trimline_mode"):
        scene.parafly_afo_trimline_mode = data.get(
            "afo_trimline_mode", 'KEEP'
        )
    if hasattr(scene, "parafly_afo_trimline_smooth_passes"):
        scene.parafly_afo_trimline_smooth_passes = data.get(
            "afo_trimline_smooth_passes", 4
        )
    if hasattr(scene, "parafly_afo_trimline_smooth_strength"):
        scene.parafly_afo_trimline_smooth_strength = data.get(
            "afo_trimline_smooth_strength", 0.35
        )
    if hasattr(scene, "parafly_afo_heeltilt_angle"):
        scene.parafly_afo_heeltilt_angle = data.get("afo_heeltilt_angle", 0.0)

    for zone_id, value in data.get("slider_values", {}).items():
        # .lower() so a project saved before the zone-id lowercase
        # normalization (e.g. "Zone_Brim") still matches the registered
        # "parafly_slider_zone_brim" property.
        prop_name = f"parafly_slider_{zone_id.lower()}"
        if hasattr(scene, prop_name):
            setattr(scene, prop_name, value)

    for zone_id, value in data.get("tlso_slider_values", {}).items():
        prop_name = f"parafly_tlso_slider_{zone_id.lower()}"
        if hasattr(scene, prop_name):
            setattr(scene, prop_name, value)

    for zone_id, value in data.get("afo_slider_values", {}).items():
        prop_name = f"parafly_afo_slider_{zone_id.lower()}"
        if hasattr(scene, prop_name):
            setattr(scene, prop_name, value)

    # Force a redraw so the restored state shows immediately rather than
    # waiting for the next unrelated UI event.
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
    except Exception:
        pass
