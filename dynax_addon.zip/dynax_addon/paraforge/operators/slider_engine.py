# paraforge/operators/slider_engine.py - Clinical Adjustment stage: the parametric
# slider engine that drives real-time mesh deformation from clinical zone vertex
# groups.
#
# v2 (SPEC_paraforge_v2_full_rebuild.md): zone ids now come from
# zone_reader.get_zone_names() (read from tt_reference_rigged.blend) instead of
# the hardcoded TRANSTIBIAL_ZONES list; metadata is looked up per-zone via
# zone_definitions.get_zone_meta(). See zone_reader.py's docstring for a real
# mismatch found between the v2 spec's assumptions and the actual reference
# file's contents.
#
# Slider scene properties are prefixed "parafly_slider_" (renamed from
# "paraforge_slider_" — this workflow is user-facing as ParaFly, not ParaForge;
# ParaForm is a separate, untouched workflow). Zone ids from get_zone_names() are
# lowercase-normalized; vertex-group lookups go through
# zone_reader.find_vertex_group() for a case-insensitive match rather than
# obj.vertex_groups.get(), which is exact-case only.
#
# Two corrections vs. the original v1 reference spec, both found while implementing this
# (documented here per this project's own established practice of flagging
# spec-vs-implementation deltas — see CLAUDE.md):
#
# 1. UNITS: the reference spec's apply_zone_deformation() divided the mm slider
#    value by 1000 ("convert mm to Blender units / metres"). DynaX is mm-space
#    (scene.unit_settings.scale_length = 0.001, i.e. 1 Blender unit = 1 mm — see
#    CLAUDE.md "Unit System Architecture", and offset.py's _mm_to_blender: "DO NOT
#    divide by 1000"). Dividing here would have shrunk every slider's effect
#    ~1000x into invisibility. Removed the /1000.0.
#
# 2. CROSS-ZONE CORRUPTION: the reference spec's apply_zone_deformation(zone_id)
#    reset every vertex NOT in the triggering zone's own vertex group back to its
#    ORIGINAL position, on every single call. Since each slider's update callback
#    calls this function with only ITS OWN zone_id, moving the Patellar Tendon
#    slider would silently wipe out any offset already applied by, say, the Tibial
#    Crest slider — directly contradicting the spec's own documented invariant
#    ("resetting one slider does not corrupt another"). Fixed by always
#    recomputing the FULL mesh from the stored baseline using every zone's current
#    slider value, not just the triggering zone's — the same "sum all bands from
#    the original" approach already proven correct in this codebase's height-band
#    Geometry Nodes rig (parametric_socket.py: "All 5 bands are summed... blended
#    boundary verts get partial contributions from two bands").

import bpy
import json
import bmesh
from mathutils import Vector

try:
    import numpy as np
except ImportError:  # Blender bundles NumPy; keep a safe fallback.
    np = None

from ..zone_reader import get_zone_names, find_vertex_group
from ..zone_definitions import get_zone_meta


# Auto-save of manual edits (smoothing) - mirrors tlso_slider_engine.py's fold
# (see apply_zone_deformation). LAST_APPLIED_KEY is a mesh FLOAT_VECTOR
# attribute holding the exact positions this engine last wrote; comparing it
# against the live mesh reveals any manual Smooth-brush edit made since, so it
# can be folded into the baseline instead of being discarded by the next slider
# recompute.
LAST_APPLIED_KEY = "paraforge_last_applied"
FOLD_EPS = 1e-4   # mm; live-vs-last-applied drift above this is a real edit


def _write_positions_attr(mesh, name, positions_flat):
    """Write a flat float32 (n*3) array into a POINT FLOAT_VECTOR attribute."""
    attr = mesh.attributes.get(name)
    if attr is not None and (attr.domain != 'POINT' or attr.data_type != 'FLOAT_VECTOR'):
        mesh.attributes.remove(attr)
        attr = None
    if attr is None:
        attr = mesh.attributes.new(name, 'FLOAT_VECTOR', 'POINT')
    attr.data.foreach_set("vector", positions_flat)


def _read_positions_attr(mesh, name):
    """Return a (n,3) float64 numpy array from a POINT FLOAT_VECTOR attribute,
    or None if it's missing / numpy is unavailable."""
    if np is None:
        return None
    attr = mesh.attributes.get(name)
    if attr is None:
        return None
    n = len(mesh.vertices)
    flat = np.empty(n * 3, dtype=np.float32)
    attr.data.foreach_get("vector", flat)
    return flat.reshape(n, 3).astype(np.float64)


def _record_last_applied(mesh):
    """Snapshot the mesh's current local positions as the last-applied state."""
    if np is None:
        return
    n = len(mesh.vertices)
    co = np.empty(n * 3, dtype=np.float32)
    mesh.vertices.foreach_get("co", co)
    _write_positions_attr(mesh, LAST_APPLIED_KEY, co)


def store_original_positions(obj):
    """
    Store the local-space vertex positions of obj as the deformation baseline,
    as a JSON string in a custom property so it persists with the .blend file.
    Called at clinical-adjustment entry (mapping_wizard._enter_adjustment_stage)
    and whenever the current shape is (re)baked as the baseline
    (smooth_brush.done_smooth). Also seeds the last-applied snapshot so the
    auto-save fold in apply_zone_deformation starts from a matching reference
    and never mistakes the freshly-baked shape for a pending manual edit.
    """
    mesh = obj.data
    positions = [list(v.co) for v in mesh.vertices]
    obj["paraforge_original_positions"] = json.dumps(positions)
    _record_last_applied(mesh)


def _zone_weights(mesh, vg_index):
    weights = {}
    for v in mesh.vertices:
        for g in v.groups:
            if g.group == vg_index:
                weights[v.index] = g.weight
                break
    return weights


def apply_zone_deformation(context, zone_id=None):
    """
    Recompute the WHOLE mesh from the stored original positions, applying every
    zone's current slider value. `zone_id` is accepted for API parity with each
    slider property's per-property update signature but is otherwise unused — see
    the module docstring for why a partial per-zone update is unsafe here.

    Each zone is pushed along ONE average normal for that zone, not each
    vertex's own normal (same fix as tlso_slider_engine.py's
    apply_tlso_zone_deformation — per-vertex normals are unreliable across a
    large curved surface, producing a deformation that looks correct on some
    vertices and inverted on others within the same zone).
    """
    obj = context.scene.paraforge_active_object
    if obj is None or obj.type != 'MESH':
        return

    raw = obj.get("paraforge_original_positions")
    if raw is None:
        return
    original_positions = json.loads(raw)

    mesh = obj.data
    n = len(mesh.vertices)
    if len(original_positions) != n:
        return  # topology changed since the baseline was stored — nothing safe to do

    # ── Auto-save fold ────────────────────────────────────────────────
    # Every slider move rebuilds the whole mesh from the baseline, so a manual
    # Smooth-brush edit made in between would silently be thrown away. Detect
    # that edit as the difference between the live mesh and the positions we
    # last wrote, and fold it permanently into the baseline so it survives this
    # and every future recompute — no explicit "Done Smoothing" click required.
    # (Mirrors tlso_slider_engine.py's fold.)
    last_applied = _read_positions_attr(mesh, LAST_APPLIED_KEY)
    if last_applied is not None and len(last_applied) == n:
        live = np.empty(n * 3, dtype=np.float32)
        mesh.vertices.foreach_get("co", live)
        delta = live.reshape(n, 3).astype(np.float64) - last_applied
        if np.abs(delta).max() > FOLD_EPS:
            base = np.asarray(original_positions, dtype=np.float64) + delta
            original_positions = base.tolist()
            obj["paraforge_original_positions"] = json.dumps(original_positions)

    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()

    for v in bm.verts:
        v.co = Vector(original_positions[v.index])
    bm.normal_update()
    original_normals = [v.normal.copy() for v in bm.verts]

    for zid in get_zone_names():
        vg = find_vertex_group(obj, zid)
        if vg is None:
            continue
        slider_value = getattr(context.scene, f"parafly_slider_{zid}", 0.0)
        if slider_value == 0.0:
            continue
        weights = _zone_weights(mesh, vg.index)
        if not weights:
            continue

        zone_normals = [original_normals[idx] for idx in weights.keys()]
        avg_normal = sum(zone_normals, Vector()).normalized()
        if avg_normal.length_squared == 0.0:
            continue

        for idx, weight in weights.items():
            bm.verts[idx].co += avg_normal * (slider_value * weight)

    bm.to_mesh(mesh)
    bm.free()
    mesh.update()

    # Remember exactly what we just wrote, so the next call's fold step can tell
    # a real manual edit apart from this engine's own output.
    _record_last_applied(mesh)


def _slider_prop_name(zone_id):
    return f"parafly_slider_{zone_id}"


def _make_update_callback(zone_id):
    """Return a fresh 2-arg (self, context) closure bound to this zone_id.
    Blender's property registration inspects the update callback's signature
    and rejects anything but exactly 2 params, so the zone_id must be captured
    via an enclosing function scope (not a 3rd default-valued lambda param,
    which registers fine syntactically but fails at bpy.utils registration
    time) — and it must be a fresh closure per zone, not one lambda reused in
    a loop, or every zone's slider would update only the LAST zone_id."""
    def _update(self, context):
        apply_zone_deformation(context, zone_id)
    return _update


# SPEC_parafly_slider_and_zone_corrections.md Section 1 ("remove all
# min/max limits, allow unlimited user input"): the previous fix here still
# had a hard ceiling (+/-1000mm) reachable only by typing - superseded per
# explicit request to remove hard limits entirely. No min/max kwargs are
# passed to FloatProperty below at all, so Blender falls back to its own
# default float range (effectively unbounded for any real clinical value) -
# soft_min/soft_max (still read from the zone's curated metadata) only set
# the comfortable default DRAG range; typing any value into the field, of
# any size, is never clamped.
def register_slider_properties():
    unregister_slider_properties()
    for zone_id in get_zone_names():
        meta = get_zone_meta(zone_id)
        attr = _slider_prop_name(zone_id)
        setattr(bpy.types.Scene, attr, bpy.props.FloatProperty(
            name=meta["display_name"],
            description=meta["description"],
            soft_min=meta["minimum"],
            soft_max=meta["maximum"],
            default=meta["default"],
            precision=1,
            subtype='DISTANCE',
            unit='LENGTH',
            update=_make_update_callback(zone_id),
        ))


def unregister_slider_properties():
    for zone_id in get_zone_names():
        attr = _slider_prop_name(zone_id)
        if hasattr(bpy.types.Scene, attr):
            try:
                delattr(bpy.types.Scene, attr)
            except Exception:
                pass


class PARAFORGE_OT_reset_zone(bpy.types.Operator):
    """Reset this zone's slider to 0"""
    bl_idname = "paraforge.reset_zone"
    bl_label = "Reset Zone"
    bl_options = {'REGISTER', 'UNDO'}
    zone_id: bpy.props.StringProperty()

    def execute(self, context):
        prop_name = _slider_prop_name(self.zone_id)
        if not hasattr(context.scene, prop_name):
            self.report({'ERROR'}, "Slider properties aren't registered yet — try again in a moment")
            return {'CANCELLED'}
        setattr(context.scene, prop_name, 0.0)
        # The update callback on the FloatProperty triggers apply_zone_deformation.
        return {'FINISHED'}


class PARAFORGE_OT_reset_all_zones(bpy.types.Operator):
    """Reset every zone's slider to 0"""
    bl_idname = "paraforge.reset_all_zones"
    bl_label = "Reset All Zones"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for zone_id in get_zone_names():
            prop_name = _slider_prop_name(zone_id)
            if hasattr(context.scene, prop_name):
                setattr(context.scene, prop_name, 0.0)
        return {'FINISHED'}
