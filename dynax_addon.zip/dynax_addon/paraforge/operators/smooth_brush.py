# paraforge/operators/smooth_brush.py - Smooth-only brush, shared by Preparation
# and Advanced (SPEC_paraforge_v2_full_rebuild.md Section 3). No brush selector is
# ever drawn for this — the panel only offers Start/Done, so the Smooth tool is the
# only one reachable from either section.
#
# First bug found and fixed vs. the reference spec, confirmed by headless testing on
# this project's actual Blender 5.1 build: the spec's approach was to
# `bpy.data.brushes.new(...)` and then set `brush.sculpt_tool = 'SMOOTH'`. Blender's
# 4.3+ brush-asset refactor REMOVED the sculpt_tool property from the Brush ID
# datablock entirely (verified: a freshly created SCULPT-mode brush in this build
# has no "tool" property at all, only e.g. mask_tool) — the spec's code raises
# AttributeError immediately on this Blender version. Originally fixed by activating
# the brush purely via the TOOL system (bpy.ops.wm.tool_set_by_id), believing that
# to be this codebase's "already-proven" mechanism (sculpt_helpers.py's _set_brush).
#
# SPEC_parafly_combined_improvements.md Section 3 ("smooth brush sometimes
# ignored"): that belief was never actually verified against a genuinely
# programmatic (non-mouse-click) call path. Verified directly, in a real
# (non-headless) Blender GUI session, while fixing this exact class of bug for
# the TLSO Mask brush (see tlso_mapping_wizard.py's _force_mask_brush for the
# full investigation): tool_set_by_id's poll() passes while its execute() still
# silently returns {'CANCELLED'} and leaves the brush unchanged, and
# `context.tool_settings.sculpt.brush = ...` (the spec's proposed direct-
# assignment fix here) raises `AttributeError: attribute "brush" from "Sculpt"
# is read-only` in this Blender build - neither the spec's fix nor the
# previous fix here actually works. The real mechanism: Blender 4.3+ sculpt
# brushes are Asset datablocks, activated via bpy.ops.brush.asset_activate(...)
# against Blender's bundled ESSENTIALS asset library, not via the tool system.
# tool_set_by_id is kept as a fallback in case a future Blender version changes
# this path.

import bpy
from bpy.types import Operator

# Relative path of the bundled "Smooth" brush inside Blender's own essentials
# brush-asset library - same library, same verified-working mechanism as
# tlso_mapping_wizard.py's MASK_BRUSH_ASSET_PATH.
SMOOTH_BRUSH_ASSET_PATH = "brushes/essentials_brushes-mesh_sculpt.blend/Brush/Smooth"


def _force_smooth_brush(context):
    """Activate the Smooth brush so Start Smoothing genuinely enters
    smooth-paint mode, not just Sculpt Mode with whatever brush was last
    active. Self-contained VIEW_3D area/region override - Start Smoothing is
    invoked from the DynaX sidebar (an N-panel button), so context.region
    here is the PANEL's own UI region, not the viewport's WINDOW region (see
    trimline.py's _find_view3d_under_cursor for the same gotcha)."""
    view3d_area = None
    window_region = None
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            view3d_area = area
            for region in area.regions:
                if region.type == 'WINDOW':
                    window_region = region
            break

    def _try_activate():
        try:
            res = bpy.ops.brush.asset_activate(
                asset_library_type='ESSENTIALS',
                asset_library_identifier="",
                relative_asset_identifier=SMOOTH_BRUSH_ASSET_PATH,
            )
            if 'FINISHED' in res:
                return True
        except Exception:
            pass
        try:
            bpy.ops.wm.tool_set_by_id(name='builtin_brush.Smooth')
        except Exception:
            pass
        return False

    if view3d_area is not None and window_region is not None:
        with context.temp_override(area=view3d_area, region=window_region):
            return _try_activate()
    return _try_activate()


def _active_smooth_brush(context):
    try:
        return context.tool_settings.sculpt.brush
    except Exception:
        return None


def update_smooth_strength(self, context):
    """Live-apply the Strength slider to the active brush while Smooth is
    active, so dragging the slider mid-session updates immediately without
    needing to re-click Start Smoothing."""
    try:
        ts = context.tool_settings.sculpt
        brush = ts.brush
        if brush is None:
            return
        if ts.unified_paint_settings.use_unified_strength:
            ts.unified_paint_settings.strength = context.scene.paraforge_smooth_strength
        else:
            brush.strength = context.scene.paraforge_smooth_strength
    except Exception:
        pass


class PARAFORGE_OT_start_smooth(Operator):
    """Enter Sculpt Mode with the Smooth brush force-activated"""
    bl_idname = "paraforge.start_smooth"
    bl_label = "Start Smoothing"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if obj is None or obj.type != 'MESH':
            self.report({'WARNING'}, "No active ParaForge object")
            return {'CANCELLED'}

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='SCULPT')

        activated = _force_smooth_brush(context)

        update_smooth_strength(self, context)

        if not activated:
            self.report({'WARNING'},
                "Sculpt mode on, but couldn't auto-select Smooth. Pick it from the brush list manually.")
        return {'FINISHED'}


class PARAFORGE_OT_done_smooth(Operator):
    """Exit Sculpt Mode, baking the smoothed positions as the new clinical-
    adjustment baseline"""
    bl_idname = "paraforge.done_smooth"
    bl_label = "Done Smoothing"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # SPEC_parafly_smooth_remesh_collapsible.md Section 2: real bug,
        # confirmed against slider_engine.py/tlso_slider_engine.py's actual
        # apply_zone_deformation - every slider move recomputes the WHOLE
        # mesh from the stored "original_positions" baseline (captured once,
        # at Clinical Adjustment entry), then re-applies each zone's current
        # slider offset from THAT baseline. Any smooth-brush edit changes
        # live mesh.vertices co's directly but never touches that stored
        # baseline, so the very next slider move (even an unrelated zone's,
        # since apply_zone_deformation always rebuilds every vertex from
        # scratch) silently discards the smoothing back to the pre-smooth
        # shape. Fixed by re-capturing the CURRENT (smoothed) positions as
        # the new baseline here, using the exact same storage key/format
        # slider_engine.py's store_original_positions and
        # tlso_slider_engine.py's store_tlso_original_positions already
        # use - and resetting every slider to 0 in the same step, since the
        # baseline itself now already includes what those sliders had
        # deformed (leaving them at their old nonzero values would double
        # apply that offset on top of the newly-baked, already-deformed
        # shape).
        scene = context.scene
        obj = scene.paraforge_active_object
        if obj is None or obj.type != 'MESH':
            return {'FINISHED'}

        # store_*_original_positions (called per-device below) reads the current
        # mesh positions itself; we only need the count here for the log line.
        vert_count = len(obj.data.vertices)

        device = getattr(scene, 'parafly_device_type', 'TT')
        if device == 'TLSO':
            from ..tlso_zone_reader import get_tlso_zone_names
            from .tlso_slider_engine import store_tlso_original_positions
            # store_tlso_original_positions bakes the CURRENT (smoothed) shape as
            # the baseline AND re-seeds the last-applied snapshot in one step, so
            # the slider-reset recompute below folds nothing spurious (see
            # tlso_slider_engine's auto-save fold).
            store_tlso_original_positions(obj)
            for zone_id in get_tlso_zone_names():
                prop = f"parafly_tlso_slider_{zone_id}"
                if hasattr(scene, prop):
                    setattr(scene, prop, 0.0)
            print(f"[ParaFly] TLSO smooth baked — {vert_count} verts, sliders reset")
        else:
            from ..zone_reader import get_zone_names
            from .slider_engine import store_original_positions
            # Bakes the CURRENT (smoothed) shape as the baseline AND re-seeds the
            # last-applied snapshot in one step, so the slider-reset recompute
            # below folds nothing spurious (see slider_engine's auto-save fold).
            store_original_positions(obj)
            for zone_id in get_zone_names():
                prop = f"parafly_slider_{zone_id}"
                if hasattr(scene, prop):
                    setattr(scene, prop, 0.0)
            print(f"[ParaFly] TT smooth baked — {vert_count} verts, sliders reset")

        self.report({'INFO'}, "Smooth baked as new baseline. Sliders reset to 0.")
        return {'FINISHED'}
