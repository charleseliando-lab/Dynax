# paraforge/operators/afo_correction.py - Angular Correction stage for AFO:
# 4 sliders (ankle/footroll/forefoot/heeltilt) that rotate the foot segment of
# the mesh about anatomical axes derived from the aligned landmarks
# (afo_alignment.py's "_axes" dict), recomputing from a stored baseline every
# time - the same drift-free pattern already proven in
# slider_engine.py/tlso_slider_engine.py.
#
# Corrections vs. SPEC_parafly_afo_complete.md Section 8, found by checking
# against the real codebase:
#
# 1. scene.parafly_active_object -> scene.paraforge_active_object (see
#    tlso_alignment.py's module docstring - this exact mistake already
#    documented once).
#
# 2. The spec's PARAFLY_OT_afo_apply_corrections wrote the baseline directly
#    as obj["paraforge_original_positions"] - TT's OWN key, not a
#    device-namespaced one. Uses store_afo_original_positions()
#    (afo_slider_engine.py) instead, so this file and the mapping wizard's
#    later stage-transition guard can never disagree on the key string.
#
# 3. bl_idname prefix parafly.* -> paraforge.afo_* (see tlso_alignment.py's
#    module docstring); classes renamed PARAFLY_OT_afo_* -> PARAFORGE_OT_afo_*
#    to match the established PARAFORGE_OT_tlso_* convention.

import bpy
import json
import math
from mathutils import Vector, Matrix

try:
    import numpy as np
except ImportError:  # Blender normally bundles NumPy; keep a safe fallback.
    np = None

from .afo_slider_engine import (
    store_afo_original_positions, AFO_BASELINE_KEY,
    get_afo_baseline_vectors, has_afo_baseline,
)


PREVIEW_DEBOUNCE_SECONDS = 0.08
_baseline_cache_key = None
_baseline_cache = None
_influence_cache_key = None
_influence_cache = None
_numpy_cache_key = None
_numpy_cache = None


def _get_cached_baseline(obj, vertex_count):
    global _baseline_cache_key, _baseline_cache
    # The baseline lives in a mesh attribute now (see afo_slider_engine). Cache
    # the Vector conversion, invalidated by the small baseline-revision counter
    # store_afo_original_positions bumps each time it (re)writes the baseline.
    rev = int(obj.get("parafly_afo_baseline_rev", 0))
    key = (obj.data.as_pointer(), vertex_count, rev)
    if key != _baseline_cache_key:
        _baseline_cache = get_afo_baseline_vectors(obj)
        _baseline_cache_key = key
    return _baseline_cache


def _flush_afo_correction_preview():
    _apply_afo_corrections(bpy.context)
    return None


def _cancel_pending_afo_correction():
    if bpy.app.timers.is_registered(_flush_afo_correction_preview):
        bpy.app.timers.unregister(_flush_afo_correction_preview)


def _schedule_afo_corrections(context):
    """Collapse a burst of slider updates into one full-mesh preview."""
    _cancel_pending_afo_correction()
    bpy.app.timers.register(
        _flush_afo_correction_preview,
        first_interval=PREVIEW_DEBOUNCE_SECONDS,
    )


def _get_axes(scene):
    try:
        lm = json.loads(scene.parafly_afo_landmarks)
        return lm.get("_axes", {})
    except Exception:
        return {}


def _correction_blend_weight(z, ankle_z, blend_half_height):
    """Smoothly transition from corrected foot (1) to fixed shank (0)."""
    lower = ankle_z - blend_half_height
    upper = ankle_z + blend_half_height
    if z <= lower:
        return 1.0
    if z >= upper:
        return 0.0
    t = (upper - z) / (upper - lower)
    return t * t * (3.0 - 2.0 * t)


def _forefoot_blend_weight(position, heel, foot_axis, foot_length):
    """Protect hindfoot, blend through midfoot, fully affect forefoot."""
    if foot_length <= 1e-9:
        return 0.0
    progress = (position - heel).dot(foot_axis) / foot_length
    if progress <= 0.40:
        return 0.0
    if progress >= 0.75:
        return 1.0
    t = (progress - 0.40) / 0.35
    return t * t * (3.0 - 2.0 * t)


def _affected_vertices(
        baseline, ankle_mid, blend_half_height,
        heel, foot_axis, foot_length):
    global _influence_cache_key, _influence_cache
    key = (
        _baseline_cache_key,
        tuple(ankle_mid), blend_half_height,
        tuple(heel), tuple(foot_axis), foot_length,
    )
    if key != _influence_cache_key:
        affected = []
        for index, position in enumerate(baseline):
            ankle_weight = _correction_blend_weight(
                position.z, ankle_mid.z, blend_half_height
            )
            if ankle_weight <= 1e-6:
                continue
            forefoot_weight = _forefoot_blend_weight(
                position, heel, foot_axis, foot_length
            )
            affected.append(
                (index, position, ankle_weight, forefoot_weight)
            )
        _influence_cache = tuple(affected)
        _influence_cache_key = key
    return _influence_cache


def _matrix3_array(matrix):
    return np.asarray([list(row) for row in matrix.to_3x3()], dtype=np.float64)


def _apply_numpy_corrections(
        mesh, baseline, affected,
        ankle_mid, heel_pt, transformed_pivot,
        rot_ankle, rot_footroll, rot_forefoot_horizontal,
        rot_forefoot_vertical, rot_heeltilt,
        has_forefoot_correction):
    global _numpy_cache_key, _numpy_cache
    if np is None:
        return False
    key = (_influence_cache_key, _baseline_cache_key)
    if key != _numpy_cache_key:
        indices = np.fromiter(
            (item[0] for item in affected), dtype=np.int32,
            count=len(affected),
        )
        original = np.asarray(
            [tuple(item[1]) for item in affected], dtype=np.float64
        )
        ankle_weights = np.fromiter(
            (item[2] for item in affected), dtype=np.float64,
            count=len(affected),
        )[:, None]
        forefoot_weights = np.fromiter(
            (item[3] for item in affected), dtype=np.float64,
            count=len(affected),
        )[:, None]
        baseline_array = np.asarray(
            [tuple(position) for position in baseline], dtype=np.float64
        )
        _numpy_cache = (
            indices, original, ankle_weights,
            forefoot_weights, baseline_array,
        )
        _numpy_cache_key = key
    indices, original, ankle_weights, forefoot_weights, baseline_array = _numpy_cache

    ankle = np.asarray(tuple(ankle_mid), dtype=np.float64)
    heel = np.asarray(tuple(heel_pt), dtype=np.float64)
    corrected = (original - ankle) @ _matrix3_array(rot_ankle).T + ankle
    corrected = (corrected - heel) @ _matrix3_array(rot_footroll).T + heel
    if has_forefoot_correction:
        pivot = np.asarray(tuple(transformed_pivot), dtype=np.float64)
        forefoot = (
            (corrected - pivot) @ _matrix3_array(rot_forefoot_horizontal).T
            + pivot
        )
        forefoot = (
            (forefoot - pivot) @ _matrix3_array(rot_forefoot_vertical).T
            + pivot
        )
        corrected += (forefoot - corrected) * forefoot_weights
    corrected = (corrected - heel) @ _matrix3_array(rot_heeltilt).T + heel
    corrected = original + (corrected - original) * ankle_weights

    output = baseline_array.copy()
    output[indices] = corrected
    mesh.vertices.foreach_set("co", output.ravel())
    return True


def _apply_afo_corrections(context):
    """
    Apply all 4 angular corrections to the mesh.
    Always recalculates from the correction baseline
    to prevent cumulative drift.
    """
    scene = context.scene
    obj = scene.paraforge_active_object

    if obj is None or obj.type != 'MESH':
        return

    if not has_afo_baseline(obj):
        return

    axes = _get_axes(scene)
    if not axes:
        return

    mesh = obj.data
    baseline = _get_cached_baseline(obj, len(mesh.vertices))
    if baseline is None or len(baseline) != len(mesh.vertices):
        return  # topology changed since the baseline was stored

    ankle_mid = Vector(axes["ankle_mid"])
    ankle_axis = Vector(axes["ankle_axis"])   # medial-lateral rotation axis
    foot_axis = Vector(axes["foot_axis"])    # anterior direction
    heel_pt = Vector(axes["heel"])
    mt_mid = Vector(axes.get("mt_mid", heel_pt + foot_axis * 100.0))
    foot_length = (mt_mid - heel_pt).dot(foot_axis)
    if foot_length <= 1e-9:
        foot_length = (mt_mid - heel_pt).length
    forefoot_pivot = heel_pt + foot_axis * (foot_length * 0.55)

    # Blend the corrected foot into the fixed shank through an ankle band.
    # The band scales with the patient's heel-to-ankle height, avoiding a
    # fixed millimetre assumption across paediatric and adult scans.
    ankle_height = max(abs(ankle_mid.z - heel_pt.z), 1.0)
    blend_half_height = max(ankle_height * 0.35, 5.0)

    ankle_deg = scene.parafly_afo_ankle_angle
    footroll_deg = scene.parafly_afo_footroll_angle
    forefoot_deg = scene.parafly_afo_forefoot_angle
    forefoot_vertical_deg = scene.parafly_afo_forefoot_vertical_angle
    heeltilt_deg = scene.parafly_afo_heeltilt_angle

    ankle_rad = math.radians(ankle_deg)
    footroll_rad = math.radians(footroll_deg)
    forefoot_rad = math.radians(forefoot_deg)
    forefoot_vertical_rad = math.radians(forefoot_vertical_deg)
    heeltilt_rad = math.radians(heeltilt_deg)

    # ── Build rotation matrices ───────────────────────────────────
    # Each rotation is about a specific anatomical axis, valid because
    # afo_alignment.py guarantees the standard pose (heel at origin, toes
    # toward -Y, sole flat on Z=0) before this stage is ever reached.

    # 1. Ankle: rotate around medial-lateral axis (lat_mal <-> med_mal).
    #    Positive = dorsiflexion (foot tips up).
    rot_ankle = Matrix.Rotation(ankle_rad, 4, ankle_axis)

    # 2. Foot roll: rotate around anterior-posterior axis (heel -> MT mid).
    #    Positive = supination.
    ap_axis = foot_axis.copy()
    ap_axis.z = 0
    if ap_axis.length_squared < 1e-9:
        ap_axis = Vector((0, -1, 0))
    ap_axis.normalize()
    rot_footroll = Matrix.Rotation(footroll_rad, 4, ap_axis)

    # 4. Heel tilt: rotate around the world Y axis (anterior-posterior, given
    #    the standard pose) at the heel. Positive = varus.
    rot_heeltilt = Matrix.Rotation(heeltilt_rad, 4, Vector((0, 1, 0)))

    # Forefoot rotations share one pivot, transformed through the preceding
    # whole-foot rotations so combined corrections remain coherent.
    has_forefoot_correction = (
        abs(forefoot_rad) > 1e-12 or abs(forefoot_vertical_rad) > 1e-12
    )
    if has_forefoot_correction:
        transformed_pivot = ankle_mid + (
            rot_ankle @ (forefoot_pivot - ankle_mid)
        )
        transformed_pivot = heel_pt + (
            rot_footroll @ (transformed_pivot - heel_pt)
        )
        local_vertical = rot_footroll.to_3x3() @ (
            rot_ankle.to_3x3() @ Vector((0, 0, 1))
        )
        local_ml_axis = rot_footroll.to_3x3() @ (
            rot_ankle.to_3x3() @ ankle_axis
        )
        rot_forefoot_horizontal = Matrix.Rotation(
            forefoot_rad, 4, local_vertical
        )
        rot_forefoot_vertical = Matrix.Rotation(
            forefoot_vertical_rad, 4, local_ml_axis
        )

    affected = _affected_vertices(
        baseline, ankle_mid, blend_half_height,
        heel_pt, foot_axis, foot_length,
    )
    used_numpy = _apply_numpy_corrections(
        mesh, baseline, affected,
        ankle_mid, heel_pt,
        transformed_pivot if has_forefoot_correction else None,
        rot_ankle, rot_footroll,
        rot_forefoot_horizontal if has_forefoot_correction else None,
        rot_forefoot_vertical if has_forefoot_correction else None,
        rot_heeltilt, has_forefoot_correction,
    )
    if not used_numpy:
        for index, orig, weight, forefoot_weight in affected:
            v = mesh.vertices[index]
            corrected = ankle_mid + (rot_ankle @ (orig - ankle_mid))
            corrected = heel_pt + (rot_footroll @ (corrected - heel_pt))
            if has_forefoot_correction:
                forefoot_corrected = transformed_pivot + (
                    rot_forefoot_horizontal @ (
                        corrected - transformed_pivot
                    )
                )
                forefoot_corrected = transformed_pivot + (
                    rot_forefoot_vertical @ (
                        forefoot_corrected - transformed_pivot
                    )
                )
                corrected = corrected.lerp(
                    forefoot_corrected, forefoot_weight
                )
            corrected = heel_pt + (
                rot_heeltilt @ (corrected - heel_pt)
            )
            v.co = orig.lerp(corrected, weight)

    mesh.update()


class PARAFORGE_OT_afo_store_correction_baseline(bpy.types.Operator):
    bl_idname = "paraforge.afo_store_correction_baseline"
    bl_label = "Store Correction Baseline"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.scene.paraforge_active_object
        if obj is None:
            self.report({'ERROR'}, "No AFO scan is loaded")
            return {'CANCELLED'}
        store_afo_original_positions(obj)
        self.report({'INFO'}, "Correction baseline stored.")
        return {'FINISHED'}


class PARAFORGE_OT_afo_apply_corrections(bpy.types.Operator):
    bl_idname = "paraforge.afo_apply_corrections"
    bl_label = "Apply Corrections"
    bl_description = "Bake angular corrections into mesh and proceed to zone mapping"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        obj = scene.paraforge_active_object
        if obj is None:
            self.report({'ERROR'}, "No AFO scan is loaded")
            return {'CANCELLED'}

        # A live preview may still be waiting for the debounce interval.
        # Evaluate the exact final slider state once before baking it.
        _cancel_pending_afo_correction()
        _apply_afo_corrections(context)

        # Bake current corrected positions as the baseline the zone-mapping
        # slider engine (afo_slider_engine.py) will deform from - shared
        # helper, shared key, see module docstring.
        store_afo_original_positions(obj)

        scene.parafly_afo_ankle_angle = 0.0
        scene.parafly_afo_footroll_angle = 0.0
        scene.parafly_afo_forefoot_angle = 0.0
        scene.parafly_afo_forefoot_vertical_angle = 0.0
        scene.parafly_afo_heeltilt_angle = 0.0
        _cancel_pending_afo_correction()

        scene.parafly_afo_stage = 'MAPPING'
        self.report({'INFO'}, "Corrections applied. Proceed to zone mapping.")
        return {'FINISHED'}


class PARAFORGE_OT_afo_reset_corrections(bpy.types.Operator):
    bl_idname = "paraforge.afo_reset_corrections"
    bl_label = "Reset"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        scene.parafly_afo_ankle_angle = 0.0
        scene.parafly_afo_footroll_angle = 0.0
        scene.parafly_afo_forefoot_angle = 0.0
        scene.parafly_afo_forefoot_vertical_angle = 0.0
        scene.parafly_afo_heeltilt_angle = 0.0
        _cancel_pending_afo_correction()
        _apply_afo_corrections(context)
        return {'FINISHED'}


class PARAFORGE_OT_afo_ideal_alignment(bpy.types.Operator):
    """Set sliders to clinically ideal AFO alignment."""
    bl_idname = "paraforge.afo_ideal_alignment"
    bl_label = "Ideal Alignment"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        scene.parafly_afo_ankle_angle = 4.0   # 4 degrees dorsiflexion
        scene.parafly_afo_footroll_angle = 0.0
        scene.parafly_afo_forefoot_angle = 0.0
        scene.parafly_afo_forefoot_vertical_angle = 0.0
        scene.parafly_afo_heeltilt_angle = 0.0
        self.report({'INFO'}, "Ideal alignment: 4° dorsiflexion set.")
        return {'FINISHED'}


def _compute_sva(scene):
    """
    Shank vs Vertical Angle (SVA).
    Angle between shank axis and vertical (Z axis).
    """
    axes = _get_axes(scene)
    if not axes:
        return None
    shank = Vector(axes.get("shank_axis", (0, 0, 1)))
    vertical = Vector((0, 0, 1))
    angle = math.degrees(shank.angle(vertical))
    direction = "dorsi" if shank.y < 0 else "plant"
    return angle, direction


def _compute_calcaneal(scene):
    """
    Calcaneal angle: rear-foot vs vertical.
    Angle of heel-to-ankle vector vs vertical.
    """
    axes = _get_axes(scene)
    if not axes:
        return None
    heel = Vector(axes.get("heel", (0, 0, 0)))
    ankle_mid = Vector(axes.get("ankle_mid", (0, 0, 0)))
    rear_foot_vec = (ankle_mid - heel).normalized()
    vertical = Vector((0, 0, 1))
    angle = math.degrees(rear_foot_vec.angle(vertical))
    direction = "valgus" if rear_foot_vec.x > 0 else "varus"
    return angle, direction
