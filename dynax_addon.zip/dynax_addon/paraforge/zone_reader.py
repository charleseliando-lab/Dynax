# paraforge/zone_reader.py - Reads clinical zone names from the bundled reference
# .blend at runtime instead of hardcoding them, per SPEC_paraforge_v2_full_rebuild.
#
# Deviation from the reference spec, found by actually inspecting the file rather
# than trusting the spec's description of it (this project's own established
# practice - see CLAUDE.md's many "verified headless, real bug found" entries):
#
# tt_reference_rigged.blend is NOT a clean single-mesh template. It's a real
# working DynaX session file containing the Checkpoints feature's snapshot/
# checkpoint objects (1_calibrated_ORIGINAL_SNAPSHOT, 1_calibrated_CHECKPOINT_*)
# alongside the live mesh (1_calibrated). The spec's get_zone_names() took
# data_to.objects[0] unconditionally and used a case-sensitive "zone_" prefix
# check - on this real file that grabs 1_calibrated_ORIGINAL_SNAPSHOT, which has
# ZERO vertex groups, so it would silently return an empty zone list. The real
# zone groups live on 1_calibrated and are named "Zone_..." (capitalized), e.g.
# Zone_Tibia_Crest, Zone_Patella_Tendon, Zone_Medial_Shaft, Zone_Lateral_Condyle,
# Zone_Posterior_Popliteal, Zone_Brim - 12 zones total, not the 6 the spec assumed.
#
# Fixed by scanning every loaded mesh object for the first one that actually HAS
# at least one zone-prefixed vertex group (case-insensitive), instead of blindly
# taking index 0.
#
# Zone ids are additionally normalized to lowercase before caching (e.g.
# "Zone_Brim" -> "zone_brim") so every consumer works from one consistent casing
# regardless of how a vertex group happens to be capitalized in a given .blend.
# Because obj.vertex_groups.get() is a case-sensitive exact-string lookup,
# find_vertex_group() below does the case-insensitive matching wherever code
# needs to find a real vertex group by zone id.

import bpy
import os

REFERENCE_BLEND_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "reference_models",
    "tt_reference_rigged.blend"
)

_cached_zones = None


def get_zone_names():
    """
    Read all vertex group names beginning with "zone_" (case-insensitive) from
    the first mesh object in tt_reference_rigged.blend that actually has any,
    scanning every object in the file rather than assuming the first one.
    Results are cached after first load - call invalidate_zone_cache() to force
    a re-read. Returns a list of lowercase zone id strings, e.g.
    ['zone_patella_tendon', ...].
    """
    global _cached_zones
    if _cached_zones is not None:
        return _cached_zones

    zone_names = []

    if not os.path.exists(REFERENCE_BLEND_PATH):
        print(f"[ParaForge] WARNING: Reference blend not found at {REFERENCE_BLEND_PATH}")
        _cached_zones = zone_names
        return zone_names

    loaded_object_names = []
    try:
        with bpy.data.libraries.load(REFERENCE_BLEND_PATH, link=False) as (data_from, data_to):
            data_to.objects = list(data_from.objects)
        loaded_object_names = [o.name for o in data_to.objects if o is not None]

        for obj in data_to.objects:
            if obj is not None and obj.type == 'MESH':
                found = [vg.name for vg in obj.vertex_groups if vg.name.lower().startswith("zone_")]
                if found:
                    zone_names = found
                    break
    finally:
        # Clean up - remove the temporarily loaded objects AND their mesh
        # datablocks (removing only the object leaks an orphaned mesh
        # datablock every time this runs, since register() calls this once
        # per addon-enable).
        removed_meshes = []
        for name in loaded_object_names:
            obj = bpy.data.objects.get(name)
            if obj is not None:
                if obj.type == 'MESH' and obj.data is not None:
                    removed_meshes.append(obj.data)
                bpy.data.objects.remove(obj, do_unlink=True)
        for mesh in removed_meshes:
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)

    zone_names = sorted(set(name.lower() for name in zone_names))

    _cached_zones = zone_names
    print(f"[ParaForge] Loaded {len(zone_names)} zones from reference blend: {zone_names}")
    return zone_names


def invalidate_zone_cache():
    global _cached_zones
    _cached_zones = None


def find_vertex_group(obj, zone_id):
    """Case-insensitive vertex-group lookup by zone id. obj.vertex_groups.get()
    is an exact case-sensitive string match, which would silently miss a group
    whose stored name doesn't exactly match zone_id's casing (e.g. a group
    created before the lowercase normalization above, or a hand-authored one).
    Returns the VertexGroup, or None if no case-insensitive match exists."""
    target = zone_id.lower()
    for vg in obj.vertex_groups:
        if vg.name.lower() == target:
            return vg
    return None


def zone_id_to_display_name(zone_id):
    """
    Convert 'Zone_Patella_Tendon' -> 'Patella Tendon' (strips a leading
    "zone_"/"Zone_" case-insensitively, then title-cases the remainder).
    """
    name = zone_id
    if name.lower().startswith("zone_"):
        name = name[5:]
    return name.replace("_", " ").title()
