# paraforge/image_loader.py - Loads a per-zone reference image for TLSO's mapping
# wizard, with a graceful text-label fallback when the image doesn't exist yet.
# These images do not need to exist for the code to work.
#
# SPEC_tlso_zone_update_7zones.md Fix 1 ("images not displaying"): this
# previously used `layout.template_preview(img, show_buttons=False)` on a
# plain `bpy.data.images.load()`'d Image datablock. That datablock has no
# pre-generated `.preview` (ImagePreview) thumbnail just from being loaded -
# template_preview relies on one already existing, so it drew nothing and
# failed silently. `layout.template_image(...)` and `template_ID_preview`
# aren't usable either - `hasattr(bpy.types.UILayout, 'template_image')` is
# False in this Blender build (verified directly), and template_ID_preview
# needs a PointerProperty to an Image plus an ImageUser, neither of which
# this addon has any reason to add just to show a static reference picture.
# Fixed using `bpy.utils.previews` (a `bpy.utils.previews.ImagePreviewCollection`)
# - the standard, documented Blender mechanism for showing a static image
# file in a panel via `layout.template_icon(icon_value=...)`.
#
# SPEC_tlso_mapping_combined_fix.md Fix 2 ("images too large for
# bpy.utils.previews"): the previous version passed the real asset PNGs
# straight into `pcoll.load()` at their native size - verified directly that
# these are ~1370x1150px, 1.4-1.8MB files. bpy.utils.previews is designed for
# small icon-scale thumbnails, not full-resolution photos; loading them at
# native size produced a preview that never actually rendered visibly (no
# exception - `pcoll.load()` and the earlier `[ParaFly] Loaded N zone preview
# images` console line both succeeded either way, which is exactly why this
# wasn't caught by the previous fix's console-output-only verification).
# Fixed by resizing each source PNG down to a real icon-scale thumbnail
# (256x320px) via Blender's own Image.scale()+save() API before handing it to
# bpy.utils.previews - verified directly that this resize step itself works
# (1369x1149 -> 256x320, reloads correctly). Thumbnails are cached in the OS
# temp folder (keyed by source mtime) so this only re-runs when a source PNG
# actually changes, not on every addon reload.
#
# SPEC_parafly_slider_and_zone_corrections.md Section 3.5: zone_tlso_waist_area
# and zone_tlso_trochanter_pad were split into explicit _left/_right zones
# (tlso_zone_definitions.py), but only the original unified PNGs
# (zone_tlso_waist_area.png, zone_tlso_trochanter_pad.png) exist on disk -
# both sides of real bilateral anatomy look the same in a reference
# illustration, so ZONE_IMAGE_ALIASES loads that same source image under
# each split zone's id too, rather than needing two near-duplicate PNGs.

import bpy
import bpy.utils.previews
import os
import tempfile

TLSO_ASSET_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "assets", "tlso"
)

# Cleared on OS restart automatically (standard OS temp-folder behavior) -
# never needs manual cleanup from this addon.
THUMB_DIR = os.path.join(tempfile.gettempdir(), "dynax_tlso_thumbs")

# Split zones that reuse an existing unified-anatomy reference image under
# their own zone id (see module docstring) - source_id must be a real
# filename in TLSO_ASSET_DIR (without ".png").
ZONE_IMAGE_ALIASES = {
    # Trochanter Pad zones were removed from the workflow (2026-07-13); their
    # aliases are gone too. Waist Area remains split left/right.
    "zone_tlso_waist_area_left": "zone_tlso_waist_area",
    "zone_tlso_waist_area_right": "zone_tlso_waist_area",
}

_preview_collections = {}


def _make_thumbnail(src_path, thumb_path, width=256, height=320):
    """Resize src_path down to width x height and save to thumb_path via
    Blender's own image API. Skips regenerating if a thumbnail already
    exists and is newer than the source file. Returns True if a usable
    thumbnail exists at thumb_path afterward, False on failure (caller falls
    back to the original full-size file rather than showing nothing)."""
    if (os.path.exists(thumb_path)
            and os.path.getmtime(thumb_path) >= os.path.getmtime(src_path)):
        return True

    try:
        img = bpy.data.images.load(src_path, check_existing=False)
        img.scale(width, height)
        img.filepath_raw = thumb_path
        img.file_format = 'PNG'
        img.save()
        bpy.data.images.remove(img)
        return True
    except Exception as e:
        print(f"[ParaFly] Thumbnail creation failed for {os.path.basename(src_path)}: {e}")
        return False


def load_zone_previews():
    """Load every TLSO zone PNG in assets/tlso/ into a preview collection, as
    resized thumbnails (see module docstring Fix 2). Call once from
    __init__.py's register(). Safe to call again (e.g. addon disable/
    re-enable) - unloads any existing collection first so previews are never
    leaked or duplicated."""
    unload_zone_previews()
    os.makedirs(THUMB_DIR, exist_ok=True)

    pcoll = bpy.utils.previews.new()
    count = 0

    if not os.path.isdir(TLSO_ASSET_DIR):
        print(f"[ParaFly] Asset dir not found: {TLSO_ASSET_DIR}")
        _preview_collections["tlso"] = pcoll
        return

    for fname in sorted(os.listdir(TLSO_ASSET_DIR)):
        if not fname.lower().endswith(".png"):
            continue

        zone_id = fname[:-len(".png")]
        src_path = os.path.join(TLSO_ASSET_DIR, fname)
        thumb_path = os.path.join(THUMB_DIR, f"thumb_{fname}")

        ok = _make_thumbnail(src_path, thumb_path)
        load_path = thumb_path if ok and os.path.exists(thumb_path) else src_path

        try:
            pcoll.load(zone_id, load_path, 'IMAGE')
            count += 1
        except Exception as e:
            print(f"[ParaFly] Preview load failed '{fname}': {e}")

    # Alias split zones (waist/trochanter _left/_right) onto their shared
    # unified-anatomy source image - see ZONE_IMAGE_ALIASES above.
    for alias_id, source_id in ZONE_IMAGE_ALIASES.items():
        if source_id not in pcoll or alias_id in pcoll:
            continue
        src_path = os.path.join(TLSO_ASSET_DIR, f"{source_id}.png")
        thumb_path = os.path.join(THUMB_DIR, f"thumb_{source_id}.png")
        load_path = thumb_path if os.path.exists(thumb_path) else src_path
        if not os.path.exists(load_path):
            continue
        try:
            pcoll.load(alias_id, load_path, 'IMAGE')
            count += 1
        except Exception as e:
            print(f"[ParaFly] Preview alias load failed '{alias_id}': {e}")

    _preview_collections["tlso"] = pcoll
    print(f"[ParaFly] Loaded {count} zone preview images")

    # Force a redraw so thumbnails appear immediately rather than waiting for
    # the next unrelated UI event - harmless no-op if there's no window yet
    # (e.g. mid-registration on Blender startup).
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
    except Exception:
        pass


def unload_zone_previews():
    """Call from __init__.py's unregister(). Safe to call even if never loaded."""
    for pcoll in _preview_collections.values():
        try:
            bpy.utils.previews.remove(pcoll)
        except Exception:
            pass
    _preview_collections.clear()


def draw_zone_image(layout, zone_id):
    """
    Draw the zone reference image compactly using template_icon.

    SPEC_tlso_image_spacing_and_import_hide.md Fix 1: the previous version
    set `col.scale_y = 8.0` on the wrapping column - scale_y stretches the
    WHOLE column's vertical layout space, not just the icon widget inside
    it, which is what produced the large blank gap above/below the image
    (the icon itself only needed a bigger *icon*, via template_icon's own
    `scale` argument, not a stretched column). Fixed by leaving the column
    at its natural scale_y (1.0, i.e. not set at all) and using
    template_icon's `scale=18.0` (up from 10.0) to make the icon itself
    bigger without adding any extra layout space around it.

    Never raises - always falls back to placeholder text on any error, so a
    single broken/missing image can't take down the rest of the wizard step
    draw (the panel's own draw_zone_image call is ALSO wrapped in try/except
    as a second layer of defense; see panels/parafly_tlso_panel.py).
    """
    try:
        pcoll = _preview_collections.get("tlso")
        if pcoll is not None and zone_id in pcoll:
            preview = pcoll[zone_id]
            col = layout.column()
            col.template_icon(icon_value=preview.icon_id, scale=18.0)
            return
    except Exception as e:
        print(f"[ParaFly] Image render failed for {zone_id}: {e}")

    box = layout.box()
    box.label(text="[ Reference image coming soon ]", icon='IMAGE_DATA')
