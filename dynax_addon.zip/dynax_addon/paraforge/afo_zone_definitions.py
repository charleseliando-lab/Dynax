# paraforge/afo_zone_definitions.py - Clinical metadata for AFO zones.
# Zone IDs are read from afo_reference.blend (afo_zone_reader.py) - not defined
# here. Zones not listed receive safe fallback defaults via get_afo_zone_meta().
#
# Per-zone metadata content kept from SPEC_parafly_afo_complete.md Section 4
# as authored. One real bug fixed vs. the spec: AFO_ZONE_FALLBACK had no
# "display_name" key at all, so get_afo_zone_meta() would KeyError the moment
# any code read meta["display_name"] for a zone not in AFO_ZONE_METADATA
# (mapping wizard and slider engine both do, on every zone). Fixed to the same
# fallback pattern already proven in zone_definitions.get_zone_meta() /
# tlso_zone_definitions.get_tlso_zone_meta(): display_name derived from
# afo_zone_id_to_display_name() when there's no authored entry.

AFO_ZONE_METADATA = {
    "zone_afo_calf_band": {
        "display_name": "Calf Band",
        "description": (
            "Posterior proximal calf contact area. "
            "Primary proximal anchor of the AFO."
        ),
        "category": "Pressure Zone",
        "color": (0.85, 0.15, 0.15),
        "minimum": -100.0,
        "maximum": 100.0,
        "default": 0.0,
        "direction": "inward",
        "skippable": False,
        "tip": "Centre over the posterior calf at the proximal band level.",
        "how_to_map": (
            "Paint the posterior proximal calf region where the "
            "AFO band will contact the leg."
        ),
    },
    "zone_afo_ankle_medial": {
        "display_name": "Ankle Relief (Medial)",
        "description": (
            "Relief over the medial malleolus. "
            "Creates space to prevent bony prominence pressure."
        ),
        "category": "Relief Zone",
        "color": (0.20, 0.55, 0.85),
        "minimum": -100.0,
        "maximum": 100.0,
        "default": 0.0,
        "direction": "outward",
        "skippable": False,
        "tip": "Centre directly over the medial malleolus landmark.",
        "how_to_map": (
            "Paint the area over and around the medial malleolus "
            "that requires pressure relief."
        ),
    },
    "zone_afo_ankle_lateral": {
        "display_name": "Ankle Relief (Lateral)",
        "description": (
            "Relief over the lateral malleolus. "
            "Creates space to prevent bony prominence pressure."
        ),
        "category": "Relief Zone",
        "color": (0.20, 0.75, 0.85),
        "minimum": -100.0,
        "maximum": 100.0,
        "default": 0.0,
        "direction": "outward",
        "skippable": False,
        "tip": "Centre directly over the lateral malleolus landmark.",
        "how_to_map": (
            "Paint the area over and around the lateral malleolus "
            "that requires pressure relief."
        ),
    },
    "zone_afo_heel_relief": {
        "display_name": "Heel Relief",
        "description": (
            "Posterior heel relief. Creates space at the calcaneus "
            "for comfort and pressure distribution."
        ),
        "category": "Relief Zone",
        "color": (0.45, 0.75, 0.30),
        "minimum": -100.0,
        "maximum": 100.0,
        "default": 0.0,
        "direction": "outward",
        "skippable": True,
        "tip": "Extend slightly beyond the heel contact point.",
        "how_to_map": (
            "Paint the posterior heel region where relief "
            "from the calcaneus is needed."
        ),
    },
    "zone_afo_footplate": {
        "display_name": "Footplate",
        "description": (
            "Plantar surface contact area. Defines the foot "
            "support region of the AFO."
        ),
        "category": "Pressure Zone",
        "color": (0.95, 0.65, 0.10),
        "minimum": -100.0,
        "maximum": 100.0,
        "default": 0.0,
        "direction": "inward",
        "skippable": False,
        "tip": "Cover the full plantar surface from heel to toe.",
        "how_to_map": (
            "Paint the entire sole/plantar surface of the foot "
            "that the AFO footplate will support."
        ),
    },
    "zone_afo_anterior_trim": {
        "display_name": "Anterior Trim Line",
        "description": (
            "Front edge of the AFO along the shin. "
            "Defines the anterior boundary of the device."
        ),
        "category": "Trim Line",
        "color": (0.85, 0.85, 0.85),
        "minimum": -100.0,
        "maximum": 100.0,
        "default": 0.0,
        "direction": "boundary",
        "skippable": True,
        "tip": "Follow the anterior tibial crest contour.",
        "how_to_map": (
            "Paint the anterior shin region that defines "
            "the front trim line of the AFO."
        ),
    },
}

AFO_ZONE_FALLBACK = {
    "display_name": None,   # None -> fall back to afo_zone_id_to_display_name()
    "minimum": -100.0,
    "maximum": 100.0,
    "default": 0.0,
    "description": "Paint and adjust this zone.",
    "category": "General",
    "direction": "inward",
    "skippable": True,
    "tip": "",
    "how_to_map": "Paint the relevant area on the mesh.",
}


def get_afo_zone_meta(zone_id):
    """Return metadata for a zone, case-insensitively, falling back to safe
    defaults for any zone that exists in the reference blend but has no
    authored entry above (same pattern as zone_definitions.get_zone_meta /
    tlso_zone_definitions.get_tlso_zone_meta)."""
    meta = AFO_ZONE_METADATA.get(zone_id.lower())
    if meta is not None:
        return meta
    from .afo_zone_reader import afo_zone_id_to_display_name
    fallback = dict(AFO_ZONE_FALLBACK)
    fallback["display_name"] = afo_zone_id_to_display_name(zone_id)
    return fallback
