Drop one PNG per TLSO zone here, named exactly after the zone ID, e.g.:

  zone_tlso_thoracic_pad.png
  zone_tlso_lumbar_pad.png
  zone_tlso_trochanter_pad.png   ← shared by trochanter_pad_left AND _right
  zone_tlso_waist_area.png       ← shared by waist_area_left AND _right
  zone_tlso_thoracic_relief.png
  zone_tlso_lumbar_relief.png
  zone_tlso_abdominal_relief.png

Waist Area and Trochanter Pad are painted as separate left/right zones
(zone_tlso_waist_area_left/_right, zone_tlso_trochanter_pad_left/_right) but
only need ONE PNG each - image_loader.py's ZONE_IMAGE_ALIASES automatically
shows the same unified-anatomy image for both sides, since real bilateral
anatomy looks the same illustrated either way.

Recommended: 400x500px, dark background, clean illustration style, showing a
posterior/anterior torso outline with the relevant zone highlighted in its
designated color (see paraforge/tlso_zone_definitions.py's "color" field per
zone). None of these need to exist for the add-on to work - the Clinical
Mapping wizard shows a "[ Reference image coming soon ]" placeholder for any
missing zone image instead of crashing.
