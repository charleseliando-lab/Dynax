# paraforge/tlso_zone_definitions.py - Clinical metadata for TLSO zones.
# Zone IDs are read from tlso_reference.blend (tlso_zone_reader.py) - not defined
# here. Zones not listed receive safe fallback defaults via get_tlso_zone_meta().
#
# SPEC_tlso_zone_update_7zones.md: reduces the zone set from 11 to 7, removing
# zone_tlso_axillary_roll_right, zone_tlso_rib_hump_relief_right,
# zone_tlso_superior_trim_line, zone_tlso_inferior_trim_line, and
# zone_tlso_anterior_opening entirely, and renames the remaining zones to drop
# the "_right"/"_left" suffixes (this device's zones are no longer modeled as
# strictly one-sided - see "trochanter_pad"/"waist_area", both now bilateral).
# Adds "tip" and "how_to_map" fields, shown in the Clinical Mapping wizard
# alongside the existing description (panels/parafly_tlso_panel.py).
#
# SPEC_parafly_combined_improvements.md Section 2 (later superseded, see
# below): added automatic bilateral mirroring for zone_tlso_waist_area and
# zone_tlso_trochanter_pad - painting one side auto-mirrored it to the other.
#
# SPEC_parafly_slider_and_zone_corrections.md Sections 2/3 (current state):
# the automatic mirroring was removed entirely (caused zone deletion bugs).
# zone_tlso_waist_area and zone_tlso_trochanter_pad are now split into four
# explicit zones - zone_tlso_waist_area_left/_right and
# zone_tlso_trochanter_pad_left/_right - each painted independently like
# every other zone, with no runtime mirroring/breaking logic at all. 9 zones
# total now (see tlso_zone_reader.py's ZONE_ORDER and
# scripts/create_tlso_reference.py's TLSO_ZONE_IDS, both updated to match).
#
# Slider range: every zone's "minimum"/"maximum" here is now ONLY the
# comfortable default DRAG range (soft_min/soft_max) - tlso_slider_engine.py's
# register_tlso_slider_properties() no longer passes any hard min/max at all,
# so typing any value is never clamped (SPEC_parafly_slider_and_zone_corrections.md
# Section 1, "remove all min/max limits, allow unlimited user input").
# Widened from +/-10.0 to +/-20.0 per that spec's own explicit UI-range value
# (its Section 1.1/1.2 text separately suggested +/-100.0, but its own
# Section 1.3 registration code never actually reads a per-zone value for
# soft_min/soft_max at all - it hardcodes -20.0/20.0 directly - so +/-100
# would have been dead, unused metadata; +/-20 is what the real registered
# slider widget actually shows, and stays uniform with the TT workflow's
# zone_definitions.py, which was widened the same way for the same reason).
# The "direction" field (still used by tlso_slider_engine.py's
# zone-average-normal deformation to choose which way a positive slider
# value pushes) is unrelated to range and unaffected by any of this.

TLSO_ZONE_METADATA = {

    # ── PRESSURE ZONES (push inward) ─────────────────────────────
    "zone_tlso_thoracic_pad": {
        "display_name": "Thoracic Pad",
        "description": (
            "Primary corrective force. Paint the area where the thoracic "
            "pad will contact the rib hump on the convex side of the curve. "
            "Centre over the curve apex for maximum correction."
        ),
        "category": "Pressure Zone",
        "color": (0.85, 0.15, 0.15),   # Red
        "minimum": -20.0,
        "maximum": 20.0,
        "default": 0.0,
        "direction": "inward",
        "skippable": False,
        "tip": "Centre the pad over the curve apex for maximum correction.",
        "how_to_map": (
            "Paint the area where the thoracic pad will contact the "
            "rib hump on the convex side of the curve."
        ),
    },
    "zone_tlso_lumbar_pad": {
        "display_name": "Lumbar Pad",
        "description": (
            "Secondary corrective force. Applies corrective pressure at the "
            "lumbar curve apex on the convex side."
        ),
        "category": "Pressure Zone",
        "color": (0.95, 0.75, 0.10),   # Yellow
        "minimum": -20.0,
        "maximum": 20.0,
        "default": 0.0,
        "direction": "inward",
        "skippable": True,
        "tip": "Position to balance and support lumbar curve correction.",
        "how_to_map": (
            "Paint the area where the lumbar pad will contact the "
            "convex side of the lumbar curve."
        ),
    },
    # Trochanter Pad (left/right) zones were removed from the TLSO workflow per
    # clinical request (2026-07-13). They may still exist as vertex groups in
    # the older tlso_reference.blend, so tlso_zone_reader.TLSO_EXCLUDED_ZONES
    # filters them out at read time; their metadata is dropped here too.
    "zone_tlso_waist_area_left": {
        "display_name": "Waist Area (Left)",
        "description": (
            "Creates space on the left side of the waist just above the "
            "iliac crest. Improves comfort and allows rotational correction."
        ),
        "category": "Pressure Zone",
        "color": (0.55, 0.30, 0.85),   # Purple-blue
        "minimum": -20.0,
        "maximum": 20.0,
        "default": 0.0,
        "direction": "inward",
        "skippable": True,
        "tip": "Balance left and right waist areas for symmetry.",
        "how_to_map": (
            "Paint the left side of the waist above the iliac crest."
        ),
    },
    "zone_tlso_waist_area_right": {
        "display_name": "Waist Area (Right)",
        "description": (
            "Creates space on the right side of the waist just above the "
            "iliac crest. Improves comfort and allows rotational correction."
        ),
        "category": "Pressure Zone",
        "color": (0.58, 0.33, 0.87),   # Purple-blue
        "minimum": -20.0,
        "maximum": 20.0,
        "default": 0.0,
        "direction": "inward",
        "skippable": True,
        "tip": "Balance left and right waist areas for symmetry.",
        "how_to_map": (
            "Paint the right side of the waist above the iliac crest."
        ),
    },

    # ── RELIEF ZONES (push outward) ──────────────────────────────
    "zone_tlso_thoracic_relief": {
        "display_name": "Thoracic Relief",
        "description": (
            "Creates space over the thoracic area on the concave side "
            "to improve comfort and enhance breathing."
        ),
        "category": "Relief Zone",
        "color": (0.45, 0.30, 0.80),   # Purple
        "minimum": -20.0,
        "maximum": 20.0,
        "default": 0.0,
        "direction": "outward",
        "skippable": False,
        "tip": "Position the relief area to avoid pressure on the ribs.",
        "how_to_map": (
            "Paint the area over the thoracic region on the concave "
            "side that requires relief."
        ),
    },
    "zone_tlso_lumbar_relief": {
        "display_name": "Lumbar Relief",
        "description": (
            "Creates space on the concave side of the lumbar curve "
            "to allow lumbar correction."
        ),
        "category": "Relief Zone",
        "color": (0.45, 0.75, 0.30),   # Green
        "minimum": -20.0,
        "maximum": 20.0,
        "default": 0.0,
        "direction": "outward",
        "skippable": True,
        "tip": "Balance the relief with lumbar pad pressure.",
        "how_to_map": (
            "Paint the area on the concave side of the lumbar curve "
            "that needs relief."
        ),
    },
    "zone_tlso_abdominal_relief": {
        "display_name": "Abdominal Relief",
        "description": (
            "Provides abdominal expansion space for breathing and comfort. "
            "Located on the anterior centre of the torso."
        ),
        "category": "Relief Zone",
        "color": (0.55, 0.35, 0.85),   # Purple
        "minimum": -20.0,
        "maximum": 20.0,
        "default": 0.0,
        "direction": "outward",
        "skippable": False,
        "tip": "Keep centred and away from ribs and ASIS.",
        "how_to_map": (
            "Paint the central abdominal area where expansion "
            "and relief are needed."
        ),
    },
}

TLSO_ZONE_FALLBACK = {
    "display_name": None,   # None -> fall back to tlso_zone_id_to_display_name()
    "minimum": -20.0,
    "maximum": 20.0,
    "default": 0.0,
    "description": "Paint and adjust this zone.",
    "category": "General",
    "direction": "inward",
    "skippable": True,
    "tip": "",
    "how_to_map": "Paint the relevant area on the mesh.",
}


def get_tlso_zone_meta(zone_id):
    """Return metadata for a zone, case-insensitively, falling back to safe
    defaults for any zone that exists in the reference blend but has no
    authored entry above (same pattern as zone_definitions.get_zone_meta)."""
    meta = TLSO_ZONE_METADATA.get(zone_id.lower())
    if meta is not None:
        return meta
    from .tlso_zone_reader import tlso_zone_id_to_display_name
    fallback = dict(TLSO_ZONE_FALLBACK)
    fallback["display_name"] = tlso_zone_id_to_display_name(zone_id)
    return fallback
