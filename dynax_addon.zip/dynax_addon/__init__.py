# __init__.py - DynaX v1.16.3

import bpy
import os
from bpy.props import StringProperty, PointerProperty, FloatProperty, EnumProperty, IntProperty, BoolProperty, CollectionProperty

from . import preferences
from .preferences import get_dev_mode

from .operators.import_stl       import ImportSTL, CenterModel
from .operators.ortho_view       import DynaxSetOrthoView
from .operators.paralink_ops     import (
    DynaxParaLinkDiagnostics, DynaxParaLinkClearDiagnostics, DynaxParaLinkConnect,
    DynaxParaLinkSetMode, DynaxParaLinkAnalyseGuided, DynaxParaLinkValidateJoin,
    DynaxParaLinkResetBoundary,
)
from .operators.ruler_toggle     import RulerToggle, ClearMeasurements
from .operators.plane_slice      import PlaneSlice, PlaneSliceApply
from .operators.medical_smooth   import MedicalSmooth
from .operators.clean_slice      import CleanSlice
from .operators.boolean_join     import BooleanJoin
from .operators.join_objects     import JoinObjects
from .operators.fuse_voxel       import FuseVoxel
from .operators.scale_to_size    import ScaleToSize
from .operators.offset           import OffsetAddUpdate, OffsetApply, OffsetRemove
from .operators.extrude_faces    import ExtrudeSelectedFaces
from .operators.export_stl       import ExportSTL
from .operators.box_crop         import BoxCrop, BoxCropApply
from .operators.crop             import (
    DynaxCropBox, DynaxCropBoxApply,
)
from .operators.circumference    import (
    DynaxRingsAuto, DynaxRingPlace, DynaxRingsClear,
    DynaxRingGizmoStart, DynaxRingGizmoConfirm,
    DynaxMeasureCircumference, DynaxMeasureMultiple,
    DynaxMeasureClick, DynaxMeasureClickClear, DynaxMeasureClickCancel,
    unregister_draw_on_unload,
)
from .operators.trimline         import (
    DynaxTrimlinePlacePoints, DynaxTrimlineUndoPoint, DynaxTrimlineCloseLoop,
    DynaxTrimlineEdit, DynaxTrimlineCut, DynaxTrimlineClear, DynaxPickPart,
    DynaxTrimlineQuickSlice, DynaxFlareEdge,
    unregister_draw_on_unload as trimline_unregister_draw_on_unload,
)
from .operators.sculpt_helpers   import (
    DynaxSculptStart, DynaxSculptEnd, DynaxSculptStartSmooth, DynaxUpdateSmoothBrush,
    DynaxSelectionMaskAdd, DynaxSelectionMaskClear,
    DynaxSelectionInvert, DynaxPushPull,
    DynaxAlignScan, DynaxRotateX90, DynaxRotateY90, DynaxRotateZ90,
)
from .operators.sculpt_brushes  import (
    DynaxBrushGrab, DynaxBrushDraw, DynaxBrushSmooth, DynaxBrushInflate,
    DynaxBrushFlatten, DynaxBrushMask, DynaxBrushTrim, DynaxBrushCrease,
    DynaxBrushPinch, DynaxBrushUpdateSettings,
)
from .operators.workflow_nav     import DynaxGotoStep, DynaxStepNav
from .operators.components       import (
    DynaxImportComponent, DynaxOrganiseCollections,
    DynaxAttachComponent, DynaxAlignComponentZ,
)
from .operators.auto_remesh      import DynaxAutoRemesh, DynaxRemeshUndo, DynaxRemeshRedo
from .operators.quad_remesh      import DynaxQuadRemesh, DynaxQuadRemeshRestore
from .operators.quad_view        import DynaxQuadViewToggle
from .operators.compare_overlay  import DynaxToggleCompareOverlay, DynaxMeasureCompareOffset
from .operators.checkpoints     import (
    DynaxSaveCheckpoint, DynaxRestoreCheckpoint, DynaxClearCheckpoints,
)
from .operators.cost_estimator   import DynaxEstimateCost
from .operators.height_band_groups import (
    DynaxCreateHeightBandGroups, DynaxClearHeightBandGroups,
)
from .operators.parametric_socket import (
    DynaxLoadParametricTemplate, DynaxBuildParametricRig,
    DynaxFinalizeParametricSocket,
    DynaxPreviewBand, DynaxPreviewBandEnd,
)
from .operators.set_mode import DynaxSetMode
from .operators.settings import DynaxOpenSettings, DynaxCloseSettings, DynaxSetLanguage
from .operators.component_bridge import DynaxLoadComponent, DynaxBuildComponentBridge
from .operators.component_transition import (
    DynaxPrepareTransition, DynaxGenerateTransition, DynaxCancelTransition,
)
# operators.manual_bridge (v1.6.0-v1.9.x manual zone-selection bridge) is
# superseded by the rebuilt automatic component_bridge.py above — no longer
# imported/registered, but the file is left on disk rather than deleted.
from .operators.select_tools     import (
    DynaxSelectBox, DynaxSelectLasso, DynaxSelectCircle,
    DynaxSelectClear, DynaxSelectInvert, DynaxSelectAll,
    DynaxLockSelection, DynaxMoveRegion, DynaxRotateRegion, DynaxFinishRegion,
    DynaxCancelRegion,
    DynaxGizmoMove, DynaxGizmoRotate, DynaxMeshFilterGrab,
    DynaxMaskExtract, DynaxRegionToVertexGroup,
    DynaxSeparateSelected, DynaxSmoothCutBoundary, DynaxFillBoundary,
    DynaxDeletePart,
)
from .operators.align_gizmo      import (
    DynaxAlignGizmoMove, DynaxAlignGizmoRotate, DynaxAlignNumeric,
    DynaxAlignReset, DynaxApplyNumericRotation,
)
from .operators.paramold.mold_aligner import (
    DynaxMoldAlign, DynaxMoldRotate90, DynaxMoldFlip,
)
from .operators.paramold.mold_generator import (
    DynaxMoldGenerate, DynaxMoldExport, DynaxMoldApplyKeys, DynaxMoldApplyPourChannel,
    DynaxMoldReset, DynaxMoldSkipAlign, DynaxMoldSkipAdjust,
)
from .operators.paramold.mold_trim import (
    DynaxMoldAddCutPlane, DynaxMoldApplyCut, DynaxMoldEnterSculpt,
)
from .paraforge.operators.import_scan import (
    PARAFORGE_OT_import_scan, PARAFORGE_OT_export,
)
from .paraforge.operators.mesh_prep import (
    PARAFORGE_OT_remesh, PARAFORGE_OT_ready_begin_mapping,
    PARAFORGE_OT_apply_rotation, apply_manual_rotation,
)
from .paraforge.operators.smooth_brush import (
    PARAFORGE_OT_start_smooth, PARAFORGE_OT_done_smooth, update_smooth_strength,
)
from .paraforge.operators.mapping_wizard import (
    PARAFORGE_OT_start_painting, PARAFORGE_OT_confirm_zone,
    PARAFORGE_OT_wizard_back, PARAFORGE_OT_skip_all_dev,
)
from .paraforge.operators.slider_engine import (
    PARAFORGE_OT_reset_zone, PARAFORGE_OT_reset_all_zones,
    register_slider_properties, unregister_slider_properties,
)
from .paraforge.operators.project_io import (
    PARAFORGE_OT_save_project, PARAFORGE_OT_load_project,
)
from .paraforge.operators.device_select import PARAFORGE_OT_set_device_type
from .paraforge.operators.tlso_alignment import (
    PARAFORGE_OT_tlso_add_alignment_planes, PARAFORGE_OT_tlso_remove_alignment_planes,
    PARAFORGE_OT_tlso_apply_alignment, apply_tlso_alignment_transform,
)
from .paraforge.operators.tlso_mapping_wizard import (
    PARAFORGE_OT_tlso_start_painting, PARAFORGE_OT_tlso_confirm_zone,
    PARAFORGE_OT_tlso_skip_zone, PARAFORGE_OT_tlso_back_zone,
    PARAFORGE_OT_tlso_skip_all_dev,
)
from .paraforge.operators.tlso_slider_engine import (
    PARAFORGE_OT_tlso_reset_zone, PARAFORGE_OT_tlso_reset_all,
    register_tlso_slider_properties, unregister_tlso_slider_properties,
)
from .paraforge.operators.afo_landmarks import (
    PARAFORGE_OT_afo_place_landmarks, PARAFORGE_OT_afo_clear_landmarks,
)
from .paraforge.operators.afo_alignment import (
    PARAFORGE_OT_afo_auto_align, PARAFORGE_OT_afo_ui_set_stage,
)
from .paraforge.operators.afo_correction import (
    PARAFORGE_OT_afo_store_correction_baseline, PARAFORGE_OT_afo_apply_corrections,
    PARAFORGE_OT_afo_reset_corrections, PARAFORGE_OT_afo_ideal_alignment,
    _apply_afo_corrections,
)
from .paraforge.operators.afo_mapping_wizard import (
    PARAFORGE_OT_afo_start_painting, PARAFORGE_OT_afo_confirm_zone,
    PARAFORGE_OT_afo_skip_zone, PARAFORGE_OT_afo_back_zone,
    PARAFORGE_OT_afo_skip_all_dev,
)
from .paraforge.operators.afo_slider_engine import (
    PARAFORGE_OT_afo_reset_zone, PARAFORGE_OT_afo_reset_all,
    register_afo_slider_properties, unregister_afo_slider_properties,
)
from .paraforge.operators.afo_measurement import (
    PARAFORGE_OT_afo_measure_click, PARAFORGE_OT_afo_clear_measurements,
    PARAFORGE_OT_afo_export_measurements_csv,
)
from .paraforge.operators.trimline_bridge import PARAFORGE_OT_trimline_dispatch
from .paraforge.operators.tlso_lattice import (
    PARAFORGE_OT_tlso_lattice_create, PARAFORGE_OT_tlso_lattice_apply,
    PARAFORGE_OT_tlso_lattice_reset, DynaxTLSOSelectLevel,
)
from .paraforge.image_loader import load_zone_previews, unload_zone_previews
from .spatial_agent import landmark_manager, displacement_engine
from .operators.insole import (
    DYNAX_OT_insole_load_scan, DYNAX_OT_insole_apply_preset, DYNAX_OT_insole_export,
)
from .panels.dynax_panel         import (
    DYNAX_PT_header, DYNAX_PT_toolbar, DYNAX_PT_tools,
)
from .panels.ai_assistant        import (
    DYNAX_OT_ai_query, DYNAX_OT_ai_apply, DYNAX_OT_ai_clear, DYNAX_PT_ai_section,
    DYNAX_PT_ai_launcher,
    DYNAX_OT_show_context, DYNAX_OT_ai_quick_tool,
    DYNAX_OT_ai_confirm_action, DYNAX_OT_ai_cancel_action,
    DYNAX_OT_ai_feedback, DYNAX_OT_ai_submit_expectation, DYNAX_OT_ai_quick_prompt,
    DYNAX_OT_ai_open_import, DYNAX_OT_ai_switch_environment,
    DynaXAIConversationLine, DYNAX_UL_ai_conversation,
    dynax_ai_input_update,
)
# Phase 2 (DynaX CAD Agent tool registry): importing this module runs its
# module-level register_tool(...) calls (see ai/tools.py), populating
# TOOL_REGISTRY. This import's only purpose is that side effect - nothing
# here is a bpy.types class, so it is never added to `classes` below.
from .ai import tools as _ai_tools
# AI Agent Core: same reasoning as _ai_tools above - importing this module
# runs its module-level register_module(...) calls (ai/modules.py),
# populating MODULE_REGISTRY with the built-in Creator/ParaForm/ParaFly
# capability modules. Already imported transitively via
# panels.ai_assistant, but explicit here too so this side effect isn't
# silently dependent on that other import's internal structure.
from .ai import modules as _ai_modules
# Same reasoning again: populates ai.task_state.TASK_SCHEMAS via its
# module-level register_task_schema(...) calls.
from .ai import task_state as _ai_task_state
from .properties.dynax_properties import DynaxProperties
from .utils.branding import register_icons, unregister_icons, restore_viewport
from .utils import translations

bl_info = {
    "name": "DynaX",
    "author": "Dynalimb Technologies",
    "version": (1, 24, 8),
    "blender": (4, 1, 0),
    "category": "Medical",
    "description": "Guided prosthetic and orthotic design workflow",
    "location": "View3D > Sidebar > DynaX",
}

classes = [
    preferences.DynaXPreferences,
    DynaxProperties,
    DynaxGotoStep, DynaxStepNav,
    ImportSTL, CenterModel, ExportSTL, ScaleToSize,
    DynaxSetOrthoView,
    DynaxParaLinkDiagnostics, DynaxParaLinkClearDiagnostics, DynaxParaLinkConnect,
    DynaxParaLinkSetMode, DynaxParaLinkAnalyseGuided, DynaxParaLinkValidateJoin,
    DynaxParaLinkResetBoundary,
    RulerToggle, ClearMeasurements,
    DynaxRingsAuto, DynaxRingPlace, DynaxRingsClear,
    DynaxRingGizmoStart, DynaxRingGizmoConfirm,
    DynaxMeasureCircumference, DynaxMeasureMultiple,
    DynaxMeasureClick, DynaxMeasureClickClear, DynaxMeasureClickCancel,
    PlaneSlice, PlaneSliceApply,
    BoxCrop, BoxCropApply,
    DynaxCropBox, DynaxCropBoxApply,
    CleanSlice, BooleanJoin, JoinObjects, FuseVoxel,
    MedicalSmooth, DynaxAutoRemesh, DynaxRemeshUndo, DynaxRemeshRedo,
    DynaxQuadRemesh, DynaxQuadRemeshRestore, DynaxQuadViewToggle,
    DynaxToggleCompareOverlay, DynaxMeasureCompareOffset,
    DynaxSaveCheckpoint, DynaxRestoreCheckpoint, DynaxClearCheckpoints,
    DynaxEstimateCost,
    DynaxCreateHeightBandGroups, DynaxClearHeightBandGroups,
    DynaxLoadParametricTemplate, DynaxBuildParametricRig,
    # Registering this is what makes ParaForm's "Finalize Shape for Components"
    # button work at all — without it the panel calls a nonexistent operator,
    # dynax_paraform_finalized is never set, and the Components section (which
    # is gated on that flag) can never appear.
    DynaxFinalizeParametricSocket,
    DynaxPreviewBand, DynaxPreviewBandEnd, DynaxSetMode,
    DynaxOpenSettings, DynaxCloseSettings, DynaxSetLanguage,
    DynaxLoadComponent, DynaxBuildComponentBridge,
    DynaxPrepareTransition, DynaxGenerateTransition, DynaxCancelTransition,
    OffsetAddUpdate, OffsetApply, OffsetRemove,
    ExtrudeSelectedFaces,
    DynaxTrimlinePlacePoints, DynaxTrimlineUndoPoint, DynaxTrimlineCloseLoop,
    DynaxTrimlineEdit, DynaxTrimlineCut, DynaxTrimlineClear, DynaxPickPart,
    DynaxTrimlineQuickSlice, DynaxFlareEdge,
    DynaxSculptStart, DynaxSculptEnd, DynaxSculptStartSmooth, DynaxUpdateSmoothBrush,
    DynaxSelectionMaskAdd, DynaxSelectionMaskClear,
    DynaxSelectionInvert, DynaxPushPull,
    DynaxAlignScan, DynaxRotateX90, DynaxRotateY90, DynaxRotateZ90,
    DynaxImportComponent, DynaxOrganiseCollections,
    DynaxAttachComponent, DynaxAlignComponentZ,
    DynaxSelectBox, DynaxSelectLasso, DynaxSelectCircle,
    DynaxSelectClear, DynaxSelectInvert, DynaxSelectAll,
    DynaxLockSelection, DynaxMoveRegion, DynaxRotateRegion, DynaxFinishRegion,
    DynaxCancelRegion,
    DynaxGizmoMove, DynaxGizmoRotate, DynaxMeshFilterGrab,
    DynaxMaskExtract, DynaxRegionToVertexGroup,
    DynaxSeparateSelected, DynaxSmoothCutBoundary, DynaxFillBoundary,
    DynaxDeletePart,
    DynaxAlignGizmoMove, DynaxAlignGizmoRotate, DynaxAlignNumeric,
    DynaxAlignReset, DynaxApplyNumericRotation,
    PARAFORGE_OT_import_scan, PARAFORGE_OT_export,
    PARAFORGE_OT_remesh, PARAFORGE_OT_ready_begin_mapping, PARAFORGE_OT_apply_rotation,
    PARAFORGE_OT_start_smooth, PARAFORGE_OT_done_smooth,
    PARAFORGE_OT_start_painting, PARAFORGE_OT_confirm_zone,
    PARAFORGE_OT_wizard_back, PARAFORGE_OT_skip_all_dev,
    PARAFORGE_OT_reset_zone, PARAFORGE_OT_reset_all_zones,
    PARAFORGE_OT_save_project, PARAFORGE_OT_load_project,
    PARAFORGE_OT_set_device_type,
    PARAFORGE_OT_tlso_add_alignment_planes, PARAFORGE_OT_tlso_remove_alignment_planes,
    PARAFORGE_OT_tlso_apply_alignment,
    PARAFORGE_OT_tlso_start_painting, PARAFORGE_OT_tlso_confirm_zone,
    PARAFORGE_OT_tlso_skip_zone, PARAFORGE_OT_tlso_back_zone,
    PARAFORGE_OT_tlso_skip_all_dev,
    PARAFORGE_OT_tlso_reset_zone, PARAFORGE_OT_tlso_reset_all,
    PARAFORGE_OT_afo_place_landmarks, PARAFORGE_OT_afo_clear_landmarks,
    PARAFORGE_OT_afo_auto_align, PARAFORGE_OT_afo_ui_set_stage,
    PARAFORGE_OT_afo_store_correction_baseline, PARAFORGE_OT_afo_apply_corrections,
    PARAFORGE_OT_afo_reset_corrections, PARAFORGE_OT_afo_ideal_alignment,
    PARAFORGE_OT_afo_start_painting, PARAFORGE_OT_afo_confirm_zone,
    PARAFORGE_OT_afo_skip_zone, PARAFORGE_OT_afo_back_zone,
    PARAFORGE_OT_afo_skip_all_dev,
    PARAFORGE_OT_afo_reset_zone, PARAFORGE_OT_afo_reset_all,
    PARAFORGE_OT_afo_measure_click, PARAFORGE_OT_afo_clear_measurements,
    PARAFORGE_OT_afo_export_measurements_csv,
    PARAFORGE_OT_trimline_dispatch,
    PARAFORGE_OT_tlso_lattice_create, PARAFORGE_OT_tlso_lattice_apply,
    PARAFORGE_OT_tlso_lattice_reset, DynaxTLSOSelectLevel,
    DynaxMoldAlign, DynaxMoldRotate90, DynaxMoldFlip,
    DynaxMoldGenerate, DynaxMoldExport, DynaxMoldApplyKeys, DynaxMoldApplyPourChannel,
    DynaxMoldReset, DynaxMoldSkipAlign, DynaxMoldSkipAdjust,
    DynaxMoldAddCutPlane, DynaxMoldApplyCut, DynaxMoldEnterSculpt,
    DYNAX_PT_header, DYNAX_PT_toolbar, DYNAX_PT_tools,
    DYNAX_OT_ai_query, DYNAX_OT_ai_apply, DYNAX_OT_ai_clear, DYNAX_PT_ai_section,
    DYNAX_PT_ai_launcher,
    DYNAX_OT_show_context, DYNAX_OT_ai_quick_tool,
    DYNAX_OT_ai_confirm_action, DYNAX_OT_ai_cancel_action,
    DYNAX_OT_ai_feedback, DYNAX_OT_ai_submit_expectation, DYNAX_OT_ai_quick_prompt,
    DYNAX_OT_ai_open_import, DYNAX_OT_ai_switch_environment,
    DynaXAIConversationLine, DYNAX_UL_ai_conversation,
    # Spatial Agent (v1.23.0)
    landmark_manager.DYNAX_OT_landmark_start_zone,
    landmark_manager.DYNAX_OT_landmark_confirm_zone,
    landmark_manager.DYNAX_OT_landmark_clear_all,
    landmark_manager.DYNAX_OT_landmark_delete_zone,
    displacement_engine.DYNAX_OT_apply_landmark_rules,
    displacement_engine.DYNAX_OT_reset_zone_adjustments,
    displacement_engine.DYNAX_OT_toggle_spatial_compare,
    # ParaFly Insole geometry operators (v1.23.0)
    DYNAX_OT_insole_load_scan, DYNAX_OT_insole_apply_preset, DYNAX_OT_insole_export,
]


def _safe_unregister_class(cls):
    try:
        bpy.utils.unregister_class(cls)
    except Exception:
        pass


def _safe_register_class(cls):
    try:
        existing = getattr(bpy.types, cls.__name__, None)
        if existing is not None:
            try:
                bpy.utils.unregister_class(existing)
            except Exception:
                pass
    except Exception:
        pass
    bpy.utils.register_class(cls)


# SPEC_tlso_zone_update_7zones.md Section 7: zones removed from
# tlso_reference.blend (see tlso_zone_definitions.py's module docstring) whose
# slider properties may still be registered on bpy.types.Scene from an
# earlier session that never restarted Blender - register_tlso_slider_properties()
# already only registers properties for get_tlso_zone_names()'s current
# (7-zone) list, but its own unregister pass iterates that SAME current list
# too, so it can't know about a stale property for a zone the reference blend
# no longer has. Explicitly named here so a hot-reload (not a full Blender
# restart) can't leave one of these behind.
REMOVED_TLSO_ZONE_IDS = [
    "zone_tlso_axillary_roll_right",
    "zone_tlso_rib_hump_relief_right",
    "zone_tlso_superior_trim_line",
    "zone_tlso_inferior_trim_line",
    "zone_tlso_anterior_opening",
]


def cleanup_removed_tlso_zone_properties():
    for zone_id in REMOVED_TLSO_ZONE_IDS:
        prop_name = f"parafly_tlso_slider_{zone_id}"
        if hasattr(bpy.types.Scene, prop_name):
            try:
                delattr(bpy.types.Scene, prop_name)
            except Exception:
                pass


def _register_sliders_deferred():
    """One-shot bpy.app.timers callback — see the comment at its call site in
    register() for why this can't run synchronously inside register() itself.
    Covers all three ParaFly device workflows' dynamic sliders (TT, TLSO, AFO) —
    afo_zone_reader.get_afo_zone_names() hits the exact same restricted-bpy.data
    problem as TT's get_zone_names() / TLSO's get_tlso_zone_names(), for the
    same reason (bpy.data.libraries.load reading the reference blend)."""
    try:
        register_slider_properties()
    except Exception as e:
        print(f"[DynaX] Failed to register ParaFly TT slider properties: {e}")
    try:
        register_tlso_slider_properties()
    except Exception as e:
        print(f"[DynaX] Failed to register ParaFly TLSO slider properties: {e}")
    try:
        register_afo_slider_properties()
    except Exception as e:
        print(f"[DynaX] Failed to register ParaFly AFO slider properties: {e}")
    try:
        displacement_engine.register_zone_adjust_properties()
    except Exception as e:
        print(f"[DynaX] Failed to register Spatial Agent zone-adjust properties: {e}")
    return None  # do not repeat


def register():
    for cls in reversed(classes):
        _safe_unregister_class(cls)
    cleanup_removed_tlso_zone_properties()
    for attr in (
        "dynax_props", "dynax_export_path", "dynax_progress_display",
        "paraforge_active_object", "paraforge_stage",
        "paraforge_mapping_step", "paraforge_remesh_voxel_size",
        "paraforge_smooth_strength", "paraforge_manual_rot_x",
        "paraforge_manual_rot_y", "paraforge_manual_rot_z",
        "parafly_device_type", "parafly_tlso_stage", "parafly_tlso_mapping_step",
        "parafly_tlso_planes_active", "parafly_advanced_open", "parafly_export_open",
        "parafly_components_open",
        "parafly_tlso_pos_x", "parafly_tlso_pos_y", "parafly_tlso_pos_z",
        "parafly_tlso_rot_x", "parafly_tlso_rot_y", "parafly_tlso_rot_z",
        "parafly_afo_stage", "parafly_afo_mapping_step", "parafly_afo_ui_stage",
        "parafly_afo_landmarks", "parafly_afo_current_landmark",
        "parafly_afo_ankle_angle", "parafly_afo_footroll_angle",
        "parafly_afo_forefoot_angle", "parafly_afo_forefoot_vertical_angle",
        "parafly_afo_heeltilt_angle",
        "parafly_afo_measurements", "parafly_afo_measure_mode",
        "parafly_afo_meas_open",
        "dynax_component_loaded", "dynax_bridge_complete", "dynax_component_scale",
        "dynax_transition_profile", "dynax_transition_stage", "dynax_cutter_active",
        "dynax_ui_compare_open", "dynax_ui_checkpoints_open", "dynax_ui_instructions_open",
        "dynax_connection_style", "dynax_support_count", "dynax_paralink_style",
        "dynax_paralink_mode", "dynax_paralink_boundary_offset",
        "dynax_paralink_guided_loop_length", "dynax_paralink_guided_offset_distance",
        "dynax_paralink_guided_transition_z", "dynax_paralink_guided_quality",
        "dynax_paralink_guided_ready",
        "dynax_ai_input", "dynax_ai_response", "dynax_ai_busy",
        "dynax_ai_history_text", "dynax_ai_conversation_lines",
        "dynax_ai_conversation_lines_index",
        "dynax_ai_suggestion", "dynax_ai_offline", "dynax_ai_online_mode",
        "dynax_ai_last_feedback", "dynax_ai_feedback_turn", "dynax_ai_expectation",
        "dynax_mold_wall_thickness", "dynax_mold_mode", "dynax_mold_split_axis",
        "dynax_mold_pour_position", "dynax_mold_has_undercuts", "dynax_mold_volume_ml",
        "dynax_mold_cut_direction",
        "dynax_tlso_lattice_active", "dynax_tlso_lattice_mode",
        "dynax_insole_preset", "dynax_insole_scan_loaded", "dynax_insole_foot_side",
        "dynax_spatial_concept", "dynax_spatial_landmark_id", "dynax_landmark_zones",
        "dynax_spatial_show_advanced", "dynax_stump_type", "dynax_prominence_depth",
        "dynax_ai_mode",
    ):
        if hasattr(bpy.types.Scene, attr):
            try:
                delattr(bpy.types.Scene, attr)
            except Exception:
                pass
    for cls in classes:
        _safe_register_class(cls)
    register_icons()
    load_zone_previews()
    translations.register()
    bpy.types.Scene.dynax_props = PointerProperty(type=DynaxProperties)
    bpy.types.Scene.dynax_export_path = StringProperty(
        name="Export path",
        default=os.path.expanduser("~/DynaxExports"),
        subtype='DIR_PATH',
    )
    bpy.types.Scene.dynax_progress_display = FloatProperty(
        name="Progress", default=0.0, min=0.0, max=100.0,
        subtype='PERCENTAGE',
    )

    # ── ParaForge Clinical Zones scene state (v1.13.0) ─────────────────────────
    bpy.types.Scene.paraforge_active_object = PointerProperty(
        type=bpy.types.Object,
        name="ParaForge Active Object",
    )
    bpy.types.Scene.paraforge_stage = EnumProperty(
        name="ParaForge Stage",
        items=[
            ('INPUT', 'Input', ''),
            ('PREPARATION', 'Preparation', ''),
            ('MAPPING', 'Clinical Mapping', ''),
            ('ADJUSTMENT', 'Clinical Adjustment', ''),
            ('ADVANCED', 'Advanced', ''),
        ],
        default='INPUT',
    )
    bpy.types.Scene.paraforge_mapping_step = IntProperty(
        name="Mapping Step", default=0, min=0,
    )
    # NOTE: DynaX is mm-space (scale_length = 0.001, 1 Blender unit = 1 mm — see
    # CLAUDE.md "Unit System Architecture"). The reference spec's default of 0.003
    # assumed 1 unit = 1 metre; the mm-scale equivalent used here (default 3.0 mm,
    # floor matching auto_remesh.py's MIN_VOXEL = 1.5 mm) is what actually produces
    # a ~3 mm voxel remesh in this addon's coordinate space.
    bpy.types.Scene.paraforge_remesh_voxel_size = FloatProperty(
        name="Voxel Size (mm)", default=3.0, min=0.5, max=15.0, precision=2,
        description="Voxel remesh resolution in millimetres",
    )
    bpy.types.Scene.paraforge_smooth_strength = FloatProperty(
        name="Strength", default=0.5, min=0.1, max=1.0, precision=2,
        update=update_smooth_strength,
    )
    bpy.types.Scene.paraforge_manual_rot_x = FloatProperty(
        name="Rotate X", default=0.0, min=-180.0, max=180.0,
        update=lambda self, context: apply_manual_rotation(context),
    )
    bpy.types.Scene.paraforge_manual_rot_y = FloatProperty(
        name="Rotate Y", default=0.0, min=-180.0, max=180.0,
        update=lambda self, context: apply_manual_rotation(context),
    )
    bpy.types.Scene.paraforge_manual_rot_z = FloatProperty(
        name="Rotate Z", default=0.0, min=-180.0, max=180.0,
        update=lambda self, context: apply_manual_rotation(context),
    )

    # ── ParaFly TLSO scene state (v1.15.0) ──────────────────────────────────
    bpy.types.Scene.parafly_device_type = EnumProperty(
        name="ParaFly Device",
        items=[
            ('NONE', 'None', ''),
            ('TT', 'Transtibial', ''),
            ('TLSO', 'TLSO', ''),
            ('AFO', 'AFO', ''),
        ],
        default='NONE',
    )
    bpy.types.Scene.parafly_tlso_stage = EnumProperty(
        name="ParaFly TLSO Stage",
        items=[
            ('INPUT', 'Input', ''),
            ('ALIGNMENT', 'Orientation & Alignment', ''),
            ('MAPPING', 'Clinical Mapping', ''),
            ('ADJUSTMENT', 'Clinical Adjustment', ''),
            ('ADVANCED', 'Advanced', ''),
        ],
        default='INPUT',
    )
    bpy.types.Scene.parafly_tlso_mapping_step = IntProperty(
        name="TLSO Mapping Step", default=0, min=0,
    )
    # SPEC_parafly_smooth_remesh_collapsible.md Section 4: Advanced Tools and
    # Export (shared by TT and TLSO - panels/paraforge_panel.py's
    # _draw_advanced/_draw_export) are collapsible, collapsed by default -
    # replaces the earlier parafly_advanced_stage staged-wizard property,
    # which no longer has any code reading it.
    bpy.types.Scene.parafly_advanced_open = BoolProperty(
        name="Advanced Tools", default=False,
    )
    bpy.types.Scene.parafly_export_open = BoolProperty(
        name="Export", default=False,
    )
    # paraforge_panel._draw_components reads this. It was added with the shared
    # Components section but never registered here, so every ParaFly TT draw
    # raised AttributeError at that line — killing Components, Export AND Save
    # Project (everything drawn after it) with no visible error in the sidebar.
    bpy.types.Scene.parafly_components_open = BoolProperty(
        name="Components", default=False,
    )
    bpy.types.Scene.parafly_tlso_planes_active = BoolProperty(
        name="TLSO Alignment Planes Active", default=False,
    )
    # Position/rotation fine-tune, live-updating the object's transform while
    # the alignment planes are visible (mm-space position, matching this
    # addon's convention throughout — NOT metres, unlike the reference spec's
    # assumption; see tlso_alignment.py's module docstring).
    bpy.types.Scene.parafly_tlso_pos_x = FloatProperty(
        name="Position X", default=0.0, min=-1000.0, max=1000.0,
        update=lambda self, context: apply_tlso_alignment_transform(context),
    )
    bpy.types.Scene.parafly_tlso_pos_y = FloatProperty(
        name="Position Y", default=0.0, min=-1000.0, max=1000.0,
        update=lambda self, context: apply_tlso_alignment_transform(context),
    )
    bpy.types.Scene.parafly_tlso_pos_z = FloatProperty(
        name="Position Z", default=0.0, min=-1000.0, max=1000.0,
        update=lambda self, context: apply_tlso_alignment_transform(context),
    )
    bpy.types.Scene.parafly_tlso_rot_x = FloatProperty(
        name="Rotation X", default=0.0, min=-180.0, max=180.0,
        update=lambda self, context: apply_tlso_alignment_transform(context),
    )
    bpy.types.Scene.parafly_tlso_rot_y = FloatProperty(
        name="Rotation Y", default=0.0, min=-180.0, max=180.0,
        update=lambda self, context: apply_tlso_alignment_transform(context),
    )
    bpy.types.Scene.parafly_tlso_rot_z = FloatProperty(
        name="Rotation Z", default=0.0, min=-180.0, max=180.0,
        update=lambda self, context: apply_tlso_alignment_transform(context),
    )

    # ── ParaFly AFO scene state (v1.17.0) ───────────────────────────────────
    bpy.types.Scene.parafly_afo_stage = EnumProperty(
        name="AFO Stage",
        items=[
            ('INPUT', 'Input', ''),
            ('LANDMARKS', 'Landmarks', ''),
            ('ALIGNMENT', 'Alignment', ''),
            ('CORRECTION', 'Angular Correction', ''),
            ('MAPPING', 'Zone Mapping', ''),
            ('ADJUSTMENT', 'Parametric Adj.', ''),
            ('MEASUREMENT', 'Measurements', ''),
        ],
        default='INPUT',
    )
    bpy.types.Scene.parafly_afo_mapping_step = IntProperty(
        name="AFO Mapping Step", default=0, min=0,
    )
    bpy.types.Scene.parafly_afo_ui_stage = StringProperty(
        name="AFO Open Stage", default="",
    )
    # Landmark storage (each landmark = 3 floats X,Y,Z), StringProperty (JSON)
    # for persistence across saves - see afo_landmarks.py's _get_landmarks/
    # _set_landmarks.
    bpy.types.Scene.parafly_afo_landmarks = StringProperty(
        name="AFO Landmarks JSON", default="{}",
    )
    bpy.types.Scene.parafly_afo_current_landmark = StringProperty(
        name="Current Landmark", default="",
    )
    # Angular correction values - update= callbacks deform the mesh live from
    # the stored correction baseline (afo_correction.py's
    # _apply_afo_corrections), same drift-free recompute-from-baseline
    # pattern already proven in slider_engine.py/tlso_slider_engine.py.
    bpy.types.Scene.parafly_afo_ankle_angle = FloatProperty(
        name="Ankle",
        description="Plantarflexion (−) ↔ Dorsiflexion (+)",
        default=0.0, soft_min=-30.0, soft_max=30.0, precision=1,
        update=lambda self, context: _apply_afo_corrections(context),
    )
    bpy.types.Scene.parafly_afo_footroll_angle = FloatProperty(
        name="Foot Roll",
        description="Pronation (−) ↔ Supination (+)",
        default=0.0, soft_min=-20.0, soft_max=20.0, precision=1,
        update=lambda self, context: _apply_afo_corrections(context),
    )
    bpy.types.Scene.parafly_afo_forefoot_angle = FloatProperty(
        name="Forefoot",
        description="Abduction (−) ↔ Adduction (+)",
        default=0.0, soft_min=-20.0, soft_max=20.0, precision=1,
        update=lambda self, context: _apply_afo_corrections(context),
    )
    bpy.types.Scene.parafly_afo_forefoot_vertical_angle = FloatProperty(
        name="Forefoot Vertical",
        description="Plantarflexion (−) ↔ Dorsiflexion (+) of the forefoot",
        default=0.0, soft_min=-20.0, soft_max=20.0, precision=1,
        update=lambda self, context: _apply_afo_corrections(context),
    )
    bpy.types.Scene.parafly_afo_heeltilt_angle = FloatProperty(
        name="Heel Tilt",
        description="Valgus (−) ↔ Varus (+)",
        default=0.0, soft_min=-15.0, soft_max=15.0, precision=1,
        update=lambda self, context: _apply_afo_corrections(context),
    )
    # Measurement storage
    bpy.types.Scene.parafly_afo_measurements = StringProperty(
        name="AFO Measurements JSON", default="[]",
    )
    bpy.types.Scene.parafly_afo_measure_mode = EnumProperty(
        name="Measure Mode",
        items=[
            ('CIRCUMFERENCE', 'Circumference', ''),
            ('LENGTH', 'Length', ''),
        ],
        default='CIRCUMFERENCE',
    )
    # Collapsible Measurements box, same pattern as parafly_advanced_open/
    # parafly_export_open above.
    bpy.types.Scene.parafly_afo_meas_open = BoolProperty(
        name="Measurements", default=False,
    )
    # NOTE: SPEC_parafly_afo_complete.md Section 5 also specified a
    # parafly_afo_smooth_strength property - deliberately NOT registered here.
    # Nothing would ever read it: the shared Smooth Brush section
    # (paraforge_panel._draw_smooth_standalone, reused as-is by AFO's own
    # panel) reads scene.paraforge_smooth_strength, the one property already
    # shared by TT and TLSO - not a third per-device copy.

    # SPEC_tlso_mapping_combined_fix.md: the color-swatch property
    # (parafly_tlso_zone_color, a read-only COLOR FloatVectorProperty shown
    # via layout.prop(..., text="") with .enabled = False) crashed Blender's
    # draw loop silently in this build - removed entirely, along with its
    # registration here. See panels/parafly_tlso_panel.py's _draw_mapping
    # for the replacement (a plain icon+label direction indicator, no
    # property involved).

    # SPEC_parafly_slider_and_zone_corrections.md Section 2: the automatic
    # bilateral-mirroring feature was removed entirely (caused zone deletion
    # bugs) - Waist Area and Trochanter Pad are now explicit _left/_right
    # zones painted separately from the start (see tlso_zone_definitions.py),
    # so there's no runtime mirroring/breaking state to track anymore.

    # SPEC_parafly_trimline_thickness_borrow_creator.md: the custom
    # parafly_trimline_painted / parafly_thickness_mm / parafly_thickness_applied
    # properties (and the trimline.py/thickness.py operators they backed) were
    # removed entirely - ParaFly's Advanced section now calls Creator's real
    # Trimline/Thickness operators directly (see panels/paraforge_panel.py's
    # _draw_trimline_section/_draw_thickness_section), which track their own
    # state via scene["dynax_trim_stage"] and dynax_props.solidify_thickness_mm
    # respectively - no ParaFly-specific properties needed for either.

    # NOT called directly here — see _register_sliders_deferred below. Verified
    # by actually running the real GUI app (not just --background scripts,
    # which bypass this entirely): a direct call raises
    # "AttributeError: '_RestrictData' object has no attribute 'libraries'"
    # whenever this register() runs at Blender's own startup auto-load of an
    # already-enabled addon (the common case for a returning user) — Blender
    # restricts bpy.data file I/O during that callback, and
    # register_slider_properties() -> get_zone_names() reads
    # tt_reference_rigged.blend via bpy.data.libraries.load(). With the call
    # left in place here, every ParaFly slider silently failed to register and
    # the Clinical Adjustment panel then errored on every redraw trying to
    # draw a Scene property that was never created.
    bpy.app.timers.register(_register_sliders_deferred, first_interval=0.0)

    # ── Automatic Component Bridge scene state (v1.16.0) ────────────────────
    bpy.types.Scene.dynax_component_loaded = BoolProperty(
        name="Component Loaded", default=False,
    )
    bpy.types.Scene.dynax_bridge_complete = BoolProperty(
        name="Bridge Complete", default=False,
    )
    bpy.types.Scene.dynax_component_scale = FloatProperty(
        name="Component Scale",
        description="Scale factor for component size (1.0 = full adult size)",
        default=1.0, min=0.5, max=1.0, precision=2,
    )
    # Parametric Transition Surface (v1.17.1) - see component_bridge.py's
    # module docstring fix #7 for the redesign vs.
    # SPEC_component_bridge_parametric_transition.md.
    bpy.types.Scene.dynax_transition_profile = EnumProperty(
        name="Transition Profile",
        description="Shape of the transition between socket and component",
        items=[
            ('SMOOTH_FILLET',    'Smooth Fillet',
             'Organic S-curve transition, natural manufactured appearance'),
            ('STANDARD',         'Standard',
             'Balanced taper with moderate curvature'),
            ('STRAIGHT_TAPER',   'Straight Taper',
             'Linear conical transition'),
            ('CURVED_TAPER',     'Curved Taper',
             'Accelerating taper, wider at socket end'),
            ('REINFORCED_COLLAR','Reinforced Collar',
             'Widened collar at component interface for strength'),
            ('PEDIATRIC',        'Pediatric',
             'Gentle fillet optimised for small component sizes'),
            ('HEAVY_DUTY',       'Heavy Duty',
             'Thicker transition with reinforced rings'),
        ],
        default='SMOOTH_FILLET',
    )
    # DynaX Transition System - dual shrinkwrap "Smart Transition" (v1.18.0),
    # offered alongside the Quick Bridge above. See component_transition.py's
    # module docstring for the real bugs found and fixed vs. its spec.
    bpy.types.Scene.dynax_transition_stage = EnumProperty(
        name="Transition Stage",
        items=[
            ('NONE',        'None',        ''),
            ('LOADED',      'Loaded',      ''),
            ('ALIGNED',     'Aligned',     ''),
            ('INTERACTIVE', 'Interactive', ''),
            ('COMPLETE',    'Complete',    ''),
        ],
        default='NONE',
    )
    bpy.types.Scene.dynax_cutter_active = BoolProperty(
        name="Cutter Active", default=False,
    )

    # Collapsible-section state (v1.19.0) — Compare/Checkpoints are shared
    # reference tools shown on every Creator step (see dynax_panel.py's
    # _draw_creator_panel), and Instructions is the per-step how-to text;
    # all default closed since they're not primary workflow actions, matching
    # the existing parafly_advanced_open/parafly_export_open convention.
    bpy.types.Scene.dynax_ui_compare_open = BoolProperty(
        name="Compare", default=False,
    )
    bpy.types.Scene.dynax_ui_checkpoints_open = BoolProperty(
        name="Checkpoints", default=False,
    )
    bpy.types.Scene.dynax_ui_instructions_open = BoolProperty(
        name="Instructions", default=False,
    )

    # Smart Transition connection style (v1.20.0) - post-Generate smoothing
    # level applied by component_transition.py's _apply_connection_style().
    # The 4 structural columns visible in the raw refined result are a
    # direct consequence of the component's real bolt-hole geometry (the
    # outer zone's shrinkwrap pulls the wall between holes outward) -
    # these controls let the user choose to blend them away, keep them
    # visible for strength, or something in between, rather than treating
    # them as an unwanted artifact to always hide.
    bpy.types.Scene.dynax_connection_style = EnumProperty(
        name="Connection Style",
        items=[
            ('SMOOTH',     'Smooth',
             'Clean cosmetic transition - bridge artifacts smoothed away'),
            ('STRUCTURAL', 'Structural',
             'Visible structural support columns for maximum strength'),
            ('HYBRID',     'Hybrid (Recommended)',
             'Smooth outer transition with integrated structural supports'),
        ],
        default='HYBRID',
    )
    bpy.types.Scene.dynax_support_count = EnumProperty(
        name="Support Count",
        items=[
            ('AUTO', 'Auto (Recommended)', 'Automatically determine optimal count'),
            ('4',    '4',                  '4 structural supports'),
            ('6',    '6',                  '6 structural supports'),
        ],
        default='AUTO',
    )

    # ParaLink (v2.0.0-dev) - separate style property from Smart Transition's
    # dynax_connection_style, since ParaLink is offered alongside Quick
    # Bridge/Smart Transition (Phase 1 of the migration doc's own plan),
    # not replacing either - keeping the properties independent means a
    # user's Smart Transition style choice never silently drives ParaLink
    # or vice versa.
    bpy.types.Scene.dynax_paralink_style = EnumProperty(
        name="Connection Style",
        items=[
            ('SMOOTH',     'Smooth',     'Organic transition'),
            ('STRUCTURAL', 'Structural', 'Visible supports'),
            ('HYBRID',     'Hybrid',     'Recommended'),
        ],
        default='HYBRID',
    )

    # ── ParaLink Involvement Levels (v1.21.0) ───────────────────────────────
    # Four-mode Connection Mode selector. AUTO uses the existing pipeline
    # exactly as-is; GUIDED/SEMI/MANUAL only add UI state around it (mode
    # switch, slider values, guided-analysis display metrics) - see
    # panels/components_section.py and operators/paralink_ops.py. No
    # ParaLink geometry module was modified to add these.
    bpy.types.Scene.dynax_paralink_mode = EnumProperty(
        name="Connection Mode",
        items=[
            ('AUTO', 'Auto', 'Fully automatic - ParaLink handles everything'),
            ('GUIDED', 'Guided', 'AI suggests, you confirm'),
            ('SEMI', 'Semi-Manual', 'You control the key parameters'),
            ('MANUAL', 'Manual', 'Maximum control'),
        ],
        default='AUTO',
    )
    # v1.21.0 test-feedback fix: the previous four sliders (blend distance,
    # transition angle, socket/adapter offset) had no path into
    # run_paralink()/generate_transition_surface() - verified by reading
    # both signatures, neither accepts any of the four. Replaced with
    # connection_style (dynax_paralink_style, already registered above).
    #
    # v1.21.0 test-feedback fix #2: the absolute "cut height (mm)" field
    # that replaced them was still confusing (clinicians don't know the
    # socket's absolute Z in world space) and has itself been replaced by
    # a relative +/- mm nudge on the auto-detected boundary - 0 means fully
    # automatic. See operators/paralink_ops.py's
    # _resolve_user_transition_z() for how this becomes run_paralink()'s
    # user_transition_z.
    bpy.types.Scene.dynax_paralink_boundary_offset = FloatProperty(
        name="Upper boundary",
        description=(
            "Move the socket connection boundary up (+) or down (-) from "
            "the auto-detected position. 0 = automatic."
        ),
        default=0.0, min=-200.0, max=200.0, soft_min=-100.0, soft_max=100.0,
        step=1, precision=1,
        unit='NONE', subtype='NONE',
    )
    # Guided-mode analysis results, for display only - real envelope_analyser.py
    # / boundary-loop outputs, not estimates derived from the removed sliders.
    bpy.types.Scene.dynax_paralink_guided_loop_length = FloatProperty(
        name="Guided Boundary Loop Length", default=0.0,
    )
    bpy.types.Scene.dynax_paralink_guided_offset_distance = FloatProperty(
        name="Guided Offset Distance", default=0.0,
    )
    bpy.types.Scene.dynax_paralink_guided_transition_z = FloatProperty(
        name="Guided Transition Z", default=0.0,
    )
    bpy.types.Scene.dynax_paralink_guided_quality = FloatProperty(
        name="Guided Connection Quality", default=0.0, min=0.0, max=100.0,
    )
    bpy.types.Scene.dynax_paralink_guided_ready = BoolProperty(
        name="Guided Analysis Ready", default=False,
    )

    # ── DynaX AI Assistant (v1.21.0) ────────────────────────────────────────
    bpy.types.Scene.dynax_ai_input = StringProperty(
        name="Question", default="", update=dynax_ai_input_update,
    )
    bpy.types.Scene.dynax_ai_response = StringProperty(
        name="Response", default="",
    )
    bpy.types.Scene.dynax_ai_busy = BoolProperty(
        name="Busy", default=False,
    )
    bpy.types.Scene.dynax_ai_suggestion = StringProperty(
        name="Suggestion JSON", default="",
    )
    bpy.types.Scene.dynax_ai_offline = BoolProperty(
        name="Used offline fallback", default=False,
    )
    # Phase 3 (DynaX CAD Agent): rendered ConversationSession log, refreshed
    # after every turn - see ai/conversation.py. The panel also reads the
    # live session object directly for its own display; this property is
    # the plain-text copy sent as offline context / kept for parity with
    # the other dynax_ai_* scene state.
    bpy.types.Scene.dynax_ai_history_text = StringProperty(
        name="Conversation history", default="",
    )
    # Scroll fix: template_list-backed conversation display - see
    # panels/ai_assistant.py's DynaXAIConversationLine/DYNAX_UL_ai_
    # conversation/_sync_conversation_lines for why this exists (only the
    # conversation should scroll, everything else in the popover is a
    # plain fixed column).
    bpy.types.Scene.dynax_ai_conversation_lines = CollectionProperty(
        type=DynaXAIConversationLine,
    )
    bpy.types.Scene.dynax_ai_conversation_lines_index = IntProperty(
        name="Conversation Line Index", default=0,
    )
    # Phase 4 (DynaX CAD Agent feedback capture)
    bpy.types.Scene.dynax_ai_last_feedback = StringProperty(
        name="Last AI feedback", default="",  # "positive"|"negative"|""
    )
    bpy.types.Scene.dynax_ai_feedback_turn = IntProperty(
        name="Feedback turn index", default=-1,
    )
    bpy.types.Scene.dynax_ai_expectation = StringProperty(
        name="What were you expecting?", default="",
    )
    # v1.21.0 test-feedback fix: explicit online/offline toggle, default OFF
    # (offline-first — matches the hard "must work fully offline" constraint).
    # When True, DYNAX_OT_ai_query tries ai.dynax.app first and falls back to
    # local_fallback() on ANY failure; when False it skips the API entirely.
    bpy.types.Scene.dynax_ai_online_mode = BoolProperty(
        name="Online AI",
        description=(
            "Call ai.dynax.app for enhanced suggestions. "
            "Falls back to offline rules if unavailable."
        ),
        default=False,
    )

    # ── ParaMold: silicone finger prosthesis molds (v1.22.0) ────────────────
    bpy.types.Scene.dynax_mold_wall_thickness = FloatProperty(
        name="Wall thickness (mm)", default=8.0, min=4.0, max=20.0,
    )
    bpy.types.Scene.dynax_mold_mode = EnumProperty(
        name="Mode",
        items=[
            ('AUTO', 'Automatic', ''),
            ('MANUAL', 'Manual', ''),
        ],
        default='AUTO',
    )
    bpy.types.Scene.dynax_mold_split_axis = EnumProperty(
        name="Split axis",
        items=[
            ('X', 'Sagittal (left-right)', ''),
            ('Y', 'Coronal (front-back)', ''),
        ],
        default='X',
    )
    bpy.types.Scene.dynax_mold_pour_position = EnumProperty(
        name="Pour position",
        items=[
            ('PROXIMAL', 'Proximal end', ''),
            ('DISTAL', 'Distal tip', ''),
        ],
        default='PROXIMAL',
    )
    bpy.types.Scene.dynax_mold_has_undercuts = BoolProperty(
        name="Undercuts detected", default=False,
    )
    bpy.types.Scene.dynax_mold_volume_ml = FloatProperty(
        name="Silicone volume (mL)", default=0.0,
    )
    bpy.types.Scene.dynax_mold_cut_direction = EnumProperty(
        name="Keep which part",
        items=[
            ('KEEP_LOWER', 'Keep lower part', 'Remove everything above the cut plane'),
            ('KEEP_UPPER', 'Keep upper part', 'Remove everything below the cut plane'),
        ],
        default='KEEP_LOWER',
    )

    # ── ParaFly TLSO Spine Curve Lattice (v1.22.0) ───────────────────────────
    bpy.types.Scene.dynax_tlso_lattice_active = BoolProperty(
        name="Lattice active", default=False,
    )
    bpy.types.Scene.dynax_tlso_lattice_mode = EnumProperty(
        name="Lattice mode",
        items=[
            ('AUTO', 'Auto-fit to scan', ''),
            ('MANUAL', 'Manual adjustment', ''),
        ],
        default='MANUAL',
    )

    # ── ParaFly Insole groundwork only (v1.22.0) - no operators consume ─────
    # these yet; the full scan-based insole build is a future session's work.
    bpy.types.Scene.dynax_insole_preset = StringProperty(
        name="Selected preset", default="",
    )
    bpy.types.Scene.dynax_insole_scan_loaded = BoolProperty(
        name="Foot scan loaded", default=False,
    )
    bpy.types.Scene.dynax_insole_foot_side = EnumProperty(
        name="Foot side",
        items=[
            ('LEFT', 'Left foot', ''),
            ('RIGHT', 'Right foot', ''),
        ],
        default='LEFT',
    )

    # ── Spatial Agent — Transtibial Socket (v1.23.0) ─────────────────────
    bpy.types.Scene.dynax_spatial_concept = EnumProperty(
        name="Concept",
        items=[
            ("TSB", "TSB", "Total Surface Bearing"),
            ("PTB", "PTB", "Patellar Tendon Bearing"),
        ],
        default="TSB",
    )
    # v3.0.0+: zone identity comes from the clinician-authored CAD
    # Modification Matrix (spatial_agent/ruleset/transtibial_ruleset.json —
    # see landmark_manager.py / ruleset_engine.py). Dynamic (callback)
    # items, not a static list, purely for this add-on's established
    # GC-safety pattern (properties/dynax_properties.py's _component_items)
    # — the ruleset itself is a plain JSON read with no Blender-startup
    # restriction, unlike ParaFly's zone system this used to be modeled on.
    bpy.types.Scene.dynax_spatial_landmark_id = EnumProperty(
        name="Landmark",
        items=landmark_manager.spatial_zone_enum_items,
    )
    bpy.types.Scene.dynax_landmark_zones = StringProperty(default="[]")
    # v1.24.3: patient constraints the ruleset's own "ASK FIRST" agent_rule
    # requires before any displacement — see
    # ruleset_engine.get_patient_covariate_modifiers and
    # DYNAX_OT_apply_landmark_rules.execute's blocking check.
    bpy.types.Scene.dynax_stump_type = EnumProperty(
        name="Stump Type",
        items=[
            ("NONE", "Not Set", ""),
            ("BONY", "Bony", "Minimal soft tissue — bony prominences are superficial and palpable"),
            ("FLESHY", "Fleshy", "Good soft tissue cover over bony structures"),
        ],
        default="NONE",
    )
    bpy.types.Scene.dynax_prominence_depth = EnumProperty(
        name="Prominence Depth",
        items=[
            ("NONE", "Not Set", ""),
            ("SUPERFICIAL", "Superficial", "Prominences are close to skin surface, easily palpable"),
            ("COVERED", "Well Covered", "Prominences have adequate soft tissue cover"),
        ],
        default="NONE",
    )
    bpy.types.Scene.dynax_spatial_show_advanced = BoolProperty(
        default=False, name="Show All Landmarks",
    )
    # dynax_spatial_rules_applied gates the slider section in the panel —
    # there is nothing to fine-tune until Apply Landmark Rules has stored a
    # baseline snapshot (displacement_engine.store_baseline_snapshot). The
    # per-zone dynax_zone_adjust_<id> sliders themselves are registered by
    # displacement_engine.register_zone_adjust_properties(), called from
    # _register_sliders_deferred below — NOT here, for the same restricted-
    # bpy.data-at-startup reason the ParaFly TT/TLSO/AFO sliders are deferred.
    bpy.types.Scene.dynax_spatial_rules_applied = BoolProperty(default=False)
    bpy.types.Scene.dynax_ai_mode = EnumProperty(
        name="AI Panel Mode",
        items=[
            ("CHAT", "Chat", "DynaX CAD Agent chat"),
            ("SPATIAL", "Spatial Agent", "Landmark-based socket design"),
        ],
        default="CHAT",
    )


def unregister():
    # Cancel the deferred slider-registration timer before anything else -
    # register() schedules it via bpy.app.timers.register() but unregister()
    # never cancelled it, so it survived disable/uninstall (pre-existing
    # v1.21.0 test-feedback bug, unrelated to the ParaLink/session-recorder/
    # AI Assistant changes). Placed first so the timer is gone before classes
    # are removed.
    try:
        if bpy.app.timers.is_registered(_register_sliders_deferred):
            bpy.app.timers.unregister(_register_sliders_deferred)
    except Exception:
        pass
    try:
        unregister_slider_properties()
    except Exception:
        pass
    try:
        unregister_tlso_slider_properties()
    except Exception:
        pass
    try:
        unregister_afo_slider_properties()
    except Exception:
        pass
    try:
        displacement_engine.unregister_zone_adjust_properties()
    except Exception:
        pass
    try:
        translations.unregister()
    except Exception:
        pass
    try:
        unregister_draw_on_unload()
    except Exception:
        pass
    try:
        trimline_unregister_draw_on_unload()
    except Exception:
        pass
    try:
        restore_viewport()
        unregister_icons()
    except Exception:
        pass
    try:
        unload_zone_previews()
    except Exception:
        pass
    for attr in (
        "dynax_props", "dynax_export_path", "dynax_progress_display",
        "paraforge_active_object", "paraforge_stage",
        "paraforge_mapping_step", "paraforge_remesh_voxel_size",
        "paraforge_smooth_strength", "paraforge_manual_rot_x",
        "paraforge_manual_rot_y", "paraforge_manual_rot_z",
        "parafly_device_type", "parafly_tlso_stage", "parafly_tlso_mapping_step",
        "parafly_tlso_planes_active", "parafly_advanced_open", "parafly_export_open",
        "parafly_components_open",
        "parafly_tlso_pos_x", "parafly_tlso_pos_y", "parafly_tlso_pos_z",
        "parafly_tlso_rot_x", "parafly_tlso_rot_y", "parafly_tlso_rot_z",
        "parafly_afo_stage", "parafly_afo_mapping_step", "parafly_afo_ui_stage",
        "parafly_afo_landmarks", "parafly_afo_current_landmark",
        "parafly_afo_ankle_angle", "parafly_afo_footroll_angle",
        "parafly_afo_forefoot_angle", "parafly_afo_forefoot_vertical_angle",
        "parafly_afo_heeltilt_angle",
        "parafly_afo_measurements", "parafly_afo_measure_mode",
        "parafly_afo_meas_open",
        "dynax_component_loaded", "dynax_bridge_complete", "dynax_component_scale",
        "dynax_transition_profile", "dynax_transition_stage", "dynax_cutter_active",
        "dynax_ui_compare_open", "dynax_ui_checkpoints_open", "dynax_ui_instructions_open",
        "dynax_connection_style", "dynax_support_count", "dynax_paralink_style",
        "dynax_paralink_mode", "dynax_paralink_boundary_offset",
        "dynax_paralink_guided_loop_length", "dynax_paralink_guided_offset_distance",
        "dynax_paralink_guided_transition_z", "dynax_paralink_guided_quality",
        "dynax_paralink_guided_ready",
        "dynax_ai_input", "dynax_ai_response", "dynax_ai_busy",
        "dynax_ai_history_text", "dynax_ai_conversation_lines",
        "dynax_ai_conversation_lines_index",
        "dynax_ai_suggestion", "dynax_ai_offline", "dynax_ai_online_mode",
        "dynax_ai_last_feedback", "dynax_ai_feedback_turn", "dynax_ai_expectation",
        "dynax_mold_wall_thickness", "dynax_mold_mode", "dynax_mold_split_axis",
        "dynax_mold_pour_position", "dynax_mold_has_undercuts", "dynax_mold_volume_ml",
        "dynax_mold_cut_direction",
        "dynax_tlso_lattice_active", "dynax_tlso_lattice_mode",
        "dynax_insole_preset", "dynax_insole_scan_loaded", "dynax_insole_foot_side",
        "dynax_spatial_concept", "dynax_spatial_landmark_id", "dynax_landmark_zones",
        "dynax_spatial_show_advanced", "dynax_spatial_rules_applied", "dynax_stump_type", "dynax_prominence_depth",
        "dynax_ai_mode",
    ):
        if hasattr(bpy.types.Scene, attr):
            try:
                delattr(bpy.types.Scene, attr)
            except Exception:
                pass
    # dynax_zone_adjust_<id> properties are removed by
    # displacement_engine.unregister_zone_adjust_properties() above, which
    # (like register_zone_adjust_properties) sources the id list from
    # paraforge.zone_reader.get_zone_names() rather than a static list here.
    for cls in reversed(classes):
        _safe_unregister_class(cls)


if __name__ == "__main__":
    register()
