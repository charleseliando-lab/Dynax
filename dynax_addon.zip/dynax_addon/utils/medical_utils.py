# utils/medical_utils.py - Medical Utilities

import bpy
import os

def get_export_path():
    """Returns the export path from the scene properties"""
    return bpy.context.scene.dynax_export_path