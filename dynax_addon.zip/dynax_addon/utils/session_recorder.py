# utils/session_recorder.py - opt-in, offline-safe, anonymous session recording.
#
# Same privacy posture and pending/sent folder pattern as the DynaX Studio
# launcher's analytics_sync.py (see ../../dynax_studio/launcher/analytics_sync.py):
# opt-in only, pseudonymous, never blocks the app, never contains patient data.
# Unlike that launcher module, this runs INSIDE the add-on (so it also works in
# a standalone Blender install with no Studio launcher present), which means it
# does its own network I/O - a deliberate, documented deviation from this
# codebase's usual "the add-on never performs network I/O" rule (see
# analytics/collector.py's module docstring and CLAUDE.md's v1.20.8 analytics
# addendum). Every public entry point below is fail-open and fail-silent: a
# session-recorder bug can never interrupt clinical work, and network code
# never runs on Blender's main thread.
#
# What is recorded is a fixed, closed set of internal identifiers (workflow
# name, step names, counts, a session UUID, timestamps) - never patient names,
# scan data, file paths, measurements, or any free-form value.
#
# Privacy note: free-form AI conversation text (user_input, reason) is only
# stored when the clinician has explicitly enabled "Share AI conversation
# text" in preferences. Default is False — closed-vocabulary fields only
# are stored by default. See _ai_sharing_enabled() and its call sites in
# log_ai_interaction()/log_failed_intent() below. This is a separate,
# narrower opt-in than analytics_enabled (see preferences.py:
# share_ai_conversations is only selectable once analytics_enabled is on),
# resolving the earlier flagged conflict where those two methods stored raw
# clinician-typed text unconditionally.

from __future__ import annotations

import json
import os
import threading
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path

ADDON_PACKAGE_NAME = "dynax_addon"
SYNC_URL = "https://api.dynax.app/api/v1/studio/sessions"
THREAD_TIMEOUT_SECONDS = 10


def _analytics_enabled() -> bool:
    """Opt-in gate. False (and silent) unless the user has explicitly enabled
    it in Add-on Preferences. Never raises - any failure here means "do
    nothing", not "assume enabled"."""
    try:
        import bpy
        prefs = bpy.context.preferences.addons[ADDON_PACKAGE_NAME].preferences
        return bool(getattr(prefs, "analytics_enabled", False))
    except Exception:
        return False


def _ai_sharing_enabled() -> bool:
    """Narrower opt-in than _analytics_enabled(): gates whether raw,
    free-form AI conversation text (user_input/reason) may be stored at
    all. False (and silent) unless the clinician has explicitly enabled
    it - never raises."""
    try:
        import bpy
        prefs = bpy.context.preferences.addons.get(ADDON_PACKAGE_NAME)
        if prefs is None:
            return False
        return bool(getattr(prefs.preferences, "share_ai_conversations", False))
    except Exception:
        return False


def _sessions_root() -> Path:
    appdata = os.environ.get("APPDATA")
    base = Path(appdata) if appdata else Path.home() / ".dynax"
    return base / "DynaX" / "sessions"


def _ensure_dir(path: Path) -> bool:
    try:
        path.mkdir(parents=True, exist_ok=True)
        return True
    except Exception:
        return False


def _addon_version() -> str:
    try:
        from .. import bl_info
        return ".".join(str(part) for part in bl_info["version"])
    except Exception:
        return "unknown"


def _blender_version() -> str:
    try:
        import bpy
        return bpy.app.version_string
    except Exception:
        return "unknown"


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class SessionRecorder:
    """One recorder instance per Blender session (see get_recorder() below).
    Every method is a no-op unless analytics_enabled is True in Add-on
    Preferences, checked once in start(); every method also fails silently on
    any internal error - recording a session must never be able to break a
    clinical workflow."""

    def __init__(self):
        self._active = False
        self._data = None
        self._start_monotonic = None

    def start(self, workflow, device_type):
        # workflow is one of a closed set of six literals: "creator",
        # "paraforge", "parafly_afo", "parafly_tlso", "paralink_tt",
        # "paralink". ParaFly TT gets its own "paralink_tt" value (added
        # after the original five-value spec omitted it) rather than being
        # folded into "paralink", which is reserved for the standalone
        # ParaLink workflow. See operators/import_stl.py's
        # _SESSION_WORKFLOW_MAP for where callers map into this set.
        if not _analytics_enabled():
            self._active = False
            return
        try:
            self._data = {
                "session_id": str(uuid.uuid4()),
                "addon_version": _addon_version(),
                "blender_version": _blender_version(),
                "workflow": workflow or "unknown",
                "device_type": device_type or "unknown",
                "steps_used": [],
                "step_count": 0,
                "paralink_mode_used": "none",
                "paralink_attempts": 0,
                "paralink_success": None,
                "ai_assistant_used": False,
                "ai_suggestions_applied": 0,
                "export_format": "none",
                "session_duration_seconds": 0,
                "ai_interactions": [],
                "failed_intents": [],
                "started_at": _now_iso(),
                "ended_at": None,
            }
            self._start_monotonic = time.monotonic()
            self._active = True
        except Exception:
            self._active = False

    def log_step(self, step_name):
        if not self._active:
            return
        try:
            self._data["steps_used"].append(str(step_name))
            self._data["step_count"] = len(self._data["steps_used"])
        except Exception:
            pass

    def log_paralink(self, mode, success):
        if not self._active:
            return
        try:
            self._data["paralink_mode_used"] = str(mode) if mode else "none"
            self._data["paralink_attempts"] += 1
            self._data["paralink_success"] = bool(success)
        except Exception:
            pass

    def log_ai(self, applied):
        if not self._active:
            return
        try:
            self._data["ai_assistant_used"] = True
            if applied:
                self._data["ai_suggestions_applied"] += 1
        except Exception:
            pass

    def log_export(self, format_name):
        if not self._active:
            return
        try:
            self._data["export_format"] = str(format_name) if format_name else "none"
        except Exception:
            pass

    def log_ai_interaction(self, user_input, intent_resolved,
                            tool_called="", tool_success=False,
                            outcome="", was_online=False):
        """Log one AI turn with its outcome. user_input is raw free-form
        text and is only stored when _ai_sharing_enabled() - the separate
        "Share AI conversation text" preference is on; otherwise it is
        replaced with the literal "[not shared]" placeholder and every
        other, closed-vocabulary field is still recorded normally."""
        if not self._active:
            return
        try:
            sharing = _ai_sharing_enabled()
            entry = {
                "turn_index": len(self._data["ai_interactions"]),
                "user_input": (str(user_input) if user_input is not None else "")
                              if sharing else "[not shared]",
                "intent_resolved": bool(intent_resolved),
                "tool_called": str(tool_called) if tool_called else "",
                "tool_success": bool(tool_success),
                "outcome": str(outcome) if outcome else "",
                "user_feedback": None,
                "was_online": bool(was_online),
                "timestamp": _now_iso(),
            }
            self._data["ai_interactions"].append(entry)
        except Exception:
            pass

    def log_failed_intent(self, user_input, reason, closest_tool=""):
        """Log when a clinician asked for something DynaX cannot currently
        do. Valuable product data - user_input/reason are raw free-form
        text and are only stored when _ai_sharing_enabled() is on;
        otherwise both are replaced with the literal "[not shared]"
        placeholder, and closest_tool/timestamp are still recorded."""
        if not self._active:
            return
        try:
            sharing = _ai_sharing_enabled()
            entry = {
                "user_input": (str(user_input) if user_input is not None else "")
                              if sharing else "[not shared]",
                "closest_tool": str(closest_tool) if closest_tool else None,
                "reason": (str(reason) if reason is not None else "")
                          if sharing else "[not shared]",
                "timestamp": _now_iso(),
            }
            self._data["failed_intents"].append(entry)
        except Exception:
            pass

    def set_ai_feedback(self, turn_index, feedback):
        """Record the clinician's thumbs up/down on a specific AI
        interaction. Flagged mismatch: ai.conversation.ConversationSession's
        turn_count() (what the panel's feedback operator actually has on
        hand) counts EVERY turn - user questions, tool-result turns,
        feedback/expectation turns - while ai_interactions' own turn_index
        here only increments per log_ai_interaction() call, so the two
        indices diverge after the first exchange. An exact-match-only
        lookup would silently fail to attach feedback in the common case.
        Since the panel UI only ever offers feedback on the MOST RECENT
        interaction (Part C's own rule), falling back to the last entry
        when the given index doesn't match is correct in every case the UI
        can actually produce, not just a token gets_the-thing-attached to
        SOMETHING hack."""
        if not self._active:
            return
        try:
            interactions = self._data["ai_interactions"]
            if not interactions:
                return
            for entry in interactions:
                if entry.get("turn_index") == turn_index:
                    entry["user_feedback"] = str(feedback) if feedback else None
                    return
            interactions[-1]["user_feedback"] = str(feedback) if feedback else None
        except Exception:
            pass

    def end(self):
        if not self._active:
            return
        try:
            self._data["ended_at"] = _now_iso()
            if self._start_monotonic is not None:
                self._data["session_duration_seconds"] = round(
                    time.monotonic() - self._start_monotonic, 1)
            payload = dict(self._data)
        except Exception:
            self._active = False
            return

        self._active = False
        try:
            _write_and_sync(payload)
        except Exception:
            pass


def _write_and_sync(payload: dict) -> None:
    pending_dir = _sessions_root() / "pending"
    if not _ensure_dir(pending_dir):
        return  # folder creation failed -> silently do nothing, per spec

    session_id = payload.get("session_id") or str(uuid.uuid4())
    pending_path = pending_dir / f"{session_id}.json"
    try:
        pending_path.write_text(
            json.dumps(payload, ensure_ascii=True, separators=(",", ":")),
            encoding="utf-8",
        )
    except Exception:
        return

    thread = threading.Thread(
        target=_sync_one, args=(pending_path, payload), daemon=True,
    )
    try:
        thread.start()  # fire and forget - never joined
    except Exception:
        pass


def _sync_one(pending_path: Path, payload: dict) -> None:
    """Runs on a daemon thread. Any failure (timeout, connection refused,
    4xx/5xx, malformed response, anything) leaves the file in pending/ and
    logs nothing - silent by design, per spec."""
    try:
        body = json.dumps(payload, ensure_ascii=True, separators=(",", ":")).encode("utf-8")
        request = urllib.request.Request(
            SYNC_URL, data=body, method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(request, timeout=THREAD_TIMEOUT_SECONDS) as response:
            status = getattr(response, "status", None) or response.getcode()
            if status in (200, 201):
                _move_to_sent(pending_path)
    except Exception:
        return  # left in pending/, nothing raised, nothing logged


def _move_to_sent(pending_path: Path) -> None:
    try:
        sent_dir = _sessions_root() / "sent"
        if not _ensure_dir(sent_dir):
            return
        pending_path.replace(sent_dir / pending_path.name)
    except Exception:
        pass


_recorder = None


def get_recorder() -> SessionRecorder:
    global _recorder
    if _recorder is None:
        _recorder = SessionRecorder()
    return _recorder
