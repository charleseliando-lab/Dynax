# utils/mask_utils.py - Version-safe sculpt mask access (v1.9.1)
#
# Blender changed the mask storage API across versions:
#   - Blender <= 4.x:  bm.verts.layers.paint_mask
#   - Blender 5.0+:     mask stored as a float attribute named ".sculpt_mask"
#                       on the mesh, accessed via bm.verts.layers.float[".sculpt_mask"]
# This helper tries each method so the same code works everywhere.

import bmesh


def get_mask_layer(bm):
    """
    Return the bmesh vertex mask layer, or None if no mask exists yet.
    Works across Blender 3.x, 4.x and 5.x.
    """
    # Method 1: classic paint_mask (Blender <= 4.x)
    try:
        layers = bm.verts.layers
        if hasattr(layers, "paint_mask"):
            pm = layers.paint_mask
            existing = pm.get("mask")
            if existing is not None:
                return existing
            # If none exists yet, return None (caller can create)
            return None
    except (AttributeError, TypeError):
        pass

    # Method 2: float attribute ".sculpt_mask" (Blender 5.0+)
    try:
        float_layers = bm.verts.layers.float
        # Try the new internal attribute name
        for name in (".sculpt_mask", "sculpt_mask", ".mask"):
            lyr = float_layers.get(name)
            if lyr is not None:
                return lyr
    except (AttributeError, TypeError):
        pass

    return None


def ensure_mask_layer(bm):
    """
    Get the mask layer, creating it if it doesn't exist.
    Returns the layer (never None on success).
    """
    layer = get_mask_layer(bm)
    if layer is not None:
        return layer

    # Try to create one
    # Method 1: classic
    try:
        if hasattr(bm.verts.layers, "paint_mask"):
            return bm.verts.layers.paint_mask.new("mask")
    except (AttributeError, TypeError, ValueError):
        pass

    # Method 2: float attribute (Blender 5.0+)
    try:
        return bm.verts.layers.float.new(".sculpt_mask")
    except (AttributeError, TypeError, ValueError):
        pass

    return None


def read_masked_indices(obj, threshold=0.1):
    """
    Return a list of vertex indices whose mask value exceeds threshold.
    Reads directly from the mesh — works in object mode.
    Falls back to mesh attributes if bmesh layer isn't found.
    """
    me = obj.data

    # Try bmesh approach first
    bm = bmesh.new()
    bm.from_mesh(me)
    layer = get_mask_layer(bm)
    if layer is not None:
        indices = [v.index for v in bm.verts if v[layer] > threshold]
        bm.free()
        return indices
    bm.free()

    # Fallback: read the mesh attribute directly (Blender 5.0+)
    for attr_name in (".sculpt_mask", "sculpt_mask"):
        attr = me.attributes.get(attr_name)
        if attr is not None:
            indices = []
            for i, d in enumerate(attr.data):
                try:
                    if d.value > threshold:
                        indices.append(i)
                except AttributeError:
                    break
            if indices:
                return indices
    return []


def clear_mask(obj):
    """Set all mask values to zero. Works in object mode."""
    me = obj.data

    bm = bmesh.new()
    bm.from_mesh(me)
    layer = get_mask_layer(bm)
    if layer is not None:
        for v in bm.verts:
            v[layer] = 0.0
        bm.to_mesh(me)
        bm.free()
        me.update()
        return True
    bm.free()

    # Fallback: clear the mesh attribute directly
    for attr_name in (".sculpt_mask", "sculpt_mask"):
        attr = me.attributes.get(attr_name)
        if attr is not None:
            for d in attr.data:
                try:
                    d.value = 0.0
                except AttributeError:
                    break
            me.update()
            return True
    return False
