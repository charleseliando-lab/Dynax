# utils/measurement_helpers.py - Shared click-to-measure engine (v1.20.8)
#
# ONE measurement engine for the whole add-on. Extracted verbatim (behaviour
# identical) from paraforge/operators/afo_measurement.py, which was the only
# working click-to-measure implementation in the codebase and had already
# solved the hard parts against real scans:
#
#   * cross-section by plane/edge intersection in the object's LOCAL space,
#     with the cut height transformed into local space first and every hit
#     transformed back to world - so a rotated/moved/scaled object measures
#     correctly (a world-space bmesh copy would silently measure the wrong
#     plane on a rotated object),
#   * ring ordering by angle around the cross-section's OWN centroid, which
#     is what makes an irregular real limb section measure correctly where a
#     naive atan2-on-world-XY ordering tangles,
#   * a tagged marker ring object (custom property, NOT an operator-instance
#     attribute) so the previous ring is found and removed across separate
#     operator invocations instead of leaking a datablock per click.
#
# Creator (operators/circumference.py) and ParaFly AFO
# (paraforge/operators/afo_measurement.py) both call THIS module. The AFO
# Codex work is preserved: its operators, idnames, properties and reporting
# are untouched - only the duplicated maths bodies now delegate here.
#
# Nothing in this module ever modifies the measured mesh: it reads a bmesh
# copy of obj.data and frees it, and the marker it creates is a separate
# CURVE object.

import bpy
import bmesh
import math
from mathutils import Vector

# Tag carried by every measurement marker ring this module creates. Kept as the
# AFO module's original string so rings created by the pre-refactor AFO build
# are still found and cleaned up after an upgrade.
MEASURE_RING_TAG = "dynax_is_afo_measure_ring"

# Minimum hits that can form a closed section. Fewer means the plane grazed the
# surface (or missed it) and there is no valid closed cross-section to report.
MIN_SECTION_POINTS = 3


# ── Navigation classification ─────────────────────────────────────────────────
#
# Shared by every DynaX modal that raycasts on click. A modal that only checks
# `event.type == 'LEFTMOUSE'` places a point when the user Alt/Ctrl/Shift-drags
# to orbit (Alt+LMB IS orbit under Emulate 3 Button Mouse), which is the
# "navigation created an accidental selection/point" class of bug.
#
# Mirrors paraforge/operators/afo_landmarks.py's _NAVIGATION_EVENTS /
# _is_navigation_event (Codex work, left in place) so both behave identically.

_NAVIGATION_EVENTS = frozenset({
    'MIDDLEMOUSE',
    'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'WHEELINMOUSE', 'WHEELOUTMOUSE',
    'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE', 'MOUSESMARTZOOM',
    'NDOF_MOTION', 'NDOF_BUTTON_MENU', 'NDOF_BUTTON_FIT',
    'NUMPAD_0', 'NUMPAD_1', 'NUMPAD_2', 'NUMPAD_3', 'NUMPAD_4',
    'NUMPAD_5', 'NUMPAD_6', 'NUMPAD_7', 'NUMPAD_8', 'NUMPAD_9',
    'NUMPAD_PLUS', 'NUMPAD_MINUS', 'NUMPAD_PERIOD',
})


def is_navigation_event(event):
    """True if `event` is viewport navigation and must never place a point."""
    event_type = getattr(event, "type", "")
    if event_type in _NAVIGATION_EVENTS or event_type.startswith('NDOF_BUTTON_'):
        return True
    # A modified left-click is navigation (orbit/zoom gestures), never placement.
    if event_type == 'LEFTMOUSE':
        return bool(getattr(event, "alt", False) or getattr(event, "ctrl", False)
                    or getattr(event, "shift", False) or getattr(event, "oskey", False))
    return False


def find_view3d_under_cursor(context, event):
    """Return (region, rv3d, (x, y)) for the VIEW_3D WINDOW region under the
    mouse, or (None, None, None).

    Uses absolute window coords (event.mouse_x/y) converted to region-local
    coords, so it works when the modal was started from an N-panel button -
    context.region then points at the PANEL, and unprojecting against it gives
    a garbage ray. Same pattern already proven in operators/trimline.py.
    """
    x, y = getattr(event, "mouse_x", 0), getattr(event, "mouse_y", 0)
    screen = getattr(context, "screen", None)
    if screen is None:
        return None, None, None
    for area in screen.areas:
        if area.type != 'VIEW_3D':
            continue
        rv3d = area.spaces.active.region_3d
        for region in area.regions:
            if region.type == 'WINDOW' \
                    and region.x <= x < region.x + region.width \
                    and region.y <= y < region.y + region.height:
                return region, rv3d, (x - region.x, y - region.y)
    return None, None, None


def raycast_surface(context, obj, event):
    """Raycast the mouse onto `obj` and return the WORLD-space surface hit, or
    None if the click missed the mesh / landed outside a 3D viewport.

    Casts against the EVALUATED object (modifiers honoured) in the object's
    local space - obj.ray_cast takes and returns local space - then brings the
    hit back to world space. Skipping that final transform is the classic cause
    of markers landing off the surface on a moved/rotated object.
    """
    from bpy_extras import view3d_utils

    if obj is None or obj.type != 'MESH':
        return None
    region, rv3d, coord = find_view3d_under_cursor(context, event)
    if region is None or rv3d is None:
        return None

    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    ray_dir = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)

    depsgraph = context.evaluated_depsgraph_get()
    obj_eval = obj.evaluated_get(depsgraph)
    matrix_inv = obj.matrix_world.inverted()
    success, location, _normal, _index = obj_eval.ray_cast(
        matrix_inv @ ray_origin, matrix_inv.to_3x3() @ ray_dir)
    if not success:
        return None
    return obj.matrix_world @ location


# ── Cross-section maths ───────────────────────────────────────────────────────

def cross_section_points(obj, z_world):
    """World-space points where `obj`'s edges cross the TRANSVERSE (world
    horizontal) plane at `z_world`. Returns [] when the plane misses the mesh.

    The section is taken against the true WORLD plane: every vertex is brought
    into world space and compared against `z_world` directly. It is NOT taken
    against a local-Z=const plane.

    That distinction is the measure-click fix and it matters. A local-Z=const plane
    is only the world horizontal plane when the object carries no rotation; on
    a rotated object it TILTS, and at 90 degrees it becomes a world-VERTICAL
    plane - which is what produced the reported "circumference runs lengthwise
    along the limb" result. The ordering/measuring code downstream
    (`sort_ring_by_angle`, the perimeter sum) has always assumed a world
    horizontal section, so slicing locally also tangled the ring on any
    rotated object. This now matches `operators/circumference.py`'s auto-ring
    path (`_measure_at_z`), which has always sectioned in world space and has
    always been correct.

    World Z is Creator's canonical longitudinal axis - the auto rings, the
    height-band groups, the distal-end detection and `_get_world_bounds` all
    key off it - so it is reused here rather than a second axis being invented.

    Never modifies the mesh: it reads a bmesh copy of obj.data and frees it.
    """
    if obj is None or obj.type != 'MESH':
        return []

    matrix = obj.matrix_world

    bm = bmesh.new()
    try:
        bm.from_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()

        world = [matrix @ vert.co for vert in bm.verts]

        points = []
        for edge in bm.edges:
            w0 = world[edge.verts[0].index]
            w1 = world[edge.verts[1].index]
            if (w0.z < z_world) != (w1.z < z_world):
                denominator = w1.z - w0.z
                if abs(denominator) < 1e-12:
                    continue
                t = (z_world - w0.z) / denominator
                points.append(w0.lerp(w1, t))
        return points
    finally:
        # try/finally so an exception mid-iteration can never leak the bmesh.
        bm.free()


def cross_section_loops(obj, z_world):
    """Split the transverse section at `z_world` into SEPARATE contours.

    Returns a list of dicts: {"points": [world Vector, ...] in walk order,
    "closed": bool}. Ordering comes from the mesh's own FACE CONNECTIVITY (a
    face crossed by the plane contributes one segment between the two edges it
    crosses), not from an angle sort - so an irregular, concave or off-centre
    real limb section traces correctly, and two separate contours (an inner and
    an outer wall, or two limbs in one scan) come back as two loops instead of
    one zigzag through both.

    `cross_section_points`/`measure_circumference` deliberately keep their old
    flat-list "sum every crossing" behaviour for ParaFly AFO; this is additive.
    """
    if obj is None or obj.type != 'MESH':
        return []

    matrix = obj.matrix_world

    bm = bmesh.new()
    try:
        bm.from_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        world = [matrix @ vert.co for vert in bm.verts]

        hit = {}          # edge index -> world-space crossing point
        for edge in bm.edges:
            w0 = world[edge.verts[0].index]
            w1 = world[edge.verts[1].index]
            if (w0.z < z_world) != (w1.z < z_world):
                denominator = w1.z - w0.z
                if abs(denominator) < 1e-12:
                    continue
                t = (z_world - w0.z) / denominator
                hit[edge.index] = w0.lerp(w1, t)

        if not hit:
            return []

        neighbours = {index: [] for index in hit}
        for face in bm.faces:
            crossed = [e.index for e in face.edges if e.index in hit]
            # A convex face crossed by a plane has exactly 2 crossing edges.
            # Anything else (a non-planar ngon grazing the plane) is ambiguous
            # and is skipped rather than guessed at.
            if len(crossed) != 2:
                continue
            a, b = crossed
            if b not in neighbours[a]:
                neighbours[a].append(b)
            if a not in neighbours[b]:
                neighbours[b].append(a)
    finally:
        bm.free()

    return _trace_contours(hit, neighbours)


def _trace_contours(hit, neighbours):
    """Walk the crossing-point adjacency graph into ordered contours."""
    loops = []
    unvisited = set(hit)

    while unvisited:
        # Prefer starting at an END (degree < 2) so an open contour is walked
        # from its own start; otherwise any node of a closed ring will do.
        start = None
        for index in unvisited:
            if len(neighbours[index]) < 2:
                start = index
                break
        if start is None:
            start = next(iter(unvisited))

        order = [start]
        unvisited.discard(start)
        previous, current = None, start
        while True:
            nxt = None
            for candidate in neighbours[current]:
                if candidate != previous and candidate in unvisited:
                    nxt = candidate
                    break
            if nxt is None:
                break
            order.append(nxt)
            unvisited.discard(nxt)
            previous, current = current, nxt

        closed = len(order) >= MIN_SECTION_POINTS and \
            order[0] in neighbours[order[-1]]
        loops.append({"points": [hit[i] for i in order], "closed": closed})

    return loops


def select_loop_at_point(loops, point):
    """Index of the contour that belongs to `point`, or None.

    CLOSED contours are always preferred - an open contour is a section through
    a hole/boundary, not a circumference - and among them the one whose nearest
    vertex sits closest to the clicked point wins. Deliberately NOT "the
    longest contour": on a two-walled model the longest is often the wrong wall,
    and a stray vertical artefact contour can be longest of all.
    """
    if not loops:
        return None

    candidates = [i for i, loop in enumerate(loops)
                  if loop["closed"] and len(loop["points"]) >= MIN_SECTION_POINTS]
    if not candidates:
        return None

    best, best_distance = None, None
    for index in candidates:
        distance = min((p - point).length for p in loops[index]["points"])
        if best_distance is None or distance < best_distance:
            best, best_distance = index, distance
    return best


def contour_length(points):
    """Closed perimeter, in mm, of an ordered contour."""
    count = len(points)
    if count < MIN_SECTION_POINTS:
        return 0.0
    return sum((points[(i + 1) % count] - points[i]).length for i in range(count))


def measure_circumference_at_point(obj, point):
    """Measure the transverse circumference of `obj` through the clicked
    world-space `point`.

    Returns (circumference_mm, ordered_loop_points, diagnostics). The
    circumference is 0.0 and the point list empty when there is no valid CLOSED
    section there - callers report that rather than showing a bogus number.

    The returned points are the exact contour the number was computed from, so
    the marker ring and the readout can never disagree.
    """
    loops = cross_section_loops(obj, point.z)
    index = select_loop_at_point(loops, point)
    diagnostics = {
        "clicked_point": (point.x, point.y, point.z),
        "plane_origin": (point.x, point.y, point.z),
        "plane_normal": (0.0, 0.0, 1.0),
        "coordinate_space": "WORLD",
        "loop_count": len(loops),
        "closed_loop_count": sum(1 for loop in loops if loop["closed"]),
        "selected_loop": index,
    }
    if index is None:
        diagnostics["circumference_mm"] = 0.0
        return 0.0, [], diagnostics

    points = loops[index]["points"]
    circumference = contour_length(points)
    diagnostics["selected_loop_points"] = len(points)
    diagnostics["closed"] = True
    diagnostics["circumference_mm"] = circumference
    diagnostics["diameter_mm"] = measure_diameter(circumference)
    return circumference, points, diagnostics


def sort_ring_by_angle(points):
    """Order cross-section hits into a ring; returns (ordered_points, centroid).

    Sorted by signed angle around the section's own centroid, measured in the
    horizontal plane against the first point as reference. This is what handles
    an irregular real scan section, where the hits come out of the bmesh in
    arbitrary edge order.
    """
    if not points:
        return [], Vector((0.0, 0.0, 0.0))

    centroid = sum(points, Vector()) / len(points)
    ref = (points[0] - centroid)
    ref.z = 0.0
    if ref.length_squared == 0.0:
        return list(points), centroid
    ref.normalize()

    def angle_key(point):
        v = point - centroid
        v.z = 0.0
        if v.length_squared == 0.0:
            return 0.0
        v.normalize()
        return math.atan2(v.cross(ref).z, v.dot(ref))

    return sorted(points, key=angle_key), centroid


def measure_circumference(obj, z_world):
    """Circumference in mm of `obj`'s cross-section at `z_world`.

    Returns 0.0 when there is no valid closed cross-section there (fewer than
    MIN_SECTION_POINTS hits) - callers report that to the user rather than
    showing a bogus number. DynaX runs in mm-space (1 unit = 1 mm), so the
    summed segment lengths are already millimetres.
    """
    points = cross_section_points(obj, z_world)
    if len(points) < MIN_SECTION_POINTS:
        return 0.0

    ordered, _centroid = sort_ring_by_angle(points)
    total = 0.0
    count = len(ordered)
    for i in range(count):
        total += (ordered[(i + 1) % count] - ordered[i]).length
    return total


def measure_diameter(circumference_mm):
    """Equivalent-circle diameter for a measured circumference."""
    return circumference_mm / math.pi if circumference_mm > 0.0 else 0.0


# ── Marker ring ───────────────────────────────────────────────────────────────

def remove_existing_ring():
    """Remove every tagged measurement ring (object + curve + material).

    Finds rings by their custom-property tag rather than an operator-instance
    attribute, so a ring left by a PREVIOUS operator invocation is still found
    and cleaned up - without this, every click leaks an object, a curve
    datablock and a material.
    """
    for obj in list(bpy.data.objects):
        if not obj.get(MEASURE_RING_TAG):
            continue
        data = obj.data
        materials = list(data.materials) if data is not None else []
        bpy.data.objects.remove(obj, do_unlink=True)
        if data is not None and data.users == 0:
            bpy.data.curves.remove(data)
        for material in materials:
            if material.users == 0:
                bpy.data.materials.remove(material)


def draw_measurement_ring(context, obj, z_world, color=(0.1, 0.5, 1.0, 1.0),
                          name="dynax_measure_ring"):
    """Create a visible marker ring on `obj`'s cross-section at `z_world`,
    replacing any existing tagged ring. Returns the ring object or None when
    there is no valid closed section.

    The ring is an independent CURVE object - the measured mesh is never
    touched. It is hide_select so a clinician can't accidentally grab it
    instead of the scan.
    """
    points = cross_section_points(obj, z_world)
    if len(points) < MIN_SECTION_POINTS:
        remove_existing_ring()
        return None
    ordered, _centroid = sort_ring_by_angle(points)
    return draw_ring_from_points(context, ordered, color=color, name=name)


def draw_ring_from_points(context, ordered, color=(0.1, 0.5, 1.0, 1.0),
                          name="dynax_measure_ring"):
    """Draw a marker ring through an ALREADY-ORDERED contour.

    Used by Creator's click measurement so the visible ring and the reported
    circumference come from the exact same contour - never one loop drawn while
    a different one is measured.
    """
    remove_existing_ring()

    if len(ordered) < MIN_SECTION_POINTS:
        return None

    curve_data = bpy.data.curves.new(name, type='CURVE')
    curve_data.dimensions = '3D'
    curve_data.bevel_depth = 1.0

    spline = curve_data.splines.new('POLY')
    # A fresh POLY spline already owns 1 point, so add exactly len-1 more:
    # add(len) would leave one never-assigned point sitting at the origin and,
    # with use_cyclic_u, spike the ring through world zero.
    spline.points.add(len(ordered) - 1)
    for i, point in enumerate(ordered):
        spline.points[i].co = (point.x, point.y, point.z, 1.0)
    spline.use_cyclic_u = True

    ring_obj = bpy.data.objects.new(name, curve_data)
    ring_obj[MEASURE_RING_TAG] = True
    ring_obj.hide_select = True
    context.collection.objects.link(ring_obj)

    material = bpy.data.materials.new(f"{name}_mat")
    material.diffuse_color = color
    ring_obj.data.materials.append(material)
    return ring_obj
