# utils/branding.py - DynaX logo icon + white viewport theme (v2.0.1)

import bpy
import os

_icons = None
_saved_bg = {}   # store original viewport colors to restore later


def get_logo_icon_id():
    """Return the preview icon id for the DynaX logo, or 0 if unavailable"""
    global _icons
    if _icons is None:
        return 0
    if "dynax_logo" in _icons:
        return _icons["dynax_logo"].icon_id
    return 0


def get_ai_avatar_icon_id():
    """Return the preview icon id for the DynaX AI robot avatar (the
    transparent-background version - the panel draws it small, alongside
    text, where a solid app-icon tile would show an ugly square edge), or
    0 if unavailable. Used by panels/ai_assistant.py's header and
    assistant-turn rows."""
    global _icons
    if _icons is None:
        return 0
    if "dynax_ai_avatar" in _icons:
        return _icons["dynax_ai_avatar"].icon_id
    return 0


def register_icons():
    global _icons
    try:
        import bpy.utils.previews
        _icons = bpy.utils.previews.new()
        icons_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "icons")
        logo_path = os.path.join(icons_dir, "dynax_logo.png")
        if os.path.exists(logo_path):
            _icons.load("dynax_logo", logo_path, 'IMAGE')
        avatar_path = os.path.join(icons_dir, "dynax_ai_avatar.png")
        if os.path.exists(avatar_path):
            _icons.load("dynax_ai_avatar", avatar_path, 'IMAGE')
    except Exception:
        _icons = None


def unregister_icons():
    global _icons
    if _icons is not None:
        try:
            bpy.utils.previews.remove(_icons)
        except Exception:
            pass
        _icons = None


# ── DynaX-blue viewport theme (exclusive DynaX look, v2.6.10) ──────────────────

# DynaX brand blue, matching the logo. Kept as a single tuple so it's easy to
# tweak in one place if the brand color changes.
DYNAX_BLUE = (0.106, 0.243, 0.471)   # deep DynaX blue, RGB 0-1 range


def set_dynax_viewport():
    """
    Set the 3D viewport background to DynaX blue. Saves the original first so
    it can be restored. This changes Blender's theme (global), so we restore
    on exit.
    """
    global _saved_bg
    try:
        theme = bpy.context.preferences.themes[0]
        v3d = theme.view_3d
        grad = v3d.space.gradients
        if not _saved_bg:
            _saved_bg = {
                'type': grad.background_type,
                'high': tuple(grad.high_gradient),
                'low':  tuple(grad.gradient) if hasattr(grad, 'gradient') else None,
            }
        grad.background_type = 'SINGLE_COLOR'
        grad.high_gradient = DYNAX_BLUE
    except Exception:
        pass


# Kept as an alias so any existing call sites (set_white_viewport) still work
# without needing to be tracked down and renamed individually.
def set_white_viewport():
    set_dynax_viewport()


def restore_viewport():
    """Restore the original viewport background colors"""
    global _saved_bg
    if not _saved_bg:
        return
    try:
        theme = bpy.context.preferences.themes[0]
        grad = theme.view_3d.space.gradients
        grad.background_type = _saved_bg.get('type', 'LINEAR')
        if _saved_bg.get('high'):
            grad.high_gradient = _saved_bg['high']
        if _saved_bg.get('low') is not None and hasattr(grad, 'gradient'):
            grad.gradient = _saved_bg['low']
    except Exception:
        pass
    _saved_bg = {}
