# utils/translations.py - DynaX multi-language support (v1)
#
# English is the source/default language. French, German, Arabic are
# selectable sub-languages via Settings. Uses Blender's native i18n
# system (bpy.app.translations) — registering a msgid/msgstr dict here makes
# Blender automatically substitute matching strings anywhere in the UI
# (layout.label(text=...), operator(text=...), tooltips, etc.) once the
# user's Preferences > Interface language is set to a registered locale and
# translate_interface/translate_tooltips are on. No internet or external
# libs required, and no per-call-site changes are needed elsewhere in the
# addon for strings that already match a registered msgid exactly.
#
# v1 starter set covering core navigation and action labels only.
# Expand dictionaries as more strings are identified — do not change
# the registration mechanism itself.

import bpy

DYNAX_TRANSLATIONS = {
    "fr_FR": {
        ("*", "Welcome Dr, Let's Build."): "Bienvenue Dr, Construisons.",
        ("*", "Creator"): "Créateur",
        ("*", "ParaForge"): "ParaForge",
        ("*", "Import scan"): "Importer le scan",
        ("*", "Clean up mesh"): "Nettoyer le maillage",
        ("*", "Align & rotate"): "Aligner et pivoter",
        ("*", "Crop"): "Rogner",
        ("*", "Measure"): "Mesurer",
        ("*", "Sculpt & modify"): "Sculpter et modifier",
        ("*", "Trim line"): "Ligne de découpe",
        ("*", "Add thickness"): "Ajouter l'épaisseur",
        ("*", "Components"): "Composants",
        ("*", "Export STL"): "Exporter STL",
        ("*", "Bake"): "Cuire",
        ("*", "Remove"): "Supprimer",
        ("*", "Thickness (mm)"): "Épaisseur (mm)",
        ("*", "Back"): "Retour",
        ("*", "Next"): "Suivant",
        ("*", "Undo"): "Annuler",
        ("*", "Redo"): "Rétablir",
        ("*", "Settings"): "Paramètres",
        ("*", "Language"): "Langue",
        ("*", "Export STL to Downloads"): "Exporter STL vers Téléchargements",
        ("*", "File Name"): "Nom du fichier",
    },
    "de_DE": {
        ("*", "Welcome Dr, Let's Build."): "Willkommen Dr., Lassen Sie uns Bauen.",
        ("*", "Creator"): "Ersteller",
        ("*", "ParaForge"): "ParaForge",
        ("*", "Import scan"): "Scan importieren",
        ("*", "Clean up mesh"): "Netz bereinigen",
        ("*", "Align & rotate"): "Ausrichten & drehen",
        ("*", "Crop"): "Zuschneiden",
        ("*", "Measure"): "Messen",
        ("*", "Sculpt & modify"): "Formen & anpassen",
        ("*", "Trim line"): "Trimmlinie",
        ("*", "Add thickness"): "Dicke hinzufügen",
        ("*", "Components"): "Komponenten",
        ("*", "Export STL"): "STL exportieren",
        ("*", "Bake"): "Backen",
        ("*", "Remove"): "Entfernen",
        ("*", "Thickness (mm)"): "Dicke (mm)",
        ("*", "Back"): "Zurück",
        ("*", "Next"): "Weiter",
        ("*", "Undo"): "Rückgängig",
        ("*", "Redo"): "Wiederholen",
        ("*", "Settings"): "Einstellungen",
        ("*", "Language"): "Sprache",
        ("*", "Export STL to Downloads"): "STL nach Downloads exportieren",
        ("*", "File Name"): "Dateiname",
    },
    # Blender's own language enum has no "ar_SA" identifier - Arabic is
    # "ar_EG" in this Blender build (bpy.types.PreferencesView.language).
    # This key MUST match what DynaxSetLanguage assigns to
    # preferences.view.language exactly, or lookups silently miss and the
    # UI stays in English even though the language switched.
    "ar_EG": {
        ("*", "Welcome Dr, Let's Build."): "مرحباً دكتور، لنبدأ البناء.",
        ("*", "Creator"): "المُنشئ",
        ("*", "ParaForge"): "بارافورج",
        ("*", "Import scan"): "استيراد المسح",
        ("*", "Clean up mesh"): "تنظيف الشبكة",
        ("*", "Align & rotate"): "محاذاة وتدوير",
        ("*", "Crop"): "قص",
        ("*", "Measure"): "قياس",
        ("*", "Sculpt & modify"): "نحت وتعديل",
        ("*", "Trim line"): "خط التشذيب",
        ("*", "Add thickness"): "إضافة سماكة",
        ("*", "Components"): "المكونات",
        ("*", "Export STL"): "تصدير STL",
        ("*", "Bake"): "دمج",
        ("*", "Remove"): "إزالة",
        ("*", "Thickness (mm)"): "السماكة (مم)",
        ("*", "Back"): "رجوع",
        ("*", "Next"): "التالي",
        ("*", "Undo"): "تراجع",
        ("*", "Redo"): "إعادة",
        ("*", "Settings"): "الإعدادات",
        ("*", "Language"): "اللغة",
        ("*", "Export STL to Downloads"): "تصدير STL إلى التنزيلات",
        ("*", "File Name"): "اسم الملف",
        # Placeholder-quality — a native Arabic-speaking clinician should
        # review medical/clinical terms before wider release. RTL layout
        # mirroring is not implemented (Blender limitation).
    },
}


def register():
    try:
        bpy.app.translations.register(__name__, DYNAX_TRANSLATIONS)
    except Exception as e:
        print(f"[DynaX] Translation registration failed: {e}")


def unregister():
    try:
        bpy.app.translations.unregister(__name__)
    except Exception:
        pass


def dx_text(context, english_text):
    """Fallback wrapper for cases outside Blender's automatic translation
    (used sparingly for a few key labels in the welcome/settings screens).
    For most standard bpy.types.Operator labels/tooltips, Blender's own
    translation system (registered above) handles it automatically once the
    user sets Preferences > Interface > Translation, or via
    dynax.set_language."""
    return english_text  # Blender's own system handles registered strings;
    # this wrapper exists so custom layout.label() calls have one
    # consistent call site if manual lookup is ever needed later.
