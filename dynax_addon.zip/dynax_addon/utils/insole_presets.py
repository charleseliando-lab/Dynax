# utils/insole_presets.py - ParaFly Insole groundwork: clinical preset loader.
#
# Groundwork only for the v1.22.0 session (Workstream B) - no operators or
# geometry consume this yet. The full insole build (scan-based offloading/
# support-zone generation) is a future session's work; this just gives that
# future session a preset library + a stable loader API to build against.

import json
import pathlib

PRESET_DIR = pathlib.Path(__file__).parent.parent / "data" / "insole_presets"


def list_presets() -> list:
    """Return all available presets as a list of
    {"name": str, "filename": str, "description": str}."""
    presets = []
    for f in sorted(PRESET_DIR.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding='utf-8'))
            presets.append({
                "name": data.get("name", f.stem),
                "filename": f.name,
                "description": data.get("description", ""),
            })
        except Exception:
            pass
    return presets


def load_preset(filename: str):
    """Load a single preset by filename. Returns None if missing/invalid."""
    path = PRESET_DIR / filename
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return None


def get_preset_enum_items():
    """Return an items list suitable for an EnumProperty."""
    items = []
    for p in list_presets():
        items.append((p["filename"], p["name"], p["description"]))
    return items if items else [("none", "No presets found", "")]
