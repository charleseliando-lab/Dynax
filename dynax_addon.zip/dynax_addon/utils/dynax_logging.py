# utils/dynax_logging.py - Clinician-safe operator error handling (v1.20.8)
#
# The Creator workflow surfaced raw Python tracebacks to clinicians: an
# unhandled exception inside an operator's execute() makes Blender show a red
# "Python: RuntimeError ..." banner, which is meaningless to a prosthetist and
# reads as "the software is broken".
#
# `creator_guard` wraps an execute()/invoke() so that:
#   * an EXPECTED failure is reported as one concise sentence and CANCELLED,
#   * the full traceback still goes to the DynaX log file + console for support,
#   * the operator never leaks a half-finished state.
#
# Log location mirrors the launcher's own convention (per-user AppData, never
# Program Files, never patient data): only the operator idname and the
# traceback are written - no project path, no scan name, no filename.

import functools
import logging
import os
import traceback
from pathlib import Path

_LOGGER_NAME = "dynax_addon"
_configured = False


def _log_dir():
    """Per-user DynaX log directory. Matches DynaX Studio's own logs folder
    when running inside Studio, so support has one place to look."""
    base = os.environ.get("LOCALAPPDATA")
    if base:
        return Path(base) / "DynaX Studio" / "logs"
    return Path.home() / ".dynax_studio" / "logs"


def get_logger():
    """Return the DynaX add-on logger, configuring a rotating file handler once.

    Never raises: if the log file cannot be opened (read-only profile, locked
    file), the logger falls back to console-only rather than taking down the
    operator it is supposed to be protecting.
    """
    global _configured
    logger = logging.getLogger(_LOGGER_NAME)
    if _configured:
        return logger

    logger.setLevel(logging.DEBUG)
    try:
        from logging.handlers import RotatingFileHandler
        directory = _log_dir()
        directory.mkdir(parents=True, exist_ok=True)
        handler = RotatingFileHandler(
            directory / "dynax_addon.log", maxBytes=512_000, backupCount=2,
            encoding="utf-8")
        handler.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)-7s %(message)s"))
        logger.addHandler(handler)
    except Exception:  # noqa: BLE001 - logging must never break an operator
        logger.addHandler(logging.StreamHandler())

    _configured = True
    return logger


def log_operator_error(idname, exc):
    """Record the full traceback for `exc` raised by operator `idname`."""
    text = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    try:
        get_logger().error("Operator %s failed:\n%s", idname, text)
    except Exception:  # noqa: BLE001
        pass
    # Always mirror to the console: in a dev/headless run there may be no file.
    print(f"[DynaX] Operator {idname} failed:\n{text}")


def validate_mesh_object(operator, context, obj=None, *, require_mesh=True):
    """Common Creator precondition: there IS an active mesh object to work on.

    Returns the object, or None after reporting a concise error. Callers do
    `obj = validate_mesh_object(self, context)` then `if obj is None: return
    {'CANCELLED'}` - this is what stops "no active object" turning into an
    AttributeError traceback in front of a clinician.
    """
    target = obj if obj is not None else getattr(context, "active_object", None)
    if target is None:
        operator.report({'ERROR'}, "Select your scan mesh first.")
        return None
    # An object the user deleted while a modal was running still exists as a
    # Python reference but its datablock is gone; touching it crashes.
    try:
        _ = target.name
    except ReferenceError:
        operator.report({'ERROR'}, "That object no longer exists. Select a mesh and try again.")
        return None
    if require_mesh and target.type != 'MESH':
        operator.report({'ERROR'}, "Select a mesh object first.")
        return None
    return target


def creator_guard(message="Something went wrong. See the DynaX log for details."):
    """Decorator for operator execute()/invoke(): convert an unexpected
    exception into a concise report + {'CANCELLED'}, logging the traceback.

    Deliberately does NOT swallow the operator's own control flow: a normal
    return value (including {'CANCELLED'} the operator chose itself) passes
    through untouched. Only genuine exceptions are intercepted.
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(self, context, *args, **kwargs):
            try:
                return func(self, context, *args, **kwargs)
            except Exception as exc:  # noqa: BLE001 - that is the whole point
                log_operator_error(getattr(self, "bl_idname", func.__qualname__), exc)
                try:
                    self.report({'ERROR'}, message)
                except Exception:  # noqa: BLE001
                    pass
                _emergency_cleanup(context)
                return {'CANCELLED'}
        return wrapper
    return decorator


def _emergency_cleanup(context):
    """Best-effort return to a sane state after a guarded operator blew up.

    Only touches interaction state (mode, status bar) - never geometry, never
    the user's objects. A failed operator must not also leave the clinician
    stuck in Edit mode with a status bar from a dead modal.
    """
    try:
        import bpy
        if context.mode != 'OBJECT' and getattr(context, "active_object", None):
            bpy.ops.object.mode_set(mode='OBJECT')
    except Exception:  # noqa: BLE001
        pass
    try:
        workspace = getattr(context, "workspace", None)
        if workspace is not None:
            workspace.status_text_set(None)
    except Exception:  # noqa: BLE001
        pass
