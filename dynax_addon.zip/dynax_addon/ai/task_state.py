# ai/task_state.py - DynaX AI Agent Core: structured task/slot-filling state.
#
# Fixes the reported regression: the same question ("what device type?")
# being re-asked after the user already answered it, and free text like
# "I need an AFO for a 7 year old with CP" not being understood as three
# already-answered slots. A conversation is treated as an evolving TASK
# STATE (per the behaviour spec's "not just chat history" principle), not
# independent one-shot Q&A.
#
# This is the offline, deterministic layer: rule-based slot extraction
# (regex/keyword), not real NLU. It is honestly scoped that way - a real
# online LLM (once ai.dynax.app exists) gets the same TaskState plus the
# full conversation history and context (see panels/ai_assistant.py's
# _query_thread payload) to do genuinely better extraction; this module is
# what keeps the add-on's "must work fully offline" guarantee true for the
# structured-task behaviour too, not just the old flat keyword rules.
#
# No bpy import except where explicitly noted as read-only scene inspection
# passed in from the caller (this module never touches bpy directly).

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional

# ── Vocabulary (extends, does not duplicate, RULES in panels/ai_assistant.py -
# that table is clinical-notes-per-device-type; this is device NAME
# detection only, reused by extraction, not clinical content) ────────────

DEVICE_KEYWORDS = {
    "insole": ("insole", "foot orthotic", "orthotic insole"),
    "afo": ("afo", "ankle foot orthosis", "ankle-foot orthosis"),
    "kafo": ("kafo", "knee ankle foot"),
    "tlso": ("tlso", "spinal orthosis", "spinal brace"),
    "socket": ("socket", "transtibial", "transfemoral", "prosthetic socket"),
}

_LATERALITY_KEYWORDS = {
    "left": ("left foot", "left side", "left leg", " left ", "left."),
    "right": ("right foot", "right side", "right leg", " right ", "right."),
}

_CONDITION_KEYWORDS = (
    "cerebral palsy", "cp", "spina bifida", "diabetes", "diabetic",
    "clubfoot", "drop foot", "foot drop", "scoliosis", "spinal cord injury",
    "stroke", "amputation", "amputee",
)

_AGE_PATTERN = re.compile(r"\b(\d{1,3})\s*(?:years?|yrs?|y/o|yo)\b", re.IGNORECASE)

_AFFIRM_WORDS = ("yes", "yeah", "yep", "i do", "already have", "it's on",
                  "its on", "i have", "already imported", "already there")
_DENY_WORDS = ("no", "not yet", "don't have", "dont have", "haven't",
               "havent", "nope")


def _extract_device(text: str) -> Optional[str]:
    t = text.lower()
    for device, keywords in DEVICE_KEYWORDS.items():
        if any(k in t for k in keywords):
            return device
    return None


def _extract_laterality(text: str) -> Optional[str]:
    t = f" {text.lower()} "
    for side, keywords in _LATERALITY_KEYWORDS.items():
        if any(k in t for k in keywords):
            return side
    return None


def _extract_age(text: str) -> Optional[int]:
    m = _AGE_PATTERN.search(text)
    if m:
        try:
            return int(m.group(1))
        except ValueError:
            return None
    return None


def _extract_condition(text: str) -> Optional[str]:
    t = text.lower()
    for cond in _CONDITION_KEYWORDS:
        if cond in t:
            return "cerebral palsy" if cond == "cp" else cond
    return None


def _extract_yes_no(text: str) -> Optional[bool]:
    t = text.lower()
    if any(w in t for w in _AFFIRM_WORDS):
        return True
    if any(w in t for w in _DENY_WORDS):
        return False
    return None


SLOT_EXTRACTORS = {
    "device": _extract_device,
    "laterality": _extract_laterality,
    "age": _extract_age,
    "condition": _extract_condition,
    "scan_available": _extract_yes_no,
}


# ── Task schemas — data, not code. A future module adds a new device or
# workflow by adding an entry here (or calling register_task_schema), not
# by editing this engine. ─────────────────────────────────────────────────

@dataclass
class TaskSchema:
    name: str
    required_slots: tuple  # asked, in order, until filled
    optional_slots: tuple = ()  # recorded if volunteered, never asked for
    prompts: dict = field(default_factory=dict)  # slot -> list of phrasings


TASK_SCHEMAS: dict = {}


def register_task_schema(schema: TaskSchema) -> None:
    TASK_SCHEMAS[schema.name] = schema


def get_task_schema(name: str) -> Optional[TaskSchema]:
    return TASK_SCHEMAS.get(name)


register_task_schema(TaskSchema(
    name="import_scan",
    required_slots=(),
    optional_slots=("laterality",),
    prompts={},
))

register_task_schema(TaskSchema(
    name="create_device",
    required_slots=("device", "scan_available"),
    optional_slots=("laterality", "age", "condition"),
    prompts={
        "device": [
            "Sure — what device are you creating (insole, AFO, socket, TLSO)?",
            "Which device is this for?",
        ],
        "scan_available": [
            "Do you already have a scan, or should we start from measurements?",
            "Is there a scan ready, or are we working from measurements?",
        ],
        "laterality": [
            "Is this the left or right side?",
            "Left or right?",
        ],
    },
))


# ── Task state ────────────────────────────────────────────────────────────

@dataclass
class TaskState:
    task_name: str = ""            # e.g. "create_device", "import_scan"
    slots: dict = field(default_factory=dict)
    asked_counts: dict = field(default_factory=dict)  # slot -> times asked
    last_object_name: str = ""     # for "it"/"this"/"the scan" resolution
    status: str = "idle"           # idle | active | complete | abandoned

    def is_active(self) -> bool:
        return self.status == "active"

    def is_relevant(self) -> bool:
        """True while a task is in progress OR just completed - a
        completed task must still be reachable for redirection (behaviour
        spec point 9: "let's work on the socket instead" right after
        finishing an AFO conversation), not just while slots are still
        being filled. Only "idle" (reset/never started) or "abandoned"
        tasks are not routed to the task engine."""
        return self.status in ("active", "complete")

    def reset(self) -> None:
        self.task_name = ""
        self.slots = {}
        self.asked_counts = {}
        self.status = "idle"
        # last_object_name deliberately survives reset - "it" should still
        # resolve across an intent change within the same session.


def start_task(state: TaskState, task_name: str) -> None:
    state.task_name = task_name
    state.slots = {}
    state.asked_counts = {}
    state.status = "active"


def apply_extraction(state: TaskState, text: str, schema: TaskSchema) -> list:
    """Extract every slot this schema cares about from free text and store
    any newly-found values. Returns the list of slot names that were
    NEWLY filled by this call (for "got it, device=AFO" style
    acknowledgement) - a slot already filled is never overwritten by a
    lower-confidence re-extraction from a later, unrelated message."""
    newly_filled = []
    all_slots = tuple(schema.required_slots) + tuple(schema.optional_slots)
    for slot in all_slots:
        if state.slots.get(slot) is not None:
            continue  # never re-ask/overwrite an already-answered slot
        extractor = SLOT_EXTRACTORS.get(slot)
        if extractor is None:
            continue
        value = extractor(text)
        if value is not None:
            state.slots[slot] = value
            newly_filled.append(slot)
    return newly_filled


def resolve_scan_availability(state: TaskState, scene_dict: dict) -> bool:
    """Never ask "do you have a scan?" if the scene already answers it -
    see behaviour spec point 7. Returns True and fills the slot if a scan
    was found; does not touch the slot if inconclusive (still unknown)."""
    try:
        mesh_names = (scene_dict or {}).get("all_mesh_names") or []
        if mesh_names:
            state.slots["scan_available"] = True
            if not state.last_object_name:
                state.last_object_name = mesh_names[0]
            return True
    except Exception:
        pass
    return False


def next_missing_slot(state: TaskState, schema: TaskSchema) -> Optional[str]:
    for slot in schema.required_slots:
        if state.slots.get(slot) is None:
            return slot
    return None


def build_question(state: TaskState, schema: TaskSchema, slot: str) -> str:
    """Rotates phrasing so repeatedly asking (a clarification retry, not a
    forbidden re-ask of an ALREADY-ANSWERED slot) doesn't read as a
    robotic loop - behaviour spec point 13."""
    variants = schema.prompts.get(slot) or [f"What is the {slot}?"]
    count = state.asked_counts.get(slot, 0)
    state.asked_counts[slot] = count + 1
    return variants[min(count, len(variants) - 1)]


_task_state: Optional[TaskState] = None


def get_task_state() -> TaskState:
    """Session-scoped singleton, same lifecycle/pattern as
    ai.conversation.get_session() - not persisted across Blender restarts."""
    global _task_state
    if _task_state is None:
        _task_state = TaskState()
    return _task_state


def reset_task_state() -> None:
    global _task_state
    _task_state = TaskState()


def resolve_reference(text: str, state: TaskState, scene_dict: dict) -> Optional[str]:
    """Best-effort resolution of "it"/"this"/"that"/"the scan" to a real
    object name, using task state first (what the user is actively working
    on) and falling back to the scene's active/only mesh. Returns None if
    genuinely ambiguous - callers should ask rather than guess (behaviour
    spec point 10/5)."""
    t = (text or "").lower()
    if not any(ref in t for ref in ("it", "this", "that", "the scan")):
        return None
    if state.last_object_name:
        return state.last_object_name
    try:
        active = (scene_dict or {}).get("active_object_name")
        if active:
            return active
        mesh_names = (scene_dict or {}).get("all_mesh_names") or []
        if len(mesh_names) == 1:
            return mesh_names[0]
    except Exception:
        pass
    return None
