# ai/__init__.py - marks this directory as a package. Intentionally empty:
# nothing in this package registers bpy.types classes or Scene properties,
# so there is nothing for __init__.py's register()/unregister() to own here
# beyond importing individual operators/functions where they're used.
