# ai/context.py - Phase 1 of the DynaX CAD Agent: give the AI real eyes.
#
# 100% READ-ONLY. No bpy.ops calls, no mesh modifications, no scene property
# writes, anywhere in this file. Every read is wrapped in try/except and
# falls back to a safe default - this module must never be able to crash a
# clinical workflow or interrupt the AI panel, no matter what state the
# scene is in (no active object, no dynax_props yet registered, a mesh with
# broken data, etc.).
#
# This does not modify or duplicate any geometry module. The watertight/
# loose-part checks below use a throwaway bmesh copy exactly like
# operators/paralink/boundary_extractor.py's own bisect_plane calls -
# read-only inspection, never written back to the object.

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Optional


# ── A. Active mesh stats ────────────────────────────────────────────────────

@dataclass
class MeshStats:
    name: str = ""
    vertex_count: int = 0
    face_count: int = 0
    edge_count: int = 0
    dimensions_mm: tuple = (0.0, 0.0, 0.0)
    location: tuple = (0.0, 0.0, 0.0)
    is_selected: bool = False
    object_mode: str = "OBJECT"
    is_watertight: bool = False
    has_loose_parts: bool = False
    modifier_count: int = 0
    material_count: int = 0


def _collect_mesh_stats(context) -> Optional[MeshStats]:
    """Returns None if there is no active object, or it isn't a mesh, or
    anything goes wrong reading it - never raises."""
    try:
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            return None

        stats = MeshStats(name=obj.name)

        try:
            stats.is_selected = bool(obj.select_get())
        except Exception:
            pass

        try:
            stats.object_mode = str(context.mode)
        except Exception:
            pass

        try:
            mesh = obj.data
            stats.vertex_count = len(mesh.vertices)
            stats.face_count = len(mesh.polygons)
            stats.edge_count = len(mesh.edges)
        except Exception:
            pass

        try:
            # obj.dimensions is already in WORLD units (accounts for scale/
            # parenting); the scene unit scale converts Blender units -> mm.
            # This mirrors import_stl.py's own mm-space convention
            # (scale_length = 0.001 -> 1 Blender unit == 1 mm already, so
            # this multiplication is a documented no-op at DynaX's default
            # scene settings, and only matters if a scene was never put into
            # mm-space by dynax.import_stl).
            scale = context.scene.unit_settings.scale_length
            dims = obj.dimensions
            stats.dimensions_mm = tuple(round(d * 1000.0 * scale, 1) for d in dims)
        except Exception:
            pass

        try:
            loc = obj.location
            stats.location = (round(loc.x, 1), round(loc.y, 1), round(loc.z, 1))
        except Exception:
            pass

        try:
            stats.modifier_count = len(obj.modifiers)
        except Exception:
            pass

        try:
            stats.material_count = len(obj.data.materials)
        except Exception:
            pass

        try:
            import bmesh
            bm = bmesh.new()
            try:
                bm.from_mesh(obj.data)
                bm.verts.ensure_lookup_table()
                bm.edges.ensure_lookup_table()
                open_edges = [e for e in bm.edges if not e.is_manifold]
                stats.is_watertight = len(open_edges) == 0
                loose = [v for v in bm.verts if not v.link_edges]
                stats.has_loose_parts = len(loose) > 0
            finally:
                bm.free()
        except Exception:
            pass

        return stats
    except Exception:
        return None


# ── B. Scene state ──────────────────────────────────────────────────────────

@dataclass
class SceneState:
    object_count: int = 0
    mesh_object_count: int = 0
    selected_count: int = 0
    selected_names: list = field(default_factory=list)
    active_object_name: Optional[str] = None
    mode: str = "OBJECT"
    all_mesh_names: list = field(default_factory=list)


def _collect_scene_state(context) -> SceneState:
    state = SceneState()
    try:
        import bpy
        objects = list(bpy.data.objects)
        state.object_count = len(objects)
        state.all_mesh_names = [o.name for o in objects if o.type == 'MESH']
        state.mesh_object_count = len(state.all_mesh_names)
    except Exception:
        pass

    try:
        selected = list(context.selected_objects)
        state.selected_count = len(selected)
        state.selected_names = [o.name for o in selected]
    except Exception:
        pass

    try:
        active = context.active_object
        state.active_object_name = active.name if active is not None else None
    except Exception:
        pass

    try:
        state.mode = str(context.mode)
    except Exception:
        pass

    return state


# ── C. DynaX workflow state ─────────────────────────────────────────────────

@dataclass
class DynaXState:
    workflow: str = "UNKNOWN"
    active_step: str = "UNKNOWN"
    device_type: str = "UNKNOWN"
    scan_imported: bool = False
    component_loaded: bool = False
    bridge_complete: bool = False
    paralink_mode: str = "UNKNOWN"
    paralink_boundary_offset: float = 0.0
    connection_style: str = "UNKNOWN"
    measurements: dict = field(default_factory=dict)


def _collect_dynax_state(context) -> DynaXState:
    state = DynaXState()
    try:
        scene = context.scene
    except Exception:
        return state

    try:
        if hasattr(scene, 'dynax_props'):
            state.workflow = getattr(scene.dynax_props, 'dynax_mode', 'UNKNOWN')
            state.active_step = getattr(scene.dynax_props, 'active_step', 'UNKNOWN')
    except Exception:
        pass

    try:
        state.device_type = getattr(scene, 'parafly_device_type', 'UNKNOWN')
    except Exception:
        pass

    try:
        # A real scan import stamps the snapshot object created by
        # operators/import_stl.py's _snapshot_original() -
        # dynax_is_original_snapshot=True - which only ever exists after a
        # real dynax.import_stl run. More reliable than guessing from an
        # object name, which is user-controlled and unpredictable.
        import bpy
        state.scan_imported = any(
            obj.get("dynax_is_original_snapshot", False)
            for obj in bpy.data.objects
        )
    except Exception:
        pass

    try:
        state.component_loaded = bool(getattr(scene, 'dynax_component_loaded', False))
    except Exception:
        pass

    try:
        state.bridge_complete = bool(getattr(scene, 'dynax_bridge_complete', False))
    except Exception:
        pass

    try:
        state.paralink_mode = getattr(scene, 'dynax_paralink_mode', 'UNKNOWN')
    except Exception:
        pass

    try:
        state.paralink_boundary_offset = float(
            getattr(scene, 'dynax_paralink_boundary_offset', 0.0))
    except Exception:
        pass

    try:
        state.connection_style = getattr(scene, 'dynax_paralink_style', 'UNKNOWN')
    except Exception:
        pass

    try:
        raw = getattr(scene, 'parafly_afo_measurements', None)
        if raw:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                state.measurements = parsed
            elif isinstance(parsed, list):
                state.measurements = {"records": parsed}
    except Exception:
        pass

    return state


# ── D. Main context builder ─────────────────────────────────────────────────

@dataclass
class DynaXContext:
    mesh: Optional[MeshStats]
    scene: SceneState
    dynax: DynaXState
    collected_at: str


def collect_context(context) -> DynaXContext:
    """Collect full DynaX+Blender context. Read-only. Never crashes - every
    sub-collector wraps its own reads in try/except and returns a safe
    default dataclass instance rather than raising."""
    try:
        mesh = _collect_mesh_stats(context)
    except Exception:
        mesh = None

    try:
        scene_state = _collect_scene_state(context)
    except Exception:
        scene_state = SceneState()

    try:
        dynax_state = _collect_dynax_state(context)
    except Exception:
        dynax_state = DynaXState()

    try:
        collected_at = datetime.now(timezone.utc).isoformat()
    except Exception:
        collected_at = ""

    return DynaXContext(
        mesh=mesh,
        scene=scene_state,
        dynax=dynax_state,
        collected_at=collected_at,
    )


_WORKFLOW_LABELS = {
    'NONE': 'Start Menu', 'NEW_CASE': 'New Case', 'PARAFORGE_MENU': 'ParaForge Menu',
    'CREATOR': 'Creator', 'PARAFORGE': 'ParaForm', 'PARAFORGE_ZONES': 'ParaFly',
    'UNKNOWN': 'Unknown',
}
_DEVICE_LABELS = {
    'NONE': 'None', 'TT': 'Transtibial (Below Knee)', 'AFO': 'AFO', 'TLSO': 'TLSO',
    'UNKNOWN': 'Unknown',
}


def context_to_prompt_text(ctx: DynaXContext) -> str:
    """Convert DynaXContext to a concise, structured text block suitable for
    injection into an AI prompt or displayed in the panel. Never raises -
    any field read that fails is simply omitted from the block."""
    lines = ["=== DynaX Scene Context ==="]

    try:
        workflow_label = _WORKFLOW_LABELS.get(ctx.dynax.workflow, ctx.dynax.workflow)
        step = ctx.dynax.active_step
        if step and step != 'UNKNOWN':
            lines.append(f"Workflow: {workflow_label} (step: {step})")
        else:
            lines.append(f"Workflow: {workflow_label}")
    except Exception:
        pass

    try:
        if ctx.dynax.device_type and ctx.dynax.device_type not in ('NONE', 'UNKNOWN'):
            device_label = _DEVICE_LABELS.get(ctx.dynax.device_type, ctx.dynax.device_type)
            lines.append(f"Device: {device_label}")
    except Exception:
        pass

    lines.append("")

    try:
        if ctx.mesh is not None:
            lines.append(f"Active object: {ctx.mesh.name}")
            lines.append(
                f"Vertices: {ctx.mesh.vertex_count:,} | Faces: {ctx.mesh.face_count:,}")
            d = ctx.mesh.dimensions_mm
            lines.append(f"Dimensions: {d[0]:g}mm × {d[1]:g}mm × {d[2]:g}mm")
            lines.append(f"Watertight: {'Yes' if ctx.mesh.is_watertight else 'No'}")
            if ctx.mesh.has_loose_parts:
                lines.append("Loose geometry: Yes")
        else:
            lines.append("Active object: none selected")
    except Exception:
        pass

    lines.append("")

    try:
        if ctx.dynax.component_loaded:
            bridge = "Bridge complete" if ctx.dynax.bridge_complete else "Loaded"
            lines.append(f"Component: {bridge}")
        if ctx.dynax.paralink_mode and ctx.dynax.paralink_mode not in ('UNKNOWN', 'AUTO'):
            offset = ctx.dynax.paralink_boundary_offset
            offset_txt = f", boundary {offset:+.0f}mm" if offset else ""
            lines.append(
                f"ParaLink: {str(ctx.dynax.paralink_mode).title()} mode{offset_txt}")
    except Exception:
        pass

    try:
        if ctx.scene.all_mesh_names:
            active = ctx.mesh.name if ctx.mesh is not None else None
            others = [n for n in ctx.scene.all_mesh_names if n != active]
            if others:
                lines.append("")
                lines.append(f"Other objects in scene: {', '.join(others)}")
    except Exception:
        pass

    lines.append("===========================")
    return "\n".join(lines)


def context_to_dict(ctx: DynaXContext) -> dict:
    """Convert DynaXContext to a JSON-serialisable dict for sending to the
    online AI API. Never raises - falls back to an empty dict on failure,
    since the caller must still be able to send a request without context
    rather than crash the query."""
    try:
        return asdict(ctx)
    except Exception:
        return {}
