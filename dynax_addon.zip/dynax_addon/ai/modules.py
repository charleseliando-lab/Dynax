# ai/modules.py - DynaX AI Agent Core: capability-module registry.
#
# One AI core (ai/context.py, ai/tools.py, ai/dispatcher.py, ai/intent.py,
# ai/conversation.py) shared by every DynaX workflow. This file is what lets
# Creator, ParaForge/ParaForm, ParaFly (and future modules) plug their own
# tools, clinical knowledge and quick actions into that one core WITHOUT the
# core knowing anything module-specific - the core only ever calls
# detect_active_module()/get_module()/list_tools(module=...), never an
# if/elif chain of workflow names. Adding a new module means calling
# register_module() once, in that module's own file - nothing here or in
# tools.py/dispatcher.py/context.py needs to change.
#
# Read-only, same discipline as the rest of ai/: no bpy.ops, no scene writes.

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class CapabilityModule:
    """One DynaX workflow's plug-in surface into the shared AI core.

    id: stable internal key ("creator", "paraform", "parafly", "paralink").
    label: human-readable name shown in responses/UI.
    dynax_modes: values of scene.dynax_props.dynax_mode that mean this
        module is the active one (see detect_active_module()).
    device_types: for modules keyed by parafly_device_type as well as
        dynax_mode (ParaFly hosts AFO/TT/TLSO) - empty means "any/not
        applicable".
    tool_names: names of ai.tools.TOOL_REGISTRY entries this module owns or
        commonly uses - used to scope list_available_tools()'s "what can I
        do right now" answer. A tool can be listed by more than one module
        (e.g. ParaLink's tools are relevant from ParaForm and ParaFly).
    knowledge: topic keyword -> explanation text, this module's own
        contribution to ai.intent.how_to_response()'s topic table.
    quick_actions: this module's own contextual quick-start suggestions,
        shown instead of the generic DEFAULT_QUICK_ACTIONS once this module
        is detected as active.
    """
    id: str
    label: str
    dynax_modes: tuple = ()
    device_types: tuple = ()
    tool_names: tuple = ()
    knowledge: dict = field(default_factory=dict)
    quick_actions: list = field(default_factory=list)


MODULE_REGISTRY: dict = {}


def register_module(module: CapabilityModule) -> None:
    MODULE_REGISTRY[module.id] = module


def get_module(module_id: str) -> Optional[CapabilityModule]:
    return MODULE_REGISTRY.get(module_id)


def list_modules() -> list:
    return list(MODULE_REGISTRY.values())


def detect_active_module(dynax_state: dict) -> Optional[CapabilityModule]:
    """dynax_state is the dict shape of ai.context.DynaXState (workflow,
    device_type, ...) - or any object/dict exposing those two keys/attrs.
    Never raises; returns None if nothing matches (e.g. Start Menu, or a
    future dynax_mode no module has registered for yet - the core degrades
    to its generic, module-agnostic behaviour in that case, it does not
    error)."""
    try:
        if hasattr(dynax_state, "get"):
            workflow = dynax_state.get("workflow")
            device_type = dynax_state.get("device_type")
        else:
            workflow = getattr(dynax_state, "workflow", None)
            device_type = getattr(dynax_state, "device_type", None)

        candidates = [
            m for m in MODULE_REGISTRY.values() if workflow in m.dynax_modes
        ]
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]

        # More than one module claims this dynax_mode (this is how ParaFly's
        # three device workflows share one dynax_mode, PARAFORGE_ZONES, but
        # register as distinct modules) - device_type breaks the tie.
        for m in candidates:
            if device_type in m.device_types:
                return m
        return candidates[0]
    except Exception:
        return None


# ── Built-in modules ─────────────────────────────────────────────────────
# Registered here (not in each panel file) for Phase "AI Agent Core": these
# four are the add-on's existing workflows becoming the first capability
# modules plugged into the shared core, per the architecture instruction.
# A future module (a new device type, a new top-level workflow) registers
# itself the same way, from its own file, at import time - no edit needed
# here or in the core.

register_module(CapabilityModule(
    id="creator",
    label="Creator",
    dynax_modes=("CREATOR",),
    tool_names=(
        "get_scene_summary", "get_active_object", "inspect_mesh",
        "get_dimensions", "get_dynax_state", "navigate_to_step",
        "list_available_tools",
    ),
    knowledge={
        "scan": (
            "To work with a scan: import the STL/scan file, DynaX will "
            "auto-centre and check it for mesh issues, then you can move "
            "into measurement, sculpting, trimline or thickness. Import "
            "your scan and I can inspect it for you."
        ),
        "trimline": (
            "Trimline uses paint-and-separate: paint the region you want "
            "to keep or remove, then separate. There's also Quick Slice "
            "for a plain horizontal-plane cut."
        ),
        "measure": (
            "Creator measures via auto rings or click-to-measure directly "
            "on the scan. Select your scan and I can check what's "
            "available at the current step."
        ),
        "print": (
            "To prepare a model for printing: I check the mesh is "
            "watertight (no open edges) and has no loose geometry, then "
            "it's ready to export."
        ),
    },
    quick_actions=[
        {"label": "Import a scan", "query": "How do I import and prepare a scan?"},
        {"label": "Measure it", "query": "How do I measure the scan?"},
        {"label": "Fix a mesh", "query": "How do I fix mesh issues?"},
        {"label": "Prepare for printing", "query": "How do I prepare a model for printing?"},
    ],
))

register_module(CapabilityModule(
    id="paraform",
    label="ParaForm",
    dynax_modes=("PARAFORGE",),
    tool_names=(
        "get_scene_summary", "get_active_object", "inspect_mesh",
        "get_dimensions", "get_dynax_state", "get_paralink_status",
        "set_paralink_mode", "set_connection_style", "set_boundary_offset",
        "list_available_tools",
    ),
    knowledge={
        "template": (
            "ParaForm starts from a parametric base template - load it, "
            "finalize the shape to bake the rig, then Components becomes "
            "available for attaching an adapter via Quick Bridge or "
            "ParaLink."
        ),
        "insole": (
            "To create an insole: import or select a foot scan, then use "
            "DynaX's insole generation workflow to take measurements "
            "(foot length, forefoot width, heel width, arch height) and "
            "build the device from them."
        ),
        "device": (
            "To modify a device: select it, then tell me what you'd like "
            "to change (width, height, wall thickness, connection style) "
            "and I'll point you to the right control."
        ),
        "paralink": (
            "ParaLink connects a socket to a component. It has four "
            "modes: Auto, Guided, Semi-Manual and Manual. Which sounds "
            "right for what you're doing?"
        ),
    },
    quick_actions=[
        {"label": "Finalize the shape", "query": "How do I finalize the shape in ParaForm?"},
        {"label": "Attach a component", "query": "How do I use ParaLink?"},
        {"label": "Adjust the device", "query": "How do I modify a device?"},
    ],
))

register_module(CapabilityModule(
    id="parafly_afo",
    label="ParaFly (AFO)",
    dynax_modes=("PARAFORGE_ZONES",),
    device_types=("AFO",),
    tool_names=(
        "get_scene_summary", "get_active_object", "inspect_mesh",
        "get_dimensions", "get_dynax_state", "get_measurements",
        "list_available_tools",
    ),
    knowledge={
        "landmark": (
            "AFO starts with landmark placement (including the Calf "
            "landmark), then auto-alignment, angular correction sliders, "
            "zone mapping and measurements."
        ),
        "correction": (
            "AFO angular correction is a smoothstep blend around the "
            "ankle - adjust the sliders and the correction recomputes "
            "from the stored baseline."
        ),
    },
    quick_actions=[
        {"label": "Place landmarks", "query": "How do I place AFO landmarks?"},
        {"label": "Check measurements", "query": "What measurements do I have?"},
    ],
))

register_module(CapabilityModule(
    id="parafly_tlso",
    label="ParaFly (TLSO)",
    dynax_modes=("PARAFORGE_ZONES",),
    device_types=("TLSO",),
    tool_names=(
        "get_scene_summary", "get_active_object", "inspect_mesh",
        "get_dimensions", "get_dynax_state", "list_available_tools",
    ),
    knowledge={
        "alignment": (
            "TLSO starts with alignment planes, then clinical zone "
            "mapping and per-zone sliders."
        ),
    },
    quick_actions=[
        {"label": "Set up alignment", "query": "How do I set up TLSO alignment?"},
    ],
))

register_module(CapabilityModule(
    id="paramold",
    label="ParaMold",
    dynax_modes=("PARAMOLD",),
    tool_names=(
        "get_scene_summary", "get_active_object", "inspect_mesh",
        "get_dimensions", "get_dynax_state", "list_available_tools",
    ),
    knowledge={
        "mold": (
            "ParaMold designs a two-part silicone mold: import and align "
            "the finger scan, optionally trim it, Generate Mold to split "
            "it into Half A/Half B, reposition the registration keys and "
            "pour channel, Apply Keys and Apply Pour Channel, then export "
            "both halves as STL."
        ),
        "key": (
            "Registration keys keep the two mold halves aligned while "
            "pouring - a bump on Half A and a matching hole on Half B. "
            "Move them anywhere on the split face, then click Apply Keys."
        ),
        "pour": (
            "The pour channel is the moveable red cylinder that becomes "
            "the opening you pour silicone through - reposition/resize it "
            "so it overlaps the mold wall, then click Apply Pour Channel."
        ),
        "silicone": (
            "ParaMold reports the cavity volume in mL after Generate Mold "
            "- add roughly 10% for waste when mixing silicone."
        ),
    },
    quick_actions=[
        {"label": "Generate the mold", "query": "How do I generate a mold in ParaMold?"},
        {"label": "Position the keys", "query": "How do the registration keys work?"},
        {"label": "Set up the pour channel", "query": "How do I use the pour channel?"},
    ],
))

register_module(CapabilityModule(
    id="parafly_tt",
    label="ParaFly (TT)",
    dynax_modes=("PARAFORGE_ZONES",),
    device_types=("TT",),
    tool_names=(
        "get_scene_summary", "get_active_object", "inspect_mesh",
        "get_dimensions", "get_dynax_state", "get_paralink_status",
        "set_paralink_mode", "set_connection_style", "set_boundary_offset",
        "list_available_tools",
    ),
    knowledge={
        "component": (
            "ParaFly TT reuses the same Components section as ParaForm - "
            "load a component, then Quick Bridge or ParaLink to connect it."
        ),
        "paralink": (
            "ParaLink connects a socket to a component. It has four "
            "modes: Auto, Guided, Semi-Manual and Manual."
        ),
    },
    quick_actions=[
        {"label": "Attach a component", "query": "How do I use ParaLink?"},
        {"label": "Check measurements", "query": "What measurements do I have?"},
    ],
))
