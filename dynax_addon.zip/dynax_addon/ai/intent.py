# ai/intent.py - lightweight, offline, keyword-based intent classification.
#
# Fixes the reported bug: "no mesh selected" was returned for EVERY query
# when no mesh existed, including general questions like "can you guide
# me?" that have nothing to do with a specific mesh. This module decides
# WHICH kind of question was asked before anything downstream decides
# whether a mesh is required to answer it.
#
# Pure Python, no bpy import, no network - classification never needs scene
# state, only the text itself, so it works identically online or offline
# and can run on the background thread if ever needed (it currently
# doesn't run there, but nothing here would break if it did).

from __future__ import annotations

import re

# ── Categories ───────────────────────────────────────────────────────────
# GENERAL_GUIDANCE - "can you guide me", "help", "what can you do" - no
#   scene/mesh needed at all, answer from DynaX knowledge only.
# HOW_TO - "how do I create an insole", "how do I measure X" - explains a
#   DynaX workflow; no mesh needed to EXPLAIN it, even though the workflow
#   itself will eventually need one.
# MESH_ACTION - "inspect this", "check this scan", "measure the width here"
#   - refers to a specific mesh the user has (or should have) selected.
# STATUS - "what's the status", "what can you see" - context/state query,
#   already served by the Phase 2 tool registry / DYNAX_OT_show_context,
#   not a mesh requirement in itself.
# UNKNOWN - falls through to the existing RULES keyword table in
#   panels/ai_assistant.py (device-type clinical suggestions).

GENERAL_GUIDANCE = "GENERAL_GUIDANCE"
HOW_TO = "HOW_TO"
MESH_ACTION = "MESH_ACTION"
STATUS = "STATUS"
TASK = "TASK"
SELECT_DYNAX_ENVIRONMENT = "SELECT_DYNAX_ENVIRONMENT"
DYNAX_PLATFORM_EXPLANATION = "DYNAX_PLATFORM_EXPLANATION"
GREETING = "GREETING"
UNKNOWN = "UNKNOWN"

# GREETING - plain social openers ("hello", "good morning") and
# appreciation ("thank you", "great job") - neither needs a mesh or any
# DynaX knowledge to answer well, and neither should ever reach the
# clinical RULES table (panels/ai_assistant.py) or the generic guidance
# wall-of-text. Checked FIRST, before every other category: a short "hi"
# or "thanks" must never accidentally fall through to HOW_TO/MESH_ACTION/
# UNKNOWN just because some other phrase list happens to substring-match.
_GREETING_WORDS = (
    "hello", "hi", "hey", "hiya", "howdy", "greetings",
)
_GREETING_PHRASES = (
    "good morning", "good afternoon", "good evening", "good day",
    "what's up", "whats up", "how are you", "how're you", "how you doing",
    "how's it going", "hows it going",
)
_APPRECIATION_WORDS = (
    "thanks", "thx", "cheers",
)
_APPRECIATION_PHRASES = (
    "thank you", "great job", "good job", "well done", "nice work",
    "appreciate it", "you're the best", "youre the best", "you're amazing",
    "youre amazing", "that's helpful", "thats helpful", "that helped",
    "nicely done", "excellent work", "you rock", "awesome work",
    "this is awesome", "you're awesome", "youre awesome",
)
_GREETING_PATTERN = re.compile(
    r"\b(?:" + "|".join(re.escape(w) for w in _GREETING_WORDS) + r")\b"
)
_APPRECIATION_PATTERN = re.compile(
    r"\b(?:" + "|".join(re.escape(w) for w in _APPRECIATION_WORDS) + r")\b"
)

# DYNAX_PLATFORM_EXPLANATION - "how does the platform work", "how does
# DynaX work", "how does Creator/ParaForm/ParaFly work", "what is DynaX" -
# a PRODUCT question (domain DYNAX_PRODUCT/DYNAX_ENVIRONMENTS), answered
# from ai.intent.PLATFORM_TOPICS below. Deliberately its own category,
# checked before HOW_TO: "how does X work" questions must never fall into
# the same generic HOW_TO bucket as "how do I create an insole" - the
# former is a product question, the latter is a clinical/workflow one,
# and only the latter is allowed to eventually reach the device-specific
# RULES table in panels/ai_assistant.py. See that file's local_fallback()
# for how this category is kept OUT of clinical content entirely - this is
# the fix for the reported grounding bug where "how does the platform
# works" returned quadrilateral-socket/ischial-seat/Scarpa's-triangle
# content. Root cause of that specific failure (traced, not guessed): the
# RULES table's above-knee entry has "tf" as a bare keyword, matched via
# naive substring `in` - "platform" contains the letters "tf" (pla-TF-orm).
# Every 2-3 letter clinical abbreviation ("tf", "ak", "bk", "tt") was an
# unbounded substring match; panels/ai_assistant.py now matches RULES
# keywords on word boundaries only, and - more importantly - a product
# question like this is now resolved HERE, before it can ever reach that
# table at all.
_PLATFORM_EXPLANATION_PHRASES = (
    "how does the platform work", "how does dynax work",
    "how does this platform work", "how do platforms work",
    "what is dynax", "what does dynax do", "explain dynax",
    "explain the platform", "what is this platform",
    "what is this program", "what is this software",
    "how does creator work", "how does paraform work",
    "how does parafly work", "how does paraforge work",
    "how does paramold work",
    "what is creator", "what is paraform", "what is parafly",
    "what is paraforge", "what is paramold",
)
# Literal phrase lists can't cover every real phrasing ("how does the
# platform works", a typo/variant the literal list happened to catch by
# luck since it doesn't require exact "work" vs "works" - but a rephrase
# like "how's the platform supposed to work" would still slip past a pure
# phrase list). This regex catches the general shape - "how (does/do/is)
# ... (dynax/platform/creator/paraform/parafly/paraforge/this program/
# software) ... work" - regardless of the exact words in between.
_PLATFORM_EXPLANATION_PATTERN = re.compile(
    r"\bhow\s+(?:does|do|is|are)\b(?:\s+\w+){0,4}?\s+"
    r"(?:dynax|platform|creator|paraform(?:ge)?|parafly|paramold)\b"
)

# SELECT_DYNAX_ENVIRONMENT - "which platform is best for a Boston brace
# TLSO?", "should I use Creator or ParaForm for a socket?" - the user is
# asking WHICH DYNAX WORKFLOW to open for a device, not asking for
# clinical content about a device they've already started. Checked before
# every other category: "boston brace tlso" alone would otherwise never
# match GUIDANCE/HOW_TO/MESH_ACTION and falls through to the RULES keyword
# table (panels/ai_assistant.py), which matches "tlso" unconditionally and
# would answer with clinical wall-thickness/landmark notes instead of a
# platform recommendation - the exact reported bug. See ai/environments.py
# for the actual device-ontology answer this category routes to.
_PLATFORM_SELECTION_PHRASES = (
    "which platform", "what platform", "which environment",
    "what environment", "which workflow", "what workflow",
    "which tool should i use", "what tool should i use",
    "which is best to use", "best platform for", "best platform to use",
    "should i use creator", "should i use paraform", "should i use parafly",
    "creator or paraform", "creator or parafly", "paraform or parafly",
    "which dynax", "what dynax environment", "which one should i use",
)
# Same reasoning as _PLATFORM_EXPLANATION_PATTERN above: a fixed phrase
# list missed real phrasing like "which of the workflow can I use for
# tlso" (extra words between "which" and "workflow" that none of the
# literal phrases above account for) - traced directly from a real user
# session where it fell through to the clinical RULES table instead of a
# platform recommendation, the same class of bug as the original "tf"-in-
# "platform" report. This regex matches the general shape - "which/what
# (...up to 4 words...) platform/workflow/environment/tool(s)" - so word
# choice in between no longer matters.
_PLATFORM_SELECTION_PATTERN = re.compile(
    r"\b(?:which|what)\b(?:\s+\w+){0,4}?\s+"
    r"(?:platform|workflow|environment|tool)s?\b"
)

# ── Task triggers (behaviour spec: progressive, task-state conversation) ──
# Checked BEFORE the plain HOW_TO prefix check, deliberately: "how do I
# create an insole" and "how can I import a scan" both contain a task
# trigger phrase, and per the behaviour spec these should become
# progressive, action-oriented conversations (ai/task_state.py) rather than
# a flat explanation - the same underlying words, a different, better
# response shape.

_CREATE_DEVICE_PHRASES = (
    "create a", "create an", "make a", "make an", "i need a", "i need an",
    "i want to make", "i want a", "i want an", "generate a", "generate an",
    "build a", "build an",
)
_IMPORT_SCAN_PHRASES = (
    "import a scan", "import scan", "load a scan", "load scan",
    "import the scan", "how can i import", "how do i import",
    "import my scan",
)


def detect_task_trigger(text: str):
    """Returns a task name (ai.task_state.TASK_SCHEMAS key) or None. Pure
    keyword matching, same honesty as the rest of this file - not real
    intent recognition, the deterministic offline floor underneath
    whatever a real online model would eventually do better."""
    try:
        t = (text or "").lower().strip()
        if any(p in t for p in _IMPORT_SCAN_PHRASES):
            return "import_scan"
        if any(p in t for p in _CREATE_DEVICE_PHRASES):
            return "create_device"
        return None
    except Exception:
        return None

_GUIDANCE_PHRASES = (
    # "how do i use" was deliberately removed - it's a substring of
    # legitimate specific HOW_TO questions ("how do I use ParaLink?"),
    # which it was silently swallowing into the generic guidance response
    # instead of the correct topic-specific one. Caught via headless
    # testing of the AI Agent Core module registry.
    "guide me", "help me", "how does this work",
    "how do i use dynax", "how do i use this platform",
    "how do i use the platform",
    "getting started", "i use the platform", "i'm new", "im new",
    "what can you do", "what do you do", "what can i do",
    "how does dynax work", "explain dynax",
)

_HOW_TO_PREFIXES = (
    "how do i ", "how to ", "how can i ", "how would i ",
)

_MESH_ACTION_VERBS = (
    "inspect", "check", "validate", "fix", "repair", "measure",
    "increase", "decrease", "adjust", "widen", "narrow", "modify",
    "prepare", "export", "print", "cut", "trim", "show me where",
    "why is this", "why does this", "why can't i", "why cant i",
    "why isn't", "why isnt", "why won't", "why wont",
    "not working", "isn't working", "isnt working",
)
_MESH_REFERENT_WORDS = (
    "this", "this scan", "this mesh", "this model", "the scan",
    "the mesh", "the model", "it", "here",
    "my mesh", "my scan", "my model",
)

_STATUS_PHRASES = (
    "what can you see", "what do you see", "current status",
    "what's going on", "whats going on", "what state",
)


def classify_intent(text: str) -> dict:
    """Returns {"category": ..., "requires_mesh": bool}. Never raises -
    worst case falls through to UNKNOWN/requires_mesh=False, which is the
    safe direction (never wrongly BLOCKS an answer for lack of a mesh)."""
    try:
        t = (text or "").lower().strip()
        if not t:
            return {"category": UNKNOWN, "requires_mesh": False}

        # Checked first, deliberately: a short "hi"/"thanks" must never
        # fall through to any other category (HOW_TO/MESH_ACTION/UNKNOWN)
        # just because some other phrase list happens to substring-match
        # part of it, and it must never reach the clinical RULES table.
        # Length-guarded (<=6 words) so a real question that merely OPENS
        # with a greeting ("hi, how do I increase wall thickness") still
        # reaches its real category instead of being swallowed by this one.
        is_greeting = (bool(_GREETING_PATTERN.search(t))
                       or any(p in t for p in _GREETING_PHRASES))
        is_appreciation = (bool(_APPRECIATION_PATTERN.search(t))
                            or any(p in t for p in _APPRECIATION_PHRASES))
        if (is_greeting or is_appreciation) and len(t.split()) <= 6:
            return {
                "category": GREETING, "requires_mesh": False,
                "is_appreciation": is_appreciation,
            }

        if any(p in t for p in _PLATFORM_SELECTION_PHRASES) or _PLATFORM_SELECTION_PATTERN.search(t):
            return {"category": SELECT_DYNAX_ENVIRONMENT, "requires_mesh": False}

        if any(p in t for p in _PLATFORM_EXPLANATION_PHRASES) or _PLATFORM_EXPLANATION_PATTERN.search(t):
            return {"category": DYNAX_PLATFORM_EXPLANATION, "requires_mesh": False}

        if any(p in t for p in _STATUS_PHRASES):
            return {"category": STATUS, "requires_mesh": False}

        if any(p in t for p in _GUIDANCE_PHRASES):
            return {"category": GENERAL_GUIDANCE, "requires_mesh": False}

        task_name = detect_task_trigger(t)
        if task_name is not None:
            return {"category": TASK, "requires_mesh": False, "task_name": task_name}

        if any(t.startswith(p) for p in _HOW_TO_PREFIXES):
            return {"category": HOW_TO, "requires_mesh": False}

        # A mesh-action verb ALONE isn't enough - "how do I increase the
        # arch" is HOW_TO (already caught above), not a live action. Only
        # treat it as MESH_ACTION when it's paired with a referent word
        # pointing at something the user has in front of them right now.
        has_verb = any(v in t for v in _MESH_ACTION_VERBS)
        has_referent = any(r in t for r in _MESH_REFERENT_WORDS)
        if has_verb and has_referent:
            return {"category": MESH_ACTION, "requires_mesh": True}

        return {"category": UNKNOWN, "requires_mesh": False}
    except Exception:
        return {"category": UNKNOWN, "requires_mesh": False}


# ── Canned guidance content (offline-safe, no network) ──────────────────

_GREETING_REPLIES = (
    "Hello! I'm DynaX AI. What are you working on today?",
    "Hi there! Ready to help with your design - what's the plan?",
    "Hey! What can I help you build or check today?",
)
_APPRECIATION_REPLIES = (
    "You're welcome! Let me know if there's anything else you need.",
    "Glad that helped! What's next?",
    "Happy to help - just ask if you need anything else.",
)


def greeting_response(text: str, is_appreciation: bool = False, module=None) -> str:
    """Canned, offline-safe reply for GREETING-category messages. Picks
    deterministically off the message length (not randomness - see
    DEFAULT_QUICK_ACTIONS's own precedent for keeping offline responses
    reproducible/testable) so the same input always gives the same output."""
    replies = _APPRECIATION_REPLIES if is_appreciation else _GREETING_REPLIES
    reply = replies[len(text or "") % len(replies)]
    if module is not None and not is_appreciation:
        reply += f" You're currently in {module.label}."
    return reply


GUIDANCE_MESSAGE = (
    "I can guide you through DynaX step by step. I can help with:\n"
    "- Importing and preparing scans\n"
    "- Taking measurements\n"
    "- Identifying landmarks\n"
    "- Creating devices\n"
    "- Modifying geometry\n"
    "- Using parametric controls\n"
    "- Preparing models for 3D printing\n"
    "- Understanding DynaX tools\n\n"
    "What are you working on?"
)

DEFAULT_QUICK_ACTIONS = [
    {"label": "Create an insole", "query": "How do I create an insole?"},
    {"label": "Work with a scan", "query": "How do I import and prepare a scan?"},
    {"label": "Modify a device", "query": "How do I modify a device?"},
    {"label": "Prepare for printing", "query": "How do I prepare a model for printing?"},
]

_HOW_TO_TOPICS = {
    "insole": (
        "To create an insole: import or select a foot scan, then use "
        "DynaX's insole generation workflow to take measurements (foot "
        "length, forefoot width, heel width, arch height) and build the "
        "device from them. I can walk you through it step by step, or "
        "check your current scan if you already have one selected."
    ),
    "measure": (
        "DynaX measures forefoot width, heel width, foot length and arch "
        "height directly from a scan. Select your scan, then tell me "
        "which measurement you want and I'll guide you to it."
    ),
    "scan": (
        "To work with a scan: import the STL/scan file, DynaX will "
        "auto-centre and check it for mesh issues, then you can move into "
        "measurement or device creation. Import your scan and I can "
        "inspect it for you."
    ),
    "print": (
        "To prepare a model for printing: I check the mesh is watertight "
        "(no open edges) and has no loose geometry, then it's ready to "
        "export. Select the model you want to prepare and I'll validate "
        "it first."
    ),
    "paralink": (
        "ParaLink connects a socket to a component. It has four modes: "
        "Auto (one click, fully automatic), Guided (I analyse the "
        "boundaries and show you metrics before confirming), Semi-Manual "
        "(you set the connection style and boundary offset yourself), and "
        "Manual (extract boundaries, then validate and join). Which "
        "sounds right for what you're doing?"
    ),
    "device": (
        "To modify a device: select it, then tell me what you'd like to "
        "change (width, height, wall thickness, connection style) and "
        "I'll point you to the right control."
    ),
}


# ── DYNAX_PRODUCT / DYNAX_ENVIRONMENTS domain content ────────────────────
# Answers DYNAX_PLATFORM_EXPLANATION questions. Deliberately separate from
# _HOW_TO_TOPICS and every clinical device explanation in panels/
# ai_assistant.py's RULES table - a question about DynaX itself, or about
# which capability environment (Creator/ParaForm/ParaFly) does what, must
# never retrieve clinical/anatomy content just because that content also
# happens to live somewhere in this add-on's knowledge. This is the
# domain-separation fix: DYNAX_PRODUCT and CLINICAL_P_AND_O are answered
# from entirely different tables, and platform_explanation_response() never
# reads from RULES/_HOW_TO_TOPICS at all.
PLATFORM_MESSAGE = (
    "DynaX is a guided CAD platform for prosthetic and orthotic design, "
    "built around four capability environments:\n"
    "- Creator - general, scan-based device creation: import a scan, "
    "clean it up, measure, sculpt, trim, thicken and export.\n"
    "- ParaForm - parametric prosthetic socket design from a pre-rigged "
    "template, adjusted with live sliders instead of freehand sculpting.\n"
    "- ParaFly - orthotic design and correction workflows (AFO, TLSO, TT) "
    "with landmark placement, clinical zone mapping and per-zone "
    "adjustment.\n"
    "- ParaMold - two-part silicone mold design for finger prostheses and "
    "small devices: align a scan, generate the mold halves, position "
    "registration keys and a pour channel, then export.\n\n"
    "Are you asking about DynaX overall, or one of these environments "
    "specifically?"
)

_ENVIRONMENT_TOPICS = {
    "creator": (
        "Creator is DynaX's general, scan-based workflow: import a real "
        "scan, then move through cleanup, alignment, cropping, "
        "measurement, sculpting, trimline, thickness, components and "
        "export. It's the most direct path when you have a scan and want "
        "hands-on control at every step."
    ),
    "paraform": (
        "ParaForm is DynaX's parametric prosthetic socket workflow: load "
        "the pre-rigged template, adjust it with live circumference/"
        "height sliders per body region instead of freehand sculpting, "
        "then finalize the shape to attach components."
    ),
    "paraforge": (
        "ParaForge is the umbrella menu for DynaX's two parametric/"
        "clinical-zone workflows - ParaForm (prosthetic sockets) and "
        "ParaFly (orthotic devices) - reached from New Case."
    ),
    "parafly": (
        "ParaFly is DynaX's orthotic design and correction workflow, "
        "covering AFO, TLSO and TT (transtibial) devices: place clinical "
        "landmarks, align and correct, paint anatomical zones by name on "
        "a rigged reference, then adjust each zone with a live slider."
    ),
    "paramold": (
        "ParaMold is DynaX's two-part silicone mold workflow for finger "
        "prostheses and small devices: align the finger scan, generate "
        "the mold box (split into Half A/Half B), reposition the "
        "registration keys and pour channel, apply them, then export "
        "both halves as STL for printing."
    ),
}


def platform_explanation_response(text: str) -> str:
    """Answers a DYNAX_PLATFORM_EXPLANATION question from DynaX product
    knowledge only - never clinical/anatomy content. If the question names
    a specific environment (Creator/ParaForm/ParaForge/ParaFly), answers
    that environment specifically; otherwise gives the high-level product
    overview and asks which environment the user means (behaviour spec
    point 7: ask rather than guess). Never raises."""
    try:
        t = (text or "").lower()
        for topic, response in _ENVIRONMENT_TOPICS.items():
            if topic in t:
                return response
    except Exception:
        pass
    return PLATFORM_MESSAGE


def how_to_response(text: str, module=None) -> str:
    """Best-effort topic match for a HOW_TO question. `module`, if given,
    is an ai.modules.CapabilityModule - its own knowledge dict is checked
    FIRST (module-specific answers win over the generic ones: e.g.
    ParaForm's "template" explanation vs. Creator's "scan" explanation),
    then the generic cross-module topic table, then the general guidance
    message as a last resort. This is the AI Agent Core / capability-module
    seam: this function stays module-agnostic - it never hardcodes a
    module id or an if/elif per workflow, it only ever reads whatever
    `module.knowledge` dict it's handed."""
    try:
        t = (text or "").lower()
        if module is not None:
            for topic, response in (module.knowledge or {}).items():
                if topic in t:
                    return response
        for topic, response in _HOW_TO_TOPICS.items():
            if topic in t:
                return response
    except Exception:
        pass
    return GUIDANCE_MESSAGE
