# ai/conversation.py - Phase 3 of the DynaX CAD Agent: multi-turn state.
#
# Session-scoped only - not persisted across Blender restarts, not written
# to disk, not synced anywhere. This is in-memory conversation state for the
# duration of one Blender session, same "no persistent history" posture as
# everything else this add-on keeps in module-level singletons (see
# session_recorder.py's SessionRecorder / get_recorder() for the identical
# pattern this mirrors).

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class ConversationTurn:
    role: str  # "user" | "assistant"
    text: str
    tool_used: str = ""
    tool_result: dict = field(default_factory=dict)
    timestamp: str = ""


class ConversationSession:
    """Session-scoped conversation history. Not persisted across Blender
    restarts. Max 20 turns kept (older turns dropped, oldest first)."""

    MAX_TURNS = 20

    def __init__(self):
        self._turns: list = []

    def add_turn(self, role, text, tool_used="", tool_result=None) -> None:
        try:
            turn = ConversationTurn(
                role=str(role),
                text=str(text) if text is not None else "",
                tool_used=str(tool_used) if tool_used else "",
                tool_result=dict(tool_result) if tool_result else {},
                timestamp=datetime.now(timezone.utc).isoformat(),
            )
            self._turns.append(turn)
            if len(self._turns) > self.MAX_TURNS:
                self._turns = self._turns[-self.MAX_TURNS:]
        except Exception:
            pass

    def get_history(self) -> list:
        """Returns list of {role, text} dicts suitable for an LLM messages
        array - deliberately excludes tool_used/tool_result/timestamp,
        which are for the local display/log, not the wire format."""
        try:
            return [{"role": t.role, "text": t.text} for t in self._turns]
        except Exception:
            return []

    def get_history_text(self) -> str:
        """Plain text log for display and offline context injection."""
        try:
            lines = []
            for t in self._turns:
                label = "You:" if t.role == "user" else "DynaX:"
                lines.append(f"{label} {t.text}")
                if t.tool_used:
                    lines.append(f"  [used tool: {t.tool_used}]")
            return "\n".join(lines)
        except Exception:
            return ""

    def get_turns(self, last_n: int = None) -> list:
        """Return the raw ConversationTurn list (or just the last N), for
        callers - like the panel - that need tool_used/tool_result/role
        together, not just the flat {role, text} shape get_history() gives
        an LLM messages array."""
        try:
            return list(self._turns) if last_n is None else list(self._turns[-last_n:])
        except Exception:
            return []

    def clear(self) -> None:
        self._turns = []

    def turn_count(self) -> int:
        try:
            return len(self._turns)
        except Exception:
            return 0


# Module level - created ONCE at import time, never replaced. The previous
# lazy-init pattern (`_session = None` until first get_session() call, then
# reset_session() reassigning to a brand-new ConversationSession()) was
# audited: this file has exactly one real import site in the whole codebase
# (panels/ai_assistant.py's `from ..ai.conversation import get_session,
# reset_session`), so no dual-import-path module-object split was found -
# but reset_session()'s reassignment was still a real, if narrower, way for
# id(get_session()) to change out from under any caller holding an older
# reference. Eager, single, never-reassigned instantiation removes that
# possibility entirely: id(get_session()) is now guaranteed identical for
# the lifetime of the Blender session, no matter which caller (poll, draw,
# any operator) asks for it or when.
_SESSION = ConversationSession()


def get_session() -> ConversationSession:
    """Always returns the same instance. Never creates a new one."""
    return _SESSION


def reset_session() -> None:
    """Clear turns but keep the same instance - do NOT reassign _SESSION to
    a new ConversationSession(), that would reintroduce the exact
    same-object guarantee this fix exists to close."""
    _SESSION.clear()
