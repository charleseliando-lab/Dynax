# ai/environments.py - DynaX device ontology + platform-selection answers.
#
# Fixes the reported bug: "I would like to work on a Boston brace TLSO,
# which platform is the best to use?" was answered with generic TLSO
# clinical content (wall thickness, verify landmarks, etc.) instead of the
# question actually asked - which DynaX WORKFLOW to open. The old path fell
# straight through ai.intent.classify_intent()'s categories to the RULES
# keyword table in panels/ai_assistant.py, which matches "tlso" as a
# device-content question unconditionally and has no way to recognise
# "which platform" framing.
#
# ai.intent now detects that framing as its own category
# (SELECT_DYNAX_ENVIRONMENT) BEFORE the RULES fallback ever runs, and this
# module answers it from the device ontology below instead - reusing
# ai.modules.MODULE_REGISTRY (the existing Creator/ParaForm/ParaFly-AFO/TT/
# TLSO capability modules) so there is still only one place a module's
# label/identity is defined.
#
# Device identity ontology - insole/AFO/KAFO/TLSO/socket/prosthetic foot
# are clinically distinct devices and must never be conflated. Each maps to
# zero, one, or several DynaX environments; "zero" is answered honestly
# (KAFO and prosthetic feet are not modelled device workflows in DynaX
# today) rather than guessed at.
#
# Pure Python, no bpy import - same offline-safe discipline as the rest of
# ai/.

from __future__ import annotations

from .modules import get_module

DEVICE_ONTOLOGY = {
    "insole": {
        "label": "Insole / foot orthotic",
        "modules": ("creator", "paraform"),
        "note": (
            "Creator if you have a real foot scan to build from; ParaForm "
            "if you want to start from the parametric template instead."
        ),
    },
    "afo": {
        "label": "AFO (Ankle-Foot Orthosis)",
        "modules": ("parafly_afo",),
        "note": None,
    },
    "kafo": {
        "label": "KAFO (Knee-Ankle-Foot Orthosis)",
        "modules": (),
        "note": (
            "DynaX doesn't have a dedicated KAFO device type yet - ParaFly "
            "currently supports AFO, TLSO and TT (transtibial socket) only."
        ),
    },
    "tlso": {
        "label": "TLSO (spinal orthosis, e.g. Boston brace)",
        "modules": ("parafly_tlso",),
        "note": None,
    },
    "socket": {
        "label": "Prosthetic socket",
        "modules": ("creator", "paraform", "parafly_tt"),
        "note": (
            "Creator or ParaFly TT if you have a real limb scan (TT adds "
            "clinical zone mapping on top); ParaForm if you want to start "
            "from the parametric transfemoral template instead."
        ),
    },
    "prosthetic_foot": {
        "label": "Prosthetic foot",
        "modules": (),
        "note": (
            "DynaX doesn't model prosthetic feet as their own device "
            "workflow - a foot is a pre-made component you attach to a "
            "finished socket via Components > Quick Bridge or ParaLink."
        ),
    },
    "mold": {
        "label": "Silicone mold (finger prosthesis / small device)",
        "modules": ("paramold",),
        "note": None,
    },
}

# Keyword -> ontology key. Deliberately separate from ai.task_state's
# DEVICE_KEYWORDS (which drives conversational slot extraction for the
# create_device task, not environment identity) so this table can carry
# KAFO/prosthetic-foot entries that table has no reason to know about.
_DEVICE_KEYWORDS = {
    "tlso": ("tlso", "spinal orthosis", "spinal brace", "boston brace",
             "thoracic", "scoliosis brace"),
    "kafo": ("kafo", "knee ankle foot", "knee-ankle-foot"),
    "afo": ("afo", "ankle foot orthosis", "ankle-foot orthosis"),
    "prosthetic_foot": ("prosthetic foot", "foot component", "sach foot",
                         "dynamic foot"),
    "socket": ("socket", "transtibial", "transfemoral",
               "prosthetic socket", "residual limb socket"),
    "insole": ("insole", "foot orthotic", "orthotic insole"),
    "mold": ("silicone mold", "finger mold", "finger prosthesis",
              "finger prosthetic", "mold making", "two-part mold",
              "paramold"),
}


def detect_device(text: str):
    """Best-effort device-key match, most-specific phrases checked first
    (e.g. 'boston brace'/'kafo' before the more generic 'afo' substring
    that 'kafo' itself contains) so a KAFO question can't be silently
    misclassified as AFO. Never raises."""
    try:
        t = (text or "").lower()
        for device, keywords in _DEVICE_KEYWORDS.items():
            if any(k in t for k in keywords):
                return device
        return None
    except Exception:
        return None


def recommend_environment(device_key: str) -> dict:
    """Builds a local_fallback()-shaped response {"clinical_notes":...,
    "quick_actions":[...]} recommending which DynaX environment(s) support
    this device, with quick actions that jump straight into each one.
    Never raises - an unknown device_key, or a module id with no
    registered module, both degrade to a plain-text note with no quick
    actions rather than an error."""
    try:
        entry = DEVICE_ONTOLOGY.get(device_key)
        if entry is None:
            return {
                "clinical_notes": (
                    "I'm not sure which DynaX environment that device "
                    "needs - could you tell me more about it?"
                ),
                "quick_actions": [],
            }

        module_ids = entry["modules"]
        if not module_ids:
            return {
                "clinical_notes": f"{entry['label']}: {entry['note']}",
                "quick_actions": [],
            }

        labels = []
        quick_actions = []
        for mid in module_ids:
            m = get_module(mid)
            if m is None:
                continue
            labels.append(m.label)
            quick_actions.append({"label": f"Open {m.label}", "env": mid})

        if not labels:
            return {
                "clinical_notes": (
                    f"{entry['label']}: I don't have that environment "
                    "registered right now."
                ),
                "quick_actions": [],
            }

        if len(labels) == 1:
            text = f"For {entry['label']}, use {labels[0]}."
        else:
            text = f"For {entry['label']}, you can use {' or '.join(labels)}."
        if entry.get("note"):
            text += " " + entry["note"]

        return {"clinical_notes": text, "quick_actions": quick_actions[:4]}
    except Exception:
        return {
            "clinical_notes": (
                "I'm not sure which DynaX environment that device needs - "
                "could you tell me more about it?"
            ),
            "quick_actions": [],
        }


# module id -> the concrete jump target (dynax_mode, and device_type for
# ParaFly's three device-specific modules, None for modules that don't key
# off parafly_device_type). Kept here rather than in ai.modules since it's
# UI-navigation detail specific to the "open this for me" quick action, not
# part of a module's own capability description.
_MODULE_TARGETS = {
    "creator": ("CREATOR", None),
    "paraform": ("PARAFORGE", None),
    "parafly_afo": ("PARAFORGE_ZONES", "AFO"),
    "parafly_tlso": ("PARAFORGE_ZONES", "TLSO"),
    "parafly_tt": ("PARAFORGE_ZONES", "TT"),
}


def switch_to_environment(scene, module_id: str) -> bool:
    """Sets the same scene properties dynax.set_mode / paraforge.set_device_
    type do, skipping the New Case / ParaForge-menu intermediate screens
    (session-locked navigation, see CLAUDE.md) since the user already told
    the AI exactly which workflow they want. Returns False (no scene
    mutation) for an unknown module_id instead of raising."""
    target = _MODULE_TARGETS.get(module_id)
    if target is None:
        return False
    dynax_mode, device_type = target
    scene.dynax_props.dynax_mode = dynax_mode
    if device_type is not None and hasattr(scene, "parafly_device_type"):
        scene.parafly_device_type = device_type
    return True
