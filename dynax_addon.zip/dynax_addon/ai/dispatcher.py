# ai/dispatcher.py - DynaX CAD Agent tool dispatch.
#
# Phase 2: dispatch() only looks a tool up in TOOL_REGISTRY and calls its
# handler - read-only from this module's own point of view (the handler
# itself may or may not write state; the dispatcher owned no state).
#
# Phase 3 adds a single module-level _pending_action slot: the confirmation
# gate for write tools. stage_action() records what WOULD run and returns a
# human-readable preview; nothing executes until confirm_action() is called
# explicitly (from DYNAX_OT_ai_confirm_action, a real user click). Every
# call site returns a ToolResult; nothing in this module raises.

from __future__ import annotations

from typing import Optional

from .tools import get_tool, ToolResult


def dispatch(tool_name: str, params: dict, blender_context) -> ToolResult:
    """Look up a tool by name, execute its handler, return ToolResult
    always - never raises. A handler that raises internally is caught here
    too, as a second line of defence on top of each handler's own
    try/except (Tool handlers are third-party-shaped call targets from the
    dispatcher's point of view - never trust one to fail cleanly)."""
    tool = get_tool(tool_name)
    if tool is None:
        return ToolResult(
            success=False,
            tool_name=tool_name,
            data={},
            summary="",
            error=f"Unknown tool: {tool_name}",
        )
    try:
        return tool.handler(blender_context, params or {})
    except Exception as e:
        return ToolResult(
            success=False,
            tool_name=tool_name,
            data={},
            summary="",
            error=str(e),
        )


# ── Phase 3: confirmation gate for write tools ──────────────────────────
# Session-scoped, single-slot (one action staged at a time - staging a new
# one silently replaces whatever was pending, matching how the panel only
# ever shows one confirmation box). Not persisted, same posture as
# ai/conversation.py's session singleton.

_pending_action: Optional[dict] = None


def stage_action(tool_name: str, params: dict) -> str:
    """Stage a write action for confirmation. Returns a human-readable
    preview of what will happen - never executes the tool itself."""
    global _pending_action
    tool = get_tool(tool_name)
    if tool is None:
        _pending_action = None
        return f"Unknown tool: {tool_name}"

    _pending_action = {"tool_name": tool_name, "params": dict(params or {})}
    return f"I will: {tool.description} with {params}. Confirm?"


def confirm_action(blender_context) -> ToolResult:
    """Execute the staged action, if any. Always returns a ToolResult -
    never raises (dispatch() below it already guarantees that)."""
    global _pending_action
    if _pending_action is None:
        return ToolResult(
            success=False,
            tool_name="",
            data={},
            summary="No action staged",
            error="No action pending confirmation",
        )
    action = _pending_action
    _pending_action = None
    return dispatch(action["tool_name"], action["params"], blender_context)


def cancel_action() -> None:
    """Cancel the staged action, if any."""
    global _pending_action
    _pending_action = None


def has_pending_action() -> bool:
    return _pending_action is not None
