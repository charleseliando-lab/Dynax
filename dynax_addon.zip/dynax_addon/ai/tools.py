# ai/tools.py - Phase 2 of the DynaX CAD Agent: the tool registry.
#
# Phase 2 covers READ-ONLY tools only. No handler in this file may call
# bpy.ops, write a Scene/object property, or otherwise change state - same
# discipline as ai/context.py, which this file builds on and does not
# modify. Every handler is wrapped in try/except and always returns a
# ToolResult - never raises - so a bad tool call can never crash the AI
# panel or interrupt clinical work.
#
# Destructive/write tools (mesh repair, geometry generation, export, etc.)
# are explicitly out of scope for Phase 2 - see the architecture
# assessment's safety/confirmation model (read-only tools may auto-execute;
# anything that changes scene state needs a later phase's confirmation
# gate). The `is_destructive` field on Tool exists now so that gate has
# somewhere to hang once those tools are added - no tool registered below
# sets it True.

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Callable, Any, Optional

from .context import collect_context, context_to_dict


@dataclass
class ToolParam:
    name: str
    type: str  # "string"|"float"|"int"|"bool"
    description: str
    required: bool = True
    default: Any = None


@dataclass
class ToolResult:
    success: bool
    tool_name: str
    data: dict
    summary: str
    error: str = ""


@dataclass
class Tool:
    name: str
    description: str
    category: str  # "scene"|"mesh"|"dynax"|"paralink"|"workflow"
    params: list
    handler: Callable
    is_destructive: bool = False
    requires_active_mesh: bool = False
    requires_dynax_workflow: bool = False


# ── Registry ─────────────────────────────────────────────────────────────

TOOL_REGISTRY: dict = {}


def register_tool(tool: Tool) -> None:
    TOOL_REGISTRY[tool.name] = tool


def get_tool(name: str) -> Optional[Tool]:
    return TOOL_REGISTRY.get(name)


def _workflow_is_active(context_dict: dict) -> bool:
    try:
        workflow = ((context_dict or {}).get("dynax") or {}).get("workflow")
        return bool(workflow) and workflow not in ("NONE", "UNKNOWN")
    except Exception:
        return False


def list_tools(category: str = None, context_dict: dict = None) -> list:
    """Returns tools available given the current context, as plain dicts
    (JSON-serialisable, safe to embed in a prompt or show in the panel).
    Filters out tools that require an active mesh when context_dict shows
    none, and tools that require an active DynaX workflow when none is
    active. Passing context_dict=None skips both filters (returns every
    registered tool) - used by callers that only want the full catalogue."""
    try:
        has_mesh = None
        workflow_active = None
        if context_dict is not None:
            has_mesh = (context_dict.get("mesh") is not None)
            workflow_active = _workflow_is_active(context_dict)

        out = []
        for tool in TOOL_REGISTRY.values():
            if category is not None and tool.category != category:
                continue
            if context_dict is not None:
                if tool.requires_active_mesh and not has_mesh:
                    continue
                if tool.requires_dynax_workflow and not workflow_active:
                    continue
            out.append({
                "name": tool.name,
                "description": tool.description,
                "category": tool.category,
                "is_destructive": tool.is_destructive,
                "requires_active_mesh": tool.requires_active_mesh,
                "requires_dynax_workflow": tool.requires_dynax_workflow,
            })
        return out
    except Exception:
        return []


# ── Tool 1: get_scene_summary ───────────────────────────────────────────

def _handle_get_scene_summary(context, params: dict) -> ToolResult:
    try:
        ctx = collect_context(context)
        s = ctx.scene
        data = {
            "object_count": s.object_count,
            "mesh_object_count": s.mesh_object_count,
            "selected_count": s.selected_count,
            "selected_names": s.selected_names,
            "active_object_name": s.active_object_name,
            "all_mesh_names": s.all_mesh_names,
        }
        if s.object_count == 0:
            summary = "The scene is empty — no objects."
        else:
            active = s.active_object_name or "none"
            summary = (
                f"{s.object_count} object(s) in scene "
                f"({s.mesh_object_count} mesh). Active: {active}."
            )
        return ToolResult(True, "get_scene_summary", data, summary)
    except Exception as e:
        return ToolResult(False, "get_scene_summary", {}, "", str(e))


register_tool(Tool(
    name="get_scene_summary",
    description="Get a summary of all objects in the current Blender scene",
    category="scene",
    params=[],
    handler=_handle_get_scene_summary,
))


# ── Tool 2: get_active_object ───────────────────────────────────────────

def _handle_get_active_object(context, params: dict) -> ToolResult:
    try:
        ctx = collect_context(context)
        if ctx.mesh is None:
            return ToolResult(
                False, "get_active_object", {}, "",
                "No active mesh object selected.",
            )
        data = asdict(ctx.mesh)
        summary = (
            f"{ctx.mesh.name}: {ctx.mesh.vertex_count:,} verts, "
            f"{ctx.mesh.face_count:,} faces, "
            f"{'watertight' if ctx.mesh.is_watertight else 'NOT watertight'}."
        )
        return ToolResult(True, "get_active_object", data, summary)
    except Exception as e:
        return ToolResult(False, "get_active_object", {}, "", str(e))


register_tool(Tool(
    name="get_active_object",
    description="Get detailed info about the currently selected/active object",
    category="scene",
    params=[],
    handler=_handle_get_active_object,
    requires_active_mesh=True,
))


# ── Tool 3: inspect_mesh ────────────────────────────────────────────────

def _handle_inspect_mesh(context, params: dict) -> ToolResult:
    try:
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            return ToolResult(
                False, "inspect_mesh", {}, "",
                "No active mesh object selected.",
            )

        import bmesh
        bm = bmesh.new()
        try:
            bm.from_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            open_edges = [e for e in bm.edges if len(e.link_faces) == 1]
            non_manifold_edges = [e for e in bm.edges if len(e.link_faces) > 2]
            loose_verts = [v for v in bm.verts if not v.link_edges]

            # Rough duplicate-face check: two faces sharing the exact same
            # vertex-index set. Cheap, read-only, not a substitute for a
            # real geometry-cleanup tool - just a heads-up count.
            seen = set()
            duplicate_face_count = 0
            for f in bm.faces:
                key = frozenset(v.index for v in f.verts)
                if key in seen:
                    duplicate_face_count += 1
                else:
                    seen.add(key)

            is_watertight = len(open_edges) == 0 and len(non_manifold_edges) == 0

            data = {
                "open_edge_count": len(open_edges),
                "non_manifold_edge_count": len(non_manifold_edges),
                "loose_vertex_count": len(loose_verts),
                "duplicate_face_count": duplicate_face_count,
                "is_watertight": is_watertight,
                "vertex_count": len(bm.verts),
                "face_count": len(bm.faces),
            }
        finally:
            bm.free()

        issues = []
        if data["open_edge_count"]:
            issues.append(f"{data['open_edge_count']} open edge(s)")
        if data["non_manifold_edge_count"]:
            issues.append(f"{data['non_manifold_edge_count']} non-manifold edge(s)")
        if data["loose_vertex_count"]:
            issues.append(f"{data['loose_vertex_count']} loose vertex/vertices")
        if data["duplicate_face_count"]:
            issues.append(f"{data['duplicate_face_count']} duplicate face(s)")

        if issues:
            summary = f"Mesh has {', '.join(issues)}. Recommend repair before printing."
        else:
            summary = "Mesh is clean — no issues found."

        return ToolResult(True, "inspect_mesh", data, summary)
    except Exception as e:
        return ToolResult(False, "inspect_mesh", {}, "", str(e))


register_tool(Tool(
    name="inspect_mesh",
    description=(
        "Inspect a mesh for potential issues — open edges, loose geometry, "
        "non-manifold edges, face count"
    ),
    category="mesh",
    params=[],
    handler=_handle_inspect_mesh,
    requires_active_mesh=True,
))


# ── Tool 4: get_dimensions ──────────────────────────────────────────────

def _handle_get_dimensions(context, params: dict) -> ToolResult:
    try:
        ctx = collect_context(context)
        if ctx.mesh is None:
            return ToolResult(
                False, "get_dimensions", {}, "",
                "No active mesh object selected.",
            )

        x, y, z = ctx.mesh.dimensions_mm
        volume_mm3 = round(x * y * z, 1)

        centroid = ctx.mesh.location
        try:
            obj = context.active_object
            if obj is not None and obj.data is not None and len(obj.data.vertices):
                mat = obj.matrix_world
                verts = obj.data.vertices
                n = len(verts)
                sx = sum((mat @ v.co).x for v in verts) / n
                sy = sum((mat @ v.co).y for v in verts) / n
                sz = sum((mat @ v.co).z for v in verts) / n
                centroid = (round(sx, 1), round(sy, 1), round(sz, 1))
        except Exception:
            pass

        data = {
            "dimensions_mm": (x, y, z),
            "bounding_box_volume_mm3": volume_mm3,
            "centroid": centroid,
        }
        summary = f"{ctx.mesh.name}: {x:g}mm × {y:g}mm × {z:g}mm."
        return ToolResult(True, "get_dimensions", data, summary)
    except Exception as e:
        return ToolResult(False, "get_dimensions", {}, "", str(e))


register_tool(Tool(
    name="get_dimensions",
    description="Get the dimensions of the active object in millimetres",
    category="mesh",
    params=[],
    handler=_handle_get_dimensions,
    requires_active_mesh=True,
))


# ── Tool 5: get_dynax_state ──────────────────────────────────────────────

def _handle_get_dynax_state(context, params: dict) -> ToolResult:
    try:
        ctx = collect_context(context)
        data = asdict(ctx.dynax)
        summary = f"Workflow: {ctx.dynax.workflow}, step: {ctx.dynax.active_step}."
        return ToolResult(True, "get_dynax_state", data, summary)
    except Exception as e:
        return ToolResult(False, "get_dynax_state", {}, "", str(e))


register_tool(Tool(
    name="get_dynax_state",
    description=(
        "Get the current DynaX workflow, device type, step, and design state"
    ),
    category="dynax",
    params=[],
    handler=_handle_get_dynax_state,
))


# ── Tool 6: get_measurements ─────────────────────────────────────────────

def _handle_get_measurements(context, params: dict) -> ToolResult:
    try:
        ctx = collect_context(context)
        data = dict(ctx.dynax.measurements or {})
        # parafly_afo_measurements defaults to the JSON string "[]" - real
        # empty state, not "one field recorded" - context.py wraps that
        # into {"records": []}, so an empty "records" list must be treated
        # the same as no data at all here.
        if list(data.keys()) == ["records"] and not data["records"]:
            data = {}

        try:
            scene = context.scene
            for key in scene.keys():
                if str(key).startswith("dynax_last_measure_"):
                    data[str(key)] = scene[key]
        except Exception:
            pass

        if not data:
            return ToolResult(
                True, "get_measurements", {},
                "No measurements recorded yet",
            )

        return ToolResult(
            True, "get_measurements", data,
            f"{len(data)} measurement field(s) recorded.",
        )
    except Exception as e:
        return ToolResult(False, "get_measurements", {}, "", str(e))


register_tool(Tool(
    name="get_measurements",
    description="Get any clinical measurements recorded in the current DynaX session",
    category="dynax",
    params=[],
    handler=_handle_get_measurements,
    requires_dynax_workflow=True,
))


# ── Tool 7: get_paralink_status ──────────────────────────────────────────

def _handle_get_paralink_status(context, params: dict) -> ToolResult:
    try:
        ctx = collect_context(context)
        data = {
            "paralink_mode": ctx.dynax.paralink_mode,
            "connection_style": ctx.dynax.connection_style,
            "paralink_boundary_offset": ctx.dynax.paralink_boundary_offset,
            "bridge_complete": ctx.dynax.bridge_complete,
            "component_loaded": ctx.dynax.component_loaded,
        }
        if ctx.dynax.bridge_complete:
            summary = "ParaLink/bridge connection is complete."
        elif ctx.dynax.component_loaded:
            summary = (
                f"Component loaded, not yet connected "
                f"({ctx.dynax.paralink_mode} mode)."
            )
        else:
            summary = "No component loaded yet."
        return ToolResult(True, "get_paralink_status", data, summary)
    except Exception as e:
        return ToolResult(False, "get_paralink_status", {}, "", str(e))


register_tool(Tool(
    name="get_paralink_status",
    description=(
        "Get the current ParaLink connection mode, style, boundary offset, "
        "and whether a connection has been made"
    ),
    category="paralink",
    params=[],
    handler=_handle_get_paralink_status,
))


# ── Tool 8: list_available_tools ─────────────────────────────────────────

def _handle_list_available_tools(context, params: dict) -> ToolResult:
    try:
        ctx_dict = context_to_dict(collect_context(context))
        tools = list_tools(context_dict=ctx_dict)
        data = {"tools": tools}
        if not tools:
            summary = "No DynaX AI actions are currently available."
        else:
            names = ", ".join(t["name"] for t in tools)
            summary = f"{len(tools)} action(s) available: {names}."
        return ToolResult(True, "list_available_tools", data, summary)
    except Exception as e:
        return ToolResult(False, "list_available_tools", {}, "", str(e))


register_tool(Tool(
    name="list_available_tools",
    description="List what DynaX AI can currently do given the scene state",
    category="workflow",
    params=[],
    handler=_handle_list_available_tools,
))


# ── Phase 3 write tools ──────────────────────────────────────────────────
# Every handler below writes AT MOST one Scene property (or, for
# navigate_to_step, calls the one navigation-only operator this file is
# allowed to call - see that tool's own comment). None create, delete or
# modify mesh data, objects, or any bpy.data.* datablock. is_destructive
# stays False on all four per spec - a property write here undoes as
# trivially as any other Blender property change, unlike a geometry
# operation. Confirmation is enforced by the caller via
# dispatcher.stage_action()/confirm_action(), not by anything in this file
# - these handlers are the same "just execute" shape as the read-only
# tools above; they rely on never being called directly except through the
# confirm step.

_PARALINK_MODES = ("AUTO", "GUIDED", "SEMI", "MANUAL")
_CONNECTION_STYLES = ("SMOOTH", "STRUCTURAL", "HYBRID")


def _handle_set_paralink_mode(context, params: dict) -> ToolResult:
    try:
        mode = str(params.get("mode", "")).upper().strip()
        if mode not in _PARALINK_MODES:
            return ToolResult(
                False, "set_paralink_mode", {}, "",
                f"Invalid mode '{params.get('mode')}'. Must be one of: "
                f"{', '.join(_PARALINK_MODES)}.",
            )
        context.scene.dynax_paralink_mode = mode
        return ToolResult(
            True, "set_paralink_mode", {"mode": mode},
            f"ParaLink mode set to {mode}",
        )
    except Exception as e:
        return ToolResult(False, "set_paralink_mode", {}, "", str(e))


register_tool(Tool(
    name="set_paralink_mode",
    description="Set the ParaLink connection mode (AUTO/GUIDED/SEMI/MANUAL)",
    category="paralink",
    params=[
        ToolParam(
            name="mode", type="string",
            description="One of: AUTO, GUIDED, SEMI, MANUAL", required=True,
        ),
    ],
    handler=_handle_set_paralink_mode,
    is_destructive=False,
))


def _handle_set_connection_style(context, params: dict) -> ToolResult:
    try:
        style = str(params.get("style", "")).upper().strip()
        if style not in _CONNECTION_STYLES:
            return ToolResult(
                False, "set_connection_style", {}, "",
                f"Invalid style '{params.get('style')}'. Must be one of: "
                f"{', '.join(_CONNECTION_STYLES)}.",
            )
        context.scene.dynax_paralink_style = style
        return ToolResult(
            True, "set_connection_style", {"style": style},
            f"Connection style set to {style}",
        )
    except Exception as e:
        return ToolResult(False, "set_connection_style", {}, "", str(e))


register_tool(Tool(
    name="set_connection_style",
    description="Set the ParaLink connection style (SMOOTH/STRUCTURAL/HYBRID)",
    category="paralink",
    params=[
        ToolParam(
            name="style", type="string",
            description="One of: SMOOTH, STRUCTURAL, HYBRID", required=True,
        ),
    ],
    handler=_handle_set_connection_style,
    is_destructive=False,
))


def _handle_set_boundary_offset(context, params: dict) -> ToolResult:
    try:
        try:
            value = float(params.get("offset_mm"))
        except (TypeError, ValueError):
            return ToolResult(
                False, "set_boundary_offset", {}, "",
                f"offset_mm must be a number, got {params.get('offset_mm')!r}.",
            )
        clamped = max(-200.0, min(200.0, value))
        context.scene.dynax_paralink_boundary_offset = clamped
        # dynax_paralink_boundary_offset is itself registered with a
        # -50..50 RNA min/max (see __init__.py) - Blender silently
        # re-clamps to that narrower range on assignment. The 200mm clamp
        # here is the spec's requested tool-level bound; the ACTUAL
        # effective range a caller will observe is -50..50, not -200..200.
        # Not something this file should change - flagged, not fixed.
        actual = context.scene.dynax_paralink_boundary_offset
        direction = "up" if actual > 0 else ("down" if actual < 0 else "auto")
        return ToolResult(
            True, "set_boundary_offset", {"offset_mm": actual},
            f"Boundary offset set to {actual:g}mm "
            f"(moves connection zone {direction} the socket)",
        )
    except Exception as e:
        return ToolResult(False, "set_boundary_offset", {}, "", str(e))


register_tool(Tool(
    name="set_boundary_offset",
    description=(
        "Move the ParaLink connection boundary up or down the socket in "
        "mm. Positive = up, negative = down, 0 = auto"
    ),
    category="paralink",
    params=[
        ToolParam(
            name="offset_mm", type="float",
            description="Offset in mm. Range -200 to +200.", required=True,
        ),
    ],
    handler=_handle_set_boundary_offset,
    is_destructive=False,
))


def _handle_navigate_to_step(context, params: dict) -> ToolResult:
    try:
        step = str(params.get("step", "")).strip()
        try:
            from ..properties.dynax_properties import get_step_ids
            valid_steps = get_step_ids()
        except Exception:
            valid_steps = []

        if not valid_steps or step not in valid_steps:
            return ToolResult(
                False, "navigate_to_step", {}, "",
                f"Invalid step '{step}'. Must be one of: "
                f"{', '.join(valid_steps) if valid_steps else 'unknown (step list unavailable)'}.",
            )

        import bpy
        # The ONE bpy.ops call allowed in Phase 3 - navigation only, no
        # geometry modification. The real operator's property is
        # `step_id`, not `step` (verified against
        # operators/workflow_nav.py's DynaxGotoStep - the spec's own
        # pseudocode used the wrong kwarg name).
        bpy.ops.dynax.goto_step(step_id=step)
        return ToolResult(
            True, "navigate_to_step", {"step": step},
            f"Navigated to {step} step",
        )
    except Exception as e:
        return ToolResult(False, "navigate_to_step", {}, "", str(e))


register_tool(Tool(
    name="navigate_to_step",
    description="Navigate the DynaX Creator workflow to a specific step",
    category="workflow",
    params=[
        ToolParam(
            name="step", type="string",
            description=(
                "Step name e.g. import, cleanup, align, measure, sculpt, "
                "trimline, thickness, components, export"
            ),
            required=True,
        ),
    ],
    handler=_handle_navigate_to_step,
    is_destructive=False,
))
