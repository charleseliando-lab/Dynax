# properties/dynax_properties.py - DynaX v1.3

import math
import os
import bpy
from bpy.props import (
    BoolProperty, EnumProperty, FloatProperty,
    IntProperty, StringProperty, CollectionProperty
)
from ..operators.component_bridge import _get_components_folder

# ── Select & Transform session flag (v1.20.8) ─────────────────────────────────
#
# `dynax_region_edit_active` marks an open Select & Transform session. The panel
# reads it so its gating never depends on a transient Blender mode (see
# panels/dynax_panel.py's sculpt step and operators/select_tools.py).
#
# It is deliberately an ID custom property (scene["dynax_region_edit_active"])
# and NOT a registered Scene RNA property:
#   * it matches the existing convention for DynaX workflow state
#     (dynax_selection_count, dynax_trim_stage, dynax_cut_done, dynax_studio_*),
#   * it needs no registration lifecycle, so it cannot contribute to the
#     partially-registered-property draw crashes noted in STABILITY_REPORT,
#   * it round-trips through save/reload for free.
# The key is owned by operators/select_tools.py (REGION_ACTIVE_KEY); this note
# is the single place documenting why it isn't declared below.


# ── Component library discovery (v1.20.8) ─────────────────────────────────────
#
# The browser used to list one flat folder, so it showed only whatever sat in
# `dynax_addon/components/` - in every shipped tree that is exactly one file,
# SOCKET_COMPONENT.stl. That is the whole reason "only socket components" were
# visible: not a filter bug, not a hidden category, just one asset.
#
# Categories are now derived from SUBFOLDERS of the components directory: a
# subfolder IS a category, root-level files fall under "General". This invents
# nothing - a category exists only if a folder for it exists - and adding a
# category is a content task (drop in a folder of parts), not a code change.
#
# Supported formats stay .stl and .blend (the loader dispatches on extension).

COMPONENT_FORMATS = ('.stl', '.blend')
GENERAL_CATEGORY = "General"

# Blender's EnumProperty can corrupt/crash if the item strings returned by a
# callback are garbage-collected, so keep a module reference to the most recent
# list.
_COMPONENT_ITEMS_CACHE = []


def _is_component_file(name):
    return name.lower().endswith(COMPONENT_FORMATS)


def _pretty_name(filename):
    return os.path.splitext(filename)[0].replace('_', ' ').title()


def discover_component_categories(folder=None):
    """Return {category_name: [relative_path, ...]} for the component library.

    A subfolder of the components directory is a category; files directly in the
    root are listed under "General". Values are paths RELATIVE to the components
    folder (e.g. "feet/sach_foot.stl"), so the loader can resolve them without
    guessing which category a file came from.

    Only categories that actually contain a supported asset are returned - an
    empty folder is not advertised as a category with nothing in it. Returns {}
    when the library folder is missing entirely. Never raises: an unreadable
    directory is reported as absent rather than taking down the panel draw.
    """
    folder = folder or _get_components_folder()
    categories = {}
    try:
        if not os.path.isdir(folder):
            return {}
        root_files = sorted(
            name for name in os.listdir(folder)
            if _is_component_file(name)
            and os.path.isfile(os.path.join(folder, name))
        )
        if root_files:
            categories[GENERAL_CATEGORY] = list(root_files)

        for entry in sorted(os.listdir(folder)):
            sub = os.path.join(folder, entry)
            if not os.path.isdir(sub):
                continue
            files = sorted(
                f"{entry}/{name}" for name in os.listdir(sub)
                if _is_component_file(name)
                and os.path.isfile(os.path.join(sub, name))
            )
            if files:      # an empty folder is not a category
                categories[entry.replace('_', ' ').title()] = files
    except OSError:
        return {}
    return categories


def _component_items(self, context):
    global _COMPONENT_ITEMS_CACHE
    categories = discover_component_categories()
    if not categories:
        _COMPONENT_ITEMS_CACHE = [('NONE', 'No components found', '')]
        return _COMPONENT_ITEMS_CACHE

    items = []
    multiple = len(categories) > 1
    for category, files in categories.items():
        for relative in files:
            label = _pretty_name(os.path.basename(relative))
            # Only prefix with the category when there is more than one, so the
            # single-category library (today's reality) reads unchanged.
            items.append((
                relative,
                f"{category} — {label}" if multiple else label,
                f"{category} component: {os.path.basename(relative)}",
            ))
    _COMPONENT_ITEMS_CACHE = items
    return _COMPONENT_ITEMS_CACHE


def _ring_height_update(self, context):
    """Live-update the active ring position when the slider moves"""
    try:
        from ..operators.circumference import update_active_ring
        update_active_ring(context, self.ring_height_pct)
    except Exception:
        pass


def _sculpt_brush_update(self, context):
    """Live-apply the sculpt Radius/Strength sliders to the active brush."""
    try:
        from ..operators.sculpt_brushes import _apply_radius_strength
        _apply_radius_strength(context)
    except Exception:
        pass


def _select_brush_radius_update(self, context):
    """Live-apply the select-paint brush radius slider to the active circle
    select tool, so dragging the slider updates the on-screen circle without
    needing to re-click the Paint button."""
    try:
        tool = context.workspace.tools.from_space_view3d_mode(context.mode, create=False)
        if tool and tool.idname == 'builtin.select_circle':
            op_props = tool.operator_properties("view3d.select_circle")
            if op_props:
                op_props.radius = self.select_brush_radius
    except Exception:
        pass


def _smooth_brush_update(self, context):
    """Live-apply the manual-smooth Radius/Strength sliders to the active brush."""
    try:
        from ..operators.sculpt_helpers import _set_brush_radius_strength
        _set_brush_radius_strength(
            context,
            radius=self.smooth_brush_radius,
            strength=self.smooth_brush_strength,
        )
    except Exception:
        pass



# ── Prosthetist workflow steps ─────────────────────────────────────────────────
PROSTHETIST_STEPS = [
    ("import",      "Import scan",         "Import and scale your 3D scan"),
    ("cleanup",     "Clean up mesh",       "Fix holes and smooth scan artifacts"),
    ("align",       "Align & rotate",      "Orient the scan and place landmark lines"),
    ("crop",        "Crop",                "Trim away unwanted geometry with a box"),
    ("measure",     "Measure",             "Circumference and dimension measurements"),
    ("sculpt",      "Sculpt & modify",     "Shape the socket using sculpt tools"),
    ("trimline",    "Trim line",           "Draw and cut the trim line boundary"),
    ("thickness",   "Add thickness",       "Add wall thickness for 3D printing"),
    ("components",  "Components",          "Attach adapters, pylons and connectors"),
    ("export",      "Export STL",          "Validate and export for 3D printing"),
]

# ── Orthotist workflow steps (placeholder for next version) ───────────────────
ORTHOTIST_STEPS = [
    ("import",      "Import scan",         "Import and scale your 3D scan"),
    ("cleanup",     "Clean up mesh",       "Fix holes and smooth scan artifacts"),
    ("align",       "Align & landmarks",   "Orient and place anatomical landmarks"),
    ("crop",        "Crop",                "Trim away unwanted geometry with a box"),
    ("measure",     "Measure",             "Key measurements for orthosis fit"),
    ("sculpt",      "Modify shape",        "Adjust and refine the shape"),
    ("trimline",    "Trim line",           "Define orthosis boundaries"),
    ("thickness",   "Add thickness",       "Add shell thickness"),
    ("export",      "Export STL",          "Export for printing"),
]

PROSTHETIST_STEP_IDS = [s[0] for s in PROSTHETIST_STEPS]
ORTHOTIST_STEP_IDS   = [s[0] for s in ORTHOTIST_STEPS]


def get_active_steps(role=None):
    # Role selection was removed in v2.6.8 — all users get the full workflow.
    return PROSTHETIST_STEPS

def get_step_ids(role=None):
    return PROSTHETIST_STEP_IDS


class DynaxProperties(bpy.types.PropertyGroup):

    # Role selection and device type were removed in v2.6.8 — the panel shows the
    # full workflow to every user with no gating.

    # ── Top-level navigation (v1.8.0: three-layer Start Menu → New Case →
    # Workflow; v1.14.0: New Case's "ParaForge" choice now opens a ParaForge sub-menu
    # (ParaForm / ParaFly / Load Saved Project) instead of going straight into
    # ParaForm, and every active workflow is session-locked — its shared back
    # button returns all the way to the Start Menu, not to New Case, so switching
    # workflows always requires re-entering via the Start Menu) ─────────────────
    dynax_mode: EnumProperty(
        name="DynaX mode",
        items=[
            ('NONE',      "Start Menu", "Front screen — no workflow chosen yet"),
            ('NEW_CASE',  "New Case",   "Choose Creator or ParaForge"),
            ('PARAFORGE_MENU', "ParaForge", "Choose ParaForm or ParaFly"),
            ('CREATOR',   "Creator",    "Scan-based patient fitting workflow"),
            ('PARAFORGE', "ParaForm",   "Parametric base-template design (Beta)"),
            ('PARAFORGE_ZONES', "ParaFly",
             "Scan-based clinical zone parametric fitting (Beta)"),
            ('PARAMOLD', "ParaMold",
             "Two-part silicone finger prosthesis mold design"),
        ],
        default='NONE',
    )

    # ── Workflow step tracker ─────────────────────────────────────────────────
    active_step: EnumProperty(
        name="Active step",
        items=[(s[0], s[1], s[2]) for s in PROSTHETIST_STEPS],
        default='import',
    )

    # ── Settings panel + language (v1.7.0) ────────────────────────────────────
    dynax_showing_settings: BoolProperty(
        name="Showing settings",
        description="Internal: whether the Settings panel is currently open",
        default=False,
    )
    dynax_ui_language: EnumProperty(
        name="Language",
        description="DynaX interface language",
        items=[
            ('en_US', 'English', ''),
            ('fr_FR', 'Français', ''),
            ('de_DE', 'Deutsch', ''),
            # Blender's own language enum uses ar_EG for Arabic (there is no
            # ar_SA identifier) - verified against this Blender build's
            # PreferencesView.language enum. Must match the locale key
            # registered in utils/translations.py exactly, or the Arabic
            # translations silently never apply.
            ('ar_EG', 'العربية', ''),
        ],
        default='en_US',
    )

    # ── Import ────────────────────────────────────────────────────────────────
    import_units: EnumProperty(
        name="Units",
        description="STL source unit. DynaX imports into mm-space "
                    "(scale_length=0.001), so MM is a direct passthrough and "
                    "CM/M/IN are converted up into millimetres.",
        items=[
            ('AUTO', "Auto",        "Try to detect scale from model size"),
            ('MM',   "Millimeters", "STL units are millimeters (most common)"),
            ('CM',   "Centimeters", "STL units are centimeters"),
            ('M',    "Meters",      "STL units are meters"),
            ('IN',   "Inches",      "STL units are inches"),
        ],
        default='AUTO',
    )

    import_auto_scale: BoolProperty(name="Auto-scale large models", default=True)
    import_auto_scale_threshold: FloatProperty(name="Auto-scale threshold (mm)", default=10000.0, min=1.0, max=100000.0)
    import_auto_scale_up: BoolProperty(name="Auto-scale up small models", default=True)
    import_min_visible_mm: FloatProperty(name="Min visible size (mm)", default=100.0, min=1.0, max=100000.0)
    scale_target_size_mm: FloatProperty(name="Scale target (mm)", default=400.0, min=1.0, max=100000.0)

    # ── Smooth ────────────────────────────────────────────────────────────────
    smooth_factor: FloatProperty(name="Smooth factor", default=0.5, min=0.0, max=1.0)
    smooth_iterations: IntProperty(name="Iterations", default=5, min=1, max=100)
    smooth_angle: FloatProperty(name="Smooth angle", default=math.radians(35.0), min=0.0, max=math.radians(180.0), subtype='ANGLE')
    weld_threshold_mm: FloatProperty(name="Weld threshold (mm)", default=0.1, min=0.0, max=5.0)
    apply_to_selected: BoolProperty(name="Apply to selected", default=True)
    skip_if_smoothed: BoolProperty(name="Skip if already smoothed", default=False)
    protect_caps: BoolProperty(name="Protect cut caps", default=True)
    cap_angle: FloatProperty(name="Cap angle", default=math.radians(6.0), min=0.0, max=math.radians(30.0), subtype='ANGLE')

    # ── Slice / crop ──────────────────────────────────────────────────────────
    slice_keep_side: EnumProperty(
        name="Keep side",
        items=[
            ('BOTH',  "Keep both",  "Keep both halves"),
            ('INNER', "Keep inner", "Remove the side facing the plane normal"),
            ('OUTER', "Keep outer", "Remove the opposite side"),
        ],
        default='OUTER',
    )

    # ── Boolean / join ────────────────────────────────────────────────────────
    bool_apply_transforms: BoolProperty(name="Apply transforms first", default=True)
    bool_delete_operands: BoolProperty(name="Delete operands after join", default=True)

    # ── Thickness ─────────────────────────────────────────────────────────────
    solidify_thickness_mm: FloatProperty(name="Thickness (mm)", default=4.0, min=0.5, max=20.0)
    offset_direction: EnumProperty(
        name="Direction",
        items=[
            ('CENTER', "Centered", "Equally on both sides"),
            ('OUT',    "Outward",  "Outward only"),
            ('IN',     "Inward",   "Inward only"),
        ],
        default='OUT',
    )
    offset_cap_rim: BoolProperty(name="Cap open edges", default=True)
    offset_apply_scale: BoolProperty(name="Apply scale before offset", default=True)

    # ── Extrude ───────────────────────────────────────────────────────────────
    extrude_distance_mm: FloatProperty(name="Distance (mm)", default=10.0, min=-50.0, max=50.0)
    extrude_direction: EnumProperty(
        name="Direction",
        items=[
            ('NORMAL', "Normal", "Along face normals"),
            ('X', "Axis X", ""), ('Y', "Axis Y", ""), ('Z', "Axis Z", ""),
        ],
        default='NORMAL',
    )

    # ── Fuse voxel ────────────────────────────────────────────────────────────
    fuse_voxel_size: FloatProperty(name="Voxel size (mm)", default=2.0, min=0.1, max=50.0)
    fuse_auto_expand: BoolProperty(name="Auto-expand to bridge gaps", default=True)

    # ── Export ────────────────────────────────────────────────────────────────
    export_filename: StringProperty(
        name="File Name",
        description="Name for the exported STL file (no extension needed)",
        default="DynaX_Export",
    )
    apply_solidify_on_export: BoolProperty(name="Apply solidify on export", default=False)
    export_apply_modifiers: BoolProperty(name="Apply all modifiers on export", default=True)
    export_validate_mesh: BoolProperty(name="Validate before export", default=True)
    export_scale_to_mm: BoolProperty(name="Export in millimeters", default=True,
        description="DynaX works in mm-space, so the geometry is already real "
                    "millimetres. Leave ON for slicers/medical STL (raw mm). "
                    "Turn OFF only for a legacy metre-scale STL (x0.001).")

    # ── Material / print-cost estimate (v1.12.0) ──────────────────────────────
    material_density_g_cm3: FloatProperty(
        name="Material Density (g/cm³)",
        description="Density of the print material (PLA ≈1.24, PETG ≈1.27, "
                    "ABS ≈1.04, Nylon ≈1.14)",
        default=1.24, min=0.5, max=3.0,
    )
    material_cost_per_kg: FloatProperty(
        name="Material Cost (per kg)",
        description="Cost of filament per kilogram, in your local currency",
        default=15.0, min=0.0, max=1000.0,
    )
    material_currency_symbol: StringProperty(
        name="Currency Symbol", default="₦",
    )
    print_infill_percent: FloatProperty(
        name="Estimated Infill %",
        description="Approximate infill percentage for the estimate (solid "
                    "sockets are often near 100%; adjust if using partial infill)",
        default=100.0, min=5.0, max=100.0,
    )

    # ── Trimline ──────────────────────────────────────────────────────────────
    trimline_keep_top: BoolProperty(
        name="Keep proximal (top)",
        default=True,
        description="Keep the top/proximal portion after cutting",
    )

    # ── Components ────────────────────────────────────────────────────────────
    selected_component: EnumProperty(
        name="Component",
        description="Choose a component from the DynaX library",
        items=_component_items,
    )
    component_category: EnumProperty(
        name="Category",
        items=[
            ('PROSTHETIC', "Prosthetic", "Adapters, pylons, connectors, feet"),
            ('ORTHOTIC',   "Orthotic",   "Hinges, straps, pads, upright bars"),
        ],
        default='PROSTHETIC',
    )
    component_filepath: StringProperty(
        name="Component STL",
        description="Path to a component STL file to import",
        subtype='FILE_PATH',
    )
    bridge_delete_original_faces: BoolProperty(
        name="Replace faces at bridge",
        description="If ON, deletes the selected socket/component faces before "
                    "bridging (the bridge replaces them). If OFF, the bridge is "
                    "added alongside the existing faces - thicker, more solid, "
                    "recommended for FDM",
        default=False,
    )

    # ── Sculpt / push-pull ────────────────────────────────────────────────────
    pushpull_amount_mm: bpy.props.FloatProperty(
        name="Amount (mm)", default=3.0, min=0.1, max=50.0,
    )
    pushpull_circular: bpy.props.BoolProperty(
        name="Circular falloff", default=True,
    )
    selection_color: bpy.props.FloatVectorProperty(
        name="Selection color",
        subtype='COLOR',
        default=(0.0, 1.0, 0.0),
        min=0.0, max=1.0,
        description="Color of the selection/mask overlay",
    )

    # ── UI progress bar display ───────────────────────────────────────────────
    progress_display: bpy.props.FloatProperty(
        name="Progress",
        default=0.0, min=0.0, max=100.0,
        subtype='PERCENTAGE',
    )

    # ── Manual smooth brush controls ──────────────────────────────────────────
    smooth_brush_radius: bpy.props.IntProperty(
        name="Radius (px)", default=50, min=1, max=500,
        update=_smooth_brush_update,
    )
    smooth_brush_strength: bpy.props.FloatProperty(
        name="Strength", default=0.5, min=0.0, max=1.0,
        update=_smooth_brush_update,
    )

    # ── Quad remesh (Cleanup step) ────────────────────────────────────────────
    quad_remesh_target_faces: bpy.props.IntProperty(
        name="Target Faces", default=8000, min=500, max=50000,
    )
    quad_remesh_preserve_boundary: bpy.props.BoolProperty(
        name="Preserve Boundary", default=True,
    )

    # ── Auto Remesh (Cleanup step 1, operators/auto_remesh.py) ─────────────────
    # Auto Remesh reduces density via Decimate (ratio = target_faces /
    # current_faces), which hits a face-count target directly and
    # deterministically — so the manual override is a target FACE COUNT, not
    # a voxel size. 0 = auto (use the selected detail preset's target).
    dynax_remesh_target_faces: bpy.props.IntProperty(
        name="Target Faces",
        description="Exact face count to reduce to. 0 = use the selected "
                     "detail preset (Low/Medium/High).",
        default=0, min=0, max=200000,
    )

    # ── Height-band vertex groups (developer-only re-rigging tool) ────────────
    height_band_count: bpy.props.IntProperty(
        name="Number of Bands", default=5, min=2, max=10,
    )
    height_band_blend_mm: bpy.props.FloatProperty(
        name="Blend Zone (mm)", default=20.0, min=0.0, max=100.0,
    )

    # Developer Tools gate — hides internal/re-rigging tools (e.g. Phase-1
    # height-band creation) from the clinician-facing UI. OFF by default.
    show_dev_tools: bpy.props.BoolProperty(
        name="Developer Tools",
        description="Show internal tools used to re-rig templates. Not for clinical use.",
        default=False,
    )

    # ── Ring gizmo position (live slider) ─────────────────────────────────────
    ring_height_pct: bpy.props.FloatProperty(
        name="Ring height (%)",
        description="Position of the active circumference ring along the scan",
        default=50.0, min=1.0, max=99.0,
        update=lambda self, ctx: _ring_height_update(self, ctx),
    )

    # ── Numeric alignment (uFit style) ────────────────────────────────────────
    align_flexion: bpy.props.FloatProperty(
        name="Flexion/Extension", default=0.0, min=-45.0, max=45.0,
        description="Tilt forward (+) or backward (-) in degrees",
    )
    align_abduction: bpy.props.FloatProperty(
        name="Adduction/Abduction", default=0.0, min=-45.0, max=45.0,
        description="Tilt left (-) or right (+) in degrees",
    )
    align_rotation: bpy.props.FloatProperty(
        name="Rotation", default=0.0, min=-180.0, max=180.0,
        description="Spin around vertical axis in degrees",
    )

    # ── Region transform mode ─────────────────────────────────────────────────
    region_transform_mode: bpy.props.EnumProperty(
        name="Transform mode",
        items=[
            ('RIGID', "Rigid",      "Only the selected region moves; hard edge at boundary"),
            ('SOFT',  "Soft blend", "Surrounding area follows gradually (proportional)"),
        ],
        default='SOFT',
    )

    # ── Select-through toggle — OFF by default (front faces only) ──────────────
    selection_through: bpy.props.BoolProperty(
        name="Select through",
        description="Select vertices on the far side too (off = only the side facing you)",
        default=False,
    )

    # ── Circle/paint select brush radius — exposed in DynaX panel (v2.6.10) ────
    select_brush_radius: bpy.props.IntProperty(
        name="Brush Radius",
        description="Radius of the circle/paint selection brush",
        default=40, min=5, max=500,
        update=_select_brush_radius_update,
    )

    # ── Sculpt brush controls (WASP Med style) ────────────────────────────────
    brush_radius: bpy.props.IntProperty(
        name="Radius (px)", default=50, min=1, max=500,
        update=_sculpt_brush_update,
    )
    brush_strength: bpy.props.FloatProperty(
        name="Strength", default=0.5, min=0.0, max=1.0,
        update=_sculpt_brush_update,
    )

    # ── White viewport theme toggle ───────────────────────────────────────────
    white_viewport: bpy.props.BoolProperty(
        name="White viewport",
        description="Use a white 3D viewport background while using DynaX",
        default=True,
    )
