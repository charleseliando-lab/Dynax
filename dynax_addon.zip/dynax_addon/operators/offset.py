# operators/offset.py - Offset (Solidify) tools

import bpy
import bmesh
from bpy.types import Operator


def _mm_to_blender(val_mm: float) -> float:
    """In mm-space scenes (scale_length=0.001, set at import) 1 Blender unit = 1 mm,
    so a thickness in millimetres is passed straight to the Solidify modifier with
    no conversion: 4 mm -> mod.thickness = 4.0. This is the WASP / Option A model."""
    return val_mm


def _clean_for_solidify(context, obj, dist=0.1):  # 0.1 mm (mm-space, was 0.0001 m)
    """Merge-by-distance + recalc normals + dissolve degenerate geometry before
    Solidify.

    A freshly cut mesh (trimline boolean, knife, etc.) typically has near-
    duplicate vertices, zero-area slivers, and inconsistent normals along the
    seam; Solidify offsets every vertex along its normal, so degenerate edges
    and flipped normals there are exactly what produce the long
    self-intersecting "spikes"/offshoots after baking. Cleaning thoroughly
    first removes the cause instead of the symptom.
    """
    was_object_mode = context.mode == 'OBJECT'
    if not was_object_mode:
        bpy.ops.object.mode_set(mode='OBJECT')
    prev_active = context.view_layer.objects.active
    context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')
    bm = bmesh.from_edit_mesh(obj.data)

    # 1. Merge near-duplicate verts (the seam from a recent cut/separate).
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=dist)

    # 2. Remove zero-area / degenerate faces that have no consistent normal
    #    to recalc against — these are the most common source of a single
    #    vertex shooting off in a wild direction after Solidify.
    bmesh.ops.dissolve_degenerate(bm, dist=dist, edges=bm.edges[:])

    # 3. Recalculate face normals consistently across the whole shell.
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])

    bmesh.update_edit_mesh(obj.data)
    bpy.ops.object.mode_set(mode='OBJECT')
    if prev_active:
        context.view_layer.objects.active = prev_active


class OffsetAddUpdate(Operator):
    """Add or update a Solidify modifier for thickness"""
    bl_idname = "dynax.offset_add_update"
    bl_label = "Add/Update Offset"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = getattr(context.scene, "dynax_props", None)
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a Mesh object first")
            return {'CANCELLED'}

        thickness_mm = props.solidify_thickness_mm if props else 4.0
        thickness_blender = _mm_to_blender(thickness_mm)
        direction = props.offset_direction if props else 'CENTER'
        cap_rim = props.offset_cap_rim if props else True

        # Guard: DynaX operates in mm-space (scale_length=0.001, set at import).
        # If the scene is still in metre-space the modifier will receive 4.0
        # Blender-metres instead of 4.0 mm — 1000× too thick. Warn and let the
        # user re-import via DynaX rather than silently producing wrong geometry.
        scene_scale = context.scene.unit_settings.scale_length
        if abs(scene_scale - 0.001) > 1e-6:
            self.report({'WARNING'},
                "Scene is NOT in mm-space (scale_length is not 0.001). "
                "Please import your STL using DynaX → Import STL to set up "
                f"units correctly. Thickness may be wrong. (scale={scene_scale:.6f})"
            )

        # Pre-clean the cut mesh - removes the doubles/bad normals along a
        # trimline seam that otherwise turn into spikes once Solidify offsets
        # every vertex along its (currently wrong) normal.
        _clean_for_solidify(context, obj)

        mod = obj.modifiers.get("DYNAX_SOLIDIFY")
        if not mod:
            mod = obj.modifiers.new(name="DYNAX_SOLIDIFY", type='SOLIDIFY')

        # Scale is baked once at import and must NOT be re-applied here.
        # A second transform_apply corrupts the modifier's unit interpretation
        # in mm-space scenes and produces wrong thickness.
        mod.thickness = thickness_blender
        # Solidify offset: -1 inward, 0 centered, 1 outward.
        if direction == 'OUT':
            mod.offset = 1.0
        elif direction == 'IN':
            mod.offset = -1.0
        else:
            mod.offset = 0.0
        mod.use_even_offset = True           # prevents pinching on curves
        mod.use_quality_normals = True       # prevents flipped normals
        mod.use_rim = cap_rim                # caps the open boundary edge
        mod.use_rim_only = False

        # Simple mode (Blender's default EXTRUDE). The earlier NON_MANIFOLD
        # ("Complex") mode produced bad geometry on organic scan shells - notably
        # the paint-separated DynaX_Selected part. The rim pre-clean above
        # (_clean_for_solidify) plus the cut's own rim smoothing already remove
        # the doubles/flipped normals that originally motivated NON_MANIFOLD, so
        # Simple is now both cleaner on organic meshes and spike-free. Set it
        # explicitly so updating a previously-NON_MANIFOLD modifier reverts it.
        if hasattr(mod, 'solidify_mode'):
            mod.solidify_mode = 'EXTRUDE'

        self.report({'INFO'}, f"Offset set to {thickness_mm:.2f} mm")
        return {'FINISHED'}


class OffsetApply(Operator):
    """Apply the Solidify modifier"""
    bl_idname = "dynax.offset_apply"
    bl_label = "Apply Offset"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a Mesh object first")
            return {'CANCELLED'}

        mod = obj.modifiers.get("DYNAX_SOLIDIFY")
        already_baked = obj.get("dynax_thickness_baked", False)

        if not mod:
            # Seamless: if no modifier yet, create one from current settings
            # so the user can just click Bake directly.
            _clean_for_solidify(context, obj)
            props = getattr(context.scene, "dynax_props", None)
            thickness_mm = props.solidify_thickness_mm if props else 4.0
            direction = props.offset_direction if props else 'CENTER'
            cap_rim = props.offset_cap_rim if props else True
            mod = obj.modifiers.new(name="DYNAX_SOLIDIFY", type='SOLIDIFY')
            mod.thickness = _mm_to_blender(thickness_mm)
            mod.offset = 1.0 if direction == 'OUT' else (-1.0 if direction == 'IN' else 0.0)
            mod.use_even_offset = True
            mod.use_quality_normals = True
            mod.use_rim = cap_rim
            mod.use_rim_only = False
            # Simple mode (default EXTRUDE) - see OffsetAddUpdate for why.
            if hasattr(mod, 'solidify_mode'):
                mod.solidify_mode = 'EXTRUDE'

            # Thickness was already baked once before — clicking Bake again
            # with no live modifier means a NEW Solidify is about to be
            # stacked on top of the already-thickened mesh, adding MORE
            # thickness rather than re-applying the same value. This is
            # intentional (lets a user "add more" if the first pass wasn't
            # enough) but must be visible, not silent.
            if already_baked:
                self.report({'WARNING'},
                    f"Adding {thickness_mm:.1f} mm MORE on top of the already-baked "
                    "wall (stacks, doesn't replace). Use Undo if you wanted to redo "
                    "the original thickness instead.")

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        context.view_layer.objects.active = obj
        try:
            area = next((a for a in context.window.screen.areas if a.type == 'VIEW_3D'), None)
            region = None
            if area:
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if area and region:
                with context.temp_override(
                    area=area,
                    region=region,
                    active_object=obj,
                    object=obj,
                ):
                    result = bpy.ops.object.modifier_apply(modifier=mod.name)
            else:
                result = bpy.ops.object.modifier_apply(modifier=mod.name)
            if 'CANCELLED' in result:
                self.report({'ERROR'}, "Failed to apply: modifier_apply cancelled")
                return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to apply: {e}")
            return {'CANCELLED'}

        # Solidify can leave near-duplicate verts/bad normals at the rim caps;
        # clean those up so shading and any later booleans don't show spikes.
        _clean_for_solidify(context, obj)

        obj["dynax_thickness_baked"] = True
        self.report({'INFO'}, "Offset applied")
        return {'FINISHED'}


class OffsetRemove(Operator):
    """Remove the Solidify modifier"""
    bl_idname = "dynax.offset_remove"
    bl_label = "Remove Offset"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a Mesh object first")
            return {'CANCELLED'}

        mod = obj.modifiers.get("DYNAX_SOLIDIFY")
        if not mod:
            self.report({'ERROR'}, "No DYNAX_SOLIDIFY modifier found")
            return {'CANCELLED'}

        obj.modifiers.remove(mod)
        self.report({'INFO'}, "Offset removed")
        return {'FINISHED'}
