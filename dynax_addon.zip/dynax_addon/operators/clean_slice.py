# operators/clean_slice.py - Cleanup after slicing

import bpy
import bmesh
from bpy.types import Operator


class CleanSlice(Operator):
    """Clean non-manifold slice artifacts before smoothing"""
    bl_idname = "dynax.clean_slice"
    bl_label = "Clean Slice"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a Mesh object first")
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        bpy.ops.object.mode_set(mode='EDIT')
        # select_non_manifold() requires vertex or edge select mode — Blender's
        # select mode is sticky across operators, and our paint-select tools
        # (v2.6.10) switched to face-select mode for a cleaner highlight. Force
        # vertex mode here so this operator doesn't crash with
        # "An edit-mesh with vertex or edge selection mode is required".
        bpy.ops.mesh.select_mode(type='VERT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.select_non_manifold()

        bm = bmesh.from_edit_mesh(obj.data)
        non_manifold_faces = [f for f in bm.faces if f.select]
        total_faces = len(bm.faces)
        # Safety: avoid deleting most of the mesh on stubborn models
        deleted_count = 0
        if non_manifold_faces and total_faces > 0:
            if len(non_manifold_faces) / total_faces <= 0.25:
                bpy.ops.mesh.delete(type='FACE')
                deleted_count = len(non_manifold_faces)
            else:
                self.report({'WARNING'},
                    f"{len(non_manifold_faces):,} of {total_faces:,} faces "
                    f"({100*len(non_manifold_faces)/total_faces:.0f}%) flagged "
                    "non-manifold — too large a fraction to delete safely; "
                    "skipped. Run Auto Remesh first to rebuild clean topology.")

        bpy.ops.mesh.select_all(action='SELECT')
        bm = bmesh.from_edit_mesh(obj.data)
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1.0)  # 1 mm (mm-space, was 0.001 m)
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

        bpy.ops.mesh.normals_make_consistent(inside=False)

        # The face-delete + remove_doubles pass above only cleans up
        # non-manifold artifacts — it never actually closes a genuine open
        # boundary (e.g. a gap at a bent toe joint). Fill any remaining
        # boundary edges directly so "Fix open edges" does what its label says.
        bm = bmesh.from_edit_mesh(obj.data)
        open_edges_before = [e for e in bm.edges if not e.is_manifold]
        open_count_before = len(open_edges_before)

        if open_edges_before:
            bmesh.ops.holes_fill(bm, edges=open_edges_before, sides=0)
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=True)

        bm = bmesh.from_edit_mesh(obj.data)
        open_count_after = len([e for e in bm.edges if not e.is_manifold])

        bpy.ops.object.mode_set(mode='OBJECT')

        messages = []
        if deleted_count:
            messages.append(f"cleaned {deleted_count} non-manifold faces")
        if open_count_before:
            messages.append(
                f"open edges {open_count_before} -> {open_count_after}")
        else:
            messages.append("no open edges found")
        self.report({'INFO'}, "; ".join(messages).capitalize())
        return {'FINISHED'}
