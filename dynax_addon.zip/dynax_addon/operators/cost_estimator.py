# operators/cost_estimator.py - Material weight/cost estimate
#
# Uses Blender's native mesh volume calculation. No custom geometry math
# needed - bmesh.calc_volume() already does this.

import bpy
import bmesh
from bpy.types import Operator


class DynaxEstimateCost(Operator):
    """Calculate estimated material weight and cost for the active mesh"""
    bl_idname = "dynax.estimate_cost"
    bl_label = "Estimate Print Cost"
    bl_description = "Calculate estimated filament weight and cost"
    bl_options = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select the socket mesh first.")
            return {'CANCELLED'}

        props = context.scene.dynax_props

        # Evaluated (post-modifier) mesh, so thickness/booleans are reflected
        # in the volume calculation.
        depsgraph = context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        mesh = eval_obj.to_mesh()

        bm = bmesh.new()
        bm.from_mesh(mesh)
        bm.transform(obj.matrix_world)

        # Volume in mm3 (mesh must be manifold/watertight for this to be
        # accurate - this is exactly why DynaX's watertight checks matter).
        volume_mm3 = abs(bm.calc_volume(signed=True))

        bm.free()
        eval_obj.to_mesh_clear()

        volume_cm3 = volume_mm3 / 1000.0  # mm3 -> cm3

        # Apply infill percentage - a hollow/partial-infill print uses less
        # material than the full solid volume suggests.
        effective_volume_cm3 = volume_cm3 * (props.print_infill_percent / 100.0)

        weight_g = effective_volume_cm3 * props.material_density_g_cm3
        weight_kg = weight_g / 1000.0
        cost = weight_kg * props.material_cost_per_kg

        context.scene["dynax_est_volume_cm3"] = round(volume_cm3, 1)
        context.scene["dynax_est_weight_g"] = round(weight_g, 1)
        context.scene["dynax_est_cost"] = round(cost, 2)

        self.report({'INFO'},
            f"Volume: {volume_cm3:.1f} cm³ | "
            f"Weight: {weight_g:.1f} g | "
            f"Cost: {props.material_currency_symbol}{cost:.2f}")
        return {'FINISHED'}
