# operators/trimline.py - Click-to-place trimline that cuts into 2 objects (v2.2)
#
# Workflow (Ugani / Operation Namaste style):
#   1. Place points by clicking directly on the mesh surface - each click casts
#      a ray into the scene and snaps the new point onto the surface, in order.
#   2. The growing line is shown live as an editable POLY curve on the mesh.
#   3. "Close loop" joins the last point back to the first into one closed ring.
#   4. Points are editable: move them (Tab into the curve), undo last, clear all.
#   5. "Cut into two parts" severs the mesh ONLY along the closed ring into two
#      separate, manifold objects (DynaX_Proximal / DynaX_Distal).
#   6. The interior stays hollow - the cut cross-section is NOT filled.
#
# The point store lives on the scene (dynax_trim_points / dynax_trim_closed) so
# every placement step is plain data manipulation that a headless test can drive
# directly (see _add_point / _close_loop), while the interactive modal operator
# is only a thin raycast wrapper over those same helpers.

#
# ── v1.20.8 (Creator Stabilization Sprint): the CUTTING CORE was replaced ──────
#
# Everything above (click-to-place, the scene point store, the live POLY curve,
# the GPU overlay, point editing, the self-intersection guard) is UNCHANGED.
# Only how the mesh is severed changed, because the old core produced the
# reported "stepped holes and missing faces":
#
#   * The old primary cut approximated the spline with up to 48 INDEPENDENT
#     flat bisect planes, one per ring segment. Adjacent planes do not meet
#     exactly, so the rim came out as a staircase of junction slivers, which a
#     chain of corrections (remove_doubles -> _cleanup_cut_rim -> 5 passes of
#     boundary smoothing) then tried to hide. The stepping was inherent to the
#     plane approximation, not a tuning problem.
#   * The old fallback boolean-DIFFERENCEd a 2 mm-thick solidified disk, which
#     DELETES a 2 mm band of the clinician's real geometry, and then stripped
#     every face within 16 mm of the blade (`_strip_cap_faces`, tol=8x kerf) -
#     removing genuine wall faces, i.e. the missing faces / blocky holes.
#
# The replacement is a projected-curve knife intersection (`_knife_ribbon_cut`):
# build a thin RIBBON surface that follows the densified spline across the wall,
# join it to a COPY of the target, run Blender's exact `mesh.intersect`
# (separate_mode='CUT'), then remove the ribbon geometry and split the mesh
# along the resulting continuous edge loop. The cut follows the spline exactly,
# removes no material (no kerf), needs no cap stripping, and cannot step
# because it is one continuous intersection rather than N independent planes.
#
# It also fails safely: the whole operation runs on a DUPLICATE, and the real
# object is only replaced once exactly two parts are confirmed - an invalid
# spline leaves the clinician's mesh byte-for-byte untouched.
#
# Kept from the old core and still used: _densify_loop, _ring_normal,
# _check_self_intersection, _separate_loose, _name_parts, _get_world_bounds,
# _smooth_boundary (light rim relax only). The old `_build_blade_object`,
# `_strip_cap_faces`, `_boolean_blade_cut`, `_bisect_surface_cut`,
# `_remove_coplanar_cap_faces` and `_cleanup_cut_rim` are RETIRED - left on
# disk, unregistered and uncalled, per this codebase's convention for
# superseded approaches (see manual_bridge.py, _cap_cavity_loop).

import bpy
import bmesh
import math
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from bpy.types import Operator

from ..utils import measurement_helpers as mh
from ..utils.dynax_logging import (
    creator_guard, log_operator_error, validate_mesh_object,
)
# Method A (paint & separate) stores its region in select_tools' one locked
# vertex group. Trimline owns the lifetime of that region while the user is in
# this step: starting or clearing a trim line invalidates it, so a region locked
# in another step can never be consumed as a trimline region.
from .select_tools import invalidate_selection

CURVE_NAME = "DynaX_TrimCurve"
# Cut "kerf" width, in SCENE UNITS. DynaX runs in mm-space (scale_length=0.001),
# so scene units are millimetres: 2.0 = 2 mm. Also sizes the cap-strip tolerance.
# (Was 0.002 in the old metre-space model; x1000 keeps the exact same real-world
# size now that imported geometry is ~1000x larger in coordinate magnitude.)
BLADE_KERF = 2.0

POINTS_KEY = "dynax_trim_points"     # flat [x,y,z, x,y,z, ...] on the scene
CLOSED_KEY = "dynax_trim_closed"     # bool: is the ring closed
TARGET_KEY = "dynax_trimline_target" # name of the mesh being trimmed

_draw_handler = None   # SpaceView3D POST_VIEW handle for the live point overlay


# ── Helpers ────────────────────────────────────────────────────────────────────

def _get_world_bounds(obj):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    zs = [v.co.z for v in bm.verts]
    bm.free()
    return min(zs), max(zs)


def _find_view3d_under_cursor(context, event):
    """Return (region, rv3d, (mx, my)) for the VIEW_3D *window* region under the
    mouse, or (None, None, None). Uses absolute window coords (event.mouse_x/y)
    and converts them to region-local coords, so it works no matter which region
    the modal was launched from (a panel button gives context.region == panel)."""
    x, y = event.mouse_x, event.mouse_y
    for area in context.screen.areas:
        if area.type != 'VIEW_3D':
            continue
        rv3d = area.spaces.active.region_3d
        for region in area.regions:
            if region.type == 'WINDOW' \
                    and region.x <= x < region.x + region.width \
                    and region.y <= y < region.y + region.height:
                return region, rv3d, (x - region.x, y - region.y)
    return None, None, None


# ── Live GPU overlay (dots + connecting line + closing segment) ────────────────
#
# The POLY trim curve already draws a thin beveled line on the mesh, but the
# individual control points aren't visible on it. This POST_VIEW overlay adds a
# bright dot at every placed point and a crisp line through them (the last->first
# closing segment lights up once the loop is closed), reading the same scene
# point store so it stays in sync after every add/undo/clear with no extra state.

def _draw_trimline():
    scene = bpy.context.scene
    pts = _get_points(scene)
    if not pts:
        return
    try:
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    except Exception:
        return

    coords = [(p.x, p.y, p.z) for p in pts]
    closed = bool(scene.get(CLOSED_KEY, False)) and len(coords) >= 3

    gpu.state.blend_set('ALPHA')
    prev_depth = gpu.state.depth_test_get() if hasattr(gpu.state, 'depth_test_get') else None
    gpu.state.depth_test_set('NONE')   # POST_VIEW: keep dots/line on top of the mesh

    if len(coords) >= 2:
        line = coords + [coords[0]] if closed else coords
        gpu.state.line_width_set(2.5)
        batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": line})
        shader.bind()
        shader.uniform_float("color", (1.0, 0.45, 0.05, 0.95))
        batch.draw(shader)
        gpu.state.line_width_set(1.0)

    gpu.state.point_size_set(9.0)
    batch = batch_for_shader(shader, 'POINTS', {"pos": coords})
    shader.bind()
    shader.uniform_float("color", (1.0, 0.92, 0.15, 1.0))
    batch.draw(shader)
    gpu.state.point_size_set(1.0)

    if prev_depth is not None:
        gpu.state.depth_test_set(prev_depth)
    gpu.state.blend_set('NONE')


def _register_draw():
    global _draw_handler
    if _draw_handler is None:
        _draw_handler = bpy.types.SpaceView3D.draw_handler_add(
            _draw_trimline, (), 'WINDOW', 'POST_VIEW')


def _unregister_draw():
    global _draw_handler
    if _draw_handler is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_draw_handler, 'WINDOW')
        _draw_handler = None


def register_draw_on_load():
    pass  # registered on demand when point placement starts


def unregister_draw_on_unload():
    _unregister_draw()


def _redraw_viewports():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


# ── Click-to-place point store ─────────────────────────────────────────────────
#
# Points are stored flat on the scene rather than only on the curve so the data
# survives between operator calls (a Python list would not) and so the curve can
# be rebuilt deterministically from a single source of truth after every edit.

def _get_points(scene):
    flat = list(scene.get(POINTS_KEY, []))
    pts = []
    for i in range(0, len(flat) - 2, 3):
        pts.append(Vector((flat[i], flat[i + 1], flat[i + 2])))
    return pts


def _set_points(scene, pts):
    flat = []
    for p in pts:
        flat.extend([float(p[0]), float(p[1]), float(p[2])])
    scene[POINTS_KEY] = flat


def _rebuild_curve(context):
    """(Re)build the live POLY trim curve from the stored points.

    POLY (unlike NURBS) passes exactly through every control point and its
    cyclic segment is a real straight edge from the last point back to the
    first - so a closed loop actually closes, both on screen and in the data
    the cut step reads. The points are kept in the exact click order; with
    click-to-place the user already controls the order around the limb, so no
    angle/TSP reordering is needed (or wanted - it would fight notches/dips).
    """
    scene = context.scene
    pts = _get_points(scene)
    closed = bool(scene.get(CLOSED_KEY, False))

    old = bpy.data.objects.get(CURVE_NAME)
    if old:
        bpy.data.objects.remove(old, do_unlink=True)

    if len(pts) < 1:
        return None

    curve_data = bpy.data.curves.new(name=CURVE_NAME, type='CURVE')
    curve_data.dimensions = '3D'
    curve_data.resolution_u = 1

    spline = curve_data.splines.new(type='POLY')
    spline.points.add(len(pts) - 1)
    for i, co in enumerate(pts):
        spline.points[i].co = (co.x, co.y, co.z, 1.0)
    spline.use_cyclic_u = bool(closed and len(pts) >= 3)

    curve_obj = bpy.data.objects.new(CURVE_NAME, curve_data)
    context.collection.objects.link(curve_obj)
    curve_obj.data.bevel_depth = 2.0            # 2 mm in mm-space - makes the line visible on the mesh
    curve_obj[ "dynax_trim_target"] = scene.get(TARGET_KEY, "")
    return curve_obj


def _add_point(context, co):
    """Append one surface point (world space) and refresh the live curve."""
    scene = context.scene
    pts = _get_points(scene)
    pts.append(Vector((co[0], co[1], co[2])))
    _set_points(scene, pts)
    curve = _rebuild_curve(context)
    _redraw_viewports()
    return curve


def _undo_point(context):
    """Remove the most recently placed point and refresh the live curve."""
    scene = context.scene
    pts = _get_points(scene)
    if pts:
        pts.pop()
    _set_points(scene, pts)
    # Removing the last point can't leave a valid closed ring of <3 points.
    if len(pts) < 3:
        scene[CLOSED_KEY] = False
    curve = _rebuild_curve(context)
    _redraw_viewports()
    return curve


def _close_loop(context):
    """Join the last point back to the first into a complete closed ring.

    IMPORTANT: this only marks the EXISTING curve cyclic - it never deletes and
    rebuilds it. The previous version called _rebuild_curve(), which recreated
    the curve from the stored point list; any moves the user made in Tab/Edit
    mode (which update the curve object but not that stored list) were silently
    thrown away on every Close-loop click. Now those edits are preserved, and we
    instead sync the stored list FROM the edited curve so the GPU dot overlay
    (which reads the store) matches what was actually drawn.
    """
    scene = context.scene
    if len(_get_points(scene)) < 3:
        return False
    scene[CLOSED_KEY] = True

    curve_obj = bpy.data.objects.get(CURVE_NAME)
    if curve_obj and curve_obj.type == 'CURVE' and curve_obj.data.splines:
        for spline in curve_obj.data.splines:
            spline.use_cyclic_u = True
        # Pull edited control-point positions back into the scene store so the
        # overlay + any later add/undo rebuild start from the edited shape.
        mw = curve_obj.matrix_world
        live = [mw @ Vector((p.co.x, p.co.y, p.co.z))
                for p in curve_obj.data.splines[0].points]
        if len(live) >= 3:
            _set_points(scene, live)
    else:
        # No curve exists yet (cleared, or first close) - only then build one.
        _rebuild_curve(context)

    _redraw_viewports()
    return True


def _clear_points(context):
    """Drop every placed point and remove the live curve."""
    scene = context.scene
    scene[POINTS_KEY] = []
    scene[CLOSED_KEY] = False
    old = bpy.data.objects.get(CURVE_NAME)
    if old:
        bpy.data.objects.remove(old, do_unlink=True)
    _unregister_draw()
    _redraw_viewports()


# ── Step 1: place points by clicking on the mesh ───────────────────────────────

class DynaxTrimlinePlacePoints(Operator):
    """Click on the mesh to place trim-line points one at a time"""
    bl_idname = "dynax.trimline_place_points"
    bl_label = "Place points (click on mesh)"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        if context.area is None or context.area.type != 'VIEW_3D':
            self.report({'ERROR'}, "Run this in the 3D viewport")
            return {'CANCELLED'}

        scene = context.scene
        target = bpy.data.objects.get(scene.get(TARGET_KEY, ""))
        if target is None or target.type != 'MESH':
            obj = context.active_object
            if not obj or obj.type != 'MESH':
                self.report({'ERROR'}, "Select your scan mesh first")
                return {'CANCELLED'}
            scene[TARGET_KEY] = obj.name

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Starting a NEW trim line replaces the old trimline state outright:
        # any region locked by Method A (or left over from an earlier step) is
        # invalidated so it can never be picked up by a later separation, and
        # Blender's own leftover selection flags are cleared. Interaction state
        # only - the mesh itself is untouched.
        invalidate_selection(context, bpy.data.objects.get(scene.get(TARGET_KEY, "")))
        if _get_points(scene):
            _clear_points(context)

        scene["dynax_trim_stage"] = 'PLACING'
        _register_draw()
        _redraw_viewports()
        context.workspace.status_text_set(
            "Left-click on the mesh to place a point  |  "
            "Backspace/Ctrl+Z = undo  |  Right-click or Esc = finish")
        context.window_manager.modal_handler_add(self)
        self.report({'INFO'},
            "Click on the mesh to drop points. "
            "Backspace = undo, Esc/right-click = finish.")
        return {'RUNNING_MODAL'}

    def _finish(self, context):
        """Clear the status bar and select the curve. Called on modal exit so
        the viewport returns to normal - panel buttons and shortcuts work again."""
        context.workspace.status_text_set(None)
        if len(_get_points(context.scene)) > 0:
            context.scene["dynax_trim_stage"] = 'PLACED'
        else:
            context.scene["dynax_trim_stage"] = 'IDLE'
        curve_obj = bpy.data.objects.get(CURVE_NAME)
        if curve_obj:
            bpy.ops.object.select_all(action='DESELECT')
            curve_obj.select_set(True)
            context.view_layer.objects.active = curve_obj
        _redraw_viewports()

    def modal(self, context, event):
        # ── Navigation: always pass through FIRST, before any other check ──
        # On some Blender versions the trailing PASS_THROUGH fallback isn't
        # enough - if an orbit/zoom event isn't explicitly released here the
        # modal can swallow it, locking middle-mouse orbit while placing points.
        #
        # v1.20.8: this now uses the SHARED classifier, which additionally
        # treats a MODIFIED left-click (Alt/Ctrl/Shift/OS + LMB) as navigation.
        # Alt+LMB is orbit under Emulate 3 Button Mouse, so the old
        # `event.type == 'LEFTMOUSE'` test below dropped a spline point every
        # time such a user orbited - "navigation added spline points".
        if mh.is_navigation_event(event):
            return {'PASS_THROUGH'}

        # Place a point. Plain, unmodified left-click only (modified ones were
        # already classified as navigation above).
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            co = self._raycast(context, event)
            if co is not None:
                _add_point(context, co)
                _redraw_viewports()
            else:
                self.report({'WARNING'},
                    "Click landed off the mesh - try again on the surface")
            return {'RUNNING_MODAL'}

        # Undo last point (Backspace/Del or Ctrl+Z).
        if (event.type in {'BACK_SPACE', 'DEL'} and event.value == 'PRESS') \
                or (event.type == 'Z' and event.ctrl and event.value == 'PRESS'):
            _undo_point(context)
            _redraw_viewports()
            return {'RUNNING_MODAL'}

        # Finish placing points - exit the modal cleanly.
        if event.type in {'RIGHTMOUSE', 'ESC', 'RET', 'NUMPAD_ENTER'} \
                and event.value == 'PRESS':
            self._finish(context)
            n = len(_get_points(context.scene))
            self.report({'INFO'},
                f"✓ {n} point(s) placed. Click 'Close loop', then 'Cut into two parts'.")
            return {'FINISHED'}

        # Everything else (navigation, panel clicks, shortcuts) passes through so
        # the viewport never feels locked.
        return {'PASS_THROUGH'}

    def _raycast(self, context, event):
        """Cast a ray from the mouse onto the TARGET mesh and return the exact
        world-space surface hit (or None if the click missed it).

        Two things make this reliable where the previous version failed:
        1. It locates the actual VIEW_3D window region under the cursor instead
           of trusting context.region/context.region_data - when this modal is
           launched from the N-panel button those point at the *panel*, not the
           viewport, so the unprojected ray was garbage and points landed at the
           wrong depth.
        2. It ray-casts in the object's *local* space (obj.ray_cast) and then
           multiplies the hit by obj.matrix_world to bring it back to world
           space. obj.ray_cast returns a LOCAL-space location; skipping that
           transform is the classic cause of points sitting off the surface.
        """
        from bpy_extras import view3d_utils

        region, rv3d, coord = _find_view3d_under_cursor(context, event)
        if region is None or rv3d is None:
            return None

        obj = bpy.data.objects.get(context.scene.get(TARGET_KEY, ""))
        if obj is None or obj.type != 'MESH':
            return None

        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        ray_dir = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)

        # Cast against the *evaluated* mesh (so modifiers/transform are honored),
        # in object-local space as obj.ray_cast requires.
        depsgraph = context.evaluated_depsgraph_get()
        obj_eval = obj.evaluated_get(depsgraph)
        mwi = obj.matrix_world.inverted()
        local_origin = mwi @ ray_origin
        local_dir = mwi.to_3x3() @ ray_dir

        success, location, normal, face_index = obj_eval.ray_cast(local_origin, local_dir)
        if not success:
            return None

        # Local hit -> world space. This is the step that was missing before.
        return obj.matrix_world @ location


class DynaxTrimlineUndoPoint(Operator):
    """Remove the most recently placed trim-line point"""
    bl_idname = "dynax.trimline_undo_point"
    bl_label = "Undo last point"
    bl_options = {'REGISTER', 'UNDO'}

    @creator_guard("Could not undo the point. See the DynaX log for details.")
    def execute(self, context):
        if not _get_points(context.scene):
            self.report({'INFO'}, "No points to undo")
            return {'CANCELLED'}
        _undo_point(context)
        self.report({'INFO'}, f"{len(_get_points(context.scene))} point(s) left")
        return {'FINISHED'}


class DynaxTrimlineCloseLoop(Operator):
    """Join the last point back to the first into a complete closed ring"""
    bl_idname = "dynax.trimline_close_loop"
    bl_label = "Close loop"
    bl_options = {'REGISTER', 'UNDO'}

    @creator_guard("Could not close the loop. See the DynaX log for details.")
    def execute(self, context):
        if not _close_loop(context):
            self.report({'ERROR'}, "Place at least 3 points before closing the loop")
            return {'CANCELLED'}
        context.scene["dynax_trim_stage"] = 'CLOSED'
        curve_obj = bpy.data.objects.get(CURVE_NAME)
        if curve_obj:
            bpy.ops.object.select_all(action='DESELECT')
            curve_obj.select_set(True)
            context.view_layer.objects.active = curve_obj
        self.report({'INFO'}, "✓ Loop closed. Click 'Cut into two parts'.")
        return {'FINISHED'}


class DynaxTrimlineEdit(Operator):
    """Enter edit mode to drag the placed trim points"""
    bl_idname = "dynax.trimline_edit"
    bl_label = "Edit points"
    bl_options = {'REGISTER', 'UNDO'}

    @creator_guard("Could not edit the points. See the DynaX log for details.")
    def execute(self, context):
        curve_obj = bpy.data.objects.get(CURVE_NAME)
        if not curve_obj:
            self.report({'ERROR'}, "No trim line. Place some points first.")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        curve_obj.select_set(True)
        context.view_layer.objects.active = curve_obj
        bpy.ops.object.mode_set(mode='EDIT')
        self.report({'INFO'},
            "Drag the points to adjust. Tab to finish, then 'Cut into two parts'.")
        return {'FINISHED'}


# ── Step 3: Cut the mesh into two separate objects ─────────────────────────────

def _curve_world_points(curve_obj):
    """Exact world-space control points of the (single-spline) trim curve."""
    spline = curve_obj.data.splines[0]
    mw = curve_obj.matrix_world
    pts = [mw @ Vector((p.co.x, p.co.y, p.co.z)) for p in spline.points]
    return pts, bool(spline.use_cyclic_u)


def _densify_loop(pts, max_seg_len):
    """Subdivide a closed polyline so no segment exceeds max_seg_len.

    The trim line's hand-placed points are usually much coarser than the
    scanned mesh. Building the boolean blade straight from those few points
    makes it a low-poly polygon that can cross the (also faceted) mesh surface
    more than once per edge - a coarse-vs-coarse faceting clash that fragments
    the cut into extra sliver islands instead of one clean split. Densifying
    first gives the blade a smooth, fine boundary so it crosses the surface
    exactly once around the loop.
    """
    n = len(pts)
    out = []
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        steps = max(1, math.ceil((b - a).length / max_seg_len))
        for s in range(steps):
            out.append(a.lerp(b, s / steps))
    return out


def _build_blade_object(context, pts, kerf_m=BLADE_KERF, overhang=1.08):
    """RETIRED v1.20.8 - unused, kept for reference only. See the module header.

    This built the boolean fallback's blade. The blade removes a BLADE_KERF
    (2 mm) band of the clinician's real geometry, and `_strip_cap_faces` then
    deleted everything within 16 mm of it - together the direct cause of the
    reported missing faces / blocky holes. Superseded by `_knife_ribbon_cut`,
    which removes no material at all. Do not reinstate without re-reading why
    it was replaced.

    Build a thin, sealed 'cutting disk' solid that fills the curve loop's
    entire interior cross-section, so a boolean DIFFERENCE against it fully
    severs the target into two pieces - this is view-independent (unlike
    knife_project) and faithfully follows the drawn curve's actual shape.

    A closed loop drawn on a watertight scan bounds a solid, not a hollow
    shell: a thin "ring" that only traces the boundary curve barely grazes
    the surface and never reaches the solid's bulk interior, so the two
    halves stay joined underneath no matter how exactly the ring follows the
    curve. The fix is to fill the loop into a disk before cutting. The disk
    is expanded slightly past the curve before filling so its rim also takes
    a sliver off the surface itself, not just the interior - without that
    overhang, a paper-thin uncut bridge survives exactly along the original
    boundary where the disk's edge meets the surface with zero clearance.
    """
    if len(pts) < 3:
        return None

    centroid = sum(pts, Vector()) / len(pts)
    loop_radius = max((p - centroid).length for p in pts)
    pts = _densify_loop(pts, max(loop_radius / 12.0, 0.001))
    centroid = sum(pts, Vector()) / len(pts)
    pts = [centroid + (p - centroid) * overhang for p in pts]
    n = len(pts)

    bm = bmesh.new()
    verts = [bm.verts.new(p) for p in pts]
    # Fan-triangulate from the centroid rather than bmesh triangle_fill: a
    # hand-drawn ring on a curved limb is NON-planar, and triangle_fill projects
    # to a best-fit plane and can self-intersect / fold on a wobbly ring, which
    # produced a mangled disk and the "random" cut. A centroid fan is valid for
    # any star-shaped cross-section (every limb section is) regardless of how
    # non-planar the ring is - each triangle simply spans the centroid and one
    # ring edge.
    cen = bm.verts.new(centroid)
    bm.verts.ensure_lookup_table()
    for i in range(n):
        bm.faces.new((cen, verts[i], verts[(i + 1) % n]))
    bm.normal_update()
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])

    # Snapshot the flat/curved disk surface *before* solidify thickens it -
    # this is what _strip_cap_faces() uses afterward to find and remove the
    # sealing cap the boolean creates on each half, so the cut stays open
    # there (a closed cap would solidify into a sealed blob, not a wearable
    # open-rimmed socket).
    cap_bvh = BVHTree.FromBMesh(bm)

    # solidify() turns the flat filled disk into a thin sealed solid - the
    # actual "kerf" width of the cut.
    bmesh.ops.solidify(bm, geom=bm.faces[:], thickness=kerf_m)

    me = bpy.data.meshes.new("DynaX_Blade_tmp")
    bm.to_mesh(me)
    bm.free()
    blade = bpy.data.objects.new("DynaX_Blade_tmp", me)
    context.collection.objects.link(blade)
    return blade, cap_bvh


def _strip_cap_faces(obj, cap_bvh, tol):
    """RETIRED v1.20.8 - unused, kept for reference only. See the module header.

    Delete the sealing faces the boolean cut creates at the trim curve.

    The boolean DIFFERENCE in trimline_cut severs a *solid*, so it seals both
    new cut surfaces shut (see _build_blade_object). That's correct for
    separating the two halves, but Solidify-with-rim downstream needs an open
    boundary loop at the cut to wrap into a single wearable shell there -
    a sealed cap would solidify into a fully enclosed blob instead. Keeping
    the cap open is also what keeps the socket interior hollow rather than
    filled with internal faces across the cross-section.
    """
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    to_delete = [f for f in bm.faces
                 if cap_bvh.find_nearest(f.calc_center_median(), tol)[0] is not None]
    if to_delete:
        bmesh.ops.delete(bm, geom=to_delete, context='FACES')
    bm.to_mesh(obj.data)
    bm.free()


def _clean_target_mesh(context, obj):
    """Merge doubles + recalc normals on the target before cutting, so the
    boolean behaves (stray duplicate verts or flipped normals fracture it)."""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')
    bm = bmesh.from_edit_mesh(obj.data)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.1)  # 0.1 mm (mm-space)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    bmesh.update_edit_mesh(obj.data)
    bpy.ops.object.mode_set(mode='OBJECT')


def _ring_normal(pts):
    """Average (Newell-style) normal of the closed loop - robust to non-planar
    rings and to which way the points were placed around the limb."""
    n = len(pts)
    c = sum(pts, Vector()) / n
    nrm = Vector((0.0, 0.0, 0.0))
    for i in range(n):
        nrm += (pts[i] - c).cross(pts[(i + 1) % n] - c)
    return nrm.normalized() if nrm.length > 1e-9 else Vector((0.0, 0.0, 1.0))


def _dist_point_to_segment(p, a, b):
    """Shortest distance from point p to segment a-b."""
    ab = b - a
    L2 = ab.dot(ab)
    if L2 < 1e-18:
        return (p - a).length
    t = max(0.0, min(1.0, (p - a).dot(ab) / L2))
    return (p - (a + ab * t)).length


def _dist_point_to_polyline(p, ring):
    """Shortest distance from point p to the closed polyline `ring`."""
    best = float('inf')
    n = len(ring)
    for i in range(n):
        d = _dist_point_to_segment(p, ring[i], ring[(i + 1) % n])
        if d < best:
            best = d
    return best


def _separate_loose(context, obj):
    """Split `obj` into its connected components, returning the resulting mesh
    objects."""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.separate(type='LOOSE')
    bpy.ops.object.mode_set(mode='OBJECT')
    return [o for o in context.selected_objects if o.type == 'MESH']


def _cleanup_cut_rim(obj):
    """RETIRED v1.20.8 - unused, kept for reference only. See the module header.

    Existed solely to clean up the retired per-segment bisect's junction
    slivers. The knife core does not create them.

    Remove degenerate zero-area faces along the cut boundary. The per-segment
    bisect can leave these slivers at segment junctions and they read as jagged
    teeth / spikes on the rim. Only faces whose verts are ALL on the open
    boundary AND whose area is effectively zero are removed, so real wall faces
    (which have interior verts) are never touched. Runs on a single, already-
    separated part, so it can't re-join the two halves."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.edges.ensure_lookup_table()
    boundary_verts = {v for e in bm.edges if e.is_boundary for v in e.verts}
    to_delete = [f for f in bm.faces
                 if all(v in boundary_verts for v in f.verts)
                 and f.calc_area() < 1e-2]   # area in mm^2 (was 1e-8 m^2 = 1e-2 mm^2)
    if to_delete:
        bmesh.ops.delete(bm, geom=to_delete, context='FACES')
        bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=0.05)  # 0.05 mm (mm-space)
        bm.to_mesh(obj.data)
        obj.data.update()
    bm.free()


def _smooth_boundary(obj, factor=0.5, iterations=5):
    """Lightly Laplacian-smooth a cut part's OPEN rim to take the teeth off the
    jagged boundary the per-segment bisect leaves behind (Image 1's spikes).

    Each boundary vertex is blended `factor` of the way toward the average of its
    boundary *neighbours* (the two verts adjacent along the rim loop), a few
    passes. This is purely positional: it changes no vertex/edge/face counts, so
    the rim stays a single clean loop that Solidify-with-rim can still wrap, and
    it never merges the two halves (they are already separate objects here).
    Interior geometry is untouched - only rim verts move, and only tangentially
    along the loop, so the overall trim shape is preserved.

    Done before Solidify so thickness no longer amplifies every little notch into
    a spike.
    """
    me = obj.data
    for _ in range(max(1, iterations)):
        bm = bmesh.new()
        bm.from_mesh(me)
        boundary_verts = {v for e in bm.edges if e.is_boundary for v in e.verts}
        if not boundary_verts:
            bm.free()
            return
        new_co = {}
        for v in boundary_verts:
            neighbours = [e.other_vert(v).co for e in v.link_edges
                          if e.other_vert(v) in boundary_verts]
            if neighbours:
                avg = sum(neighbours, Vector()) / len(neighbours)
                new_co[v] = v.co.lerp(avg, factor)
        for v, co in new_co.items():
            v.co = co
        bm.to_mesh(me)
        bm.free()


def _remove_coplanar_cap_faces(obj, ring_pts, tol=0.015):
    """RETIRED v1.20.8 - unused, kept for reference only. See the module header.

    NOTE for anyone tempted to revive it: `tol=0.015` is a stale METRE-space
    default that survived the mm-space migration, so at 0.015 mm this function
    had been silently doing nothing for several releases. The knife core needs
    no cap removal at all (it creates no caps).

    After a cut, delete any faces that are both NEAR the ring plane and
    roughly PARALLEL to it - the spurious internal "cap" faces that make a
    hollow socket read as solid. Wall faces (normal ~perpendicular to the ring
    plane) are kept, so only the flat cross-section caps near the cut are
    removed; geometry elsewhere on the part is untouched.
    """
    if not ring_pts or len(ring_pts) < 3:
        return
    centroid = sum(ring_pts, Vector()) / len(ring_pts)
    normal = _ring_normal(ring_pts)
    if normal.length < 1e-6:
        return

    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.normal_update()
    mw = obj.matrix_world
    to_delete = []
    for f in bm.faces:
        fc = mw @ f.calc_center_median()
        if abs((fc - centroid).dot(normal)) > tol:   # not near the ring plane
            continue
        fn = (mw.to_3x3() @ f.normal).normalized()
        if abs(fn.dot(normal)) > 0.7:                # parallel to plane => a cap
            to_delete.append(f)
    if to_delete:
        bmesh.ops.delete(bm, geom=to_delete, context='FACES')
        bm.to_mesh(obj.data)
    bm.free()


def _name_parts(parts):
    """Name cut parts by height: highest = Proximal, next = Distal."""
    def zc(o):
        zmin, zmax = _get_world_bounds(o)
        return (zmin + zmax) / 2
    parts.sort(key=zc, reverse=True)
    for i, p in enumerate(parts):
        if i == 0:
            p.name = "DynaX_Proximal"
        elif i == 1:
            p.name = "DynaX_Distal"
        else:
            p.name = f"DynaX_Part_{i + 1}"


def _get_bisect_dist():
    """Version-safe merge tolerance for ``bmesh.ops.bisect_plane``. Blender 5.1
    is more sensitive to a near-zero ``dist`` on dense/complex meshes - the
    degenerate slivers it leaves at the cut can hang the C-level op - so use a
    slightly larger tolerance there than on 5.0 and earlier."""
    # Values are in scene units (mm-space): 0.1 mm on 5.1+, 0.01 mm earlier.
    # (Were 1e-4 / 1e-5 in metre-space; x1000 preserves the same real tolerance.)
    major, minor = bpy.app.version[0], bpy.app.version[1]
    if (major, minor) >= (5, 1):
        return 0.1
    return 0.01


def _check_self_intersection(world_points):
    """True if the trim ring crosses itself (a figure-8 / crossing path).

    The ring is projected onto its OWN best-fit plane (more robust than the
    raw-XY approximation: the limb axis isn't always world-Z, and a tilted limb
    would make an XY projection self-cross spuriously), then every pair of
    non-adjacent segments is tested for a 2D crossing. A self-crossing ring makes
    the per-segment bisect produce degenerate geometry that can freeze Blender at
    the C level, so callers reject it up front instead of attempting the cut.
    """
    from mathutils.geometry import intersect_line_line_2d
    pts = [Vector((p[0], p[1], p[2])) for p in world_points]
    n = len(pts)
    if n < 4:
        return False
    centroid = sum(pts, Vector()) / n
    normal = _ring_normal(pts)
    # Orthonormal basis (u, v) spanning the best-fit plane.
    ref = Vector((1.0, 0.0, 0.0))
    if abs(normal.dot(ref)) > 0.9:
        ref = Vector((0.0, 1.0, 0.0))
    u = (ref - normal * ref.dot(normal)).normalized()
    v = normal.cross(u).normalized()
    p2d = [Vector(((p - centroid).dot(u), (p - centroid).dot(v))) for p in pts]
    for i in range(n):
        a1, a2 = p2d[i], p2d[(i + 1) % n]
        for j in range(i + 2, n):
            if i == 0 and j == n - 1:
                continue  # these two segments share the wrap-around vertex
            b1, b2 = p2d[j], p2d[(j + 1) % n]
            if intersect_line_line_2d(a1, a2, b1, b2) is not None:
                return True
    return False


def _bisect_surface_cut(context, obj, pts):
    """RETIRED v1.20.8 - unused, kept for reference only. See the module header.

    The per-segment plane approximation whose junction slivers ARE the reported
    stepped rim. Superseded by `_knife_ribbon_cut` (one continuous exact
    intersection instead of up to 48 independent planes).

    Cut the SURFACE of `obj` along the ring by bisecting only the faces near
    each (densified) ring segment, then splitting the resulting on-ring edges so
    the shell comes apart into two pieces.

    Unlike a boolean this needs no watertight solid - it works on an open shell
    too - and unlike a single averaged plane it follows a non-planar ring. The
    on-ring cut edges are re-identified by *geometry* after all bisects (both
    endpoints within tol of the ring polyline) rather than by holding BMEdge
    references, which neighbouring bisects would invalidate and leave gaps.
    """
    centroid = sum(pts, Vector()) / len(pts)
    loop_radius = max((p - centroid).length for p in pts)
    # Densify just enough to keep each bisect plane local and to follow a
    # non-planar ring - NOT so finely that the cut rim ends up with more verts
    # than the mesh it cuts (that bloats the open boundary loop).
    ring = _densify_loop(pts, max(loop_radius / 5.0, 1e-4))
    axis = _ring_normal(ring)          # the limb's local long axis
    # Tight tolerances so the cut stays ON the ring and never reaches the FAR
    # wall of a thin socket (which produced spurious internal cuts):
    #   tol  - an edge is "on the cut" only if BOTH ends are within 4% of the
    #          ring radius of the ring polyline.
    #   band - only bisect faces within 35% of the ring radius of a ring segment,
    #          i.e. faces the ring actually crosses, not the opposite wall.
    tol = max(loop_radius * 0.04, 1e-4)
    band = loop_radius * 0.35

    mw = obj.matrix_world
    inv = mw.inverted()
    inv3 = inv.to_3x3()

    # Precompute each densified segment and its cutting plane. The plane must be
    # roughly HORIZONTAL (separating proximal from distal), i.e. its normal is
    # seg_dir x surface_normal, where surface_normal is the RADIAL direction (out
    # from the limb axis) - NOT the axial ring normal, which would give a vertical
    # plane that slices along the limb instead of around it.
    segs = []
    n = len(ring)
    for i in range(n):
        a = ring[i]
        b = ring[(i + 1) % n]
        seg = b - a
        L = seg.length
        if L < 1e-7:
            continue
        mid = (a + b) * 0.5
        radial = (mid - centroid)
        radial = radial - radial.dot(axis) * axis        # strip axial component
        if radial.length < 1e-7:
            radial = (seg / L).cross(axis)
        radial.normalize()
        plane_no = (seg / L).cross(radial)
        if plane_no.length < 1e-7:
            continue
        plane_no.normalize()
        segs.append((a, b, mid, plane_no))
    if not segs:
        bpy.ops.object.mode_set(mode='OBJECT')
        return

    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')
    bm = bmesh.from_edit_mesh(obj.data)
    bm.faces.ensure_lookup_table()

    # Assign every face the ring passes through to its NEAREST segment, so the
    # cut has gapless coverage (a per-segment midpoint radius leaves faces at the
    # segment joints uncut, and the rim never closes -> mesh stays in one piece).
    groups = {}
    for f in bm.faces:
        c = mw @ f.calc_center_median()
        best = band
        bi = -1
        for si, (a, b, mid, no) in enumerate(segs):
            d = _dist_point_to_segment(c, a, b)
            if d < best:
                best = d
                bi = si
        if bi >= 0:
            groups.setdefault(bi, []).append(f)

    for si, faces in groups.items():
        a, b, mid, plane_no = segs[si]
        co_l = inv @ mid
        no_l = (inv3 @ plane_no).normalized()
        geom = set()
        for f in faces:
            geom.add(f)
            geom.update(f.edges)
            geom.update(f.verts)
        bmesh.ops.bisect_plane(bm, geom=list(geom),
                               plane_co=co_l, plane_no=no_l,
                               clear_inner=False, clear_outer=False,
                               dist=_get_bisect_dist())

    # Merge the tiny duplicate verts the per-segment bisects leave at the
    # segment JUNCTIONS (adjacent planes don't meet exactly), which are the main
    # cause of the jagged teeth on the rim. This MUST happen BEFORE split_edges:
    # running it after the split would re-weld the just-separated coincident verts
    # and silently fuse the two halves back into one piece (verified: post-split
    # remove_doubles drops the bisect to a single part and forces the boolean
    # fallback). Cleaning the ring here also makes the cut-edge re-selection below
    # land on a tidier loop.
    bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=0.05)  # 0.05 mm (mm-space)

    # Re-select the cut loop purely by geometry, then split it so the two shells
    # separate. An edge belongs to the cut when BOTH its endpoints sit on the
    # ring (perpendicular edges merely crossing the ring have one far endpoint).
    bm.edges.ensure_lookup_table()
    cut_edges = []
    for e in bm.edges:
        wa = mw @ e.verts[0].co
        wb = mw @ e.verts[1].co
        if _dist_point_to_polyline(wa, ring) < tol \
                and _dist_point_to_polyline(wb, ring) < tol:
            cut_edges.append(e)
    if cut_edges:
        bmesh.ops.split_edges(bm, edges=cut_edges)

    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    bmesh.update_edit_mesh(obj.data, destructive=True)
    bpy.ops.object.mode_set(mode='OBJECT')


def _boolean_blade_cut(context, obj, pts):
    """RETIRED v1.20.8 - unused, kept for reference only. See the module header.

    Fallback cut: boolean-DIFFERENCE a thin filled blade disk out of a solid,
    then strip the sealing cap so the cut stays open (hollow). Reliable on a
    watertight solid where a pure surface cut may leave the bulk interior joined.
    Returns True if the boolean applied."""
    blade, cap_bvh = _build_blade_object(context, pts)
    if not blade:
        return False
    ok = False
    try:
        m = obj.modifiers.new(name="DynaX_TrimBoolean_tmp", type='BOOLEAN')
        m.object = blade
        m.operation = 'DIFFERENCE'
        if hasattr(m, 'solver'):
            m.solver = 'EXACT'
        context.view_layer.objects.active = obj
        bpy.ops.object.modifier_apply(modifier=m.name)
        # Generous cap tolerance: on a large socket (300mm+) a tight 1.5x kerf
        # (3mm) lets the BVH nearest-lookup miss cap faces and the interior reads
        # as solid. 8x kerf (16mm) reliably catches the boolean's sealing cap.
        _strip_cap_faces(obj, cap_bvh, tol=BLADE_KERF * 8.0)
        ok = True
    except Exception:
        ok = False
        if "DynaX_TrimBoolean_tmp" in [mm.name for mm in obj.modifiers]:
            obj.modifiers.remove(obj.modifiers["DynaX_TrimBoolean_tmp"])
    bpy.data.objects.remove(blade, do_unlink=True)

    if ok:
        # Clean the boolean seam (merge-by-distance) before splitting, else stray
        # doubles keep the halves welded as one loose part.
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='EDIT')
        bm = bmesh.from_edit_mesh(obj.data)
        bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.1)  # 0.1 mm (mm-space)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bmesh.update_edit_mesh(obj.data)
        bpy.ops.object.mode_set(mode='OBJECT')
    return ok


# ── v1.20.8 cutting core: projected-curve knife intersection ──────────────────

# How far the ribbon extends either side of the surface, as a fraction of the
# ring radius. It only has to punch through the wall it crosses, so this is
# sized from the RING, not the whole mesh: a value large enough to cross a thick
# socket wall, small enough that it cannot reach the opposite wall of the limb
# and cut it too (the old bisect's `band` parameter existed for the same reason).
RIBBON_DEPTH_FRACTION = 0.14
# Densify the ring to at most this fraction of its radius per segment. The cut
# follows the polyline exactly, so this controls how faithfully the polyline
# follows the clinician's intended curve - fine enough to read as continuous,
# coarse enough that the knife stays fast on a real scan.
RIBBON_SEGMENT_FRACTION = 1.0 / 64.0


def _build_ribbon(context, pts, depth, target=None):
    """Build the cutting RIBBON: a thin open surface that follows the ring and
    spans the wall it crosses.

    Each densified ring point is extended `depth` either side of the surface so
    the swept quad strip passes clean through the wall exactly where the
    clinician drew, and nowhere else.

    The extension direction is the target's local SURFACE NORMAL at that point,
    not the radial direction. That distinction is load-bearing: a radial ribbon
    is horizontal, so where the wall itself flares towards horizontal (the brim
    region of a real socket) it runs almost PARALLEL to the wall and never
    crosses it - measured: a ring at 72% height cut nothing at all. The surface
    normal is by definition perpendicular to the wall, so the ribbon crosses it
    whatever the wall's orientation. Falls back to radial only where no normal
    is available.

    Unlike the retired blade disk, this ribbon is a SURFACE, not a solid: the
    knife intersects against it and removes NO material, so there is no kerf and
    no cap to strip afterwards.
    """
    centroid = sum(pts, Vector()) / len(pts)
    axis = _ring_normal(pts)

    bvh = None
    if target is not None:
        bm_t = bmesh.new()
        try:
            bm_t.from_mesh(target.data)
            bm_t.transform(target.matrix_world)
            bvh = BVHTree.FromBMesh(bm_t)
        finally:
            bm_t.free()

    def _radial(point):
        radial = point - centroid
        radial = radial - radial.dot(axis) * axis      # strip the axial part
        if radial.length < 1e-7:
            radial = (point - centroid).cross(axis)
            if radial.length < 1e-7:
                radial = Vector((1.0, 0.0, 0.0))
        return radial.normalized()

    inner, outer = [], []
    previous = None
    for point in pts:
        direction = None
        if bvh is not None:
            _loc, normal, _index, _dist = bvh.find_nearest(point)
            if normal is not None and normal.length > 1e-7:
                direction = normal.normalized()
                # Keep the strip coherent: flip a normal that faces opposite the
                # previous one, so the ribbon doesn't fold back on itself where
                # the scan's normals are locally inconsistent.
                if previous is not None and direction.dot(previous) < 0.0:
                    direction = -direction
        if direction is None:
            direction = _radial(point)
        previous = direction
        inner.append(point - direction * depth)
        outer.append(point + direction * depth)

    bm = bmesh.new()
    try:
        inner_verts = [bm.verts.new(p) for p in inner]
        outer_verts = [bm.verts.new(p) for p in outer]
        bm.verts.ensure_lookup_table()
        count = len(pts)
        for i in range(count):
            j = (i + 1) % count            # cyclic: the ribbon closes the ring
            try:
                bm.faces.new((inner_verts[i], outer_verts[i],
                              outer_verts[j], inner_verts[j]))
            except ValueError:
                continue                   # duplicate face on a repeated point
        bm.normal_update()
        mesh = bpy.data.meshes.new("DynaX_TrimRibbon_tmp")
        bm.to_mesh(mesh)
    finally:
        bm.free()

    ribbon = bpy.data.objects.new("DynaX_TrimRibbon_tmp", mesh)
    context.collection.objects.link(ribbon)
    return ribbon


def _knife_ribbon_cut(context, obj, pts):
    """Cut `obj`'s surface along the ring using an exact knife intersection.

    Joins the ribbon into the target, runs `mesh.intersect` in CUT mode (which
    only ADDS edges where the two surfaces cross - it never deletes geometry),
    then deletes the ribbon's own faces and splits the mesh along the new
    intersection loop so the shells come apart.

    The intersection edges are identified GEOMETRICALLY afterwards (both
    endpoints within tolerance of the ring polyline), not by holding BMEdge
    references across the operator, because the knife invalidates them.

    Returns True if the mesh was cut into 2+ loose parts.
    """
    centroid = sum(pts, Vector()) / len(pts)
    loop_radius = max((p - centroid).length for p in pts)
    ring = _densify_loop(pts, max(loop_radius * RIBBON_SEGMENT_FRACTION, 1e-4))
    depth = max(loop_radius * RIBBON_DEPTH_FRACTION, 1.0)   # >= 1 mm

    ribbon = _build_ribbon(context, ring, depth, target=obj)
    ribbon_face_count = len(ribbon.data.polygons)

    # Join the ribbon into the target so mesh.intersect sees one mesh with two
    # surfaces. Tag the ribbon's faces first so they can be identified and
    # removed after the cut regardless of how the knife re-indexes them.
    ribbon_tag = ribbon.data.attributes.new(
        name="dynax_ribbon", type='INT', domain='FACE')
    ribbon_tag.data.foreach_set("value", [1] * ribbon_face_count)

    bpy.ops.object.select_all(action='DESELECT')
    ribbon.select_set(True)
    obj.select_set(True)
    context.view_layer.objects.active = obj
    bpy.ops.object.join()          # ribbon is consumed; obj keeps the datablock

    bpy.ops.object.mode_set(mode='EDIT')
    bm = bmesh.from_edit_mesh(obj.data)
    bm.faces.ensure_lookup_table()

    tag_layer = bm.faces.layers.int.get("dynax_ribbon")
    if tag_layer is None:
        bpy.ops.object.mode_set(mode='OBJECT')
        return False

    # Select ONLY the ribbon, and intersect it against everything UNselected
    # (the scan). mode='SELECT' would self-intersect the entire selection - i.e.
    # test the scan against itself - and a real scan has enough near-coincident
    # geometry that this shattered it into ~200 fragments (measured). The ribbon
    # must be tested against the wall and nothing else.
    # Clear vert/edge flags FIRST. `select_flush(True)` propagates selection
    # outward from verts/edges, so a vertex left selected by an earlier Sculpt
    # or Edit-mode session would flush its face back into the "ribbon" side and
    # SELECT_UNSELECT would then knife scan geometry against itself. The knife's
    # only input must be its own ribbon tag.
    for vert in bm.verts:
        vert.select = False
    for edge in bm.edges:
        edge.select = False
    for face in bm.faces:
        face.select = (face[tag_layer] == 1)
    bm.select_flush(True)
    bmesh.update_edit_mesh(obj.data)

    try:
        # EXACT solver: the mm-scale, irregular real-scan geometry is exactly
        # where the FAST solver's tolerance heuristics fail. separate_mode='CUT'
        # adds the intersection edges without removing anything.
        bpy.ops.mesh.intersect(
            mode='SELECT_UNSELECT', separate_mode='CUT', solver='EXACT')
    except (RuntimeError, TypeError):
        try:
            bpy.ops.mesh.intersect(mode='SELECT_UNSELECT', separate_mode='CUT')
        except RuntimeError:
            bpy.ops.object.mode_set(mode='OBJECT')
            return False

    # ── Identify the cut curve, split it, then remove the knife ────────────
    #
    # `mesh.intersect` inserts the intersection edges and leaves them SELECTED,
    # but separate_mode='CUT' does not actually disconnect the two sides
    # (measured: the socket stayed a single loose part). So the cut curve must
    # be split explicitly.
    #
    # The curve is taken from the knife's OWN selection - the edges it just
    # created that lie purely on the scan - NOT from a geometric "near the ring"
    # test. That distinction matters: an earlier revision selected every edge
    # whose endpoints both sat within a tolerance of the ring polyline, which on
    # a dense real scan also matches hundreds of ordinary surface edges running
    # alongside the ring, and shattered the socket into ~216 fragments
    # (measured). Only the knife knows exactly where it cut.
    bm = bmesh.from_edit_mesh(obj.data)
    tag_layer = bm.faces.layers.int.get("dynax_ribbon")
    if tag_layer is None:
        bpy.ops.object.mode_set(mode='OBJECT')
        return False

    cut_edges = [
        edge for edge in bm.edges
        if edge.select and edge.link_faces
        and all(face[tag_layer] != 1 for face in edge.link_faces)
    ]
    if not cut_edges:
        # The ribbon never reached the wall: nothing was cut. Report failure so
        # the caller discards the duplicate and the real mesh is untouched.
        bpy.ops.object.mode_set(mode='OBJECT')
        return False
    bmesh.ops.split_edges(bm, edges=cut_edges)

    # The ribbon has served its purpose - delete its faces and any verts left
    # loose on the cut line, so no knife geometry survives into the result.
    ribbon_faces = [f for f in bm.faces if f[tag_layer] == 1]
    if ribbon_faces:
        bmesh.ops.delete(bm, geom=ribbon_faces, context='FACES')
    loose = [v for v in bm.verts if not v.link_faces]
    if loose:
        bmesh.ops.delete(bm, geom=loose, context='VERTS')

    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    bmesh.update_edit_mesh(obj.data, destructive=True)
    bpy.ops.object.mode_set(mode='OBJECT')

    # The tag attribute has served its purpose; leave no DynaX debris behind.
    attr = obj.data.attributes.get("dynax_ribbon")
    if attr is not None:
        obj.data.attributes.remove(attr)
    return True


def perform_spline_cut(context, obj, world_points, closed=True):
    """Cut ``obj`` along the ring defined by ``world_points`` (list of Vector,
    world space) into two separate objects ``DynaX_Proximal`` / ``DynaX_Distal``.

    Returns True on success, False on failure. This is a plain function (not an
    operator) so headless tests can drive it directly without a UI context.

    v1.20.8 strategy: a projected-curve knife intersection along the spline
    (see the module header). The cut cross-section is left OPEN (hollow) - the
    downstream Solidify-with-rim thickness step needs that open boundary to wrap
    into a wearable socket.

    FAILS SAFELY: the cut runs on a DUPLICATE of the clinician's object. The
    real object is only replaced once exactly two parts are confirmed; on any
    failure the duplicate is discarded and the original mesh is untouched.
    """
    if obj is None or obj.type != 'MESH':
        return False
    pts = [Vector((p[0], p[1], p[2])) for p in world_points]
    if not closed or len(pts) < 3:
        return False

    print("[DynaX] Starting cut operation...")
    print(f"[DynaX] Mesh: {len(obj.data.polygons)} faces, {len(pts)} spline points")

    # Reject a self-crossing ring up front - a figure-8 ribbon self-intersects
    # and the knife's result is undefined.
    if _check_self_intersection(pts):
        print("[DynaX] Cut aborted: the trim ring crosses itself.")
        return False

    if context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    original_name = obj.name
    original_matrix = obj.matrix_world.copy()

    # ── Work on a duplicate: the real mesh is never at risk ────────────────
    work = obj.copy()
    work.data = obj.data.copy()
    work.name = "DynaX_TrimWork_tmp"
    context.collection.objects.link(work)

    def _remove_object(candidate):
        """Remove an object that MAY already be gone.

        `_separate_loose` returns the work object as one of the parts, so
        discarding the parts already removes it - touching `work.name`
        afterwards raises ReferenceError on a freed StructRNA. The cleanup path
        must never be the thing that crashes.
        """
        if candidate is None:
            return
        try:
            name = candidate.name
        except ReferenceError:
            return
        existing = bpy.data.objects.get(name)
        if existing is not None:
            bpy.data.objects.remove(existing, do_unlink=True)

    def _discard(parts=()):
        for part in parts:
            _remove_object(part)
        _remove_object(work)

    try:
        _clean_target_mesh(context, work)
        print("[DynaX] Pre-clean complete. Running knife intersection...")
        if not _knife_ribbon_cut(context, work, pts):
            print("[DynaX] Knife intersection did not run.")
            _discard()
            return False
        parts = _separate_loose(context, work)
    except Exception as exc:  # noqa: BLE001 - the original must survive
        log_operator_error("dynax.trimline_cut", exc)
        _discard()
        return False

    # ── Drop cut debris ────────────────────────────────────────────────────
    # The knife can leave a handful of single-face slivers where the ribbon
    # clips a face corner (measured: two 1-face fragments on a real scan). They
    # are not clinical geometry and must not show up as "parts" the clinician
    # has to identify and delete by hand ("no accidental fragments").
    #
    # The threshold is deliberately tiny and relative, so it can only ever catch
    # true debris: a real trimmed piece is orders of magnitude larger. If a cut
    # ever produced a genuinely small-but-real piece, it would be kept and the
    # "exactly 2 parts" check below would reject the cut rather than silently
    # deleting the clinician's geometry.
    total_faces = sum(len(p.data.polygons) for p in parts)
    debris_limit = max(8, int(total_faces * 0.002))
    keep, debris = [], []
    for part in parts:
        (debris if len(part.data.polygons) <= debris_limit else keep).append(part)
    if debris:
        print(f"[DynaX] Discarding {len(debris)} cut fragment(s) "
              f"(<= {debris_limit} faces)")
        for part in debris:
            _remove_object(part)
    parts = keep

    # A trim must sever the scan into exactly two pieces. More than two means
    # the ring caught something unexpected, and guessing which pieces the
    # clinician wanted is not acceptable on clinical geometry - fail instead and
    # leave the original mesh untouched.
    if len(parts) != 2:
        print(f"[DynaX] Cut produced {len(parts)} part(s) - rejecting.")
        _discard(parts)
        return False

    # Light rim relax only. The knife produces a continuous, non-stepped
    # boundary, so the old aggressive repair chain (degenerate-sliver removal +
    # 5 smoothing passes + coplanar cap deletion) is neither needed nor wanted -
    # it was compensating for the retired bisect's staircase.
    for part in parts:
        _smooth_boundary(part, factor=0.25, iterations=1)

    # ── Commit: the real object is replaced only now, on success ───────────
    if original_name in bpy.data.objects:
        bpy.data.objects.remove(bpy.data.objects[original_name], do_unlink=True)
    for part in parts:
        part.matrix_world = original_matrix
    _name_parts(parts)
    print(f"[DynaX] Cut complete: {len(parts)} parts")
    return True


class DynaxTrimlineCut(Operator):
    """Cut the mesh along the closed ring into two separate objects"""
    bl_idname = "dynax.trimline_cut"
    bl_label = "Cut into two parts"
    bl_options = {'REGISTER', 'UNDO'}

    @creator_guard("The cut could not be completed. Your mesh was not changed — "
                   "see the DynaX log for details.")
    def execute(self, context):
        curve_obj = bpy.data.objects.get(CURVE_NAME)
        if not curve_obj:
            self.report({'ERROR'}, "No trim line found. Place points first.")
            return {'CANCELLED'}

        # Flush any in-progress curve edits to data before reading control points.
        # If the user moved points in Tab/Edit mode and clicked Cut while still in
        # edit mode, the spline.points co's aren't committed until we leave edit
        # mode - so we'd otherwise cut along the STALE pre-edit positions (Fix 1).
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        pts, is_cyclic = _curve_world_points(curve_obj)
        if not is_cyclic or len(pts) < 3:
            self.report({'ERROR'},
                "Close the loop first (need a closed ring of 3+ points to cut).")
            return {'CANCELLED'}

        target_name = curve_obj.get("dynax_trim_target", "") \
            or context.scene.get(TARGET_KEY, "")
        obj = bpy.data.objects.get(target_name) if target_name else None
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Target mesh not found.")
            return {'CANCELLED'}

        # Reject a self-crossing ring before attempting the cut - it can freeze
        # Blender at the C level inside the bisect on degenerate geometry.
        if _check_self_intersection(pts):
            self.report({'ERROR'},
                "The trim ring crosses itself - adjust the points so the loop "
                "doesn't cross over itself, then cut again.")
            return {'CANCELLED'}

        if not perform_spline_cut(context, obj, pts, closed=True):
            # perform_spline_cut works on a duplicate and only commits on
            # success, so the clinician's mesh is untouched here.
            self.report({'ERROR'},
                "Cut failed — your mesh is unchanged. Try editing the points so "
                "the ring sits cleanly around the limb, then cut again.")
            return {'CANCELLED'}

        # Remove the curve + clear the point store (also tears down the overlay)
        if bpy.data.objects.get(CURVE_NAME):
            bpy.data.objects.remove(curve_obj, do_unlink=True)
        _clear_points(context)

        parts = [o for o in bpy.data.objects
                 if o.name.startswith("DynaX_Proximal")
                 or o.name.startswith("DynaX_Distal")
                 or o.name.startswith("DynaX_Part_")]
        context.scene["dynax_cut_done"] = True
        context.scene["dynax_trim_stage"] = 'CUT'
        self.report({'INFO'},
            f"✓ Cut into {len(parts)} part(s). Pick a part, then apply thickness.")
        return {'FINISHED'}


class DynaxTrimlineClear(Operator):
    """Remove all placed points / the trim line without cutting"""
    bl_idname = "dynax.trimline_clear"
    bl_label = "Clear all points"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass
        _clear_points(context)
        # "Start over" clears BOTH trimline methods' state: Method B's points
        # above, and Method A's locked region here. Without this the group
        # survived a Start over and the next separation could consume it.
        invalidate_selection(context)
        context.scene["dynax_trim_stage"] = 'IDLE'
        self.report({'INFO'}, "Trim line cleared")
        return {'FINISHED'}


# ── Pick a part to work on ─────────────────────────────────────────────────────

class DynaxPickPart(Operator):
    """Make a cut part the active object for thickening"""
    bl_idname = "dynax.pick_part"
    bl_label = "Pick part"
    bl_options = {'REGISTER'}

    part_name: bpy.props.StringProperty()

    @creator_guard("Could not pick that part. See the DynaX log for details.")
    def execute(self, context):
        obj = bpy.data.objects.get(self.part_name)
        if not obj:
            self.report({'ERROR'}, f"Part '{self.part_name}' not found")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj
        self.report({'INFO'}, f"✓ {self.part_name} selected — apply thickness in next step")
        return {'FINISHED'}


# ── Extra trim tools kept from earlier versions (still referenced in the panel) ─

class DynaxTrimlineQuickSlice(Operator):
    """Quick flat horizontal slice at a given height"""
    bl_idname = "dynax.trimline_quick_slice"
    bl_label = "Quick slice"
    bl_options = {'REGISTER', 'UNDO'}
    height_mm: bpy.props.FloatProperty(default=150.0, min=0.0, max=2000.0)
    keep_top: bpy.props.BoolProperty(default=True)
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        zmin, zmax = _get_world_bounds(obj)
        z_cut = zmin + self.height_mm   # mm-space: scene units = mm (no /1000)
        inv = obj.matrix_world.inverted()
        pco = inv @ Vector((0, 0, z_cut))
        pno = (inv.to_3x3() @ Vector((0, 0, 1))).normalized()
        try:
            bpy.ops.object.mode_set(mode='EDIT')
            bm = bmesh.from_edit_mesh(obj.data)
            geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
            bmesh.ops.bisect_plane(bm, geom=geom, plane_co=pco, plane_no=pno,
                                   clear_inner=self.keep_top, clear_outer=not self.keep_top)
            boundary = [e for e in bm.edges if e.is_boundary]
            if boundary:
                bmesh.ops.holes_fill(bm, edges=boundary)
            bmesh.update_edit_mesh(obj.data, destructive=True)
        except Exception as e:
            self.report({'ERROR'}, f"Slice failed: {e}")
            return {'CANCELLED'}
        bpy.ops.object.mode_set(mode='OBJECT')
        return {'FINISHED'}


class DynaxFlareEdge(Operator):
    """Flare the open rim of a cut part outward"""
    bl_idname = "dynax.flare_edge"
    bl_label = "Flare open rim"
    bl_options = {'REGISTER', 'UNDO'}
    flare_mm: bpy.props.FloatProperty(default=5.0, min=0.5, max=30.0)
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='EDIT')
        bm = bmesh.from_edit_mesh(obj.data)
        bverts = {v for e in bm.edges if e.is_boundary for v in e.verts}
        if not bverts:
            bpy.ops.object.mode_set(mode='OBJECT')
            self.report({'WARNING'}, "No open rim found")
            return {'CANCELLED'}
        d = self.flare_mm   # mm-space: scene units = mm (no /1000)
        cx = sum(v.co.x for v in bm.verts) / len(bm.verts)
        cy = sum(v.co.y for v in bm.verts) / len(bm.verts)
        for v in bverts:
            dx, dy = v.co.x - cx, v.co.y - cy
            ln = math.sqrt(dx*dx + dy*dy)
            if ln > 1e-6:
                v.co.x += dx/ln * d
                v.co.y += dy/ln * d
        bmesh.update_edit_mesh(obj.data, destructive=False)
        bpy.ops.object.mode_set(mode='OBJECT')
        return {'FINISHED'}
