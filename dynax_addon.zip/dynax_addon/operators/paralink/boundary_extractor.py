# paralink/boundary_extractor.py
# Module 1 - Boundary Extractor
# Reads boundaries from source objects without modifying them (P1).

import bpy
import bmesh
import math
from mathutils import Vector
from .data_types import BoundaryResult

# Same tolerance family already proven in component_bridge.py's own
# _open_component_top (fix #1 there): a real STL's flat top is dozens of
# coplanar triangles, not one face - collecting only the single highest-Z
# face (as an earlier version of this module did) produces a 3-vertex
# "boundary" from one triangle instead of the real ~64+ vertex collar rim.
# Reused verbatim rather than re-discovered, since this exact failure mode
# is already documented against the real bundled SOCKET_COMPONENT.stl.
TOP_FACE_Z_TOLERANCE_MM = 3.0
TOP_FACE_NORMAL_Z_MIN = 0.5


class BoundaryExtractionError(Exception):
    pass


def extract_socket_boundary(socket_obj, transition_z=None):
    """
    Extract the socket outer wall boundary at transition_z.
    Does NOT modify the socket (bisect_plane runs on a throwaway bmesh
    copy of the mesh data, never written back to socket_obj.data).

    If transition_z is None, falls back to 15% up from the socket's own
    Z range (Module 3 normally supplies a geometry-driven value instead).

    Real bug found and fixed, before ever shipping this - verified against
    a real user socket, not assumed correct from the architecture doc's
    description alone: the originally-specified approach (select vertices
    within a world-Z band, then trace connected loops through mesh edges
    where BOTH endpoints fall in the band) sounds reasonable but breaks on
    real dense triangulated scan geometry. Measured directly: on the real
    socket this fragmented into 186 disconnected loop pieces (not one
    ring) out of 6737 candidate vertices, and "pick the loop with the
    highest average radius" - the spec's own stated tie-break - picked a
    13-vertex outlier fragment (73.1mm radius, a local scan-surface
    protrusion) over the actual largest connected fragment (271 vertices,
    42.7mm radius, itself still not a complete ring). Neither metric
    reliably identifies the true boundary on real geometry.

    Fixed with bmesh.ops.bisect_plane instead - already proven robust on
    real dense triangulated scan meshes earlier in this project (used for
    cross-section loop-counting when calibrating Smart Transition's rigid
    zone). Verified on the same real socket: exactly 1 continuous loop,
    357 edges, one clean pass - no fragmentation, no outlier-picking
    needed. This is graphically "a plane intersection" (P2 nominally
    warns against extracting boundaries via plane intersection, citing
    tilted/rotated sockets), but the two are not the same failure mode:
    P2's concern is a naive intersection ignoring how the socket is
    actually oriented. This one intersects in WORLD SPACE against a
    socket that has already been through DynaX's own alignment step
    (longest axis -> Z), so a world-Z-constant plane genuinely does cut a
    clean ring around the transition region for real aligned sockets -
    confirmed directly against the real case, not assumed.
    """
    mesh = socket_obj.data
    mat = socket_obj.matrix_world

    world_verts = [mat @ v.co for v in mesh.vertices]
    zs = [v.z for v in world_verts]
    z_min, z_max = min(zs), max(zs)

    if transition_z is None:
        transition_z = z_min + (z_max - z_min) * 0.15

    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    mat_inv = mat.inverted()
    local_plane_co = mat_inv @ Vector((0, 0, transition_z))
    local_plane_no = (mat_inv.to_3x3() @ Vector((0, 0, 1))).normalized()

    result = bmesh.ops.bisect_plane(
        bm, geom=bm.edges[:] + bm.faces[:],
        plane_co=local_plane_co, plane_no=local_plane_no,
        clear_inner=False, clear_outer=False,
    )
    # bisect_plane creates new vertices at the cut, invalidating the
    # lookup table built before the op ran - must re-index before any
    # further bm.verts[i] access.
    bm.verts.ensure_lookup_table()
    cut_edges = [e for e in result['geom_cut'] if isinstance(e, bmesh.types.BMEdge)]

    if len(cut_edges) < 8:
        bm.free()
        raise BoundaryExtractionError(
            f"Socket: bisect at Z={transition_z:.1f}mm produced too few "
            f"edges (found {len(cut_edges)}, need >=8). "
            f"Try a different transition height."
        )

    loops = _trace_loops_from_boundary_edges(bm, cut_edges)
    if not loops:
        bm.free()
        raise BoundaryExtractionError(
            f"Socket: no connected loop found at Z={transition_z:.1f}mm"
        )

    # Separate loops by AVERAGE RADIUS, not vertex count. A solidified socket
    # shell cut at transition_z exposes an annular pair (outer wall + inner
    # cavity wall) whose vertex counts are near-identical (e.g. 239 vs 238) and
    # can tie - the old "longest loop" tie-break then picked the inner wall as
    # often as the outer, inconsistently per component position. Radius is the
    # unambiguous discriminator: the outer wall always has the larger radius.
    ranked = _rank_loops_by_radius(bm, mat, loops)
    chosen_loop = ranked[0][0]   # largest radius = outer wall

    positions = [mat @ bm.verts[i].co.copy() for i in chosen_loop]
    bm.free()

    return _build_boundary_result(positions, 'socket')


def extract_socket_boundaries(socket_obj, transition_z=None):
    """
    Annular extraction (v1.20 shell-aware ParaLink): return BOTH the outer wall
    boundary and the inner cavity-wall boundary at transition_z as a tuple
    (outer, inner) of BoundaryResult. Both come from the SAME bisect at the same
    Z (the two largest-radius loops), so they are concentric and co-planar - the
    two loops the transition skin's two top rings weld onto. Does NOT modify the
    socket (bisect runs on a throwaway bmesh copy, per extract_socket_boundary).

    inner is None only if the cut exposes a single loop (a non-shell / solid
    socket); callers then fall back to the single-wall transition.
    """
    mesh = socket_obj.data
    mat = socket_obj.matrix_world

    world_verts = [mat @ v.co for v in mesh.vertices]
    zs = [v.z for v in world_verts]
    z_min, z_max = min(zs), max(zs)
    if transition_z is None:
        transition_z = z_min + (z_max - z_min) * 0.15

    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    mat_inv = mat.inverted()
    local_plane_co = mat_inv @ Vector((0, 0, transition_z))
    local_plane_no = (mat_inv.to_3x3() @ Vector((0, 0, 1))).normalized()

    result = bmesh.ops.bisect_plane(
        bm, geom=bm.edges[:] + bm.faces[:],
        plane_co=local_plane_co, plane_no=local_plane_no,
        clear_inner=False, clear_outer=False,
    )
    bm.verts.ensure_lookup_table()
    cut_edges = [e for e in result['geom_cut'] if isinstance(e, bmesh.types.BMEdge)]
    if len(cut_edges) < 8:
        bm.free()
        raise BoundaryExtractionError(
            f"Socket: bisect at Z={transition_z:.1f}mm produced too few "
            f"edges (found {len(cut_edges)}, need >=8)."
        )

    loops = _trace_loops_from_boundary_edges(bm, cut_edges)
    if not loops:
        bm.free()
        raise BoundaryExtractionError(
            f"Socket: no connected loop found at Z={transition_z:.1f}mm"
        )

    ranked = _rank_loops_by_radius(bm, mat, loops)
    outer_positions = [mat @ bm.verts[i].co.copy() for i in ranked[0][0]]
    inner_positions = None
    if len(ranked) >= 2:
        inner_positions = [mat @ bm.verts[i].co.copy() for i in ranked[1][0]]
    bm.free()

    outer = _build_boundary_result(outer_positions, 'socket')
    inner = (_build_boundary_result(inner_positions, 'socket_inner')
             if inner_positions is not None else None)
    return outer, inner


def _rank_loops_by_radius(bm, mat, loops):
    """Return [(loop, radius), ...] sorted by average XY radius, largest first."""
    ranked = []
    for loop in loops:
        ps = [mat @ bm.verts[i].co for i in loop]
        c = sum(ps, Vector()) / len(ps)
        r = sum(((p.x - c.x) ** 2 + (p.y - c.y) ** 2) ** 0.5 for p in ps) / len(ps)
        ranked.append((loop, r))
    ranked.sort(key=lambda t: t[1], reverse=True)
    return ranked


def extract_component_boundary(comp_obj):
    """
    Extract the component collar (top rim boundary).
    Does NOT modify the component. Does NOT delete any face.
    If the top is already an open boundary loop, trace it directly.
    If the top is closed, it is real STL geometry - dozens of coplanar
    triangles, not a single face - so every face within
    TOP_FACE_Z_TOLERANCE_MM of the true top AND with an upward-facing
    normal is collected together, and the OUTER perimeter edges of that
    combined patch (edges used by exactly one of those top faces) become
    the boundary loop.
    """
    mesh = comp_obj.data
    mat = comp_obj.matrix_world
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    bm.normal_update()

    if not bm.faces:
        bm.free()
        raise BoundaryExtractionError("Component has no faces.")

    boundary_edges = [e for e in bm.edges if e.is_boundary]
    if boundary_edges:
        loops = _trace_loops_from_boundary_edges(bm, boundary_edges)
        if loops:
            loops.sort(
                key=lambda l: sum((mat @ bm.verts[i].co).z for i in l) / len(l),
                reverse=True
            )
            positions = [mat @ bm.verts[i].co.copy() for i in loops[0]]
            bm.free()
            return _build_boundary_result(positions, 'component')

    max_z = max(v.co.z for v in bm.verts)

    def face_avg_z(f):
        return sum(v.co.z for v in f.verts) / len(f.verts)

    top_faces = [
        f for f in bm.faces
        if f.normal.z > TOP_FACE_NORMAL_Z_MIN
        and (max_z - face_avg_z(f)) <= TOP_FACE_Z_TOLERANCE_MM
    ]
    if not top_faces:
        top_faces = [f for f in bm.faces if (max_z - face_avg_z(f)) <= TOP_FACE_Z_TOLERANCE_MM]
    if not top_faces:
        bm.free()
        raise BoundaryExtractionError("Component: no detectable top opening.")

    top_face_set = set(top_faces)
    perimeter_edges = [
        e for f in top_faces for e in f.edges
        if len([lf for lf in e.link_faces if lf in top_face_set]) == 1
    ]
    loops = _trace_loops_from_boundary_edges(bm, perimeter_edges)
    if not loops:
        bm.free()
        raise BoundaryExtractionError("Component: top face patch has no traceable perimeter.")
    loops.sort(key=len, reverse=True)
    chosen_loop = loops[0]

    positions = [mat @ bm.verts[i].co.copy() for i in chosen_loop]
    bm.free()

    result = _build_boundary_result(positions, 'component')
    result.is_closed = True  # signal to Join Engine: this collar is still capped
    return result


def _trace_loops_from_boundary_edges(bm, boundary_edges):
    """Trace connected loops from boundary edges."""
    adj = {}
    for e in boundary_edges:
        v0, v1 = e.verts[0].index, e.verts[1].index
        adj.setdefault(v0, []).append(v1)
        adj.setdefault(v1, []).append(v0)

    visited = set()
    loops = []
    for start in adj:
        if start in visited:
            continue
        loop = []
        current, prev = start, None
        while True:
            visited.add(current)
            loop.append(current)
            neighbors = [n for n in adj.get(current, [])
                         if n != prev and n not in visited]
            if not neighbors:
                break
            prev, current = current, neighbors[0]
        if len(loop) >= 3:
            loops.append(loop)

    return loops


def _build_boundary_result(positions, source_name):
    """Build a BoundaryResult from a list of world-space Vectors."""
    if not positions:
        raise BoundaryExtractionError(f"{source_name}: empty position list")

    centroid = sum(positions, Vector()) / len(positions)
    radii = [math.sqrt((p.x - centroid.x) ** 2 + (p.y - centroid.y) ** 2)
             for p in positions]
    z_values = [p.z for p in positions]

    return BoundaryResult(
        positions=positions,
        centroid=centroid,
        radius_avg=sum(radii) / len(radii),
        radius_min=min(radii),
        radius_max=max(radii),
        z_avg=sum(z_values) / len(z_values),
        vertex_count=len(positions),
        is_closed=False,
        source_name=source_name,
    )
