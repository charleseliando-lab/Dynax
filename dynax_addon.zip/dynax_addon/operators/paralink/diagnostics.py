# paralink/diagnostics.py
# Sprint 0 visualization: draw boundaries and mapping as viewport objects.

import bpy
import bmesh
from mathutils import Vector


SOCKET_BOUNDARY_NAME    = "paralink_socket_boundary"
COMPONENT_BOUNDARY_NAME = "paralink_component_boundary"
MAPPING_LINES_NAME      = "paralink_mapping_lines"


def draw_boundary_curve(positions, name, color=(1.0, 0.5, 0.0)):
    """Draw a boundary as a wireframe curve object in the viewport."""
    existing = bpy.data.objects.get(name)
    if existing:
        bpy.data.objects.remove(existing, do_unlink=True)

    if not positions:
        return None

    bm = bmesh.new()
    verts = [bm.verts.new(p) for p in positions]
    bm.verts.ensure_lookup_table()

    for i in range(len(verts)):
        bm.edges.new((verts[i], verts[(i + 1) % len(verts)]))

    mesh = bpy.data.meshes.new(name + "_mesh")
    bm.to_mesh(mesh)
    bm.free()

    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)

    mat = bpy.data.materials.new(name + "_mat")
    mat.diffuse_color = (*color, 1.0)
    mat.use_nodes = False
    mesh.materials.append(mat)

    obj.display_type = 'WIRE'
    obj.show_in_front = True
    return obj


def draw_mapping_lines(socket_r, component_r, name=MAPPING_LINES_NAME):
    """
    Draw correspondence lines between socket and component resampled points.
    """
    existing = bpy.data.objects.get(name)
    if existing:
        bpy.data.objects.remove(existing, do_unlink=True)

    if not socket_r or not component_r:
        return None

    n = min(len(socket_r), len(component_r))

    bm = bmesh.new()
    for i in range(n):
        v0 = bm.verts.new(socket_r[i])
        v1 = bm.verts.new(component_r[i])
        bm.edges.new((v0, v1))

    mesh = bpy.data.meshes.new(name + "_mesh")
    bm.to_mesh(mesh)
    bm.free()

    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    obj.display_type = 'WIRE'
    obj.show_in_front = True
    return obj


def clear_diagnostics():
    """Remove all Sprint 0 diagnostic objects from the scene."""
    for name in [SOCKET_BOUNDARY_NAME,
                 COMPONENT_BOUNDARY_NAME,
                 MAPPING_LINES_NAME]:
        obj = bpy.data.objects.get(name)
        if obj:
            bpy.data.objects.remove(obj, do_unlink=True)


def print_diagnostics(socket_b, comp_b, mapping):
    """Print full diagnostic report to the Blender console."""
    d = mapping.diagnostics
    sep = "-" * 50
    print(f"\n{sep}")
    print(f"[ParaLink Sprint 0 Diagnostics]")
    print(f"{sep}")
    print(f"Socket Boundary")
    print(f"  Vertices:   {socket_b.vertex_count}")
    print(f"  Centroid:   ({socket_b.centroid.x:.1f}, "
          f"{socket_b.centroid.y:.1f}, {socket_b.centroid.z:.1f})mm")
    print(f"  Radius avg: {socket_b.radius_avg:.1f}mm")
    print(f"  Radius min: {socket_b.radius_min:.1f}mm")
    print(f"  Radius max: {socket_b.radius_max:.1f}mm")
    print(f"  Z avg:      {socket_b.z_avg:.1f}mm")
    print(f"{sep}")
    print(f"Component Boundary")
    print(f"  Vertices:   {comp_b.vertex_count}")
    print(f"  Centroid:   ({comp_b.centroid.x:.1f}, "
          f"{comp_b.centroid.y:.1f}, {comp_b.centroid.z:.1f})mm")
    print(f"  Radius avg: {comp_b.radius_avg:.1f}mm")
    print(f"  Z avg:      {comp_b.z_avg:.1f}mm")
    print(f"{sep}")
    print(f"Boundary Mapping")
    print(f"  Resampled to:     {d['n_points_after_resample']} points")
    print(f"  Twist:            {d['twist_deg']:.1f}deg")
    print(f"  Offset:           {d['offset_mm']:.1f}mm ({d['offset_direction']})")
    print(f"  Mapping quality:  {d['mapping_quality']*100:.1f}%")
    print(f"  Method:           {d['correspondence_method']}")
    if d['warnings']:
        print(f"  Warnings:")
        for w in d['warnings']:
            print(f"    ! {w}")
    else:
        print(f"  Warnings:         none")
    print(f"{sep}\n")
