# paralink/surface_generator.py
# Module 4 - Transition Surface Generator
# Generates the transition skin as independent new geometry - never
# deforms either source object (P1).

import bpy
import bmesh
import math
from mathutils import Vector

RING_VERT_COUNT = 64   # unused directly - all rings share mapping.n_points,
                        # kept only as a documented historical reference to
                        # component_bridge.py's own constant of the same name


PARALINK_PROFILES = {
    'SMOOTH': {
        "curve":          "SMOOTH",
        "rings_small":    3,
        "rings_medium":   5,
        "rings_large":    8,
        "smooth_passes":  8,
        "smooth_factor":  0.6,
    },
    'STRUCTURAL': {
        "curve":          "EASE",
        "rings_small":    4,
        "rings_medium":   6,
        "rings_large":    9,
        "smooth_passes":  2,
        "smooth_factor":  0.2,
    },
    'HYBRID': {
        "curve":          "SMOOTH",
        "rings_small":    4,
        "rings_medium":   6,
        "rings_large":    8,
        "smooth_passes":  4,
        "smooth_factor":  0.4,
    },
}


def _interpolate_curve(t, curve_type):
    """S-curve interpolation (migrated from component_bridge.py's _curve_t)."""
    if curve_type == 'LINEAR':
        return t
    elif curve_type == 'SMOOTH':
        return t * t * (3 - 2 * t)
    elif curve_type == 'EASE_IN':
        return t * t
    elif curve_type == 'EASE_OUT':
        return 1 - (1 - t) * (1 - t)
    elif curve_type == 'EASE':
        if t < 0.5:
            return 4 * t * t * t
        p = 2 * t - 2
        return 0.5 * p * p * p + 1
    return t


def _compute_ring_count(diameter_diff_mm, offset_mm, params):
    """Adaptive ring count based on geometry."""
    if diameter_diff_mm < 20.0:
        base = params["rings_small"]
    elif diameter_diff_mm < 50.0:
        base = params["rings_medium"]
    else:
        base = params["rings_large"]
    if offset_mm > 20.0:
        base += 2
    elif offset_mm > 10.0:
        base += 1
    return base


def generate_transition_surface(mapping, envelope, connection_style, context,
                                 inner_socket_boundary=None,
                                 outer_socket_boundary=None):
    """
    Generate the transition skin as a new standalone mesh object.

    Two modes:

    * SHELL-AWARE ANNULAR (v1.20, when inner_socket_boundary is given): the
      socket is a solidified shell, so the transition is built as a hollow
      neck matching the socket's wall thickness - an OUTER wall and an INNER
      cavity wall, closed at the distal end by a rim annulus + cavity floor,
      and OPEN only at its two top loops (which weld onto the socket's own
      exposed outer + inner wall loops in Module 7). The limb cavity is
      preserved because the inner wall is never filled - the old single cone
      collapsed the whole cavity into a solid funnel.

    * SINGLE-WALL FALLBACK (inner_socket_boundary is None): the original
      ring-stack cone from socket_resampled down to component_resampled. Used
      only for a non-shell / solid socket where no inner loop exists.

    socket_resampled and component_resampled are already resampled to the SAME
    n_points count by Module 2, so every ring has an identical vertex count.
    """
    params = PARALINK_PROFILES.get(connection_style, PARALINK_PROFILES['HYBRID'])

    socket_pts = mapping.socket_resampled
    comp_pts = mapping.component_resampled
    n = mapping.n_points

    sock_ctr = sum(socket_pts, Vector()) / n
    comp_ctr = sum(comp_pts, Vector()) / n
    sock_z = sock_ctr.z
    comp_z = comp_ctr.z
    sock_r = sum((p - sock_ctr).length for p in socket_pts) / n
    comp_r = sum((p - comp_ctr).length for p in comp_pts) / n
    diff_r = abs(sock_r - comp_r) * 2.0

    n_rings = _compute_ring_count(diff_r, mapping.offset_mm, params)
    curve_type = params["curve"]

    if inner_socket_boundary is not None and outer_socket_boundary is not None:
        print(f"[ParaLink] Surface Generator (annular): {n_rings} rings, "
              f"style={connection_style}, curve={curve_type}")
        return _build_annular_skin(
            outer_socket_boundary, inner_socket_boundary, comp_pts,
            n_rings, curve_type, context
        )

    print(f"[ParaLink] Surface Generator (single-wall): {n_rings} rings, "
          f"style={connection_style}, curve={curve_type}")
    all_rings = _build_ring_stack(
        socket_pts, comp_pts,
        sock_ctr, comp_ctr,
        sock_r, comp_r, sock_z, comp_z,
        n_rings, n, curve_type
    )
    return _build_transition_skin_mesh(all_rings, n, context)


# ---------------------------------------------------------------------------
# Shell-aware annular transition (v1.20)
# ---------------------------------------------------------------------------

def _resample_loop_local(positions, n):
    """Arc-length resample a loop to n points (local copy - Module 2's own
    _resample_loop is private and this module must not couple to it)."""
    count = len(positions)
    if count == 0:
        return [Vector((0, 0, 0))] * n
    dist = [0.0]
    for i in range(1, count):
        dist.append(dist[-1] + (positions[i] - positions[i - 1]).length)
    total = dist[-1] + (positions[0] - positions[-1]).length
    if total < 1e-8:
        return [positions[0].copy()] * n
    out = []
    for j in range(n):
        target = total * j / n
        for i in range(1, len(dist)):
            if dist[i] >= target:
                seg = dist[i] - dist[i - 1]
                t = 0.0 if seg < 1e-8 else (target - dist[i - 1]) / seg
                out.append(positions[i - 1].lerp(positions[i], t))
                break
        else:
            out.append(positions[-1].copy())
    return out


def _shrink_toward(pts, ctr, amount):
    """Move each point radially toward ctr in XY by `amount` mm (clamped so it
    never crosses the centre), Z unchanged - builds the inner bottom loop from
    the outer bottom loop at a constant wall thickness."""
    out = []
    for p in pts:
        dx = p.x - ctr.x
        dy = p.y - ctr.y
        r = math.hypot(dx, dy)
        if r < 1e-6:
            out.append(p.copy())
            continue
        new_r = max(r * 0.2, r - amount)   # clamp: keep >=20% of radius
        s = new_r / r
        out.append(Vector((ctr.x + dx * s, ctr.y + dy * s, p.z)))
    return out


def _resample_and_align(loop, reference, n):
    """Resample `loop` to n points and rotate it to the correspondence with
    `reference` (same length n) that minimises summed squared distance, matching
    winding first. Used to align the component ring to the socket's native outer
    ring so every synthetic ring keeps consistent index semantics."""
    r = _resample_loop_local(loop, n)
    if _signed_area_xy(r) * _signed_area_xy(reference) < 0:
        r = list(reversed(r))
    best_off, best_cost = 0, float('inf')
    for off in range(n):
        cost = sum((reference[i] - r[(i + off) % n]).length_squared
                   for i in range(0, n, max(1, n // 64)))  # subsample for speed
        if cost < best_cost:
            best_cost, best_off = cost, off
    return r[best_off:] + r[:best_off]


def _build_annular_skin(outer_boundary, inner_boundary, comp_resampled,
                        n_rings, curve_type, context):
    """
    Build the transition as an OUTER-wall-only sleeve with a closed top disc and
    a closed bottom cap. The socket's inner wall / cavity is NEVER routed to the
    component - the top disc seals the socket's cut opening at the transition
    level, so the cavity keeps a solid floor with no hole, and the sleeve carries
    the socket OUTER wall down to the component.

    Skin geometry (all one closed shell, welded onto the socket in Module 7):
      * OUTER sleeve wall : socket outer loop (O_s) -> component collar, R rings
      * TOP disc          : annulus O_s <-> I_s (closes the wall cross-section)
                            + fan I_s -> centre  (caps the cavity = socket floor)
      * BOTTOM cap        : fan component-collar ring -> centre (closes the sleeve
                            base; the component welds/sits under this cap)

    The top disc's O_s and I_s rings are the socket's EXACT native cut loops
    (outer_boundary/inner_boundary.positions), so Module 7 merges them onto the
    working socket's own outer + inner cut loops (same bisect, same Z). The inner
    loop is only CAPPED here - never extended down into the component - which is
    what removes the floor hole the earlier inner-wall/rim version produced.
    """
    socket_outer = [p.copy() for p in outer_boundary.positions]
    socket_inner = [p.copy() for p in inner_boundary.positions]
    no = len(socket_outer)
    ni = len(socket_inner)
    R = n_rings + 2

    sock_ctr = sum(socket_outer, Vector()) / no
    top_z = sum(p.z for p in socket_outer) / no

    comp_outer = _resample_and_align(comp_resampled, socket_outer, no)
    comp_ctr = sum(comp_outer, Vector()) / no

    bm = bmesh.new()

    # Outer sleeve wall rings: O_s (k=0, native) -> component collar (k=R-1).
    outer_rings = []
    for k in range(R):
        ct = _interpolate_curve(k / (R - 1), curve_type)
        outer_rings.append([bm.verts.new(socket_outer[i].lerp(comp_outer[i], ct))
                            for i in range(no)])

    # Inner top ring (I_s, native) and its loop edges - top-disc only, no wall.
    inner_top = [bm.verts.new(p) for p in socket_inner]
    for i in range(ni):
        bm.edges.new((inner_top[i], inner_top[(i + 1) % ni]))
    # O_s loop edges (created before the wall faces so both are clean loops for
    # bridge_loops, which stitches the differing outer/inner counts).
    for i in range(no):
        bm.edges.new((outer_rings[0][i], outer_rings[0][(i + 1) % no]))
    bm.edges.ensure_lookup_table()

    def _loop_edges(ring, m):
        es = []
        for i in range(m):
            e = bm.edges.get((ring[i], ring[(i + 1) % m]))
            if e is not None:
                es.append(e)
        return es

    # TOP disc: annulus O_s <-> I_s, then fan I_s -> centre (cavity floor).
    bmesh.ops.bridge_loops(bm, edges=_loop_edges(outer_rings[0], no)
                           + _loop_edges(inner_top, ni))
    top_c = bm.verts.new(Vector((sock_ctr.x, sock_ctr.y, top_z)))
    for i in range(ni):
        bm.faces.new((top_c, inner_top[(i + 1) % ni], inner_top[i]))

    # OUTER sleeve wall faces.
    for k in range(R - 1):
        for i in range(no):
            j = (i + 1) % no
            bm.faces.new((outer_rings[k][i], outer_rings[k][j],
                          outer_rings[k + 1][j], outer_rings[k + 1][i]))

    # BOTTOM cap: fan the component-collar ring to a base centre.
    bot_c = bm.verts.new(Vector((comp_ctr.x, comp_ctr.y, comp_ctr.z)))
    for i in range(no):
        bm.faces.new((bot_c, outer_rings[R - 1][i], outer_rings[R - 1][(i + 1) % no]))

    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    mesh = bpy.data.meshes.new("paralink_transition_skin")
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()
    obj = bpy.data.objects.new("paralink_transition_skin", mesh)
    context.collection.objects.link(obj)
    print(f"[ParaLink] Annular sleeve: outer {no}v/ring, inner cap {ni}v, "
          f"rings={R} (outer-only, cavity capped at transition)")
    return obj


def _signed_area_xy(pts):
    """Shoelace signed area of a loop's XY projection. Sign gives winding
    direction (positive = CCW looking down +Z, negative = CW)."""
    n = len(pts)
    area = 0.0
    for i in range(n):
        j = (i + 1) % n
        area += pts[i].x * pts[j].y - pts[j].x * pts[i].y
    return area


def _build_ring_stack(socket_pts, comp_pts,
                       sock_ctr, comp_ctr,
                       sock_r, comp_r, sock_z, comp_z,
                       n_rings, n, curve_type):
    """
    Build the ordered list of rings from socket to component.
    ring[0]       = socket_pts (real socket shape, unscaled - t=0 exactly)
    ring[1..N-1]  = synthetic circles, first one scaled from the real
                    socket shape to avoid a hard shape discontinuity
    ring[N]       = comp_pts (real component collar)

    Canonical winding (position-dependent-spike fix): the socket loop's own
    winding is the reference direction for the WHOLE stack. Investigation
    across four component positions showed the real end-rings (socket loop,
    scaled socket loop, component collar) inherit whatever direction the
    boundary extractor happened to trace - CCW at some positions, CW at
    others (the bisect-plane loop trace isn't canonicalised, and the
    auto-detected transition_z lands on different topology per position).
    The synthetic middle rings, meanwhile, were ALWAYS generated CCW
    (cos/sin over 0->2pi). When the socket traced CW (e.g. component
    offset anteriorly), the stack flipped winding twice - at the socket->
    synthetic seam and the synthetic->component seam - and each flip made
    the connecting quad strip span the full ring diameter (measured: mean
    correspondence edge 61mm/47mm vs a normal 3-4mm), i.e. self-
    intersecting bowtie faces = the collapsed spike. Fix: derive the
    reference winding from the socket loop and generate every synthetic
    ring in that same direction (angle_sign), reversing comp_pts if it
    disagrees, so the whole stack winds one way.
    """
    sock_area = _signed_area_xy(socket_pts)
    comp_area = _signed_area_xy(comp_pts)

    if (sock_area > 0) != (comp_area > 0):
        comp_pts = list(reversed(comp_pts))
        print("[ParaLink] Component winding reversed to match socket")

    angle_sign = 1.0 if sock_area > 0 else -1.0  # CCW=+1, CW=-1

    # Rotational phase (residual spiral-shear fix): the synthetic rings are
    # generated with vertex 0 on the +X axis (angle 0). The real end-rings
    # (socket loop, scaled socket loop, component collar) start at whatever
    # vertex the boundary trace began on - an arbitrary angle that varies
    # with component position. When that angle isn't ~0, synthetic vertex j
    # and real vertex j point in different directions, so the quad strip at
    # each real<->synthetic seam shears diagonally (measured: worst seam
    # 32-47mm vs a normal 3-5mm ring spacing, seen as a spiral twist in the
    # funnel wall). Fix: start every synthetic ring at the same angle as the
    # mapped socket loop's own vertex 0. The Boundary Mapper already index-
    # aligns comp_pts to socket_pts, so socket_pts[0] and comp_pts[0] sit at
    # essentially the same angle (measured within +-1.3deg across positions)
    # - a single socket-derived phase fixes both the socket->synthetic and
    # synthetic->component seams. Only the start vertex rotates; the rings
    # are still the same synthetic circles (same centre/radius/count).
    ref = socket_pts[0] - sock_ctr
    phase = math.atan2(ref.y, ref.x) if (ref.x * ref.x + ref.y * ref.y) > 1e-12 else 0.0

    rings = [socket_pts]

    for i in range(n_rings):
        t = (i + 1) / (n_rings + 1)
        t_c = _interpolate_curve(t, curve_type)

        z = sock_z + t * (comp_z - sock_z)
        cx = sock_ctr.x + t * (comp_ctr.x - sock_ctr.x)
        cy = sock_ctr.y + t * (comp_ctr.y - sock_ctr.y)
        r = sock_r + t_c * (comp_r - sock_r)

        if i == 0:
            scale = 1.0 - t_c * (1.0 - comp_r / max(sock_r, 0.01))
            ring_pts = []
            for pos in socket_pts:
                ox = pos.x - sock_ctr.x
                oy = pos.y - sock_ctr.y
                ring_pts.append(Vector((cx + ox * scale, cy + oy * scale, z)))
            rings.append(ring_pts)
        else:
            ring_pts = []
            for j in range(n):
                angle = phase + angle_sign * 2 * math.pi * j / n
                ring_pts.append(Vector((cx + r * math.cos(angle),
                                         cy + r * math.sin(angle),
                                         z)))
            rings.append(ring_pts)

    rings.append(comp_pts)
    return rings


def _build_transition_skin_mesh(rings, n, context):
    """
    Build a mesh object from an ordered stack of rings. Every ring in the
    stack has exactly n points (guaranteed by Module 2's resampling), so
    each adjacent pair connects with a clean n-quad strip.
    """
    all_verts = []
    for ring in rings:
        all_verts.extend(ring)

    all_faces = []
    for i in range(len(rings) - 1):
        offset = i * n
        next_offset = (i + 1) * n
        for j in range(n):
            jn = (j + 1) % n
            all_faces.append((
                offset + j,
                offset + jn,
                next_offset + jn,
                next_offset + j,
            ))

    mesh = bpy.data.meshes.new("paralink_transition_skin")
    mesh.from_pydata([v.to_tuple() for v in all_verts], [], all_faces)
    mesh.update()

    obj = bpy.data.objects.new("paralink_transition_skin", mesh)
    context.collection.objects.link(obj)

    print(f"[ParaLink] Transition skin: "
          f"{len(all_verts)} verts, {len(all_faces)} faces")
    return obj
