# paralink/surface_optimiser.py
# Module 6 - Surface Optimiser
# Smooths the transition skin only. Never touches source objects - the
# rigid-zone-exclusion concern that applies to Smart Transition's own
# post-Generate smoothing does not apply here: neither the socket nor the
# component is present in this mesh, only the generated skin.

import bmesh


def optimise_surface(transition_skin, support_objects,
                      connection_style, params):
    """
    Apply Laplacian smoothing to transition skin. Intensity varies by
    connection style. Never touches source objects.
    """
    n_passes = params.get("smooth_passes", 4)
    factor = params.get("smooth_factor", 0.4)

    if n_passes == 0:
        return

    mesh = transition_skin.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    all_verts = list(bm.verts)

    for _ in range(n_passes):
        bmesh.ops.smooth_laplacian_vert(
            bm,
            verts=all_verts,
            lambda_factor=factor,
            lambda_border=factor * 0.5,
            use_x=True, use_y=True, use_z=True,
            preserve_volume=True,
        )

    bm.to_mesh(mesh)
    bm.free()
    mesh.update()

    print(f"[ParaLink] Surface optimised: {n_passes} passes, "
          f"factor={factor}, style={connection_style}")
