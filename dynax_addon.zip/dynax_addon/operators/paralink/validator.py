# paralink/validator.py
# Module 8 - Validator
# Verifies the joined result and reports honestly. Does not repair - if
# open edges exist, the Join Engine has a design problem, not a cleanup
# problem (P5).

import bmesh
from mathutils import kdtree
from .data_types import ValidationResult

EXACT_MATCH_TOLERANCE_MM = 0.01
COMPONENT_PRESERVED_MIN_RATIO = 0.95
SOCKET_PRESERVED_MIN_RATIO = 0.999


def count_open_edges(obj):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    count = len([e for e in bm.edges if e.is_boundary])
    bm.free()
    return count


def _match_ratio(snapshot_positions, result_kdtree):
    """
    Fraction of snapshot_positions found within EXACT_MATCH_TOLERANCE_MM of
    some vertex in the result mesh. Uses a KDTree (mathutils.kdtree, same
    acceleration structure Blender's own BVH-adjacent tools use) since a
    naive nearest-neighbour search would be O(n*m) - too slow for a
    ~30k-vertex result checked against thousands of snapshot points.
    """
    if not snapshot_positions:
        return 1.0
    matched = 0
    for p in snapshot_positions:
        _co, _idx, dist = result_kdtree.find(p)
        if dist is not None and dist <= EXACT_MATCH_TOLERANCE_MM:
            matched += 1
    return matched / len(snapshot_positions)


def validate_result(result_obj, socket_snapshot, comp_snapshot):
    """
    Verify join result and report honestly.

    socket_snapshot / comp_snapshot: lists of world-space Vector positions
    captured BEFORE Module 7 ran (see paralink_engine.py's
    _snapshot_preserved_region) - the true socket_obj/comp_obj no longer
    exist by the time this runs (join_bodies only removes them after a
    successful join), so preservation is checked by exact-position-match
    ratio against those snapshots, not by comparing live objects.

    component_preserved requires >= 95% of the component's own vertices
    to survive in the result at their exact original position - not 100%,
    since the deliberately-deleted top-face patch (opened to create the
    join seam) and the small number of near-seam vertices touched by
    join_bodies' seam-scoped merge are expected to be missing/moved.
    socket_preserved uses a much stricter 99.9%, since the socket_snapshot
    already excludes everything within 10mm of the transition zone (see
    _snapshot_preserved_region's own docstring) - virtually all of it
    should survive untouched by construction.
    """
    bm = bmesh.new()
    bm.from_mesh(result_obj.data)
    open_edges = len([e for e in bm.edges if e.is_boundary])
    v_count = len(bm.verts)
    f_count = len(bm.faces)
    volume = bm.calc_volume()

    result_kdtree = kdtree.KDTree(v_count)
    for i, v in enumerate(bm.verts):
        result_kdtree.insert(v.co, i)
    result_kdtree.balance()
    bm.free()

    comp_ratio = _match_ratio(comp_snapshot, result_kdtree)
    socket_ratio = _match_ratio(socket_snapshot, result_kdtree)
    component_preserved = comp_ratio >= COMPONENT_PRESERVED_MIN_RATIO
    socket_preserved = socket_ratio >= SOCKET_PRESERVED_MIN_RATIO

    warnings = []
    if open_edges > 0:
        warnings.append(
            f"{open_edges} open edges - not watertight. "
            f"Use Quick Bridge for a print-safe result."
        )
    if not component_preserved:
        warnings.append(
            f"Component only {comp_ratio*100:.1f}% preserved "
            f"(expected >= {COMPONENT_PRESERVED_MIN_RATIO*100:.0f}%) - "
            f"the Join Engine may have deformed it."
        )
    if not socket_preserved:
        warnings.append(
            f"Socket only {socket_ratio*100:.1f}% preserved "
            f"(expected >= {SOCKET_PRESERVED_MIN_RATIO*100:.0f}%) - "
            f"the Join Engine may have deformed it."
        )

    report_lines = [
        f"ParaLink Result:",
        f"  Watertight:   {'Yes' if open_edges == 0 else 'No - ' + str(open_edges) + ' open edges'}",
        f"  Vertices:     {v_count}",
        f"  Faces:        {f_count}",
        f"  Component preserved: {comp_ratio*100:.1f}%",
        f"  Socket preserved:    {socket_ratio*100:.1f}%",
    ]
    if warnings:
        report_lines.append("  Warnings:")
        for w in warnings:
            report_lines.append(f"    ! {w}")

    report = "\n".join(report_lines)
    print(f"[ParaLink] {report}")

    return ValidationResult(
        open_edge_count=open_edges,
        is_watertight=(open_edges == 0),
        vertex_count=v_count,
        face_count=f_count,
        volume_mm3=volume,
        component_preserved=component_preserved,
        socket_preserved=socket_preserved,
        warnings=warnings,
        report=report,
    )
