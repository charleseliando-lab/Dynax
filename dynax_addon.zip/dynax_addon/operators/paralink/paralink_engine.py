# paralink/paralink_engine.py
# ParaLink orchestrator - calls all 8 modules in sequence.

import bpy
import bmesh

from .boundary_extractor import (
    extract_socket_boundary, extract_socket_boundaries, extract_component_boundary
)
from .boundary_mapper import map_boundaries
from .envelope_analyser import analyse_envelope
from .surface_generator import generate_transition_surface, PARALINK_PROFILES
from .support_generator import generate_supports
from .surface_optimiser import optimise_surface
from .join_engine import join_bodies
from .validator import validate_result

DEBUG_PREFIX = "PARALINK_DEBUG_"

# Debug checkpoints leave a copy of each intermediate stage (boundaries,
# transition skin, assembly) in the scene. They are development scaffolding and
# must stay OFF in shipped builds: with the skin discarded by join_bodies'
# _bridge_chain rebuild (2026-07-12), the leftover "PARALINK_DEBUG_03_after_
# surface_optimisation" skin (a twisted intermediate that the final result no
# longer uses) was appearing in the viewport and read as a broken result.
# Previous debug objects are still cleared each run regardless of this flag.
PARALINK_DEBUG_CHECKPOINTS = False


def _clear_debug_checkpoints():
    """Remove checkpoint objects from the previous ParaLink debug run."""
    for obj in list(bpy.data.objects):
        if obj.name.startswith(DEBUG_PREFIX):
            bpy.data.objects.remove(obj, do_unlink=True)


def _debug_loop_object(context, positions, name):
    """Create a wire loop checkpoint from world-space positions."""
    if not positions:
        return None

    bm = bmesh.new()
    verts = [bm.verts.new(p) for p in positions]
    bm.verts.ensure_lookup_table()
    for i in range(len(verts)):
        bm.edges.new((verts[i], verts[(i + 1) % len(verts)]))

    mesh = bpy.data.meshes.new(name + "_mesh")
    bm.to_mesh(mesh)
    bm.free()

    obj = bpy.data.objects.new(name, mesh)
    context.collection.objects.link(obj)
    obj.display_type = 'WIRE'
    obj.show_in_front = True
    return obj


def _debug_mapping_object(context, socket_pts, comp_pts, name):
    """Create mapping-line checkpoint geometry from paired world points."""
    if not socket_pts or not comp_pts:
        return None

    bm = bmesh.new()
    n = min(len(socket_pts), len(comp_pts))
    for i in range(n):
        v0 = bm.verts.new(socket_pts[i])
        v1 = bm.verts.new(comp_pts[i])
        bm.edges.new((v0, v1))

    mesh = bpy.data.meshes.new(name + "_mesh")
    bm.to_mesh(mesh)
    bm.free()

    obj = bpy.data.objects.new(name, mesh)
    context.collection.objects.link(obj)
    obj.display_type = 'WIRE'
    obj.show_in_front = True
    return obj


def _checkpoint_boundary_mapping(context, socket_b, component_b, mapping):
    """Checkpoint 01: final extracted boundaries and correspondence."""
    _debug_loop_object(
        context, socket_b.positions,
        DEBUG_PREFIX + "01_after_boundary_mapping_socket_loop"
    )
    _debug_loop_object(
        context, component_b.positions,
        DEBUG_PREFIX + "01_after_boundary_mapping_component_loop"
    )
    _debug_mapping_object(
        context, mapping.socket_resampled, mapping.component_resampled,
        DEBUG_PREFIX + "01_after_boundary_mapping_correspondence"
    )
    print("[ParaLink Debug] Checkpoint 01 saved: after boundary mapping")


def _checkpoint_mesh_object(context, obj, name):
    """Create a mesh-data copy checkpoint without modifying the source."""
    if obj is None or obj.data is None:
        return None
    mesh = obj.data.copy()
    chk = bpy.data.objects.new(DEBUG_PREFIX + name, mesh)
    chk.matrix_world = obj.matrix_world.copy()
    context.collection.objects.link(chk)
    chk.display_type = obj.display_type
    chk.show_name = True
    print(f"[ParaLink Debug] Checkpoint saved: {chk.name}")
    return chk


def _snapshot_preserved_region(obj, exclude_below_z):
    """
    World-space positions of obj's vertices that ParaLink guarantees never
    move or get merged - used by Module 8 to verify preservation after the
    true original object has already been removed (see the join call site
    below for why this can't be done from the result object alone).

    For the component (exclude_below_z=None): every vertex except the
    small number ParaLink actually modifies (the deleted top-face patch,
    and the handful of near-seam vertices touched by join_bodies'
    seam-scoped merge) - checked by exact-match ratio in validate_result,
    not by predicting exactly which ones survive.

    For the socket (exclude_below_z=transition_z): only vertices comfortably
    above the transition zone, which the seam-scoped merge never reaches
    (it only touches vertices within a few mm of the transition plane) -
    a fixed 10mm margin above transition_z keeps this snapshot clear of
    the seam-merge capture radius (4mm, see join_engine.py) with room to
    spare.
    """
    mat = obj.matrix_world
    positions = []
    for v in obj.data.vertices:
        wp = mat @ v.co
        if exclude_below_z is not None and wp.z < exclude_below_z + 10.0:
            continue
        positions.append(wp)
    return positions


def run_paralink(context, socket_obj, comp_obj,
                  connection_style='HYBRID',
                  support_count='AUTO',
                  user_transition_z=None):
    """
    ParaLink main entry point. Calls all 8 modules in sequence.
    Returns ValidationResult. Neither socket_obj nor comp_obj is modified
    - join_bodies() (Module 7) works on duplicates and only removes the
    true originals after the joined result is validated as non-empty and
    non-collapsed (see join_engine.py's own docstring).
    """
    params = PARALINK_PROFILES.get(connection_style, PARALINK_PROFILES['HYBRID'])

    print(f"\n[ParaLink] Starting - style={connection_style} "
          f"supports={support_count}")
    _clear_debug_checkpoints()

    print("[ParaLink] Module 1: Extracting boundaries...")
    socket_b = extract_socket_boundary(socket_obj, None)
    component_b = extract_component_boundary(comp_obj)

    print("[ParaLink] Module 2: Mapping boundaries...")
    mapping = map_boundaries(socket_b, component_b)

    print("[ParaLink] Module 3: Analysing envelope...")
    envelope = analyse_envelope(socket_obj, comp_obj,
                                 user_transition_z, mapping)

    # Sprint single-wall design (reverted 2026-07-12): re-extract the socket's
    # outer boundary at the geometry-driven transition_z and build a single-wall
    # transition tube. Module 7 cuts the Working Socket at that same Z and welds
    # the skin's socket-side ring onto the cut loop (_merge_at_seams). This is
    # the last documented working state where the OUTER transition connected
    # cleanly (the inner cavity is cut by create_working_socket's bisect - a
    # known, accepted issue at this baseline).
    print(f"[ParaLink] Module 1 (final): Re-extracting socket boundary at "
          f"Z={envelope.transition_z:.1f}mm (single-wall)...")
    socket_b = extract_socket_boundary(socket_obj, envelope.transition_z)
    socket_inner_b = None

    mapping = map_boundaries(socket_b, component_b)
    if PARALINK_DEBUG_CHECKPOINTS:
        _checkpoint_boundary_mapping(context, socket_b, component_b, mapping)

    print("[ParaLink] Module 4: Generating transition surface...")
    transition_skin = generate_transition_surface(
        mapping, envelope, connection_style, context,
        inner_socket_boundary=socket_inner_b,
        outer_socket_boundary=socket_b,
    )
    if PARALINK_DEBUG_CHECKPOINTS:
        _checkpoint_mesh_object(
            context, transition_skin,
            "02_after_transition_surface_generation"
        )

    print("[ParaLink] Module 5: Support generator...")
    support_objects = generate_supports(transition_skin,
                                         support_count, connection_style)

    print("[ParaLink] Module 6: Optimising surface...")
    optimise_surface(transition_skin, support_objects,
                      connection_style, params)
    if PARALINK_DEBUG_CHECKPOINTS:
        _checkpoint_mesh_object(
            context, transition_skin,
            "03_after_surface_optimisation"
        )

    # Real design gap found and fixed vs. the reference spec, before ever
    # shipping this - verified against the actual call sequence, not
    # assumed correct: Module 8's own architecture-doc description wants a
    # real component/socket preservation check ("rigid zone verts match
    # original", "inner surface verts match original"), but join_bodies()
    # (Module 7) only removes the TRUE socket_obj/comp_obj on a SUCCESSFUL
    # join (the non-destructive duplicate-validate-adopt pattern - see its
    # own docstring) - meaning by the time Module 8 would run afterward,
    # the objects it would need to compare against no longer exist in
    # bpy.data.objects at all. A real check needs "before" data captured
    # while the true originals still exist, so snapshots are taken here,
    # immediately before Module 7 runs.
    socket_snapshot = _snapshot_preserved_region(socket_obj, envelope.transition_z)
    comp_snapshot = _snapshot_preserved_region(comp_obj, None)

    print("[ParaLink] Module 7: Joining bodies...")
    result_obj, open_edges = join_bodies(
        context, socket_obj, transition_skin,
        comp_obj, support_objects,
    )
    if PARALINK_DEBUG_CHECKPOINTS:
        _checkpoint_mesh_object(
            context, result_obj,
            "04_after_assembly"
        )

    print("[ParaLink] Module 8: Validating...")
    validation = validate_result(result_obj, socket_snapshot, comp_snapshot)

    print(f"[ParaLink] Complete. Watertight: {validation.is_watertight}")
    return validation
