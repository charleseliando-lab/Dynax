# paralink/support_generator.py
# Module 5 - Support Generator, v1 real implementation (Sprint 4).
#
# The spec's architecture document describes v2 support geometry (bolt-hole
# alignment, skin blending) as explicit future work ("v2 design intent - do
# not implement now"). This v1 implementation is deliberately simpler and
# self-contained: N solid rectangular columns, evenly spaced by angle,
# spanning from the transition skin's own upper boundary ring to its lower
# boundary ring, inset slightly inward so they sit within the transition's
# volume rather than floating outside its surface. Derived entirely from
# transition_skin's own geometry (Module 4's output contract) - no
# dependency on mapping/envelope, matching P3/P4 (every module depends only
# on its defined input contract, independently replaceable).
#
# Only generated for STRUCTURAL and HYBRID styles - SMOOTH is meant to stay
# a clean organic transition with no visible structure (matches the panel's
# own style descriptions: "Smooth - Organic transition").

import bpy
import bmesh
import math
from mathutils import Vector

SUPPORT_WIDTH_MM = 4.0    # column cross-section width
SUPPORT_INSET_MM = 1.0    # how far inward from the skin's own surface


def generate_supports(transition_skin, support_count, connection_style):
    """
    ParaLink Support Generator - v1.
    Returns a list of new standalone column objects. Never touches
    transition_skin or either source object.
    """
    if connection_style not in ('STRUCTURAL', 'HYBRID'):
        print(f"[ParaLink] Support Generator: skipped for style={connection_style}")
        return []

    n_supports = _resolve_support_count(support_count)
    ring0, ringN = _get_skin_end_rings(transition_skin)
    if not ring0 or not ringN:
        print("[ParaLink] Support Generator: could not determine skin end rings, skipping")
        return []

    ctr0 = sum(ring0, Vector()) / len(ring0)
    ctrN = sum(ringN, Vector()) / len(ringN)

    support_objects = []
    for i in range(n_supports):
        angle_frac = i / n_supports
        top_pt = _point_at_angle_fraction(ring0, ctr0, angle_frac)
        bottom_pt = _point_at_angle_fraction(ringN, ctrN, angle_frac)
        obj = _build_support_column(top_pt, ctr0, bottom_pt, ctrN, i)
        support_objects.append(obj)

    print(f"[ParaLink] Support Generator: {n_supports} columns ({connection_style})")
    return support_objects


def _resolve_support_count(support_count):
    if support_count == 'AUTO':
        return 4
    try:
        return int(support_count)
    except (TypeError, ValueError):
        return 4


def _get_skin_end_rings(transition_skin):
    """
    Return (ring0_positions, ringN_positions) - the skin's own two
    boundary loops, in world space (transition_skin already sits in world
    space with an identity object transform - see surface_generator.py,
    which builds it directly from Module 1/2's already-world-space
    boundary positions).
    """
    bm = bmesh.new()
    bm.from_mesh(transition_skin.data)
    boundary_verts = [v for v in bm.verts if v.is_boundary]
    if not boundary_verts:
        bm.free()
        return [], []
    zs = [v.co.z for v in boundary_verts]
    z_mid = (min(zs) + max(zs)) / 2.0
    ring0 = [v.co.copy() for v in boundary_verts if v.co.z > z_mid]
    ringN = [v.co.copy() for v in boundary_verts if v.co.z <= z_mid]
    bm.free()
    return ring0, ringN


def _point_at_angle_fraction(ring, centre, angle_frac):
    """Ring point closest to the given fraction of a full circle, measured
    by angle around centre in the XY plane."""
    target_angle = 2 * math.pi * angle_frac
    best = ring[0]
    best_diff = None
    for p in ring:
        ang = math.atan2(p.y - centre.y, p.x - centre.x)
        if ang < 0:
            ang += 2 * math.pi
        diff = abs(ang - target_angle)
        diff = min(diff, 2 * math.pi - diff)
        if best_diff is None or diff < best_diff:
            best_diff = diff
            best = p
    return best


def _build_support_column(top_pt, top_ctr, bottom_pt, bottom_ctr, index):
    """
    Solid box column from top_pt toward bottom_pt, inset slightly inward
    (toward each ring's own centre) so it sits within the transition's
    volume instead of floating outside the skin surface.
    """
    top_dir = (top_ctr - top_pt)
    top_dir.z = 0
    top_dir = top_dir.normalized() if top_dir.length > 1e-6 else Vector((0, 0, 0))
    bottom_dir = (bottom_ctr - bottom_pt)
    bottom_dir.z = 0
    bottom_dir = bottom_dir.normalized() if bottom_dir.length > 1e-6 else Vector((0, 0, 0))

    top_in = top_pt + top_dir * SUPPORT_INSET_MM
    bottom_in = bottom_pt + bottom_dir * SUPPORT_INSET_MM

    axis = bottom_in - top_in
    axis_n = axis.normalized() if axis.length > 1e-6 else Vector((0, 0, -1))

    up = Vector((0, 0, 1))
    side = axis_n.cross(up)
    side = side.normalized() if side.length > 1e-6 else Vector((1, 0, 0))
    fwd = axis_n.cross(side).normalized()

    hw = SUPPORT_WIDTH_MM / 2.0
    verts = []
    for base_pt in (top_in, bottom_in):
        for sx, sy in [(-1, -1), (1, -1), (1, 1), (-1, 1)]:
            verts.append(base_pt + side * (sx * hw) + fwd * (sy * hw))

    faces = [
        (0, 1, 2, 3),
        (4, 5, 6, 7),
        (0, 1, 5, 4),
        (1, 2, 6, 5),
        (2, 3, 7, 6),
        (3, 0, 4, 7),
    ]

    mesh = bpy.data.meshes.new(f"paralink_support_{index}")
    mesh.from_pydata([v.to_tuple() for v in verts], [], faces)
    mesh.update()

    obj = bpy.data.objects.new(f"paralink_support_{index}", mesh)
    bpy.context.collection.objects.link(obj)
    return obj
