# paralink/data_types.py
# Pure Python dataclasses - no Blender imports.
# All data contracts between ParaLink modules defined here.

from dataclasses import dataclass
from mathutils import Vector


@dataclass
class BoundaryResult:
    """Output of Module 1 - Boundary Extractor."""
    positions:    list          # list[Vector] ordered world-space positions
    centroid:     Vector        # geometric centre
    radius_avg:   float         # average radial distance from centroid (mm)
    radius_min:   float         # minimum radius (mm)
    radius_max:   float         # maximum radius (mm)
    z_avg:        float         # average Z height (mm)
    vertex_count: int           # len(positions)
    is_closed:    bool          # True if loop closes cleanly
    source_name:  str           # 'socket' or 'component'


@dataclass
class MappingResult:
    """Output of Module 2 - Boundary Mapper."""
    socket_resampled:    list   # list[Vector] resampled to n_points
    component_resampled: list   # list[Vector] resampled to n_points
    n_points:            int    # common vertex count
    twist_deg:           float  # residual twist (degrees)
    offset_mm:           float  # XY distance between centroids
    offset_vector:       Vector # XY offset (Z=0)
    mapping_quality:     float  # 0.0-1.0
    is_concentric:       bool   # True if offset_mm < 5.0
    diagnostics:         dict   # full Sprint 0 diagnostic data


@dataclass
class EnvelopeResult:
    """Output of Module 3 - Envelope Analyser."""
    transition_z:     float  # Z level for socket boundary extraction
    envelope_height:  float  # mm height of transition region
    extension_pct:    float  # fraction of socket height
    offset_mm:        float  # component offset
    asymmetry_factor: float  # 0.0 symmetric, 1.0 maximum asymmetric
    auto_detected:    bool   # True if transition_z was computed


@dataclass
class ValidationResult:
    """Output of Module 8 - Validator."""
    open_edge_count:      int
    is_watertight:        bool
    vertex_count:         int
    face_count:           int
    volume_mm3:           float
    component_preserved:  bool
    socket_preserved:     bool
    warnings:             list
    report:               str
