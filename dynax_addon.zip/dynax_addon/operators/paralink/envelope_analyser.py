# paralink/envelope_analyser.py
# Module 3 - Envelope Analyser

import math
from .data_types import EnvelopeResult


def analyse_envelope(socket_obj, comp_obj, user_transition_z, mapping):
    """
    Determine how much of the socket participates in the transition.
    Returns geometry-driven transition_z if not user-specified.
    """
    mesh = socket_obj.data
    mat = socket_obj.matrix_world

    world_zs = [(mat @ v.co).z for v in mesh.vertices]
    z_min = min(world_zs)
    z_max = max(world_zs)
    socket_height = z_max - z_min

    offset_mm = mapping.offset_mm

    ctr_x = sum(p.x for p in mapping.socket_resampled) / mapping.n_points
    ctr_y = sum(p.y for p in mapping.socket_resampled) / mapping.n_points
    socket_r = sum(
        math.sqrt((p.x - ctr_x) ** 2 + (p.y - ctr_y) ** 2)
        for p in mapping.socket_resampled
    ) / mapping.n_points

    if user_transition_z is not None:
        transition_z = user_transition_z
        auto_detected = False
        extension_pct = (transition_z - z_min) / max(socket_height, 1.0)
    else:
        ctr_cx = sum(p.x for p in mapping.component_resampled) / mapping.n_points
        ctr_cy = sum(p.y for p in mapping.component_resampled) / mapping.n_points
        comp_r = sum(
            math.sqrt((p.x - ctr_cx) ** 2 + (p.y - ctr_cy) ** 2)
            for p in mapping.component_resampled
        ) / mapping.n_points

        diff_r = max(socket_r - comp_r, 0.0)
        base_pct = 0.10
        diff_term = (diff_r / max(socket_r, 1.0)) * 0.15
        offset_term = (offset_mm / max(socket_r, 1.0)) * 0.10
        extension_pct = max(0.10, min(0.35,
                             base_pct + diff_term + offset_term))

        transition_z = z_min + socket_height * extension_pct
        auto_detected = True

    envelope_height = transition_z - z_min
    # Real bug found and fixed vs. the reference spec, before ever running
    # it: the original formula divided offset_mm by
    # mapping.socket_resampled[0].x - the raw X COORDINATE of one arbitrary
    # resampled point, not a radius. A socket sitting away from the world
    # origin (e.g. X=150mm) would make asymmetry_factor near-zero
    # regardless of how offset the component actually is, while a socket
    # centred near X=0 would make it wildly oversized from dividing by a
    # near-zero denominator. Fixed to use the actual socket radius
    # (socket_r, already computed above the same way for extension_pct).
    asymmetry_factor = min(1.0, offset_mm / max(socket_r, 10.0))

    print(f"[ParaLink] Envelope: transition_z={transition_z:.1f}mm "
          f"extension={extension_pct * 100:.0f}% "
          f"{'(auto)' if auto_detected else '(user)'}")

    return EnvelopeResult(
        transition_z=transition_z,
        envelope_height=envelope_height,
        extension_pct=extension_pct,
        offset_mm=offset_mm,
        asymmetry_factor=asymmetry_factor,
        auto_detected=auto_detected,
    )
