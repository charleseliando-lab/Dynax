# paralink/__init__.py
# ParaLink public API

from .paralink_engine import run_paralink
from .boundary_extractor import (
    extract_socket_boundary,
    extract_socket_boundaries,
    extract_component_boundary,
    BoundaryExtractionError,
)
from .boundary_mapper import map_boundaries
from .diagnostics import (
    draw_boundary_curve,
    draw_mapping_lines,
    clear_diagnostics,
    print_diagnostics,
    SOCKET_BOUNDARY_NAME,
    COMPONENT_BOUNDARY_NAME,
    MAPPING_LINES_NAME,
)
from .surface_generator import PARALINK_PROFILES

PARALINK_VERSION = "1.0.0-sprint0"
