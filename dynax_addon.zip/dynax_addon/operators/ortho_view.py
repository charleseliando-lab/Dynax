# operators/ortho_view.py - Manual orthographic view toggle (panel header
# buttons). See import_stl.py's _set_orthographic_view() for the shared
# implementation and the automatic-switch call sites (import, centre model,
# auto-align) - this operator just exposes the same function to the user
# for manual F/B/L/R/T switching at any time.

import bpy
from bpy.types import Operator
from bpy.props import StringProperty


class DynaxSetOrthoView(Operator):
    """Switch to orthographic projection with a standard anatomical view direction"""
    bl_idname = "dynax.set_ortho_view"
    bl_label = "Set Orthographic View"
    bl_options = {'REGISTER'}

    view: StringProperty(default='FRONT')

    def execute(self, context):
        from .import_stl import _set_orthographic_view
        _set_orthographic_view(self.view)
        return {'FINISHED'}
