# operators/insole.py - ParaFly Insole geometry operators (v1.23.0)
#
# Completes the v1.22.0 groundwork (utils/insole_presets.py loader,
# data/insole_presets/*.json). Uses the shared smooth_falloff from
# spatial_agent/displacement_engine.py rather than duplicating it.

import bpy
from bpy_extras.io_utils import ImportHelper, ExportHelper
from bpy.props import StringProperty
from mathutils import Vector

from ..utils.insole_presets import load_preset
from ..spatial_agent.displacement_engine import smooth_falloff


class DYNAX_OT_insole_load_scan(bpy.types.Operator, ImportHelper):
    """Load a foot scan (STL/OBJ)"""
    bl_idname = "dynax.insole_load_scan"
    bl_label = "Load Foot Scan"

    filter_glob: StringProperty(default="*.stl;*.obj", options={'HIDDEN'})

    def execute(self, context):
        filepath = self.filepath
        if not filepath:
            self.report({'ERROR'}, "No file selected")
            return {'CANCELLED'}

        ext = filepath.lower().rsplit(".", 1)[-1] if "." in filepath else ""
        try:
            if ext == "stl":
                bpy.ops.wm.stl_import(filepath=filepath)
            elif ext == "obj":
                bpy.ops.wm.obj_import(filepath=filepath)
            else:
                self.report({'ERROR'}, "Unsupported file type — use STL or OBJ")
                return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, f"Import failed: {e}")
            return {'CANCELLED'}

        context.scene.dynax_insole_scan_loaded = True
        self.report({'INFO'}, "Foot scan loaded")
        return {'FINISHED'}


# Presets identify zones by clinical region name, not coordinates (see
# data/insole_presets/*.json — no position_mm field exists). Real region ->
# mesh-surface mapping needs a rigged reference insole (out of scope for this
# session's groundwork-completion pass); approximated here as a normalised
# (length, width) fraction of the mesh's own local bounding box, foot length
# assumed along local Y (heel at min Y, toe at max Y) and width along local X.
REGION_UV = {
    "metatarsal_heads": (0.78, 0.5),
    "heel_centre": (0.08, 0.5),
    "toe_tips": (0.97, 0.5),
    "medial_arch": (0.45, 0.65),
    "lateral_heel": (0.12, 0.30),
}


class DYNAX_OT_insole_apply_preset(bpy.types.Operator):
    """Apply the selected clinical insole preset to the active mesh"""
    bl_idname = "dynax.insole_apply_preset"
    bl_label = "Apply Preset"

    def execute(self, context):
        scene = context.scene
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "Select the insole mesh first")
            return {'CANCELLED'}

        preset_name = getattr(scene, "dynax_insole_preset", "")
        preset = load_preset(preset_name)
        if preset is None:
            self.report({'ERROR'}, f"Preset not found: {preset_name}")
            return {'CANCELLED'}

        mesh = obj.data
        bbox_min = Vector((min(v.co.x for v in mesh.vertices),
                            min(v.co.y for v in mesh.vertices),
                            min(v.co.z for v in mesh.vertices)))
        bbox_max = Vector((max(v.co.x for v in mesh.vertices),
                            max(v.co.y for v in mesh.vertices),
                            max(v.co.z for v in mesh.vertices)))

        def region_centre(region: str) -> Vector:
            u, v = REGION_UV.get(region, (0.5, 0.5))
            return Vector((
                bbox_min.x + v * (bbox_max.x - bbox_min.x),
                bbox_min.y + u * (bbox_max.y - bbox_min.y),
                bbox_max.z,
            ))

        for relief in preset.get("relief_zones", []):
            centre = region_centre(relief.get("region", ""))
            radius = relief["radius_mm"] / 1000.0
            depth = relief["depth_mm"] / 1000.0
            self._displace(mesh, centre, radius, depth, inward=True)

        for support in preset.get("support_zones", []):
            centre = region_centre(support.get("region", ""))
            width = support["width_mm"] / 1000.0
            height = support["height_mm"] / 1000.0
            self._displace(mesh, centre, width, height, inward=False)

        mesh.update()
        self.report({'INFO'}, f"Applied preset: {preset.get('name', preset_name)}")
        return {'FINISHED'}

    @staticmethod
    def _displace(mesh, centre, blend_radius, magnitude, inward):
        for v in mesh.vertices:
            distance = (v.co - centre).length
            w = smooth_falloff(distance, blend_radius)
            if w <= 0.0:
                continue
            normal = v.normal.normalized()
            if inward:
                normal = -normal
            v.co += normal * (magnitude * w)


class DYNAX_OT_insole_export(bpy.types.Operator, ExportHelper):
    """Export the active insole mesh as STL"""
    bl_idname = "dynax.insole_export"
    bl_label = "Export Insole"

    filename_ext = ".stl"
    filter_glob: StringProperty(default="*.stl", options={'HIDDEN'})

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "Select the insole mesh first")
            return {'CANCELLED'}

        try:
            bpy.ops.wm.stl_export(filepath=self.filepath, export_selected_objects=True)
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {e}")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Exported to {self.filepath}")
        return {'FINISHED'}
