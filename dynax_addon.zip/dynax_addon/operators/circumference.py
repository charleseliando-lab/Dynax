# operators/circumference.py - Visual circumference rings (v1.6)
#
# v1.20.8: adds Click Point to Measure (DynaxMeasureClick). The cross-section
# maths and the marker ring come from utils/measurement_helpers.py - the SHARED
# engine also used by ParaFly AFO - so there is exactly one measurement
# implementation in the add-on. The existing slider-driven ring tools below are
# unchanged.

import bpy
import bmesh
import math
import gpu
import blf
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from bpy.types import Operator

from ..utils import measurement_helpers as mh
from ..utils.dynax_logging import (
    creator_guard, log_operator_error, validate_mesh_object,
)

RING_COLLECTION = "DynaX_CircRings"
_draw_handler = None
_ring_data = []   # list of {z_world, circ_mm, diam_mm, points}


# ── Geometry helpers ───────────────────────────────────────────────────────────

def _get_world_bounds(obj):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    zs = [v.co.z for v in bm.verts]
    bm.free()
    return min(zs), max(zs)


def _detect_unit(obj):
    z_min, z_max = _get_world_bounds(obj)
    h = z_max - z_min
    if h < 1.0:   return "meters",      1000.0
    elif h < 10:  return "centimeters", 10.0
    else:         return "millimeters ✓", 1.0


def _measure_at_z(obj, z_world):
    """Return (circ_mm, diam_mm, points_3d) or (None, None, [])"""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    bm.edges.ensure_lookup_table()

    EPS = 1e-9
    pts = []
    for edge in bm.edges:
        v0, v1 = edge.verts
        z0, z1 = v0.co.z, v1.co.z
        if (z0 < z_world - EPS and z1 > z_world + EPS) or \
           (z1 < z_world - EPS and z0 > z_world + EPS):
            t = max(0.0, min(1.0, (z_world - z0) / (z1 - z0)))
            pts.append(v0.co.lerp(v1.co, t).copy())
    bm.free()

    if len(pts) < 3:
        return None, None, []

    cx = sum(p.x for p in pts) / len(pts)
    cy = sum(p.y for p in pts) / len(pts)
    pts.sort(key=lambda p: math.atan2(p.y - cy, p.x - cx))

    perim = sum(
        math.sqrt((pts[(i+1)%len(pts)].x - pts[i].x)**2 +
                  (pts[(i+1)%len(pts)].y - pts[i].y)**2)
        for i in range(len(pts))
    )

    circ_mm = perim * 1000.0 if perim < 5.0 else perim
    return round(circ_mm, 1), round(circ_mm / math.pi, 1), pts


# ── OpenGL draw callback ───────────────────────────────────────────────────────

def _draw_rings():
    global _ring_data
    if not _ring_data:
        return

    try:
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    except Exception:
        return

    region = bpy.context.region
    rv3d   = bpy.context.region_data

    for ring in _ring_data:
        pts  = ring["points"]
        circ = ring["circ_mm"]
        diam = ring["diam_mm"]
        z_w  = ring["z_world"]
        color = ring.get("color", (0.0, 0.85, 1.0, 0.9))

        if len(pts) < 2:
            continue

        # Draw ring line loop
        coords = [(p.x, p.y, p.z) for p in pts]
        coords.append(coords[0])  # close loop

        gpu.state.line_width_set(2.0)
        gpu.state.blend_set('ALPHA')
        batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": coords})
        shader.bind()
        shader.uniform_float("color", color)
        batch.draw(shader)
        gpu.state.line_width_set(1.0)

        # Draw label in 3D space
        try:
            from bpy_extras.view3d_utils import location_3d_to_region_2d
            cx = sum(p.x for p in pts) / len(pts)
            cy = sum(p.y for p in pts) / len(pts)
            label_3d = Vector((max(p.x for p in pts) + 0.01, cy, z_w))
            co_2d = location_3d_to_region_2d(region, rv3d, label_3d)
            if co_2d:
                blf.enable(0, blf.SHADOW)
                blf.shadow(0, 3, 0, 0, 0, 0.8)
                blf.size(0, 13)
                blf.color(0, color[0], color[1], color[2], 1.0)
                blf.position(0, co_2d.x + 5, co_2d.y, 0)
                blf.draw(0, f"{circ:.0f} mm  ∅{diam:.0f} mm")
                blf.disable(0, blf.SHADOW)
        except Exception:
            pass

    gpu.state.blend_set('NONE')


def _register_draw():
    global _draw_handler
    if _draw_handler is None:
        _draw_handler = bpy.types.SpaceView3D.draw_handler_add(
            _draw_rings, (), 'WINDOW', 'POST_VIEW'
        )


def _unregister_draw():
    global _draw_handler
    if _draw_handler is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_draw_handler, 'WINDOW')
        _draw_handler = None


def _refresh_viewport():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


# ── Operators ──────────────────────────────────────────────────────────────────

class DynaxRingsAuto(Operator):
    """Draw circumference rings automatically at equal intervals"""
    bl_idname = "dynax.rings_auto"
    bl_label = "Auto rings"
    bl_options = {'REGISTER', 'UNDO'}

    num_rings: bpy.props.IntProperty(
        name="Number of rings", default=5, min=2, max=20,
    )
    start_pct: bpy.props.FloatProperty(
        name="Start (%)", default=10.0, min=1.0, max=50.0,
    )
    end_pct: bpy.props.FloatProperty(
        name="End (%)", default=90.0, min=50.0, max=99.0,
    )

    @creator_guard("Could not draw the rings. See the DynaX log for details.")
    def execute(self, context):
        global _ring_data
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        z_min, z_max = _get_world_bounds(obj)
        height = z_max - z_min

        new_rings = []
        import json
        results = []

        for i in range(self.num_rings):
            frac = (self.start_pct + i * (self.end_pct - self.start_pct) /
                    max(self.num_rings - 1, 1)) / 100.0
            z_w = z_min + frac * height
            circ_mm, diam_mm, pts = _measure_at_z(obj, z_w)
            if circ_mm is None:
                continue

            hue = i / max(self.num_rings - 1, 1)
            color = _hsv_to_rgb(hue * 0.7, 0.9, 1.0) + (0.95,)

            new_rings.append({
                "z_world": z_w,
                "circ_mm": circ_mm,
                "diam_mm": diam_mm,
                "points":  pts,
                "color":   color,
                "pct":     round(frac * 100, 1),
                "z_mm":    round(frac * (height * 1000 if height < 5 else height), 1),
            })
            results.append({
                "z_mm":    round(frac * (height * 1000 if height < 5 else height), 1),
                "pct":     round(frac * 100, 1),
                "circ_mm": circ_mm,
                "diam_mm": diam_mm,
            })

        if not new_rings:
            self.report({'ERROR'}, "No rings could be measured. Check scan scale.")
            return {'CANCELLED'}

        # Keep manually placed rings, replace auto rings
        _ring_data = [r for r in _ring_data if r.get("manual")] + new_rings
        context.scene["dynax_circ_report"] = json.dumps(results)

        _register_draw()
        _refresh_viewport()

        self.report({'INFO'}, f"✓ {len(new_rings)} circumference rings drawn")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=280)


class DynaxRingPlace(Operator):
    """Place a single circumference ring at a specific height"""
    bl_idname = "dynax.ring_place"
    bl_label = "Place ring at height"
    bl_options = {'REGISTER', 'UNDO'}

    height_pct: bpy.props.FloatProperty(
        name="Height (%)",
        description="Height as % from bottom of scan",
        default=50.0, min=1.0, max=99.0,
    )

    @creator_guard("Could not place the ring. See the DynaX log for details.")
    def execute(self, context):
        global _ring_data
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        z_min, z_max = _get_world_bounds(obj)
        height = z_max - z_min
        frac = self.height_pct / 100.0
        z_w = z_min + frac * height

        circ_mm, diam_mm, pts = _measure_at_z(obj, z_w)
        if circ_mm is None:
            self.report({'WARNING'}, f"Could not measure at {self.height_pct:.0f}%")
            return {'CANCELLED'}

        z_mm = round(frac * (height * 1000 if height < 5 else height), 1)

        _ring_data.append({
            "z_world": z_w,
            "circ_mm": circ_mm,
            "diam_mm": diam_mm,
            "points":  pts,
            "color":   (1.0, 0.6, 0.0, 0.95),  # orange for manual
            "pct":     round(frac * 100, 1),
            "z_mm":    z_mm,
            "manual":  True,
        })

        _register_draw()
        _refresh_viewport()

        self.report({'INFO'},
            f"Ring at {self.height_pct:.0f}%: "
            f"{circ_mm:.1f} mm circ / {diam_mm:.1f} mm dia")
        return {'FINISHED'}

    def invoke(self, context, event):
        obj = context.active_object
        if obj and obj.type == 'MESH':
            z_min, z_max = _get_world_bounds(obj)
            self.height_pct = 50.0
        return context.window_manager.invoke_props_dialog(self, width=280)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "height_pct", text="Height from bottom (%)")
        layout.label(text="Cyan = auto rings  |  Orange = manual rings", icon='INFO')


# ── Click Point to Measure state ──────────────────────────────────────────────
#
# ONE scene flag owns "a click measurement is armed". The modal reads it on
# every event and exits the moment it goes away, which is how Clear Measurement
# and stage navigation can defensively cancel the tool - a modal operator
# cannot be killed from the outside, but it can be asked to stand down.

MEASURE_ACTIVE_KEY = "dynax_measure_click_active"
MEASURE_RESULT_KEYS = ("dynax_last_measure_circ_mm", "dynax_last_measure_z",
                       "dynax_last_measure_diam_mm")


def measure_click_is_active(context):
    return bool(context.scene.get(MEASURE_ACTIVE_KEY))


def cancel_active_measure(context):
    """Ask any running click-measure modal to stand down. Safe to call always.

    Called before a workflow stage change and by Clear Measurement, so the user
    can never carry an armed measurement tool into another stage or another
    Stage 5 tool.
    """
    scene = getattr(context, "scene", None)
    if scene is None:
        return False
    if MEASURE_ACTIVE_KEY not in scene:
        return False
    del scene[MEASURE_ACTIVE_KEY]
    try:
        context.workspace.status_text_set(None)
    except Exception:  # noqa: BLE001 - no workspace during load/unregister
        pass
    _refresh_viewport()
    return True


def _log_diagnostics(diagnostics):
    """Development-only diagnostics; never shown in the clinician's UI."""
    try:
        from .. import DYNAX_DEV_MODE
    except Exception:  # noqa: BLE001
        return
    if not DYNAX_DEV_MODE:
        return
    print("[DynaX MeasureClick]", " ".join(
        f"{key}={value}" for key, value in diagnostics.items()))


class DynaxMeasureClick(Operator):
    """Click a point on the scan to measure the transverse circumference of the
    limb at that height.

    Modal, because a panel button's own invoke() event lives in the sidebar
    region, which has no valid 3D region_data - a one-shot raycast off that
    event would unproject against the panel and fail. The button arms the tool;
    the NEXT click in the 3D viewport is what is measured.

    ONE-SHOT by design (measure-click fix). It used to stay RUNNING_MODAL forever after
    a successful measurement AND swallow every unmodified left-click anywhere in
    the window - including panel buttons, whose PRESS was eaten while the
    RELEASE passed through, so Next/Back/Clear simply never fired and the user
    was trapped in Stage 5. Now: clicks outside a 3D viewport region always pass
    through to the UI, and one successful measurement FINISHES the operator.

    Uses utils/measurement_helpers - the same engine ParaFly AFO measures with.
    """
    bl_idname = "dynax.measure_click"
    bl_label = "Click Point to Measure"
    bl_description = ("Click a point on the scan to measure the circumference "
                      "at that height")
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except RuntimeError:
                self.report({'ERROR'},
                            "Leave the current mode first, then measure.")
                return {'CANCELLED'}

        self._target_name = obj.name
        context.scene[MEASURE_ACTIVE_KEY] = True
        context.workspace.status_text_set(
            "Left-click the limb to measure  |  "
            "orbit/pan/zoom stay available  |  Right-click or Esc = cancel")
        context.window_manager.modal_handler_add(self)
        self.report({'INFO'},
                    "Click the limb to measure. Esc or right-click to cancel.")
        return {'RUNNING_MODAL'}

    def _cleanup(self, context):
        """Single exit path: no timers, no draw handlers, no captured input,
        no armed flag left behind, status bar restored."""
        if MEASURE_ACTIVE_KEY in context.scene:
            del context.scene[MEASURE_ACTIVE_KEY]
        try:
            context.workspace.status_text_set(None)
        except Exception:  # noqa: BLE001
            pass
        _refresh_viewport()

    def cancel(self, context):
        # Blender calls this if the modal is torn down externally (file load,
        # add-on reload) - the flag must not survive that either.
        self._cleanup(context)

    def modal(self, context, event):
        # Someone cancelled us from the outside (Clear Measurement, stage nav).
        if not context.scene.get(MEASURE_ACTIVE_KEY):
            self._cleanup(context)
            return {'CANCELLED'}

        # Navigation FIRST: orbit/pan/zoom must always work, and a modified
        # left-click is navigation, never a measurement (mh.is_navigation_event).
        if mh.is_navigation_event(event):
            return {'PASS_THROUGH'}

        if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            self._cleanup(context)
            self.report({'INFO'}, "Measurement cancelled.")
            return {'CANCELLED'}

        if event.type == 'LEFTMOUSE':
            # Anything outside a 3D viewport belongs to the UI - never eat it,
            # or every panel button in Stage 5 stops working.
            region, _rv3d, _coord = mh.find_view3d_under_cursor(context, event)
            if region is None:
                return {'PASS_THROUGH'}
            if event.value != 'PRESS':
                # Consume the matching release so it can't leak into a tool.
                return {'RUNNING_MODAL'}
            try:
                measured = self._measure(context, event)
            except Exception as exc:  # noqa: BLE001 - never traceback at a user
                log_operator_error(self.bl_idname, exc)
                self._cleanup(context)
                self.report({'ERROR'},
                            "Could not measure there. See the DynaX log for details.")
                return {'CANCELLED'}
            if measured:
                self._cleanup(context)
                return {'FINISHED'}
            # A miss (off the scan / no closed section) is reported and the tool
            # stays armed for a retry - it never freezes, Esc always exits, and
            # the panel is still clickable because only viewport clicks are eaten.
            return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'}

    def _measure(self, context, event):
        """Return True when a measurement was actually produced."""
        # Re-fetch by name: the object may have been deleted while the modal ran.
        obj = bpy.data.objects.get(getattr(self, "_target_name", ""))
        if obj is None or obj.type != 'MESH':
            self.report({'WARNING'}, "The scan is no longer available.")
            return False

        location = mh.raycast_surface(context, obj, event)
        if location is None:
            self.report({'WARNING'},
                        "Click landed off the scan — try again on the surface.")
            return False

        circ_mm, points, diagnostics = mh.measure_circumference_at_point(obj, location)
        _log_diagnostics(diagnostics)
        if circ_mm <= 0.0:
            self.report({'WARNING'},
                        "No closed cross-section at that height — try another point.")
            return False

        diam_mm = mh.measure_diameter(circ_mm)
        # Ring drawn from the SAME contour the number came from.
        mh.draw_ring_from_points(context, points,
                                 color=(1.0, 0.6, 0.0, 1.0),
                                 name="dynax_measure_ring")
        context.scene["dynax_last_measure_circ_mm"] = round(circ_mm, 1)
        context.scene["dynax_last_measure_diam_mm"] = round(diam_mm, 1)
        context.scene["dynax_last_measure_z"] = round(location.z, 1)
        _refresh_viewport()
        self.report({'INFO'},
                    f"Circumference {circ_mm:.1f} mm  (⌀{diam_mm:.1f} mm) "
                    f"at Z={location.z:.1f} mm")
        return True


class DynaxMeasureClickCancel(Operator):
    """Stop the click-measurement tool without clearing an existing result"""
    bl_idname = "dynax.measure_click_cancel"
    bl_label = "Cancel measuring"
    bl_options = {'REGISTER'}

    def execute(self, context):
        cancel_active_measure(context)
        self.report({'INFO'}, "Measurement cancelled")
        return {'FINISHED'}


class DynaxMeasureClickClear(Operator):
    """Remove the click-measurement marker ring and its readout"""
    bl_idname = "dynax.measure_click_clear"
    bl_label = "Clear Measurement"
    bl_options = {'REGISTER', 'UNDO'}

    @creator_guard("Could not clear the measurement. See the DynaX log.")
    def execute(self, context):
        # Clearing also disarms the tool: Stage 5 must be left usable, with no
        # modal still owning viewport clicks.
        cancel_active_measure(context)
        mh.remove_existing_ring()
        for key in MEASURE_RESULT_KEYS:
            if key in context.scene:
                del context.scene[key]
        _refresh_viewport()
        self.report({'INFO'}, "Measurement cleared")
        return {'FINISHED'}


class DynaxRingsClear(Operator):
    """Remove all circumference rings from viewport"""
    bl_idname = "dynax.rings_clear"
    bl_label = "Clear all rings"
    bl_options = {'REGISTER'}

    @creator_guard("Could not clear the rings. See the DynaX log.")
    def execute(self, context):
        global _ring_data
        _ring_data = []
        _unregister_draw()
        _refresh_viewport()
        if "dynax_circ_report" in context.scene:
            del context.scene["dynax_circ_report"]
        self.report({'INFO'}, "Rings cleared")
        return {'FINISHED'}


# Keep old operators working
class DynaxMeasureCircumference(Operator):
    """Measure circumference at a specific height (alias → ring_place)"""
    bl_idname = "dynax.measure_circumference"
    bl_label = "Place ring at height…"
    bl_options = {'REGISTER', 'UNDO'}

    height_pct: bpy.props.FloatProperty(
        name="Height (%)", default=50.0, min=1.0, max=99.0,
    )

    def execute(self, context):
        bpy.ops.dynax.ring_place('INVOKE_DEFAULT')
        return {'FINISHED'}

    def invoke(self, context, event):
        return bpy.ops.dynax.ring_place('INVOKE_DEFAULT')


class DynaxMeasureMultiple(Operator):
    """Measure at multiple heights (alias → rings_auto)"""
    bl_idname = "dynax.measure_multiple"
    bl_label = "Auto rings…"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return bpy.ops.dynax.rings_auto('INVOKE_DEFAULT')

    def invoke(self, context, event):
        return bpy.ops.dynax.rings_auto('INVOKE_DEFAULT')


# ── Utility ────────────────────────────────────────────────────────────────────

def _hsv_to_rgb(h, s, v):
    import colorsys
    return colorsys.hsv_to_rgb(h, s, v)


def get_ring_data():
    return _ring_data


def register_draw_on_load():
    pass  # draw registered on demand


def unregister_draw_on_unload():
    _unregister_draw()


# ── Live gizmo ring (v1.7) ─────────────────────────────────────────────────────

_active_gizmo_ring = None  # the single ring controlled by the slider


def update_active_ring(context, height_pct):
    """Called live from the slider — repositions the active gizmo ring"""
    global _active_gizmo_ring, _ring_data
    obj = context.active_object
    if not obj or obj.type != 'MESH':
        return

    z_min, z_max = _get_world_bounds(obj)
    height = z_max - z_min
    frac = height_pct / 100.0
    z_w = z_min + frac * height

    circ_mm, diam_mm, pts = _measure_at_z(obj, z_w)
    if circ_mm is None:
        return

    z_mm = round(frac * (height * 1000 if height < 5 else height), 1)

    # Update or create the active gizmo ring
    if _active_gizmo_ring is not None and _active_gizmo_ring in _ring_data:
        _active_gizmo_ring["z_world"] = z_w
        _active_gizmo_ring["circ_mm"] = circ_mm
        _active_gizmo_ring["diam_mm"] = diam_mm
        _active_gizmo_ring["points"]  = pts
        _active_gizmo_ring["pct"]     = round(frac * 100, 1)
        _active_gizmo_ring["z_mm"]    = z_mm
    else:
        ring = {
            "z_world": z_w, "circ_mm": circ_mm, "diam_mm": diam_mm,
            "points": pts, "color": (1.0, 0.6, 0.0, 0.95),
            "pct": round(frac * 100, 1), "z_mm": z_mm,
            "manual": True, "gizmo": True,
        }
        _ring_data.append(ring)
        _active_gizmo_ring = ring

    _register_draw()
    _refresh_viewport()


class DynaxRingGizmoStart(Operator):
    """Start placing a ring with the live height slider"""
    bl_idname = "dynax.ring_gizmo_start"
    bl_label  = "Place ring (slider)"
    bl_options = {'REGISTER', 'UNDO'}

    @creator_guard("Could not start the ring. See the DynaX log for details.")
    def execute(self, context):
        global _active_gizmo_ring
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Start a new gizmo ring at current slider value
        _active_gizmo_ring = None
        props = context.scene.dynax_props
        update_active_ring(context, props.ring_height_pct)
        self.report({'INFO'}, "Drag the 'Ring height' slider to position the ring")
        return {'FINISHED'}


class DynaxRingGizmoConfirm(Operator):
    """Confirm the current gizmo ring as a permanent ring"""
    bl_idname = "dynax.ring_gizmo_confirm"
    bl_label  = "Confirm ring"
    bl_options = {'REGISTER'}

    def execute(self, context):
        global _active_gizmo_ring
        if _active_gizmo_ring is not None:
            _active_gizmo_ring["gizmo"] = False  # detach from slider
            _active_gizmo_ring = None
            self.report({'INFO'}, "✓ Ring placed")
        return {'FINISHED'}
