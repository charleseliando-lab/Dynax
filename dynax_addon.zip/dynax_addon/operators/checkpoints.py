# operators/checkpoints.py - Per-step version checkpoints
#
# Saves a hidden snapshot of the working mesh at the end of each major
# workflow step. Same snapshot technique as the before/after comparison
# feature (mesh.copy(), hidden object, predictable naming, object-then-mesh
# cleanup on overwrite) — proven pattern, reused here for a different
# purpose (jumping back to a named point in the workflow instead of
# comparing against the original scan).

import bpy
from bpy.types import Operator
from bpy.props import StringProperty

CHECKPOINT_STEPS = [
    "cleanup", "align", "crop", "sculpt", "trimline", "thickness",
]


def _save_checkpoint(context, obj, step_name):
    """Save a hidden snapshot of the current mesh state, tagged with the
    step it was taken after. Overwrites any existing checkpoint for the
    same step (so re-running a step updates its checkpoint rather than
    stacking duplicates)."""
    checkpoint_name = f"{obj.name}_CHECKPOINT_{step_name}"

    existing = bpy.data.objects.get(checkpoint_name)
    if existing:
        old_mesh = existing.data
        bpy.data.objects.remove(existing, do_unlink=True)
        if old_mesh and old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)

    snap_mesh = obj.data.copy()
    snap_mesh.name = checkpoint_name + "_mesh"
    snap_obj = bpy.data.objects.new(checkpoint_name, snap_mesh)
    snap_obj.matrix_world = obj.matrix_world.copy()
    context.collection.objects.link(snap_obj)
    snap_obj.hide_set(True)
    snap_obj.hide_render = True
    snap_obj["dynax_is_checkpoint"] = True
    snap_obj["dynax_checkpoint_step"] = step_name
    snap_obj["dynax_checkpoint_target"] = obj.name

    # Track which checkpoints exist for this object, in order.
    existing_list = obj.get("dynax_checkpoint_list", "")
    steps = existing_list.split(",") if existing_list else []
    if step_name not in steps:
        steps.append(step_name)
    obj["dynax_checkpoint_list"] = ",".join(steps)

    return snap_obj


class DynaxSaveCheckpoint(Operator):
    """Manually save a checkpoint at the current point (also called
    automatically when moving to the next workflow step)"""
    bl_idname = "dynax.save_checkpoint"
    bl_label = "Save Checkpoint"
    bl_options = {'REGISTER'}

    step_name: StringProperty()

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select the working socket first.")
            return {'CANCELLED'}

        _save_checkpoint(context, obj, self.step_name)
        self.report({'INFO'}, f"Checkpoint saved: after {self.step_name}.")
        return {'FINISHED'}


class DynaxRestoreCheckpoint(Operator):
    """Restore the mesh to a previously saved checkpoint. This replaces the
    CURRENT mesh data with the checkpoint's — everything done after that
    checkpoint is lost, same as Blender's own Undo but jumping straight to a
    named point instead of stepping back one action at a time."""
    bl_idname = "dynax.restore_checkpoint"
    bl_label = "Restore Checkpoint"
    bl_options = {'REGISTER', 'UNDO'}

    step_name: StringProperty()

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select the working socket first.")
            return {'CANCELLED'}

        checkpoint_name = f"{obj.name}_CHECKPOINT_{self.step_name}"
        checkpoint_obj = bpy.data.objects.get(checkpoint_name)
        if not checkpoint_obj:
            self.report({'ERROR'}, f"No checkpoint found for '{self.step_name}'.")
            return {'CANCELLED'}

        # Swap the mesh data — restores geometry, keeps the working object's
        # name/transform/modifiers intact.
        restored_mesh = checkpoint_obj.data.copy()
        restored_mesh.name = f"{obj.name}_restored_{self.step_name}"
        old_mesh = obj.data
        obj.data = restored_mesh
        if old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)

        self.report({'WARNING'},
            f"Restored to checkpoint 'after {self.step_name}'. Any work done "
            "after this point in the current session is lost from the mesh "
            "(Blender's own Undo history may still have it temporarily — "
            "use Ctrl+Z if you restored by mistake).")
        return {'FINISHED'}


class DynaxClearCheckpoints(Operator):
    """Remove all saved checkpoints for the active object (e.g. once the
    socket is finalized and exported, to free up file size)"""
    bl_idname = "dynax.clear_checkpoints"
    bl_label = "Clear All Checkpoints"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj:
            return {'CANCELLED'}

        removed = 0
        for step in CHECKPOINT_STEPS:
            checkpoint_name = f"{obj.name}_CHECKPOINT_{step}"
            cp = bpy.data.objects.get(checkpoint_name)
            if cp:
                mesh = cp.data
                bpy.data.objects.remove(cp, do_unlink=True)
                if mesh.users == 0:
                    bpy.data.meshes.remove(mesh)
                removed += 1

        if "dynax_checkpoint_list" in obj:
            del obj["dynax_checkpoint_list"]

        self.report({'INFO'}, f"Removed {removed} checkpoint(s).")
        return {'FINISHED'}
