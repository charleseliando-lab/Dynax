# operators/workflow_nav.py - Step navigation (v2.6.8 — role selection removed)

import bpy
import time
from bpy.types import Operator
from ..properties.dynax_properties import get_step_ids
from .checkpoints import CHECKPOINT_STEPS, _save_checkpoint
from .circumference import cancel_active_measure
from .select_tools import on_workflow_step_changed

try:
    from ..analytics.collector import record_event, workflow_from_context
except ImportError:
    def record_event(*_args, **_kwargs):
        return None

    def workflow_from_context(_context):
        return None

try:
    from ..utils.session_recorder import get_recorder
except ImportError:
    def get_recorder():
        class _NullRecorder:
            def __getattr__(self, _name):
                return lambda *a, **k: None
        return _NullRecorder()

try:
    from ..panels.ai_assistant import trigger_auto_query
except ImportError:
    def trigger_auto_query(_context):
        return None


_step_started_at = time.monotonic()


class DynaxGotoStep(Operator):
    """Jump to a specific workflow step"""
    bl_idname = "dynax.goto_step"
    bl_label = "Go to step"

    step_id: bpy.props.StringProperty()

    def execute(self, context):
        global _step_started_at
        # Never carry an armed Creator measurement tool into another stage -
        # it would keep owning viewport clicks there (measure-click fix).
        cancel_active_measure(context)
        props = context.scene.dynax_props
        step_ids = get_step_ids()
        if self.step_id in step_ids:
            previous_step = props.active_step
            props.active_step = self.step_id
            # Each step owns its own selection: dropping the previous step's
            # locked region and leftover mesh selection flags here is what stops
            # a Sculpt region being consumed as a Trimline region. Interaction
            # state only - sculpted geometry is kept.
            on_workflow_step_changed(context, previous_step, props.active_step)
            try:
                get_recorder().log_step(self.step_id)
            except Exception:
                pass
            try:
                trigger_auto_query(context)
            except Exception:
                pass
        return {'FINISHED'}


class DynaxStepNav(Operator):
    """Navigate to previous or next workflow step"""
    bl_idname = "dynax.step_nav"
    bl_label = "Step navigation"

    direction: bpy.props.EnumProperty(
        items=[('PREV', "Back", ""), ('NEXT', "Next", "")],
        default='NEXT',
    )

    def execute(self, context):
        global _step_started_at
        cancel_active_measure(context)
        props = context.scene.dynax_props
        step_ids = get_step_ids()
        try:
            idx = step_ids.index(props.active_step)
        except ValueError:
            idx = 0

        # Auto-checkpoint the step being LEFT (only when actually advancing
        # forward — "Back" doesn't represent finishing a step, so it doesn't
        # checkpoint). Same snapshot technique as the before/after comparison
        # feature; see operators/checkpoints.py.
        if self.direction == 'NEXT' and props.active_step in CHECKPOINT_STEPS:
            obj = context.active_object
            if obj and obj.type == 'MESH':
                _save_checkpoint(context, obj, props.active_step)

        previous_step = props.active_step
        if self.direction == 'NEXT' and idx < len(step_ids) - 1:
            props.active_step = step_ids[idx + 1]
        elif self.direction == 'PREV' and idx > 0:
            props.active_step = step_ids[idx - 1]

        # Same hard step boundary as DynaxGotoStep above.
        on_workflow_step_changed(context, previous_step, props.active_step)

        now = time.monotonic()
        if self.direction == 'NEXT' and props.active_step != previous_step:
            record_event(
                "stage_completed",
                workflow=workflow_from_context(context),
                stage=previous_step,
                duration_s=now - _step_started_at,
            )
        if props.active_step != previous_step:
            _step_started_at = now
            try:
                get_recorder().log_step(props.active_step)
            except Exception:
                pass
            try:
                trigger_auto_query(context)
            except Exception:
                pass

        return {'FINISHED'}
