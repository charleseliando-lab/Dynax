# operators/select_tools.py - Region select via EDIT MODE (v1.9.5)
#
# ARCHITECTURE CHANGE: Uses Blender's native Edit-mode box/circle/lasso select
# instead of sculpt masking. This solves the core problems cleanly:
#   - NO mirroring (edit-mode select has no symmetry)
#   - "Select through" is OFF by default (front faces only, no inside selection)
#   - Selection IS the mesh vertex selection → converts directly to vertex group
#   - Works identically across Blender 3.x / 4.x / 5.x (stable native API)
#
# v1.20.8 (Creator Stabilization Sprint) - Select & Transform lifecycle:
#
# The workflow appeared to "exit" the moment a selection tool was chosen. The
# tools were fine; the PANEL was the bug. Its whole section was gated on
# `context.mode == 'SCULPT'` (panels/dynax_panel.py), but every selection tool
# here deliberately switches to EDIT mode - so on the next redraw the section
# vanished and the user was dropped back at "Enter sculpt mode".
#
# The fix has two halves:
#   * panels/dynax_panel.py now treats SCULPT *or* EDIT as in-workflow, and
#     keys the section on the explicit `dynax_region_edit_active` scene flag
#     that the operators below own - so a mode switch that the workflow itself
#     performs can never look like the user leaving.
#   * this module now owns an explicit session: entering takes a BASELINE of
#     the mesh (so Cancel can restore it byte-exact), Confirm applies and
#     exits cleanly, Cancel restores and exits cleanly, and Clear Selection
#     only drops the painted region - it never ends the session.
#
# The session flag is set on ENTRY to any select tool and cleared ONLY by
# Confirm/Cancel, never by a mode change, so nothing here can bounce the user
# back to Sculpt mode unless they explicitly ask for it.

import bpy
import bmesh
from mathutils import Vector
from bpy.types import Operator

from ..utils.dynax_logging import (
    creator_guard, log_operator_error, validate_mesh_object,
)

VGROUP_NAME = "DynaX_Selection"

# Scene flag: a region-edit session is open. Owned by this module; read by the
# panel so its gating never depends on a transient Blender mode.
REGION_ACTIVE_KEY = "dynax_region_edit_active"
# Name of the mesh datablock holding the pre-edit baseline for Cancel.
BASELINE_KEY = "dynax_region_baseline_mesh"


# ── Selection ownership + freshness (selection-isolation fix) ──────────────────
#
# `DynaX_Selection` is ONE persistent vertex group on the mesh, and both the
# Sculpt step's "Select & transform region" and the Trimline step's Method A
# drive the same operators to write it. Nothing recorded WHICH workflow locked
# it, so a region locked in Sculpt stayed live and `dynax.separate_selected`
# (which reads the group and only the group - never the visible mesh selection)
# happily separated the old Sculpt region while the viewport highlighted a
# freshly painted Trimline one.
#
# The group is now STAMPED at lock time with the workflow step that owns it, the
# object it was taken from, and an invalidation counter. Anything that can make
# a stored region stale bumps the scene counter; a consumer must find a stamp
# that still matches or it refuses outright and never falls back.

# Object props, stamped on the mesh that the region was locked from.
SELECTION_OWNER_KEY = "dynax_selection_owner"    # workflow step id
SELECTION_STAMP_KEY = "dynax_selection_stamp"    # generation at lock time
# Scene prop: monotonically increasing invalidation counter.
SELECTION_GENERATION_KEY = "dynax_selection_generation"
SELECTION_COUNT_KEY = "dynax_selection_count"


def current_generation(scene):
    """The scene's current selection generation (invalidation counter)."""
    try:
        return int(scene.get(SELECTION_GENERATION_KEY, 0))
    except (TypeError, ValueError):
        return 0


def bump_generation(scene):
    """Invalidate every stored region stamp. Cheap, and never touches geometry."""
    generation = current_generation(scene) + 1
    scene[SELECTION_GENERATION_KEY] = generation
    return generation


def active_step(context):
    """The workflow step id currently on screen, or "" when unavailable."""
    props = getattr(context.scene, "dynax_props", None)
    return getattr(props, "active_step", "") or ""


def clear_mesh_selection_flags(context, obj):
    """Drop Blender's own vertex/edge/face selection flags on `obj`.

    Interaction state only - vertex positions, vertex groups other than the
    DynaX region, modifiers, shape keys and every sculpted change are untouched.

    Handles both modes explicitly. In EDIT mode the authoritative copy is the
    live edit-mesh, so it is cleared through bmesh and written back; clearing
    only `obj.data` there would be silently overwritten the moment Blender
    flushed the edit-mesh (the classic "stale edit-mesh selection" trap).
    """
    if obj is None or obj.type != 'MESH':
        return False

    if obj.mode == 'EDIT':
        try:
            bm = bmesh.from_edit_mesh(obj.data)
            for vert in bm.verts:
                vert.select = False
            for edge in bm.edges:
                edge.select = False
            for face in bm.faces:
                face.select = False
            bm.select_flush(False)
            bmesh.update_edit_mesh(obj.data)
            # Keep the object-mode copy in step, so a later mode switch cannot
            # resurrect the flags we just cleared.
            obj.update_from_editmode()
        except Exception:  # noqa: BLE001 - never block a workflow transition
            return False
        return True

    mesh = obj.data
    for vert in mesh.vertices:
        vert.select = False
    for edge in mesh.edges:
        edge.select = False
    for polygon in mesh.polygons:
        polygon.select = False
    mesh.update()
    return True


def stamp_selection(context, obj, owner):
    """Record which workflow locked the current region, and when."""
    obj[SELECTION_OWNER_KEY] = owner
    obj[SELECTION_STAMP_KEY] = current_generation(context.scene)


def selection_owner(obj):
    return obj.get(SELECTION_OWNER_KEY, "") if obj is not None else ""


def selection_is_fresh(context, obj, owner):
    """(ok, reason) - is `obj`'s locked region a live region owned by `owner`?

    Every condition is checked explicitly and a failure is always a refusal,
    never a fallback to whatever happens to be selected.
    """
    if obj is None or obj.type != 'MESH':
        return False, "Select the working mesh first."
    if VGROUP_NAME not in obj.vertex_groups:
        return False, "no locked region"
    stored_owner = obj.get(SELECTION_OWNER_KEY, "")
    if not stored_owner:
        return False, "the locked region predates this workflow step"
    if stored_owner != owner:
        return False, f"the locked region belongs to the {stored_owner} step"
    try:
        stamp = int(obj.get(SELECTION_STAMP_KEY, -1))
    except (TypeError, ValueError):
        stamp = -1
    if stamp != current_generation(context.scene):
        return False, "the locked region is out of date"
    return True, ""


def invalidate_selection(context, obj=None, drop_group=True):
    """Forget any locked region and clear leftover selection flags.

    Interaction state ONLY. This never restores a baseline, never swaps a mesh
    datablock and never removes geometry, so sculpting already applied survives
    untouched - clearing a selection is not an undo.

    Called when a workflow step changes, when a trim line is cleared or
    restarted, and by Clear Selection, so no workflow can inherit another's
    region.
    """
    scene = context.scene
    if obj is None:
        obj = context.active_object
    bump_generation(scene)
    scene[SELECTION_COUNT_KEY] = 0

    if obj is None or obj.type != 'MESH':
        return False

    clear_mesh_selection_flags(context, obj)
    if drop_group and VGROUP_NAME in obj.vertex_groups:
        obj.vertex_groups.remove(obj.vertex_groups[VGROUP_NAME])
    for key in (SELECTION_OWNER_KEY, SELECTION_STAMP_KEY):
        if key in obj:
            del obj[key]
    return True


def on_workflow_step_changed(context, previous_step, new_step):
    """Hard boundary between workflow steps.

    Each step owns its own selection: leaving one drops its locked region and
    its leftover mesh selection flags, so the next step starts clean and can
    never consume the previous step's region. An open region-edit session is
    closed the way Confirm closes it (geometry kept, baseline released) rather
    than left half-open across a step change.
    """
    if previous_step == new_step:
        return False
    obj = context.active_object
    scene = context.scene
    if _session_open(scene):
        if obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT':
            obj.update_from_editmode()          # keep the sculpted/edited result
        _end_session(context, obj)
    invalidate_selection(context, obj)
    return True


# ── Region-edit session ────────────────────────────────────────────────────────

def _session_open(scene):
    return bool(scene.get(REGION_ACTIVE_KEY, False))


def _begin_session(context, obj):
    """Mark the region-edit session open and snapshot the mesh for Cancel.

    The baseline is a full mesh-datablock copy - the same technique the
    Version Checkpoints and before/after comparison already use - so Cancel
    restores vertex positions byte-exact rather than trying to invert whatever
    transforms the user applied. Taken ONCE per session: re-entering a tool
    mid-session (Box -> Circle -> Move) must not overwrite the baseline, or
    Cancel would only undo the last step.
    """
    scene = context.scene
    if _session_open(scene) and obj.get(BASELINE_KEY):
        return
    _clear_baseline(obj)
    baseline = obj.data.copy()
    baseline.name = f"{obj.name}_REGION_BASELINE"
    baseline.use_fake_user = True   # survive a save/reload mid-session
    obj[BASELINE_KEY] = baseline.name
    scene[REGION_ACTIVE_KEY] = True


def _clear_baseline(obj):
    """Drop the stored baseline mesh datablock, if any."""
    name = obj.get(BASELINE_KEY, "")
    if name:
        mesh = bpy.data.meshes.get(name)
        if mesh is not None:
            mesh.use_fake_user = False
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)
    if BASELINE_KEY in obj:
        del obj[BASELINE_KEY]


def _end_session(context, obj=None):
    """Close the session and tidy up interaction state (not geometry)."""
    scene = context.scene
    if obj is not None:
        _clear_baseline(obj)
    scene[REGION_ACTIVE_KEY] = False
    _set_proportional(context, False)
    _viewport_xray(context, False)


# ── Context-safe mode switching ────────────────────────────────────────────────

def _set_mode(context, obj, mode):
    """
    Switch object mode reliably, even when the mouse is over the N-panel
    (which otherwise makes bpy.ops.object.mode_set fail silently).
    Returns True if the object ended up in the requested mode.
    """
    if obj.mode == mode:
        return True

    # Try with a 3D viewport context override
    win = context.window
    scr = win.screen if win else None
    if scr:
        for area in scr.areas:
            if area.type == 'VIEW_3D':
                try:
                    with context.temp_override(window=win, area=area,
                                               active_object=obj, object=obj):
                        bpy.ops.object.mode_set(mode=mode)
                except Exception:
                    pass
                break

    # Fallback plain call
    if obj.mode != mode:
        try:
            bpy.ops.object.mode_set(mode=mode)
        except Exception:
            pass

    return obj.mode == mode


# ── Helpers ────────────────────────────────────────────────────────────────────

def _enter_edit_select(context, select_through=False):
    """
    Enter Edit mode set up for region selection:
      - face select mode (cleaner highlight, avoids the dense vertex-dot
        overlay that's disorienting for non-Blender-trained clinicians)
      - X-ray / select-through controllable per-tool
      - nothing selected to start
    """
    obj = context.active_object
    if not obj or obj.type != 'MESH':
        return False

    if context.mode != 'EDIT':
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='EDIT')

    # Face-select mode gives a clean solid highlight instead of a dense grid
    # of vertex dots, which is much easier for clinicians to read at a glance.
    bpy.ops.mesh.select_mode(type='FACE')

    # Control select-through via X-ray in the viewport, and quiet down the
    # overlay so the highlight is the only thing that stands out.
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    try:
                        space.shading.show_xray = select_through
                    except Exception:
                        pass
                    try:
                        space.overlay.show_extra_indices = False
                    except Exception:
                        pass
    return True


def _viewport_xray(context, on):
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    try:
                        space.shading.show_xray = on
                    except Exception:
                        pass


# ── Selection tools ────────────────────────────────────────────────────────────

class DynaxSelectBox(Operator):
    """Box-select a region (drag a rectangle). Press B or just drag."""
    bl_idname = "dynax.select_box"
    bl_label = "Box select"
    bl_options = {'REGISTER'}

    @creator_guard("Could not start box select. See the DynaX log for details.")
    def execute(self, context):
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}
        props = context.scene.dynax_props
        if not _enter_edit_select(context, props.selection_through):
            self.report({'ERROR'}, "Could not enter selection mode. Hover the 3D viewport and try again.")
            return {'CANCELLED'}
        _begin_session(context, obj)
        # Activate the native box-select tool
        try:
            bpy.ops.wm.tool_set_by_id(name='builtin.select_box')
        except Exception:
            pass
        self.report({'INFO'},
            "Drag a box over the area to select. Then click 'Lock selection'.")
        return {'FINISHED'}


class DynaxSelectLasso(Operator):
    """Lasso-select a region (draw a freehand outline)"""
    bl_idname = "dynax.select_lasso"
    bl_label = "Lasso select"
    bl_options = {'REGISTER'}

    @creator_guard("Could not start lasso select. See the DynaX log for details.")
    def execute(self, context):
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}
        props = context.scene.dynax_props
        if not _enter_edit_select(context, props.selection_through):
            self.report({'ERROR'}, "Could not enter selection mode. Hover the 3D viewport and try again.")
            return {'CANCELLED'}
        _begin_session(context, obj)
        try:
            bpy.ops.wm.tool_set_by_id(name='builtin.select_lasso')
        except Exception:
            pass
        self.report({'INFO'},
            "Draw a lasso outline to select. Then click 'Lock selection'.")
        return {'FINISHED'}


class DynaxSelectCircle(Operator):
    """Circle-select a region (paint over verts with a round brush)"""
    bl_idname = "dynax.select_circle"
    bl_label = "Circle select"
    bl_options = {'REGISTER'}

    @creator_guard("Could not start circle select. See the DynaX log for details.")
    def execute(self, context):
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}
        props = context.scene.dynax_props
        # Respect the user's own Select-through toggle. Forcing X-ray ON here
        # (as v2.6.10 did) caused painting to select straight through to the
        # BACK of the mesh too, which is the "both sides get selected" bug.
        # The actual gap problem on concave folds is better solved by
        # painting from a couple of angles (front, then SHIFT+paint from
        # another angle) rather than by forcing X-ray globally.
        if not _enter_edit_select(context, select_through=props.selection_through):
            self.report({'ERROR'}, "Could not enter selection mode. Hover the 3D viewport and try again.")
            return {'CANCELLED'}
        _begin_session(context, obj)
        try:
            bpy.ops.wm.tool_set_by_id(name='builtin.select_circle')
        except Exception:
            pass

        # Sync the native circle-select tool's radius with the DynaX panel's
        # own radius property. operator_properties_last() only seeds the next
        # manual operator call and does NOT affect the tool widget already
        # active on screen — it had no visible effect. The radius for
        # builtin.select_circle is actually stored on the tool's own
        # ToolSettings.gpencil_sculpt-style "size" via the active brush-less
        # circle select, which Blender exposes through
        # `tool_settings.unified_paint_settings` is NOT used here since this
        # is a mesh select tool, not a paint tool — instead we directly poke
        # the WindowManager's active tool's operator properties, which DOES
        # update the on-screen circle radius immediately.
        radius = getattr(props, "select_brush_radius", 40)
        try:
            tool = context.workspace.tools.from_space_view3d_mode(context.mode, create=False)
            if tool and tool.idname == 'builtin.select_circle':
                # The tool's brush-circle radius is stored in its own
                # operator properties (ToolDef.operator_properties), which
                # IS what drives the on-screen circle and the actual select
                # radius used when the user clicks/drags.
                op_props = tool.operator_properties("view3d.select_circle")
                if op_props:
                    op_props.radius = radius
        except Exception:
            pass

        self.report({'INFO'},
            f"Paint over the area to select (radius={radius}px, scroll to resize, "
            "SHIFT=add, CTRL=subtract). Then 'Lock selection'.")
        return {'FINISHED'}


class DynaxSelectClear(Operator):
    """Clear the painted region only — stays in Select & Transform"""
    bl_idname = "dynax.select_clear"
    bl_label = "Clear selection"
    bl_options = {'REGISTER', 'UNDO'}

    @creator_guard("Could not clear the selection. See the DynaX log for details.")
    def execute(self, context):
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}

        # NOTE: this clears the painted region ONLY. It deliberately does not
        # touch the session flag or the baseline - clearing a selection to
        # repaint it is a normal step mid-session, not an exit.

        # Deselect all in edit mode
        if context.mode == 'EDIT':
            bpy.ops.mesh.select_all(action='DESELECT')

        # Drops the locked group, the mesh selection flags in either mode, the
        # ownership stamp, and bumps the generation - so a cleared region can
        # never be consumed afterwards.
        invalidate_selection(context, obj)
        self.report({'INFO'}, "✓ Selection cleared")
        return {'FINISHED'}


class DynaxSelectInvert(Operator):
    """Invert the current selection"""
    bl_idname = "dynax.select_invert"
    bl_label = "Invert selection"
    bl_options = {'REGISTER'}

    @creator_guard("Could not invert the selection. See the DynaX log for details.")
    def execute(self, context):
        # Validate first: mode_set with no active mesh raised a raw RuntimeError
        # straight at the clinician.
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}
        if not _set_mode(context, obj, 'EDIT'):
            self.report({'ERROR'}, "Hover the 3D viewport and try again.")
            return {'CANCELLED'}
        bpy.ops.mesh.select_all(action='INVERT')
        return {'FINISHED'}


class DynaxSelectAll(Operator):
    """Select the entire mesh"""
    bl_idname = "dynax.select_all"
    bl_label = "Select all"
    bl_options = {'REGISTER'}

    @creator_guard("Could not select all. See the DynaX log for details.")
    def execute(self, context):
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}
        if not _set_mode(context, obj, 'EDIT'):
            self.report({'ERROR'}, "Hover the 3D viewport and try again.")
            return {'CANCELLED'}
        bpy.ops.mesh.select_all(action='SELECT')
        return {'FINISHED'}


# ── Lock selection → vertex group ──────────────────────────────────────────────

class DynaxLockSelection(Operator):
    """Save the current selection as a persistent vertex group"""
    bl_idname = "dynax.lock_selection"
    bl_label = "Lock selection"
    bl_options = {'REGISTER', 'UNDO'}

    @creator_guard("Could not lock the selection. See the DynaX log for details.")
    def execute(self, context):
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}

        # Locking is a valid session entry point too (e.g. the user painted with
        # Blender's own tools): make sure a baseline exists before any transform.
        _begin_session(context, obj)

        # Flush any edit-mode selection into the mesh data WITHOUT relying on
        # bpy.ops mode switching (which fails when the panel has mouse focus).
        # obj.update_from_editmode() copies the live edit selection to obj.data.
        if obj.mode == 'EDIT':
            obj.update_from_editmode()

        # Read the selection from mesh data (now up to date)
        selected = [v.index for v in obj.data.vertices if v.select]

        if not selected:
            self.report({'WARNING'},
                "Nothing selected. Use Box/Lasso/Circle to select an area first.")
            return {'CANCELLED'}

        # Switch to Object mode using the context-safe helper (works even
        # when the mouse is over the N-panel).
        if obj.mode != 'OBJECT':
            if not _set_mode(context, obj, 'OBJECT'):
                self.report({'ERROR'},
                    "Could not leave Edit mode. Move your mouse over the 3D "
                    "viewport and press Tab, then click Lock selection again.")
                return {'CANCELLED'}

        # Now safe to create the vertex group
        if VGROUP_NAME in obj.vertex_groups:
            obj.vertex_groups.remove(obj.vertex_groups[VGROUP_NAME])
        vg = obj.vertex_groups.new(name=VGROUP_NAME)
        vg.add(selected, 1.0, 'REPLACE')

        # Stamp the region with the workflow step that locked it and the current
        # generation. Consumers (Separate region) check both, so a region locked
        # in Sculpt can never be picked up as a Trimline region.
        stamp_selection(context, obj, active_step(context))

        context.scene[SELECTION_COUNT_KEY] = len(selected)
        self.report({'INFO'},
            f"✓ Locked {len(selected):,} verts. Choose blend then Move/Rotate.")
        return {'FINISHED'}


# ── Transform the locked region ────────────────────────────────────────────────

def _restore_selection_from_group(context, obj):
    """
    Select exactly the locked vertex group's verts, nothing else.
    Sets selection on mesh data directly (reliable), then enters Edit mode.
    """
    if VGROUP_NAME not in obj.vertex_groups:
        return False

    if obj.mode != 'OBJECT':
        _set_mode(context, obj, 'OBJECT')

    vg_index = obj.vertex_groups[VGROUP_NAME].index
    me = obj.data

    in_group = set()
    for v in me.vertices:
        for g in v.groups:
            if g.group == vg_index and g.weight > 0.5:
                in_group.add(v.index)
                break

    if not in_group:
        return False

    for v in me.vertices:
        v.select = (v.index in in_group)
    for e in me.edges:
        e.select = False
    for p in me.polygons:
        p.select = False
    me.update()

    obj.vertex_groups.active = obj.vertex_groups[VGROUP_NAME]
    _set_mode(context, obj, 'EDIT')
    try:
        bpy.ops.mesh.select_mode(type='VERT')
    except Exception:
        pass

    try:
        context.scene.tool_settings.transform_pivot_point = 'MEDIAN_POINT'
    except Exception:
        pass
    return True


def _set_proportional(context, enabled):
    ts = context.scene.tool_settings
    ts.use_proportional_edit = enabled
    if enabled:
        ts.proportional_edit_falloff = 'SMOOTH'
        obj = context.active_object
        if obj:
            ts.proportional_size = max(obj.dimensions) * 0.1


class DynaxMoveRegion(Operator):
    """Move the locked region — rigid or soft blend"""
    bl_idname = "dynax.move_region"
    bl_label = "Move region"
    bl_options = {'REGISTER', 'UNDO'}

    @creator_guard("Could not start Move. See the DynaX log for details.")
    def execute(self, context):
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}
        if VGROUP_NAME not in obj.vertex_groups:
            self.report({'WARNING'},
                "No locked region. Select an area, then click 'Lock selection'.")
            return {'CANCELLED'}

        # Switching Move -> Rotate -> Push/Pull re-selects the SAME locked
        # vertex group every time, so the painted region persists across tool
        # switches instead of being lost with the transient edit selection.
        _begin_session(context, obj)
        props = context.scene.dynax_props
        if not _restore_selection_from_group(context, obj):
            self.report({'ERROR'}, "Could not isolate the locked region")
            return {'CANCELLED'}
        _set_proportional(context, props.region_transform_mode == 'SOFT')
        try:
            bpy.ops.wm.tool_set_by_id(name='builtin.move')
        except Exception:
            pass
        mode_txt = "soft blend" if props.region_transform_mode == 'SOFT' else "rigid"
        self.report({'INFO'},
            f"✓ Move gizmo ready ({mode_txt}). Drag the arrows to move the region.")
        return {'FINISHED'}


class DynaxRotateRegion(Operator):
    """Rotate the locked region — rigid or soft blend"""
    bl_idname = "dynax.rotate_region"
    bl_label = "Rotate region"
    bl_options = {'REGISTER', 'UNDO'}

    @creator_guard("Could not start Rotate. See the DynaX log for details.")
    def execute(self, context):
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}
        if VGROUP_NAME not in obj.vertex_groups:
            self.report({'WARNING'},
                "No locked region. Select an area, then click 'Lock selection'.")
            return {'CANCELLED'}

        _begin_session(context, obj)
        props = context.scene.dynax_props
        if not _restore_selection_from_group(context, obj):
            self.report({'ERROR'}, "Could not isolate the locked region")
            return {'CANCELLED'}
        _set_proportional(context, props.region_transform_mode == 'SOFT')
        try:
            bpy.ops.wm.tool_set_by_id(name='builtin.rotate')
        except Exception:
            pass
        mode_txt = "soft blend" if props.region_transform_mode == 'SOFT' else "rigid"
        self.report({'INFO'},
            f"✓ Rotate gizmo ready ({mode_txt}). Drag the rings to rotate.")
        return {'FINISHED'}


class DynaxFinishRegion(Operator):
    """Confirm the region edit — keeps your changes and closes the tool"""
    bl_idname = "dynax.finish_region"
    bl_label = "Confirm region edit"
    bl_options = {'REGISTER', 'UNDO'}

    @creator_guard("Could not finish the region edit. See the DynaX log for details.")
    def execute(self, context):
        obj = context.active_object
        # Commit any live edit-mode changes to the mesh datablock before the
        # session's baseline is dropped, so Confirm keeps exactly what is on
        # screen.
        if obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT':
            obj.update_from_editmode()
        if context.mode != 'OBJECT' and obj is not None:
            _set_mode(context, obj, 'OBJECT')
        _end_session(context, obj)
        self.report({'INFO'}, "✓ Region edit applied")
        return {'FINISHED'}


class DynaxCancelRegion(Operator):
    """Cancel the region edit — restores the mesh as it was before you started"""
    bl_idname = "dynax.cancel_region"
    bl_label = "Cancel region edit"
    bl_options = {'REGISTER', 'UNDO'}

    @creator_guard("Could not cancel the region edit. See the DynaX log for details.")
    def execute(self, context):
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}

        baseline_name = obj.get(BASELINE_KEY, "")
        baseline = bpy.data.meshes.get(baseline_name) if baseline_name else None
        if baseline is None:
            # Nothing to restore: still close the session cleanly rather than
            # leaving the user stuck in a half-open tool.
            if context.mode != 'OBJECT':
                _set_mode(context, obj, 'OBJECT')
            _end_session(context, obj)
            self.report({'WARNING'}, "No baseline to restore — region edit closed.")
            return {'CANCELLED'}

        # Must leave Edit mode BEFORE swapping the datablock: Blender holds the
        # edit-mesh open over obj.data, and replacing it underneath corrupts it.
        if context.mode != 'OBJECT':
            if not _set_mode(context, obj, 'OBJECT'):
                self.report({'ERROR'},
                    "Hover the 3D viewport and click Cancel again.")
                return {'CANCELLED'}

        current = obj.data
        restored = baseline.copy()          # keep the baseline itself intact
        restored.name = current.name
        obj.data = restored
        if current.users == 0:
            bpy.data.meshes.remove(current)

        # The locked group lived on the discarded datablock; the region is gone
        # with it, which is exactly what Cancel means. Bump the generation so no
        # consumer can act on a stamp that outlived its geometry.
        invalidate_selection(context, obj)
        _end_session(context, obj)
        self.report({'INFO'}, "✓ Region edit cancelled — mesh restored")
        return {'FINISHED'}


# ── Paint-select → separate → smooth (Method A, native vertex-group split) ──────
#
# An alternative to the spline trimline cut: paint/box/lasso-select the region to
# keep, lock it into the DynaX_Selection vertex group, then separate it into its
# own object using Blender's native mesh.separate - which works on ANY mesh and
# never hits the bisect's edge cases. The split rim is then smoothed (and
# optionally filled) so it prints cleanly.

class DynaxSeparateSelected(Operator):
    """Separate the locked selection into its own object, leaving the rest as a
    second object."""
    bl_idname = "dynax.separate_selected"
    bl_label = "Separate selected region"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}

        # FRESHNESS GATE (selection-isolation fix). The region must have been
        # locked in the step that is asking for it, on THIS object, and must not
        # have been invalidated since. A stale region is refused outright - this
        # operator must never fall back to a previous step's region, to the
        # visible mesh selection, or to whatever vertex group happens to exist.
        step = active_step(context)
        ok, reason = selection_is_fresh(context, obj, step)
        if not ok:
            if step == 'trimline':
                self.report({'WARNING'},
                    "No active trimline. Create or confirm a trimline first — "
                    f"select the region to keep, then 'Lock selection' ({reason}).")
            else:
                self.report({'WARNING'},
                    f"No region locked in this step ({reason}). Select a region, "
                    "then click 'Lock selection' first.")
            return {'CANCELLED'}

        # Collect the locked verts (weight > 0.5).
        vg_index = obj.vertex_groups[VGROUP_NAME].index
        me = obj.data
        in_group = set()
        for v in me.vertices:
            for g in v.groups:
                if g.group == vg_index and g.weight > 0.5:
                    in_group.add(v.index)
                    break
        if not in_group:
            self.report({'WARNING'}, "Locked region is empty. Paint a region first.")
            return {'CANCELLED'}

        # Enter edit mode and select the faces whose MAJORITY of verts are in the
        # group (partial faces stay with the remainder, so the split lands on
        # whole faces). Select verts+edges+faces explicitly so mesh.separate has a
        # fully consistent selection to act on.
        if not _set_mode(context, obj, 'EDIT'):
            self.report({'ERROR'},
                "Could not enter Edit mode. Hover the 3D viewport and try again.")
            return {'CANCELLED'}

        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        for v in bm.verts:
            v.select = False
        for e in bm.edges:
            e.select = False
        sel_faces = [f for f in bm.faces
                     if sum(1 for v in f.verts if v.index in in_group) > len(f.verts) / 2]
        for f in bm.faces:
            f.select = False
        for f in sel_faces:
            f.select = True
            for v in f.verts:
                v.select = True
            for e in f.edges:
                e.select = True
        bm.select_flush(True)
        bmesh.update_edit_mesh(me)

        if not sel_faces:
            _set_mode(context, obj, 'OBJECT')
            self.report({'WARNING'},
                "No whole faces fell inside the region — select a larger area.")
            return {'CANCELLED'}

        try:
            bpy.ops.mesh.separate(type='SELECTED')
        except Exception as e:
            _set_mode(context, obj, 'OBJECT')
            self.report({'ERROR'}, f"Separate failed: {e}")
            return {'CANCELLED'}
        _set_mode(context, obj, 'OBJECT')

        # The original datablock (`obj`) keeps the remainder; every other selected
        # mesh is the separated selection. Naming by identity is reliable
        # regardless of which part is larger.
        parts = [o for o in context.selected_objects if o.type == 'MESH']
        sel_n = 0
        for o in parts:
            if o is obj:
                o.name = "DynaX_Remainder"
            elif sel_n == 0:
                o.name = "DynaX_Selected"
                sel_n += 1
            else:
                sel_n += 1
                o.name = f"DynaX_Part_{sel_n + 1}"

        # Tint the remainder red and keep it visible, so it's easy to spot in the
        # viewport/outliner and delete once the user has confirmed the keep part.
        remainder_obj = bpy.data.objects.get("DynaX_Remainder")
        if remainder_obj:
            remainder_obj.color = (0.8, 0.2, 0.2, 0.5)
            remainder_obj.hide_viewport = False

        selected_obj = bpy.data.objects.get("DynaX_Selected")
        if selected_obj:
            bpy.ops.object.select_all(action='DESELECT')
            selected_obj.select_set(True)
            context.view_layer.objects.active = selected_obj

        # The region has been consumed. Both halves inherit a copy of the group
        # and its stamp from the split, so invalidate now - re-running Separate
        # must require a NEW lock, not re-use a region that no longer describes
        # a single object.
        for part in (bpy.data.objects.get("DynaX_Remainder"),
                     bpy.data.objects.get("DynaX_Selected")):
            if part is not None and part.type == 'MESH':
                for key in (SELECTION_OWNER_KEY, SELECTION_STAMP_KEY):
                    if key in part:
                        del part[key]
        bump_generation(context.scene)
        context.scene[SELECTION_COUNT_KEY] = 0

        self.report({'INFO'},
            "✓ Region separated into DynaX_Selected and DynaX_Remainder. "
            "Smooth the cut boundary, then add thickness.")
        return {'FINISHED'}


class DynaxSmoothCutBoundary(Operator):
    """Smooth the open cut-boundary edges on the active object. Run on each part
    after separating; run again for more smoothing."""
    bl_idname = "dynax.smooth_cut_boundary"
    bl_label = "Smooth cut boundary"
    bl_options = {'REGISTER', 'UNDO'}

    iterations: bpy.props.IntProperty(
        name="Iterations",
        description="More iterations = smoother boundary (but may distort shape)",
        default=8, min=1, max=32)
    factor: bpy.props.FloatProperty(
        name="Strength",
        description="How strongly to pull boundary verts toward the average",
        default=0.6, min=0.0, max=1.0)

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()

        boundary_verts = {v for e in bm.edges if e.is_boundary for v in e.verts}
        if not boundary_verts:
            bm.free()
            self.report({'WARNING'},
                "No open boundary found on this object — it may already be "
                "closed, or hasn't been cut/separated yet.")
            return {'CANCELLED'}

        print(f"[DynaX] Smoothing {len(boundary_verts)} boundary verts, "
              f"{self.iterations} iterations, factor {self.factor}")

        # Iteratively pull each boundary vert toward the average of its boundary
        # neighbours - rounds off the jagged teeth on the cut rim.
        for _ in range(self.iterations):
            new_co = {}
            for v in boundary_verts:
                nb = [e.other_vert(v).co for e in v.link_edges
                      if e.other_vert(v) in boundary_verts]
                if nb:
                    avg = sum(nb, Vector()) / len(nb)
                    new_co[v] = v.co.lerp(avg, self.factor)
            for v, co in new_co.items():
                v.co = co

        # Lightly relax the ring of verts just inside the boundary too, so the
        # smoothed rim blends into the surface without a visible crease.
        adjacent = set()
        for v in boundary_verts:
            for e in v.link_edges:
                ov = e.other_vert(v)
                if ov not in boundary_verts:
                    adjacent.add(ov)
        for _ in range(2):
            adj_co = {}
            for v in adjacent:
                nb = [e.other_vert(v).co for e in v.link_edges]
                if nb:
                    avg = sum(nb, Vector()) / len(nb)
                    adj_co[v] = v.co.lerp(avg, 0.2)
            for v, co in adj_co.items():
                v.co = co

        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(obj.data)
        obj.data.update()
        bm.free()

        self.report({'INFO'},
            f"✓ Boundary smoothed ({self.iterations} iterations). "
            "Run again for more, or add thickness now.")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=280)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "iterations", text="Smoothing passes")
        layout.prop(self, "factor",     text="Strength (0=none, 1=full)")
        layout.separator()
        layout.label(text="Tip: run 2–3 times for very smooth edges", icon='INFO')


class DynaxFillBoundary(Operator):
    """Fill the open cut boundary to make the mesh watertight before thickening."""
    bl_idname = "dynax.fill_boundary"
    bl_label = "Fill cut boundary"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        bm = bmesh.new()
        bm.from_mesh(obj.data)
        boundary_edges = [e for e in bm.edges if e.is_boundary]
        if not boundary_edges:
            bm.free()
            self.report({'WARNING'}, "No open boundary to fill.")
            return {'CANCELLED'}

        try:
            bmesh.ops.triangle_fill(bm, edges=boundary_edges, use_beauty=True)
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        except Exception as e:
            bm.free()
            self.report({'ERROR'}, f"Fill failed: {e}")
            return {'CANCELLED'}

        bm.to_mesh(obj.data)
        obj.data.update()
        bm.free()
        self.report({'INFO'}, "✓ Boundary filled. Now add thickness.")
        return {'FINISHED'}


class DynaxDeletePart(Operator):
    """Delete a separated part (e.g. the Remainder after separation)"""
    bl_idname = "dynax.delete_part"
    bl_label = "Delete part"
    bl_options = {'REGISTER', 'UNDO'}

    part_name: bpy.props.StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.part_name)
        if not obj:
            self.report({'ERROR'}, f"'{self.part_name}' not found")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass
        bpy.data.objects.remove(obj, do_unlink=True)
        self.report({'INFO'}, f"✓ Deleted {self.part_name}")
        return {'FINISHED'}


# ── Legacy aliases ─────────────────────────────────────────────────────────────

class DynaxGizmoMove(Operator):
    bl_idname = "dynax.gizmo_move"
    bl_label = "Move selected region"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        return bpy.ops.dynax.move_region()

class DynaxGizmoRotate(Operator):
    bl_idname = "dynax.gizmo_rotate"
    bl_label = "Rotate selected region"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        return bpy.ops.dynax.rotate_region()

class DynaxMeshFilterGrab(Operator):
    bl_idname = "dynax.mesh_filter_grab"
    bl_label = "Grab region"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        return bpy.ops.dynax.move_region()

class DynaxMaskExtract(Operator):
    bl_idname = "dynax.mask_filter_smooth"
    bl_label = "Relax selected region"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        if VGROUP_NAME not in obj.vertex_groups:
            self.report({'WARNING'}, "Lock a selection first")
            return {'CANCELLED'}
        _restore_selection_from_group(context, obj)
        try:
            bpy.ops.mesh.vertices_smooth(factor=0.5, repeat=3)
        except Exception:
            pass
        return {'FINISHED'}

class DynaxRegionToVertexGroup(Operator):
    bl_idname = "dynax.region_to_vgroup"
    bl_label = "Lock selection for transform"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        return bpy.ops.dynax.lock_selection()
