# operators/box_crop.py - Box Crop Operator

import bpy
from bpy.types import Operator

# CLASS 1: The Tool Starter
class BoxCrop(Operator):
    """Step 1: Create a box to define the crop area"""
    bl_idname = "dynax.box_crop"
    bl_label = "Start Box Crop"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a Mesh object first")
            return {'CANCELLED'}

        # Create the Cutter Box sized to the object
        max_dim = max(obj.dimensions) if obj.dimensions.length > 0 else 1.5
        box_size = max_dim * 1.2
        bpy.ops.mesh.primitive_cube_add(size=box_size, location=obj.location)
        box = context.active_object
        box.name = "Dynax_Cutter"
        box.display_type = 'WIRE' 
        
        # Add Modifier
        context.view_layer.objects.active = obj
        mod = obj.modifiers.new(name="DynaxCrop", type='BOOLEAN')
        mod.operation = 'INTERSECT' 
        mod.object = box
        
        # FIX: Your Blender version uses 'FLOAT' instead of 'FAST'
        try:
            mod.solver = 'FLOAT'
        except TypeError:
            # Fallback to EXACT if the version changes again
            mod.solver = 'EXACT'
        
        # Select Box for adjustment
        bpy.ops.object.select_all(action='DESELECT')
        box.select_set(True)
        context.view_layer.objects.active = box
        
        # Switch to Scale Tool
        bpy.ops.wm.tool_set_by_id(name='builtin.scale')

        self.report({'INFO'}, "Adjust the box, then click 'Apply Crop'")
        return {'FINISHED'}

# CLASS 2: The Tool Finisher
class BoxCropApply(Operator):
    """Step 2: Apply the cut and delete the box"""
    bl_idname = "dynax.box_crop_apply"
    bl_label = "Apply Crop"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        box = bpy.data.objects.get("Dynax_Cutter")
        
        target_obj = None
        for o in context.scene.objects:
            if o.type == 'MESH' and "DynaxCrop" in o.modifiers:
                target_obj = o
                break
        
        if not target_obj or not box:
            self.report({'ERROR'}, "Could not find the Crop Box or Target Object")
            return {'CANCELLED'}

        # Apply Modifier
        context.view_layer.objects.active = target_obj
        try:
            bpy.ops.object.modifier_apply(modifier="DynaxCrop")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to apply: {e}")
            return {'CANCELLED'}

        # Delete Box and Cleanup
        bpy.data.objects.remove(box, do_unlink=True)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.fill_holes()
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_loose()
        bpy.ops.mesh.delete(type='VERT')
        bpy.ops.object.mode_set(mode='OBJECT')
        
        bpy.ops.wm.tool_set_by_id(name='builtin.select_box')

        self.report({'INFO'}, "Crop Applied Successfully")
        return {'FINISHED'}
