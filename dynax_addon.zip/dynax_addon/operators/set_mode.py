# operators/set_mode.py - DynaX workflow mode selector (Creator / ParaForge)
#
# Tiny operator that flips the top-level entry mode. The panel reads
# props.dynax_mode to decide which workflow to render.

from bpy.types import Operator
from bpy.props import StringProperty


class DynaxSetMode(Operator):
    bl_idname = "dynax.set_mode"
    bl_label = "Set DynaX Mode"
    bl_description = "Switch between the Creator (scan) and ParaForge (parametric) workflows"
    bl_options = {'REGISTER'}

    mode: StringProperty()

    def execute(self, context):
        context.scene.dynax_props.dynax_mode = self.mode
        # Reset the ParaFly device picker (TT/TLSO) whenever the user leaves
        # all the way back to the Start Menu, so re-entering ParaFly always
        # shows the picker fresh rather than silently reusing whichever
        # device was last active in the previous session.
        if self.mode == 'NONE' and hasattr(context.scene, "parafly_device_type"):
            context.scene.parafly_device_type = 'NONE'
        return {'FINISHED'}
