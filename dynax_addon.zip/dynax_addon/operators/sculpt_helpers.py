# operators/sculpt_helpers.py - Sculpt tools v1.4 (9 brushes + colored selection mask)
#
# v1.20.8: state validation + clinician-safe error reporting. Entering sculpt
# mode when already in it, selecting the same brush twice, or acting with no
# active mesh used to raise raw Python errors at the user; each is now a
# validated no-op or one concise message (see utils/dynax_logging.py).

import bpy
import bmesh
import math
from mathutils import Vector
from bpy.types import Operator
from bpy.props import FloatProperty, FloatVectorProperty, EnumProperty, BoolProperty

from ..utils.dynax_logging import (
    creator_guard, log_operator_error, validate_mesh_object,
)


def _set_object_mode(context, obj):
    """Leave whatever mode `obj` is in, tolerating a panel-focused context."""
    if obj is None or obj.mode == 'OBJECT':
        return True
    try:
        bpy.ops.object.mode_set(mode='OBJECT')
    except RuntimeError:
        pass
    return obj.mode == 'OBJECT'

# The 9 approved brushes
OP_BRUSHES = [
    ("dynax.sculpt_grab",    "Grab / Move",  "BRUSH_GRAB",       "builtin_brush.Grab"),
    ("dynax.sculpt_draw",    "Draw",         "BRUSH_ADD",        "builtin_brush.Draw"),
    ("dynax.sculpt_smooth",  "Smooth",       "MOD_SMOOTH",       "builtin_brush.Smooth"),
    ("dynax.sculpt_inflate", "Inflate",      "BRUSH_INFLATE",    "builtin_brush.Inflate"),
    ("dynax.sculpt_flatten", "Flatten",      "MOD_SMOOTH",       "builtin_brush.Flatten"),
    ("dynax.sculpt_mask",    "Mask",         "MOD_MASK",         "builtin_brush.Mask"),
    ("dynax.sculpt_trim",    "Trim / Cut",   "MOD_BOOLEAN",      "builtin_brush.Draw Sharp"),
    ("dynax.sculpt_crease",  "Crease",       "LINCURVE",         "builtin_brush.Crease"),
    ("dynax.sculpt_pinch",   "Pinch",        "FULLSCREEN_ENTER", "builtin_brush.Pinch"),
]

MASK_OBJ_NAME = "DynaX_SelectionMask"


def _disable_symmetry(context):
    """Kill all mirror symmetry. Blender restores the last-used symmetry settings
    on every mode switch, so this MUST be called AFTER mode_set into
    SCULPT/PAINT_VERTEX — not before — or symmetry silently comes back on."""
    try:
        sculpt = context.tool_settings.sculpt
        if sculpt:
            sculpt.use_symmetry_x = False
            sculpt.use_symmetry_y = False
            sculpt.use_symmetry_z = False
    except Exception:
        pass
    try:
        vpaint = context.tool_settings.vertex_paint
        if vpaint and hasattr(vpaint, 'use_symmetry_x'):
            vpaint.use_symmetry_x = False
            vpaint.use_symmetry_y = False
            if hasattr(vpaint, 'use_symmetry_z'):
                vpaint.use_symmetry_z = False
    except Exception:
        pass


def _enter_sculpt(context):
    """Enter sculpt mode if not already in it. Idempotent: calling it while
    already sculpting is a no-op, NOT an OBJECT->SCULPT round trip (which
    flickered the viewport and pushed a spurious undo step every time the user
    picked a brush)."""
    if context.mode == 'SCULPT':
        _disable_symmetry(context)   # still re-assert: Blender restores it
        return True
    obj = getattr(context, "active_object", None)
    if obj is None or obj.type != 'MESH':
        return False
    try:
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='SCULPT')
    except RuntimeError:
        return False
    _disable_symmetry(context)
    return True


def _set_brush(context, tool_name):
    if not _enter_sculpt(context):
        return False
    try:
        bpy.ops.wm.tool_set_by_id(name=tool_name)
        return True
    except Exception:
        try:
            # Blender 4.x+ brush name format
            alt = tool_name.replace("builtin_brush.", "builtin_brush.")
            bpy.ops.wm.tool_set_by_id(name=alt)
            return True
        except Exception:
            return False


def _brush_operator_body(operator, context, tool_name, label):
    """Shared body for the 9 brush operators.

    Selecting the same brush twice is a normal, harmless action (a clinician
    re-clicking to be sure) and must never error: tool_set_by_id is already
    idempotent, so this just re-asserts it and reports. A failure to switch is
    reported concisely instead of raising.
    """
    obj = validate_mesh_object(operator, context)
    if obj is None:
        return {'CANCELLED'}
    if not _set_brush(context, tool_name):
        operator.report({'ERROR'},
                        f"Could not select the {label} brush. "
                        "Hover the 3D viewport and try again.")
        return {'CANCELLED'}
    context.scene["dynax_active_brush"] = label
    return {'FINISHED'}


# ── Main sculpt operators ──────────────────────────────────────────────────────

class DynaxSculptStart(Operator):
    """Enter sculpt mode with O&P optimised settings"""
    bl_idname = "dynax.sculpt_start"
    bl_label = "Enter sculpt mode"
    bl_options = {'REGISTER', 'UNDO'}

    @creator_guard("Could not enter sculpt mode. See the DynaX log for details.")
    def execute(self, context):
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}
        # Entering sculpt mode twice is a no-op, not an error (_enter_sculpt is
        # idempotent) - clicking the button again must not flicker the viewport
        # or stack undo steps.
        already = (context.mode == 'SCULPT')
        if not _enter_sculpt(context):
            self.report({'ERROR'},
                        "Could not enter sculpt mode. Hover the 3D viewport and try again.")
            return {'CANCELLED'}
        try:
            bpy.ops.wm.tool_set_by_id(name='builtin_brush.Grab')
        except Exception:
            pass
        self.report({'INFO'},
                    "Already in sculpt mode — select a brush below" if already
                    else "Sculpt mode — select a brush below")
        return {'FINISHED'}


class DynaxSculptEnd(Operator):
    """Exit sculpt mode"""
    bl_idname = "dynax.sculpt_end"
    bl_label = "✓  Done sculpting"
    bl_options = {'REGISTER', 'UNDO'}

    @creator_guard("Could not exit sculpt mode. See the DynaX log for details.")
    def execute(self, context):
        obj = getattr(context, "active_object", None)
        if context.mode != 'OBJECT':
            _set_object_mode(context, obj)
        # This button is the workflow's EXPLICIT exit, so it also closes any open
        # region-edit session (keeping the edit - Cancel is the discard path).
        from .select_tools import _end_session
        _end_session(context, obj if obj is not None and obj.type == 'MESH' else None)
        # Remove selection mask if present
        mask = bpy.data.objects.get(MASK_OBJ_NAME)
        if mask:
            bpy.data.objects.remove(mask, do_unlink=True)
        self.report({'INFO'}, "✓ Sculpting complete")
        return {'FINISHED'}


# ── 9 brush operators ──────────────────────────────────────────────────────────

class DynaxSculptGrab(Operator):
    bl_idname = "dynax.sculpt_grab"
    bl_label = "Grab / Move"
    bl_options = {'REGISTER'}
    @creator_guard("Could not select the Grab brush. See the DynaX log.")
    def execute(self, context):
        return _brush_operator_body(self, context, 'builtin_brush.Grab', "Grab / Move")

class DynaxSculptDraw(Operator):
    bl_idname = "dynax.sculpt_draw"
    bl_label = "Draw"
    bl_options = {'REGISTER'}
    @creator_guard("Could not select the Draw brush. See the DynaX log.")
    def execute(self, context):
        return _brush_operator_body(self, context, 'builtin_brush.Draw', "Draw")

class DynaxSculptSmooth(Operator):
    bl_idname = "dynax.sculpt_smooth"
    bl_label = "Smooth"
    bl_options = {'REGISTER'}
    @creator_guard("Could not select the Smooth brush. See the DynaX log.")
    def execute(self, context):
        return _brush_operator_body(self, context, 'builtin_brush.Smooth', "Smooth")

class DynaxSculptInflate(Operator):
    bl_idname = "dynax.sculpt_inflate"
    bl_label = "Inflate"
    bl_options = {'REGISTER'}
    @creator_guard("Could not select the Inflate brush. See the DynaX log.")
    def execute(self, context):
        return _brush_operator_body(self, context, 'builtin_brush.Inflate', "Inflate")

class DynaxSculptFlatten(Operator):
    bl_idname = "dynax.sculpt_flatten"
    bl_label = "Flatten"
    bl_options = {'REGISTER'}
    @creator_guard("Could not select the Flatten brush. See the DynaX log.")
    def execute(self, context):
        return _brush_operator_body(self, context, 'builtin_brush.Flatten', "Flatten")

class DynaxSculptMask(Operator):
    bl_idname = "dynax.sculpt_mask"
    bl_label = "Mask"
    bl_options = {'REGISTER'}
    @creator_guard("Could not select the Mask brush. See the DynaX log.")
    def execute(self, context):
        return _brush_operator_body(self, context, 'builtin_brush.Mask', "Mask")

class DynaxSculptTrim(Operator):
    bl_idname = "dynax.sculpt_trim"
    bl_label = "Trim / Cut"
    bl_options = {'REGISTER'}
    @creator_guard("Could not select the Trim brush. See the DynaX log.")
    def execute(self, context):
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}
        # Draw Sharp doesn't exist on every Blender build; fall back to Draw.
        if _set_brush(context, 'builtin_brush.Draw Sharp') \
                or _set_brush(context, 'builtin_brush.Draw'):
            context.scene["dynax_active_brush"] = "Trim / Cut"
            return {'FINISHED'}
        self.report({'ERROR'},
                    "Could not select the Trim brush. Hover the 3D viewport and try again.")
        return {'CANCELLED'}

class DynaxSculptCrease(Operator):
    bl_idname = "dynax.sculpt_crease"
    bl_label = "Crease"
    bl_options = {'REGISTER'}
    @creator_guard("Could not select the Crease brush. See the DynaX log.")
    def execute(self, context):
        return _brush_operator_body(self, context, 'builtin_brush.Crease', "Crease")

class DynaxSculptPinch(Operator):
    bl_idname = "dynax.sculpt_pinch"
    bl_label = "Pinch"
    bl_options = {'REGISTER'}
    @creator_guard("Could not select the Pinch brush. See the DynaX log.")
    def execute(self, context):
        return _brush_operator_body(self, context, 'builtin_brush.Pinch', "Pinch")


# ── Selection mask (colored region indicator) ──────────────────────────────────

class DynaxSelectionMaskAdd(Operator):
    """Paint a colored selection region on the mesh to mark area for sculpting"""
    bl_idname = "dynax.selection_mask_add"
    bl_label = "Paint selection area"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}

        # Enter sculpt mode and switch to Mask brush
        # The Mask brush IS the selection tool in sculpt mode
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='SCULPT')
        _disable_symmetry(context)

        try:
            bpy.ops.wm.tool_set_by_id(name='builtin_brush.Mask')
        except Exception:
            pass

        # Set mask overlay color from scene property
        props = context.scene.dynax_props
        try:
            ts = context.tool_settings.sculpt
            ts.show_mask = True
        except Exception:
            pass

        self.report({'INFO'},
            "Paint your selection area on the mesh. "
            "Then use Push/Pull or a brush — it will affect only the masked area.")
        return {'FINISHED'}


class DynaxSelectionMaskClear(Operator):
    """Clear the sculpt mask"""
    bl_idname = "dynax.selection_mask_clear"
    bl_label = "Clear selection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}

        if context.mode != 'SCULPT':
            if context.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='SCULPT')
        _disable_symmetry(context)

        try:
            bpy.ops.sculpt.mask_flood_fill(mode='VALUE', value=0.0)
        except Exception:
            pass

        self.report({'INFO'}, "Selection mask cleared")
        return {'FINISHED'}


class DynaxSelectionInvert(Operator):
    """Invert the sculpt mask selection"""
    bl_idname = "dynax.selection_invert"
    bl_label = "Invert selection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'SCULPT':
            if context.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='SCULPT')
        _disable_symmetry(context)
        try:
            bpy.ops.sculpt.mask_flood_fill(mode='INVERT')
        except Exception:
            pass
        return {'FINISHED'}


class DynaxPushPull(Operator):
    """Push or pull the masked/selected area of the mesh by a set amount"""
    bl_idname = "dynax.push_pull"
    bl_label = "Push / Pull"
    bl_options = {'REGISTER', 'UNDO'}

    amount_mm: FloatProperty(
        name="Amount (mm)",
        default=3.0, min=0.1, max=50.0,
        description="How far to push or pull the selected area",
    )
    direction: EnumProperty(
        name="Direction",
        items=[
            ('PULL', "Pull (out)", "Move vertices outward / away from centre"),
            ('PUSH', "Push (in)", "Move vertices inward / toward centre"),
        ],
        default='PULL',
    )
    use_mask: BoolProperty(
        name="Respect mask",
        default=True,
        description="Only affect masked vertices",
    )
    circular: BoolProperty(
        name="Circular falloff",
        default=True,
        description="Apply circular/smooth falloff from centre of selection",
    )

    @creator_guard("Push/Pull failed. See the DynaX log for details.")
    def execute(self, context):
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            _set_object_mode(context, obj)

        # mm-space scene (scale_length=0.001): 1 unit = 1 mm, so use the mm value
        # directly (no /1000). dist_m holds scene units.
        dist_m = self.amount_mm * (1 if self.direction == 'PULL' else -1)

        # A region locked by Select & Transform wins over the sculpt mask, so the
        # painted region survives a Move -> Rotate -> Push/Pull tool switch
        # (v1.20.8). With no locked region this is exactly the old mask
        # behaviour, so the standalone sculpt Push/Pull is unchanged.
        # ...but only a region locked in the CURRENT step counts. A region
        # belonging to another workflow step is ignored here exactly as it is
        # ignored by the trimline separation, and Push/Pull falls back to its
        # own sculpt mask rather than silently deforming someone else's region.
        from .select_tools import VGROUP_NAME, active_step, selection_is_fresh
        region_indices = None
        vgroup = obj.vertex_groups.get(VGROUP_NAME)
        if vgroup is not None and not selection_is_fresh(
                context, obj, active_step(context))[0]:
            vgroup = None
        if vgroup is not None:
            region_indices = {
                v.index for v in obj.data.vertices
                for g in v.groups
                if g.group == vgroup.index and g.weight > 0.5
            }
            if not region_indices:
                region_indices = None

        mesh = obj.data
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()

        # Get mask layer if present (version-safe)
        from ..utils.mask_utils import get_mask_layer
        mask_layer = get_mask_layer(bm)
        use_mask = self.use_mask and region_indices is None
        if mask_layer is None and use_mask:
            # No mask painted — warn and affect all
            self.report({'WARNING'}, "No mask found — affecting whole mesh. Paint mask first.")
            use_mask = False

        # Compute centroid of affected verts
        affected = []
        for v in bm.verts:
            if region_indices is not None:
                if v.index not in region_indices:
                    continue
            elif use_mask and mask_layer:
                mask_val = v[mask_layer]
                if mask_val < 0.1:
                    continue
            affected.append(v)

        if not affected:
            bm.free()
            self.report({'WARNING'}, "No selected vertices found. Paint a region or a mask first.")
            return {'CANCELLED'}

        cx = sum(v.co.x for v in affected) / len(affected)
        cy = sum(v.co.y for v in affected) / len(affected)
        cz = sum(v.co.z for v in affected) / len(affected)
        centre = Vector((cx, cy, cz))

        max_dist = max((v.co - centre).length for v in affected) or 1.0

        for v in affected:
            # Falloff weight
            if self.circular:
                d = (v.co - centre).length
                weight = 1.0 - (d / max_dist)
                weight = max(0.0, weight)
            else:
                weight = 1.0

            if use_mask and mask_layer:
                weight *= v[mask_layer]

            # Move along vertex normal
            normal = v.normal.normalized()
            v.co += normal * dist_m * weight

        bm.to_mesh(mesh)
        bm.free()
        mesh.update()

        self.report({'INFO'},
            f"{'Pulled' if self.direction == 'PULL' else 'Pushed'} {len(affected)} verts by {self.amount_mm:.1f} mm")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=280)


# ── Alignment helpers ──────────────────────────────────────────────────────────

class DynaxAlignScan(Operator):
    """Auto-align scan: longest axis → Z (up)"""
    bl_idname = "dynax.align_scan"
    bl_label = "Auto-align (longest → Z)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        dims = obj.dimensions
        if max(dims.x, dims.y, dims.z) == dims.x:
            obj.rotation_euler[1] += math.radians(90)
            msg = "Rotated: X → Z"
        elif max(dims.x, dims.y, dims.z) == dims.y:
            obj.rotation_euler[0] += math.radians(90)
            msg = "Rotated: Y → Z"
        else:
            msg = "Already aligned: Z is longest axis"
        bpy.ops.object.transform_apply(rotation=True, location=False, scale=False)
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        obj.location = (0, 0, 0)

        # Orthographic FRONT view after alignment - clinically essential for
        # assessing socket shape/symmetry, perspective would distort it.
        from .import_stl import _set_orthographic_view
        _set_orthographic_view('FRONT')

        self.report({'INFO'}, msg)
        return {'FINISHED'}


class DynaxRotateX90(Operator):
    bl_idname = "dynax.rotate_x90"
    bl_label = "Rotate X +90°"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        obj = context.active_object
        if not obj: return {'CANCELLED'}
        obj.rotation_euler[0] += math.radians(90)
        bpy.ops.object.transform_apply(rotation=True, location=False, scale=False)
        return {'FINISHED'}

class DynaxRotateY90(Operator):
    bl_idname = "dynax.rotate_y90"
    bl_label = "Rotate Y +90°"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        obj = context.active_object
        if not obj: return {'CANCELLED'}
        obj.rotation_euler[1] += math.radians(90)
        bpy.ops.object.transform_apply(rotation=True, location=False, scale=False)
        return {'FINISHED'}

class DynaxRotateZ90(Operator):
    bl_idname = "dynax.rotate_z90"
    bl_label = "Rotate Z +90°"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        obj = context.active_object
        if not obj: return {'CANCELLED'}
        obj.rotation_euler[2] += math.radians(90)
        bpy.ops.object.transform_apply(rotation=True, location=False, scale=False)
        return {'FINISHED'}


def _activate_smooth_brush(context):
    """
    Force the Smooth sculpt brush to actually engage.
    Works across Blender 3.x, 4.x and 5.x where brush APIs differ.
    """
    # Method 1: asset-based brush (Blender 4.3+/5.x)
    try:
        bpy.ops.brush.asset_activate(
            asset_library_type='ESSENTIALS',
            relative_asset_identifier="brushes/essentials_brushes-mesh_sculpt.blend/Brush/Smooth",
        )
        return True
    except Exception:
        pass

    # Method 2: tool_set_by_id (Blender 3.6–4.2)
    for tool_name in ('builtin_brush.Smooth', 'builtin.smooth'):
        try:
            bpy.ops.wm.tool_set_by_id(name=tool_name)
            return True
        except Exception:
            continue

    # Method 3: direct brush data assignment (fallback)
    try:
        smooth_brush = bpy.data.brushes.get('Smooth')
        if smooth_brush is None:
            for b in bpy.data.brushes:
                if b.sculpt_tool == 'SMOOTH':
                    smooth_brush = b
                    break
        if smooth_brush:
            context.tool_settings.sculpt.brush = smooth_brush
            return True
    except Exception:
        pass

    return False


def _set_brush_radius_strength(context, radius=None, strength=None):
    """Set the active sculpt brush radius (px) and strength"""
    try:
        ts = context.tool_settings.sculpt
        brush = ts.brush
        if brush:
            if radius is not None:
                # unified setting takes priority if enabled
                if ts.unified_paint_settings.use_unified_size:
                    ts.unified_paint_settings.size = int(radius)
                else:
                    brush.size = int(radius)
            if strength is not None:
                if ts.unified_paint_settings.use_unified_strength:
                    ts.unified_paint_settings.strength = strength
                else:
                    brush.strength = strength
    except Exception:
        pass


class DynaxSculptStartSmooth(Operator):
    """Enter sculpt mode with ONLY the Smooth brush active (for cleanup step)"""
    bl_idname = "dynax.sculpt_start_smooth"
    bl_label  = "Enter smooth mode"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.mode_set(mode='SCULPT')

        _disable_symmetry(context)

        ok = _activate_smooth_brush(context)

        # Apply radius/strength from scene props
        props = context.scene.dynax_props
        _set_brush_radius_strength(
            context,
            radius=props.smooth_brush_radius,
            strength=props.smooth_brush_strength,
        )

        if ok:
            self.report({'INFO'}, "Smooth brush active — paint on the mesh to smooth")
        else:
            self.report({'WARNING'},
                "Sculpt mode on, but couldn't auto-select Smooth. "
                "Pick Smooth from the brush list manually.")
        return {'FINISHED'}


class DynaxUpdateSmoothBrush(Operator):
    """Apply the radius/strength sliders to the active smooth brush"""
    bl_idname = "dynax.update_smooth_brush"
    bl_label  = "Update brush"
    bl_options = {'REGISTER'}

    def execute(self, context):
        props = context.scene.dynax_props
        _set_brush_radius_strength(
            context,
            radius=props.smooth_brush_radius,
            strength=props.smooth_brush_strength,
        )
        return {'FINISHED'}
