# operators/crop.py - Crop tools (Box only) — v2.6.12
#
# Lives in its own Crop step in the DynaX panel, right after Align & Rotate.
# Lets the clinician trim away unwanted geometry with a bounding box
# (boolean intersect: start -> resize/move -> apply).
#
# NOTE: Plane Crop was removed in v2.6.12 for stability. The apply step
# proved unreliable (wrong-side cuts) even after an auto-retry fix attempt.
# The original Plane Crop code is preserved outside the package for future
# reference if it's revisited.

import bpy
from bpy.types import Operator


def _set_boolean_solver(mod):
    """Pick a boolean solver that exists on this Blender build. Some versions
    expose 'FLOAT'/'EXACT'; older ones differ."""
    try:
        mod.solver = 'FLOAT'
    except TypeError:
        try:
            mod.solver = 'EXACT'
        except TypeError:
            pass


class DynaxCropBox(Operator):
    """Create a box region; resize it, then run Apply Box Crop to keep only
    the geometry inside it"""
    bl_idname = "dynax.crop_box"
    bl_label = "Crop by Box"
    bl_description = "Keep only geometry inside a box region"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Select a mesh object first")
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        dims = obj.dimensions
        bpy.ops.mesh.primitive_cube_add(size=1, location=obj.location)
        box = context.active_object
        box.name = "DynaX_CropBox"
        box["dynax_crop_target"] = obj.name
        box.scale = (max(dims.x, 1.0) * 0.6,
                     max(dims.y, 1.0) * 0.6,
                     max(dims.z, 1.0) * 0.6)
        box.display_type = 'WIRE'

        bpy.ops.object.select_all(action='DESELECT')
        box.select_set(True)
        context.view_layer.objects.active = box
        try:
            bpy.ops.wm.tool_set_by_id(name='builtin.scale')
        except Exception:
            pass

        self.report({'INFO'},
                    "Resize/move the box, then run 'Apply Box Crop' to confirm.")
        return {'FINISHED'}


class DynaxCropBoxApply(Operator):
    """Apply the box crop (boolean intersect) and remove the box"""
    bl_idname = "dynax.crop_box_apply"
    bl_label = "Apply Box Crop"
    bl_description = "Apply the box crop and remove the box"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        box = bpy.data.objects.get("DynaX_CropBox")
        if not box:
            self.report({'WARNING'}, "No DynaX_CropBox found — run 'Box Crop' first.")
            return {'CANCELLED'}

        # Prefer the target remembered when the box was created; otherwise fall
        # back to a selected mesh that isn't the box.
        target = bpy.data.objects.get(box.get("dynax_crop_target", "") or "")
        if not target or target.type != 'MESH':
            target = next((o for o in context.scene.objects
                           if o.type == 'MESH' and o.name != "DynaX_CropBox"
                           and o.select_get()), None)
        if not target:
            self.report({'WARNING'}, "Select the mesh to crop and ensure DynaX_CropBox exists.")
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        mod = target.modifiers.new(name="DynaX_BoxCrop", type='BOOLEAN')
        mod.operation = 'INTERSECT'
        mod.object = box
        _set_boolean_solver(mod)

        context.view_layer.objects.active = target
        try:
            bpy.ops.object.modifier_apply(modifier="DynaX_BoxCrop")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to apply box crop: {e}")
            return {'CANCELLED'}

        bpy.data.objects.remove(box, do_unlink=True)
        try:
            bpy.ops.wm.tool_set_by_id(name='builtin.select_box')
        except Exception:
            pass
        self.report({'INFO'}, "Box crop applied.")
        return {'FINISHED'}
