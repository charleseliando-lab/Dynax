# operators/export_stl.py - Export STL Operator

import bpy
import bmesh
import os
import struct
from bpy.types import Operator

try:
    from ..analytics.collector import record_event, workflow_from_context
except ImportError:
    def record_event(*_args, **_kwargs):
        return None

    def workflow_from_context(_context):
        return None

try:
    from ..utils.session_recorder import get_recorder
except ImportError:
    def get_recorder():
        class _NullRecorder:
            def __getattr__(self, _name):
                return lambda *a, **k: None
        return _NullRecorder()


def _write_binary_stl(filepath, obj, scale=1.0):
    """Write `obj` to a binary STL by hand - the always-available fallback when
    neither the 4.2+ `wm.stl_export` nor the legacy `export_mesh.stl` operator is
    present (or one of them raised). Triangulates n-gons via loop_triangles and
    bakes the object's world transform, so the file matches what the slicer
    expects. `scale` multiplies every coordinate (1000.0 for metres->mm)."""
    me = obj.data
    me.calc_loop_triangles()
    mw = obj.matrix_world
    tris = me.loop_triangles
    with open(filepath, 'wb') as f:
        f.write(b'\0' * 80)                       # 80-byte header
        f.write(struct.pack('<I', len(tris)))     # triangle count
        for t in tris:
            n = t.normal
            f.write(struct.pack('<fff', n.x, n.y, n.z))
            for vi in t.vertices:
                co = (mw @ me.vertices[vi].co) * scale
                f.write(struct.pack('<fff', co.x, co.y, co.z))
            f.write(struct.pack('<H', 0))         # attribute byte count


def get_downloads_folder() -> str:
    """Return the user's Downloads folder on Windows, macOS, and Linux,
    falling back to the home directory if none is found."""
    home = os.path.expanduser("~")
    for candidate in ("Downloads", "Download"):
        path = os.path.join(home, candidate)
        if os.path.isdir(path):
            return path
    return home


class ExportSTL(Operator):
    """Exports the selected mesh to STL (Applies Modifiers)"""
    bl_idname = "dynax.export_stl"
    bl_label = "Export STL"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # 1. Validation
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No object selected")
            return {'CANCELLED'}

        # 2. Resolve destination folder: a custom export path if the user set a
        #    valid one, otherwise the OS Downloads folder (v2.6.8 default).
        props = getattr(context.scene, "dynax_props", None)
        custom = (getattr(context.scene, "dynax_export_path", "") or "").strip()
        export_path = custom if custom and os.path.isdir(custom) else get_downloads_folder()

        if not os.path.exists(export_path):
            try:
                os.makedirs(export_path)
            except OSError:
                self.report({'ERROR'}, f"Could not create directory: {export_path}")
                return {'CANCELLED'}

        # 3. Construct Filename from the user-supplied name (fallback to object name).
        raw_name = (props.export_filename if props else "").strip() or obj.name or "DynaX_Export"
        safe_name = "".join(c for c in raw_name if c.isalnum() or c in " ._-").strip() or "DynaX_Export"
        if safe_name.lower().endswith(".stl"):
            safe_name = safe_name[:-4]
        target_file = os.path.join(export_path, f"{safe_name}.stl")

        # 4. Export Logic (Version Safe)
        apply_solidify = props.apply_solidify_on_export if props else False
        apply_modifiers = props.export_apply_modifiers if props else True
        validate_mesh = props.export_validate_mesh if props else True
        scale_to_mm = props.export_scale_to_mm if props else True

        original_selected = [o for o in context.selected_objects]
        original_active = context.view_layer.objects.active

        export_obj = obj
        temp_obj = None

        # Always work on a temp copy so we can safely apply transforms/mods for export.
        temp_obj = obj.copy()
        temp_obj.data = obj.data.copy()
        context.collection.objects.link(temp_obj)
        export_obj = temp_obj

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Apply transforms to avoid tiny or negative-scale exports.
        try:
            area = next((a for a in context.window.screen.areas if a.type == 'VIEW_3D'), None)
            region = None
            if area:
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if area and region:
                with context.temp_override(
                    area=area,
                    region=region,
                    active_object=export_obj,
                    object=export_obj,
                ):
                    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
            else:
                bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
        except Exception:
            pass

        # Apply modifiers on the temp copy if requested.
        if apply_modifiers:
            depsgraph = context.evaluated_depsgraph_get()
            eval_obj = export_obj.evaluated_get(depsgraph)
            # new_from_object() returns a real, ORIGINAL mesh datablock with all
            # modifiers baked in. The previous code assigned eval_obj.to_mesh()
            # (an EVALUATED, temporary mesh) onto the original object, which
            # Blender 5.x rejects outright -> "Can only assign evaluated data to
            # evaluated object". That RuntimeError was the export silently failing.
            new_mesh = bpy.data.meshes.new_from_object(eval_obj)
            old_mesh = export_obj.data
            export_obj.data = new_mesh
            bpy.data.meshes.remove(old_mesh, do_unlink=True)
        elif apply_solidify and export_obj.modifiers.get("DYNAX_SOLIDIFY"):
            try:
                bpy.ops.object.modifier_apply(modifier="DYNAX_SOLIDIFY")
            except Exception as e:
                self.report({'ERROR'}, f"Failed to apply solidify for export: {e}")
                return {'CANCELLED'}

        # Basic validation to avoid exporting empty/tiny meshes.
        if validate_mesh:
            mesh = export_obj.data
            if not mesh or len(mesh.vertices) == 0:
                self.report({'ERROR'}, "Export mesh is empty")
                return {'CANCELLED'}

            coords = [v.co for v in mesh.vertices]
            min_x = min(v.x for v in coords)
            min_y = min(v.y for v in coords)
            min_z = min(v.z for v in coords)
            max_x = max(v.x for v in coords)
            max_y = max(v.y for v in coords)
            max_z = max(v.z for v in coords)
            max_dim = max(max_x - min_x, max_y - min_y, max_z - min_z)
            # mm-space scene (scale_length=0.001): geometry is already in real
            # millimetres, so a mm STL is a RAW passthrough (scale 1.0). The OFF
            # path emits a legacy metre-scale STL (x0.001) for slicers that expect
            # Blender's old metre output.
            export_scale = 1.0 if scale_to_mm else 0.001
            if max_dim * export_scale < 0.1:
                self.report({'ERROR'}, "Mesh is extremely small after export scale")
                return {'CANCELLED'}

            bm = bmesh.new()
            bm.from_mesh(mesh)
            non_manifold = sum(1 for e in bm.edges if not e.is_manifold)
            bm.free()
            # DynaX cut parts are deliberately OPEN shells (hollow socket with an
            # open rim), so non-manifold/open edges are EXPECTED here - they are
            # not a reason to refuse export. Warn, but still write the file; most
            # slicers handle open meshes, and a hard cancel here was making the
            # Export button silently "do nothing".
            if non_manifold > 0:
                self.report({'WARNING'},
                    f"Mesh has {non_manifold} open/non-manifold edge(s) "
                    "(expected for a hollow cut part) - exporting anyway.")

        bpy.ops.object.select_all(action='DESELECT')
        export_obj.select_set(True)
        context.view_layer.objects.active = export_obj

        export_scale = 1.0 if scale_to_mm else 0.001
        exported = False
        last_error = None
        try:
            if hasattr(bpy.ops.wm, "stl_export"):
                # Blender 4.2+ (New System)
                # use_scene_unit MUST be False: the scene is mm-space
                # (scale_length=0.001), and letting the exporter re-apply the scene
                # unit would shrink the already-mm geometry 1000x (a 500 mm socket
                # would write as 0.5). We scale explicitly via export_scale instead.
                kwargs = dict(
                    filepath=target_file,
                    export_selected_objects=True,
                    apply_modifiers=True,
                    use_scene_unit=False,
                )
                if "global_scale" in bpy.ops.wm.stl_export.get_rna_type().properties.keys():
                    kwargs["global_scale"] = export_scale
                elif "scale" in bpy.ops.wm.stl_export.get_rna_type().properties.keys():
                    kwargs["scale"] = export_scale
                elif "scale_factor" in bpy.ops.wm.stl_export.get_rna_type().properties.keys():
                    kwargs["scale_factor"] = export_scale
                try:
                    props_keys = bpy.ops.wm.stl_export.get_rna_type().properties.keys()
                    kwargs = {k: v for k, v in kwargs.items() if k in props_keys}
                except Exception:
                    pass
                bpy.ops.wm.stl_export(**kwargs)
                exported = True
            elif hasattr(bpy.ops, "export_mesh") and hasattr(bpy.ops.export_mesh, "stl"):
                # Blender 4.1 and older (Legacy System)
                kwargs = dict(
                    filepath=target_file,
                    use_selection=True,       # IMPORTANT: Only export selected
                    use_mesh_modifiers=True,  # Apply the smooth/cuts
                    use_scene_unit=False,     # geometry is already real mm
                    global_scale=export_scale,
                )
                try:
                    props_keys = bpy.ops.export_mesh.stl.get_rna_type().properties.keys()
                    kwargs = {k: v for k, v in kwargs.items() if k in props_keys}
                except Exception:
                    pass
                bpy.ops.export_mesh.stl(**kwargs)
                exported = True
        except Exception as e:
            last_error = e
            exported = False

        # Final fallback: write the STL ourselves. Covers Blender builds where
        # neither export operator exists, or where the operator raised/produced
        # nothing - so the Export button always yields a file instead of failing
        # silently.
        if not exported or not os.path.exists(target_file):
            try:
                _write_binary_stl(target_file, export_obj, scale=export_scale)
                exported = True
            except Exception as e:
                self.report({'ERROR'}, f"Failed to export: {last_error or e}")
                return {'CANCELLED'}

        self.report({'INFO'}, f"Exported to {target_file}")

        # Restore the user's original selection and drop the temp export copy.
        bpy.ops.object.select_all(action='DESELECT')
        for o in original_selected:
            try:
                o.select_set(True)
            except Exception:
                pass
        context.view_layer.objects.active = original_active
        if temp_obj:
            bpy.data.objects.remove(temp_obj, do_unlink=True)

        record_event(
            "export_completed", workflow=workflow_from_context(context), value="stl")
        try:
            get_recorder().log_export("stl")
            get_recorder().end()
        except Exception:
            pass

        return {'FINISHED'}
