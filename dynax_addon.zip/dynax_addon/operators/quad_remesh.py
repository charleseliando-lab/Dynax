# operators/quad_remesh.py - Quad remesh (Cleanup step)
#
# HISTORY:
# v1 wrapped Blender's quadriflow_remesh operator directly. Dropped after
# real-scan testing: quadriflow requires a strictly manifold, single-shell,
# consistent-normal input, and a real 768k-face scan run through Auto Remesh
# + repeated Fix Open Edges passes still plateaued at 119 non-manifold edges
# (out of ~70k) that DynaX's own repair tools could not fully close —
# quadriflow refused ({'CANCELLED'}) on that input.
#
# v2 replaced quadriflow entirely with Voxel Remesh (tolerant of messy input,
# native output already quad-dominant and manifold). This "worked" in that it
# never crashed, but produces a BLOCKY, voxelized quad grid rather than
# genuine anatomically-flowing quad topology — the wrong KIND of result, not
# just a lower-quality one. Investigated using Voxel Remesh purely as a
# manifold-repair pre-pass before quadriflow (at several resolutions): the
# repaired mesh was topologically manifold (0 non-manifold edges/verts) but
# STILL fragmented into 150-290 disconnected shells on this real scan's
# thin/curved/multi-region anatomy — quadriflow's "needs to be manifold"
# warning turned out to mean "single coherent shell", not just
# edge/vertex-manifold. Isolating only the largest shell "fixed" quadriflow's
# refusal but then quadriflow catastrophically shrank the result (dims ratio
# down to ~0.03-0.18) because that largest shell was itself only ~1-2% of the
# real surface (the rest scattered across the other shells) — quadriflow was
# being asked to upsample a small fragment ~10x, not decimate a whole scan.
# A targeted local repair (delete+refill just the faces around the residual
# non-manifold edges, without a full voxel rebuild) also failed: the
# select-expand step swept in far more of the mesh than intended and produced
# a similarly fragmented, badly distorted result.
#
# v3: TRY quadriflow FIRST on every run — for scans whose topology is clean
# enough, this gives real quad-flow retopology, which is what this tool is
# actually for. If quadriflow refuses/errors, OR its result fails the same
# distortion/near-empty validation Auto Remesh uses, fall back to the Voxel
# Remesh approach (v2) as a tolerant best-effort method. Also added a
# fragmentation gate (_largest_shell_fraction, require >=90%) after finding a
# "successful", bbox-preserved voxel result was actually 54 disconnected
# shells with the largest only 8.5% of the mesh — bbox alone can't detect
# scattered debris that happens to span the same overall extent. Swept
# target_faces 500-100,000 on a real scan: the un-isolated multi-shell input
# NEVER passed the 90% shell-fraction gate at any resolution.
#
# v4: the missing piece was WHERE the fragmentation gate said no — a real
# Auto-Remeshed (Decimate) scan is typically already a FEW shells (verified:
# 3, largest = 64.7% of vertices but 94-100% of the real bounding box — the
# smaller shells are mostly overlapping/redundant scan data, not unique
# anatomy elsewhere), not the 50-290 fragments that appeared in v2's
# investigation. Those hundreds of fragments were VOXEL REMESH ITSELF
# fragmenting an already-multi-shell input while trying to reconcile several
# shells in one SDF pass. Isolating the single largest shell BEFORE either
# remesh method runs (not after a voxel pass) fixes this at the source. BUT
# (found in end-to-end testing through the real operator, not just isolated
# diagnostic scripts): even the single isolated shell still fragmented Voxel
# Remesh badly (6-63% largest-shell-fraction, not the 97-98% an earlier
# isolated diagnostic had suggested) — Voxel Remesh fundamentally assumes an
# enclosed volume, and a real single-wall anatomical scan is an OPEN sheet
# (open at the proximal rim by design, per this addon's own measurement
# code) — even a few thousand boundary edges out of hundreds of thousands of
# faces is enough to leak Voxel Remesh's SDF into near-empty or scattered
# results at every voxel size tried (1.5-4.0mm). Voxel Remesh is the wrong
# tool for this input shape, isolated or not.
#
# v5 (current) — QuadriFlow was never actually broken by the open boundary or
# by multiple boundary loops (verified with synthetic open-shell meshes: 1
# loop, 2 loops, and 11,200-face dense single-loop meshes all pass QuadriFlow
# fine with use_preserve_boundary=True). What blocks it on a real scan is a
# HANDFUL of genuine 2-manifold violations left over from scan-registration
# overlap — measured directly on the real reference scan's isolated largest
# shell (517k faces): after remove_doubles(0.05mm) + dissolve_degenerate
# closed most near-duplicate seams, exactly 3 WIRE edges (0 linked faces) and
# 8 T-JUNCTION edges (3-4 linked faces, i.e. small overlapping duplicate
# patches sharing an edge) remained out of ~4800 non-manifold edges — the
# other ~4800 were legitimate open-boundary edges QuadriFlow already handles.
# `_repair_for_quadriflow()` deletes the 3 wire edges outright and, per
# T-junction edge, keeps only its 2 LARGEST-area linked faces (the real
# surface) and deletes the smaller extra one(s) (the duplicate overlap
# sliver) — turning "non-manifold" into "clean boundary-only", which
# QuadriFlow accepts. Verified end-to-end on the real scan at target_faces
# 800/4000/8000: QuadriFlow now returns FINISHED at every target, 100% quads,
# single/near-single shell (98-99% largest-shell-fraction), bbox status OK.
# Voxel Remesh is kept only as a last-resort fallback for scans this repair
# still can't clean (it will still look blocky, not anatomically-flowing,
# but a "quad-ish, watertight" fallback beats an outright refusal). Shell
# isolation (v4) is still applied first — it's still correct to discard
# duplicate/overlapping SHELLS (whole disconnected regions), which is a
# different, coarser problem than the fine-grained wire/T-junction cleanup
# this version adds on top.

import bpy
import bmesh
from bpy.types import Operator
from bpy.props import IntProperty, BoolProperty

from .auto_remesh import classify_remesh_result


# Voxel-fallback estimate — same k=2.0 surface-area formula as Auto Remesh's
# retired voxel-mode. Fallback-only: quad-topology conversion here just needs
# a voxel size in the right neighborhood, not an exact target_faces hit
# (verified on a real scan across a 2-4mm range: 100% quads, 0 non-manifold,
# single coherent result, faces in the low thousands).
MIN_VOXEL = 1.0


def _real_surface_area(obj):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    area = sum(f.calc_area() for f in bm.faces)
    bm.free()
    return area


def _estimate_voxel_for_target(real_area, target_faces):
    if real_area <= 0:
        return 3.0
    k = 2.0
    voxel = (k * real_area / max(target_faces, 1)) ** 0.5
    return max(MIN_VOXEL, voxel)


# A result can pass the bbox-distortion check while being scattered debris —
# measured directly on a real scan: a "successful", bbox-preserved 642-face
# voxel-remesh result was actually 54 disconnected shells, with the LARGEST
# single shell only 8.5% of the total mesh. The overall bounding box matched
# because the debris was scattered across roughly the same extent as the real
# shape, not because the shape was intact. bbox alone cannot detect this —
# only checking how much of the mesh lives in one connected piece can.
MIN_LARGEST_SHELL_FRACTION = 0.90


def _largest_shell_fraction(obj):
    """Fraction of total vertices belonging to the single largest connected
    component. 1.0 = one coherent shell; low values mean the mesh has
    fragmented into scattered debris."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    total = len(bm.verts)
    if total == 0:
        bm.free()
        return 0.0, 0
    visited = [False] * total
    bm.verts.ensure_lookup_table()
    largest = 0
    shell_count = 0
    for start in bm.verts:
        if visited[start.index]:
            continue
        shell_count += 1
        stack = [start]
        visited[start.index] = True
        count = 0
        while stack:
            v = stack.pop()
            count += 1
            for e in v.link_edges:
                o = e.other_vert(v)
                if not visited[o.index]:
                    visited[o.index] = True
                    stack.append(o)
        largest = max(largest, count)
    bm.free()
    return largest / total, shell_count


def _isolate_largest_shell(obj):
    """Keep only the largest connected shell in obj.data, in place. Returns
    (discarded_vert_fraction, shell_count_before).

    Real scans commonly contain multiple disconnected regions (duplicate/
    overlapping surface patches, stray scanner noise) even after Auto Remesh
    — measured on a real scan: 3 shells, largest = 64.7% of vertices but
    94-100% of the real bounding box (the smaller shells were mostly
    overlapping/redundant with the main body, not unique anatomy elsewhere).
    That multi-shell input is what actually broke both remesh methods:
    QuadriFlow refuses outright, and Voxel Remesh doesn't just get coarser —
    it fragments into 50+ tiny disconnected pieces trying to reconcile
    several shells in one SDF pass, even though each shell is individually
    fine. Isolating the single largest shell BEFORE remeshing fixed this:
    verified the same voxel target that produced 9-30% largest-shell-fraction
    (fragmented) on the multi-shell input produced 97-98% (coherent) on the
    pre-isolated single shell, at unchanged target face counts."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    total = len(bm.verts)
    if total == 0:
        bm.free()
        return 0.0, 0

    visited = [False] * total
    shells = []
    for start in bm.verts:
        if visited[start.index]:
            continue
        stack = [start]
        visited[start.index] = True
        members = [start]
        while stack:
            v = stack.pop()
            for e in v.link_edges:
                o = e.other_vert(v)
                if not visited[o.index]:
                    visited[o.index] = True
                    stack.append(o)
                    members.append(o)
        shells.append(members)

    if len(shells) <= 1:
        bm.free()
        return 0.0, len(shells)

    shells.sort(key=len, reverse=True)
    keep_idx = set(v.index for v in shells[0])
    to_delete = [v for v in bm.verts if v.index not in keep_idx]
    discarded_fraction = len(to_delete) / total

    bmesh.ops.delete(bm, geom=to_delete, context='VERTS')
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    return discarded_fraction, len(shells)


# Near-coincident distance for closing scan-registration seam gaps and
# collapsing degenerate slivers — matches offset.py's _clean_for_solidify
# convention for "small enough to be noise, not real detail" in this addon's
# mm-space.
REPAIR_MERGE_DIST_MM = 0.05


def _repair_for_quadriflow(obj):
    """Remove the small number of genuine 2-manifold violations (wire edges,
    T-junctions from overlapping scan-registration patches) that block
    QuadriFlow, WITHOUT touching the mesh's legitimate open boundary (the
    proximal rim etc. — QuadriFlow handles that fine on its own via
    use_preserve_boundary). See this module's v5 history note for the real
    scan measurements this is based on: out of ~4800 non-manifold edges on
    a real isolated shell, only 3 were wire and 8 were T-junctions — the
    rest were legitimate boundary QuadriFlow already accepts."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)

    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=REPAIR_MERGE_DIST_MM)
    bmesh.ops.dissolve_degenerate(bm, dist=REPAIR_MERGE_DIST_MM, edges=bm.edges[:])
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])

    bm.edges.ensure_lookup_table()
    wire_edges = [e for e in bm.edges if len(e.link_faces) == 0]
    bmesh.ops.delete(bm, geom=wire_edges, context='EDGES')

    bm.edges.ensure_lookup_table()
    tjunction_edges = [e for e in bm.edges if len(e.link_faces) >= 3]
    faces_to_remove = set()
    for e in tjunction_edges:
        linked = sorted(e.link_faces, key=lambda f: f.calc_area(), reverse=True)
        faces_to_remove.update(linked[2:])
    bmesh.ops.delete(bm, geom=list(faces_to_remove), context='FACES')
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])

    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()


class DynaxQuadRemesh(Operator):
    """Rebuild the mesh into clean quad topology. Tries Blender's QuadriFlow
    remesher first (genuine anatomically-flowing quad retopology); if the
    mesh's topology isn't clean enough for that, falls back to a Voxel
    Remesh pass (tolerant of messy scanner input, still produces a manifold
    quad-dominant result). Destructive either way: a backup copy is kept so
    this can be undone via 'Restore pre-remesh mesh'."""
    bl_idname = "dynax.quad_remesh"
    bl_label = "Quad Remesh"
    bl_description = ("Rebuild mesh as clean quads (improves topology for "
                       "sculpting and future parametric controls). Destructive.")
    bl_options = {'REGISTER', 'UNDO'}

    target_faces: IntProperty(
        name="Target Faces",
        description="Approximate number of quad faces in the result",
        default=8000, min=500, max=50000,
    )
    preserve_boundary: BoolProperty(
        name="Preserve Boundary",
        description="Keep open edges (e.g. the proximal brim rim) intact",
        default=True,
    )
    preserve_sharp: BoolProperty(
        name="Preserve Sharp Features",
        description="Try to keep sharp edges/creases in the result",
        default=False,
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a Mesh object first")
            return {'CANCELLED'}

        if len(obj.data.vertices) == 0:
            self.report({'ERROR'}, "No mesh data found")
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        try:
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
        except Exception as e:
            self.report({'ERROR'},
                f"Could not apply object transform before remeshing: {e}. "
                "Remesh aborted.")
            return {'CANCELLED'}

        # Back up the mesh datablock before the destructive remesh, stored as
        # a custom property reference so "Restore" can bring it back even
        # after a Blender restart within the same session/file. This copy is
        # NEVER assigned to obj.data until a final restore — both remesh
        # attempts below work on their own copies so a failed first attempt
        # can't corrupt the fallback's starting point.
        try:
            backup_name = f"{obj.name}_PRE_REMESH_BACKUP"
            existing_backup = bpy.data.meshes.get(backup_name)
            if existing_backup and existing_backup is not obj.data:
                bpy.data.meshes.remove(existing_backup)
            backup_mesh = obj.data.copy()
        except ReferenceError:
            self.report({'ERROR'},
                "Quad Remesh could not access the mesh object. Please "
                "reselect your scan and try again.")
            return {'CANCELLED'}
        backup_mesh.name = backup_name

        if len(backup_mesh.vertices) == 0:
            bpy.data.meshes.remove(backup_mesh)
            self.report({'ERROR'},
                "Failed to create pre-remesh backup. Aborting remesh.")
            return {'CANCELLED'}

        obj["dynax_pre_remesh_mesh"] = backup_mesh.name

        orig_dims = tuple(obj.dimensions)
        before = len(obj.data.polygons)

        # Isolate the largest connected shell BEFORE either remesh method
        # runs — see _isolate_largest_shell's docstring for why this is what
        # actually fixes both methods on real multi-shell scans. Done on a
        # working copy; backup_mesh (used for the final Restore) is never
        # touched by this or anything below.
        working_mesh = obj.data.copy()
        obj.data = working_mesh
        discarded_frac, shell_count_before = _isolate_largest_shell(obj)
        if shell_count_before > 1:
            print(f"[QuadRemesh] isolated largest of {shell_count_before} disconnected "
                  f"shells; set aside {discarded_frac:.0%} of vertices before "
                  "remeshing (full original recoverable via Restore)")

        # Close the small number of genuine 2-manifold violations (wire
        # edges, T-junctions from overlapping scan-registration patches) that
        # actually block QuadriFlow — see _repair_for_quadriflow's docstring
        # and this module's v5 history note. The mesh's real open boundary is
        # untouched; QuadriFlow handles that on its own.
        _repair_for_quadriflow(obj)

        # Pristine snapshot of the isolated+repaired (pre-remesh) state, so
        # the voxel fallback can restart from it even after quadriflow
        # mutates obj.data in place below.
        isolated_snapshot = obj.data.copy()

        # ── Attempt 1: QuadriFlow — genuine quad-flow retopology ───────────
        method_used, fail_detail = self._try_quadriflow(obj, orig_dims)

        # ── Attempt 2: Voxel Remesh fallback ────────────────────────────────
        if method_used is None:
            print(f"[QuadRemesh] quadriflow unusable ({fail_detail}); "
                  "falling back to voxel remesh")
            old = obj.data
            obj.data = isolated_snapshot.copy()
            if old is not backup_mesh:
                bpy.data.meshes.remove(old, do_unlink=True)

            method_used, fail_detail = self._try_voxel(obj, orig_dims)

        bpy.data.meshes.remove(isolated_snapshot)

        if method_used is None:
            old_mesh = obj.data
            obj.data = backup_mesh
            if old_mesh is not backup_mesh:
                bpy.data.meshes.remove(old_mesh, do_unlink=True)
            del obj["dynax_pre_remesh_mesh"]
            # backup_mesh is now the live obj.data — rename it away from
            # backup_name so a retry's fresh backup-collision lookup above
            # can't find and remove the mesh the object is currently using
            # (this is exactly what deleted a user's working mesh on retry:
            # the old backup_mesh, still named "..._PRE_REMESH_BACKUP" and
            # now live as obj.data, was found and bpy.data.meshes.remove()'d
            # out from under the object).
            backup_mesh.name = obj.name
            self.report({'ERROR'},
                f"Quad Remesh cancelled — both methods failed ({fail_detail}). "
                "Original mesh preserved. Try a different target face count.")
            return {'CANCELLED'}

        verts = len(obj.data.vertices)
        after = len(obj.data.polygons)
        quads = sum(1 for p in obj.data.polygons if len(p.vertices) == 4)
        print(f"[QuadRemesh] method={method_used}: {before} -> {after} faces, {quads} quads")

        method_label = ("QuadriFlow" if method_used == 'quadriflow'
                         else "Voxel Remesh fallback")
        discard_note = ""
        if shell_count_before > 1:
            discard_note = (
                f" {shell_count_before} disconnected pieces were found; "
                f"{discarded_frac:.0%} of vertices (the smaller pieces) were "
                "set aside before remeshing — Restore recovers the full original.")
        self.report({'INFO'},
            f"[{method_label}] {before:,} faces -> {after:,} faces "
            f"({quads:,} quads, {100*quads/max(after,1):.0f}%).{discard_note} "
            "Use 'Restore pre-remesh mesh' if you want to undo this.")
        return {'FINISHED'}

    def _try_quadriflow(self, obj, orig_dims):
        """Attempt QuadriFlow directly on obj.data (modifies it in place on
        success or partial failure alike — caller resets obj.data before
        trying the fallback). Returns ('quadriflow', None) on a validated
        success, or (None, reason) otherwise."""
        try:
            result = bpy.ops.object.quadriflow_remesh(
                mode='FACES',
                target_faces=self.target_faces,
                use_preserve_boundary=self.preserve_boundary,
                use_preserve_sharp=self.preserve_sharp,
                use_mesh_symmetry=False,
                smooth_normals=True,
            )
        except Exception as e:
            return None, f"quadriflow error: {e}"

        if result != {'FINISHED'}:
            return None, f"quadriflow returned {result}"

        verts = len(obj.data.vertices)
        after = len(obj.data.polygons)
        result_dims = tuple(obj.dimensions)
        # No target_faces passed to classify_remesh_result — quadriflow is
        # not guaranteed to hit an exact count either; only the bbox-
        # distortion gate applies here, same reasoning as the voxel path.
        status, reason = classify_remesh_result(after, None, orig_dims, result_dims)
        shell_frac, shell_count = _largest_shell_fraction(obj)
        print(f"[QuadRemesh] quadriflow validation: status={status} reason={reason!r} "
              f"faces={after} dims={result_dims} "
              f"largest_shell_fraction={shell_frac:.2f} shells={shell_count}")

        if status == 'FAIL' or verts < 100:
            return None, reason or "quadriflow produced a near-empty/distorted result"
        if shell_frac < MIN_LARGEST_SHELL_FRACTION:
            return None, (f"result fragmented into {shell_count} disconnected pieces "
                f"(largest is only {shell_frac:.0%} of the mesh) — not a usable shape")
        return 'quadriflow', None

    def _try_voxel(self, obj, orig_dims):
        """Voxel Remesh fallback on obj.data (a fresh working copy the
        caller has already assigned). Returns ('voxel', None) on a
        validated success, or (None, reason) otherwise."""
        real_area = _real_surface_area(obj)
        voxel = _estimate_voxel_for_target(real_area, self.target_faces)
        print(f"[QuadRemesh] voxel fallback: real_area={real_area:,.0f}mm^2, "
              f"target_faces={self.target_faces}, voxel={voxel:.4f}")

        remesh_mod = obj.modifiers.new(name="DynaX_QuadRemesh", type='REMESH')
        remesh_mod.mode = 'VOXEL'
        remesh_mod.voxel_size = voxel
        remesh_mod.adaptivity = 0.0
        remesh_mod.use_smooth_shade = True

        try:
            bpy.ops.object.modifier_apply(modifier=remesh_mod.name)
        except Exception as e:
            if remesh_mod.name in obj.modifiers:
                obj.modifiers.remove(remesh_mod)
            return None, f"voxel remesh error: {e}"

        verts = len(obj.data.vertices)
        after = len(obj.data.polygons)
        result_dims = tuple(obj.dimensions)
        status, reason = classify_remesh_result(after, None, orig_dims, result_dims)
        shell_frac, shell_count = _largest_shell_fraction(obj)
        print(f"[QuadRemesh] voxel validation: status={status} reason={reason!r} "
              f"faces={after} dims={result_dims} "
              f"largest_shell_fraction={shell_frac:.2f} shells={shell_count}")

        if status == 'FAIL' or verts < 100:
            return None, reason or "voxel remesh produced a near-empty/distorted result"
        if shell_frac < MIN_LARGEST_SHELL_FRACTION:
            return None, (f"result fragmented into {shell_count} disconnected pieces "
                f"(largest is only {shell_frac:.0%} of the mesh) — not a usable shape")
        return 'voxel', None


class DynaxQuadRemeshRestore(Operator):
    """Restore the mesh as it was before the last Quad Remesh"""
    bl_idname = "dynax.quad_remesh_restore"
    bl_label = "Restore Pre-Remesh Mesh"
    bl_description = "Undo the quad remesh and bring back the original topology"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a Mesh object first")
            return {'CANCELLED'}

        backup_name = obj.get("dynax_pre_remesh_mesh", "")
        backup_mesh = bpy.data.meshes.get(backup_name) if backup_name else None
        if not backup_mesh:
            self.report({'WARNING'}, "No pre-remesh backup found for this object.")
            return {'CANCELLED'}

        old_mesh = obj.data
        obj.data = backup_mesh
        bpy.data.meshes.remove(old_mesh, do_unlink=True)
        del obj["dynax_pre_remesh_mesh"]
        # See the matching comment in DynaxQuadRemesh.execute()'s CANCELLED
        # path: backup_mesh is now live obj.data and must not keep the
        # "..._PRE_REMESH_BACKUP" name, or a future Quad Remesh run's
        # backup-collision lookup will find and delete it out from under
        # the object.
        backup_mesh.name = obj.name

        self.report({'INFO'}, "Restored pre-remesh mesh.")
        return {'FINISHED'}
