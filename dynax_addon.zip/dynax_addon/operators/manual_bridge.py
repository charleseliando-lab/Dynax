# operators/manual_bridge.py - Manual bridge (v1.6.0)
#
# Replaces the automatic bridge/enclosure attempts (v1.5.5-v1.5.7). The
# clinician manually selects which part of the socket outer wall and which
# part of the component should be connected, then DynaX bridges those two
# selections using Blender's native bridge_edge_loops operator - proven,
# reliable, handles arbitrary mismatched shapes without custom ring-matching
# math. See CLAUDE.md "Manual Bridge" section for why automatic generation
# was abandoned.

import bpy
import bmesh
from bpy.types import Operator
from bpy.props import BoolProperty

from .select_tools import _enter_edit_select, _set_mode


class DynaxSelectSocketZone(Operator):
    """Enter face-select mode on the socket to choose which part of the
    outer wall will be involved in the bridge connection"""
    bl_idname = "dynax.select_socket_zone"
    bl_label = "Select Socket Connection Zone"
    bl_description = ("Enter face-select mode on the SOCKET - select the "
                       "region of the outer wall you want to connect to "
                       "the component")
    bl_options = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH' or obj.get("dynax_is_component"):
            self.report({'ERROR'},
                "Select the SOCKET object (not the component) first.")
            return {'CANCELLED'}

        props = context.scene.dynax_props
        if not _enter_edit_select(context, props.selection_through):
            self.report({'ERROR'}, "Could not enter Edit Mode on the socket.")
            return {'CANCELLED'}
        bpy.ops.mesh.select_all(action='DESELECT')

        context.scene["dynax_bridge_socket_obj"] = obj.name
        # Starting a fresh selection invalidates any previous confirmation.
        context.scene["dynax_socket_zone_confirmed"] = False
        context.scene["dynax_manual_bridge_built"] = False
        self.report({'INFO'},
            "Select the socket faces to involve in the connection "
            "(Box/Lasso/Circle select), then click 'Confirm Socket Zone'.")
        return {'FINISHED'}


class DynaxConfirmSocketZone(Operator):
    """Confirm the selected socket faces"""
    bl_idname = "dynax.confirm_socket_zone"
    bl_label = "Confirm Socket Zone"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or context.mode != 'EDIT_MESH':
            self.report({'ERROR'}, "Must be in Edit Mode with faces selected.")
            return {'CANCELLED'}

        bm = bmesh.from_edit_mesh(obj.data)
        selected_faces = [f for f in bm.faces if f.select]
        if not selected_faces:
            self.report({'ERROR'}, "No faces selected.")
            return {'CANCELLED'}

        context.scene["dynax_socket_zone_face_count"] = len(selected_faces)
        context.scene["dynax_socket_zone_confirmed"] = True

        _set_mode(context, obj, 'OBJECT')
        self.report({'INFO'},
            f"Socket zone confirmed: {len(selected_faces)} faces. "
            "Now select the component zone.")
        return {'FINISHED'}


class DynaxSelectComponentZone(Operator):
    """Enter face-select mode on the component to choose which part will
    be involved in the bridge connection"""
    bl_idname = "dynax.select_component_zone"
    bl_label = "Select Component Connection Zone"
    bl_description = ("Enter face-select mode on the COMPONENT - select "
                       "the region you want connected to the socket")
    bl_options = {'REGISTER'}

    def execute(self, context):
        comp_name = context.scene.get("dynax_active_component", "")
        comp_obj = bpy.data.objects.get(comp_name)
        if not comp_obj:
            self.report({'ERROR'}, "No component loaded.")
            return {'CANCELLED'}

        bpy.ops.object.select_all(action='DESELECT')
        comp_obj.select_set(True)
        context.view_layer.objects.active = comp_obj

        props = context.scene.dynax_props
        if not _enter_edit_select(context, props.selection_through):
            self.report({'ERROR'}, "Could not enter Edit Mode on the component.")
            return {'CANCELLED'}
        bpy.ops.mesh.select_all(action='DESELECT')

        context.scene["dynax_component_zone_confirmed"] = False
        context.scene["dynax_manual_bridge_built"] = False
        self.report({'INFO'},
            "Select the component faces to involve in the connection, "
            "then click 'Confirm Component Zone'. Bolt holes and "
            "functional openings will be preserved automatically - "
            "just select the general connection area.")
        return {'FINISHED'}


class DynaxConfirmComponentZone(Operator):
    """Confirm the selected component faces"""
    bl_idname = "dynax.confirm_component_zone"
    bl_label = "Confirm Component Zone"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or context.mode != 'EDIT_MESH':
            self.report({'ERROR'}, "Must be in Edit Mode with faces selected.")
            return {'CANCELLED'}

        bm = bmesh.from_edit_mesh(obj.data)
        selected_faces = [f for f in bm.faces if f.select]
        if not selected_faces:
            self.report({'ERROR'}, "No faces selected.")
            return {'CANCELLED'}

        context.scene["dynax_component_zone_face_count"] = len(selected_faces)
        context.scene["dynax_component_zone_confirmed"] = True

        _set_mode(context, obj, 'OBJECT')
        self.report({'INFO'},
            f"Component zone confirmed: {len(selected_faces)} faces. "
            "Now click 'Build Bridge'.")
        return {'FINISHED'}


class DynaxBuildManualBridge(Operator):
    """Bridge the confirmed socket zone and component zone boundaries using
    Blender's native bridge_edge_loops, on DUPLICATES of the socket and
    component so the originals are left untouched. Bolt holes and openings
    on the component are preserved since nothing is deleted from either mesh
    except (optionally) the selected connection faces themselves."""
    bl_idname = "dynax.build_manual_bridge"
    bl_label = "Build Bridge"
    bl_description = "Connect the selected socket and component zones"
    bl_options = {'REGISTER', 'UNDO'}

    delete_original_faces: BoolProperty(
        name="Remove selected faces before bridging",
        description=("If ON, deletes the selected faces first so the bridge "
                     "replaces them (creates an opening that the bridge fills). "
                     "If OFF, the bridge is added alongside the existing faces "
                     "(thicker, more solid connection - recommended for FDM)"),
        default=False,
    )

    def execute(self, context):
        socket_name = context.scene.get("dynax_bridge_socket_obj", "")
        socket_obj = bpy.data.objects.get(socket_name)
        comp_name = context.scene.get("dynax_active_component", "")
        comp_obj = bpy.data.objects.get(comp_name)

        if not socket_obj or not comp_obj:
            self.report({'ERROR'}, "Socket or component not found.")
            return {'CANCELLED'}

        if not context.scene.get("dynax_socket_zone_confirmed") or \
           not context.scene.get("dynax_component_zone_confirmed"):
            self.report({'ERROR'},
                "Confirm both the socket zone and component zone selections first.")
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            _set_mode(context, context.active_object, 'OBJECT')

        # Duplicate both objects so the originals stay intact if this fails.
        # MeshVertex/MeshPolygon .select flags are persisted mesh data, so the
        # confirmed zone selections carry over onto the duplicates untouched.
        bpy.ops.object.select_all(action='DESELECT')
        socket_obj.select_set(True)
        comp_obj.select_set(True)
        context.view_layer.objects.active = socket_obj
        bpy.ops.object.duplicate()

        dup_objs = context.selected_objects
        dup_socket = next((o for o in dup_objs if o.name.startswith(socket_obj.name)), None)
        dup_comp = next((o for o in dup_objs if o is not dup_socket
                         and o.name.startswith(comp_obj.name)), None)

        if not dup_socket or not dup_comp:
            self.report({'ERROR'}, "Duplication failed.")
            return {'CANCELLED'}

        # Join the two duplicates into one mesh so bridge_edge_loops can
        # operate across both selections at once (it requires a single object).
        bpy.ops.object.select_all(action='DESELECT')
        dup_socket.select_set(True)
        dup_comp.select_set(True)
        context.view_layer.objects.active = dup_socket
        bpy.ops.object.join()

        joined_obj = context.active_object
        joined_obj.name = "DynaX_Bridge_Result"

        # Enter edit mode - the selections made earlier are preserved on the
        # mesh data as long as we didn't clear them.
        bpy.ops.object.mode_set(mode='EDIT')
        bm = bmesh.from_edit_mesh(joined_obj.data)

        selected_faces = [f for f in bm.faces if f.select]
        if len(selected_faces) < 2:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.data.objects.remove(joined_obj, do_unlink=True)
            self.report({'ERROR'},
                "Selections were lost during join. Please redo zone selection "
                "immediately before building.")
            return {'CANCELLED'}

        if self.delete_original_faces:
            bmesh.ops.delete(bm, geom=selected_faces, context='FACES')
            bmesh.update_edit_mesh(joined_obj.data)
            # select_non_manifold requires vertex/edge select mode (face mode,
            # active up to here, isn't accepted and raises a poll error).
            bpy.ops.mesh.select_mode(type='EDGE')
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.select_non_manifold()
        else:
            # Leave the original faces in place. bridge_edge_loops CONSUMES
            # (replaces) any fully-selected 2D face patch it's fed, so feeding
            # it the whole patch selection would silently delete the patch
            # anyway - not the "thicker, extra material" result this option
            # promises. Instead select ONLY the outer boundary edges of the
            # two selected islands (an edge with exactly one of its linked
            # faces inside the selection) and bridge those - the patches
            # themselves are never touched, and the new tube is added as
            # genuinely extra material alongside them.
            selected_set = set(selected_faces)
            boundary_edges = [e for e in bm.edges
                              if sum(1 for f in e.link_faces if f in selected_set) == 1]
            bpy.ops.mesh.select_mode(type='EDGE')
            bpy.ops.mesh.select_all(action='DESELECT')
            for e in boundary_edges:
                e.select = True
            bmesh.update_edit_mesh(joined_obj.data)

        try:
            bpy.ops.mesh.bridge_edge_loops(
                type='CLOSED',
                use_merge=False,
                merge_factor=0.5,
                twist_offset=0,
                number_cuts=2,
                interpolation='SURFACE',
                smoothness=1.0,
                profile_shape_factor=0.0,
            )
        except Exception as e:
            bpy.ops.object.mode_set(mode='OBJECT')
            self.report({'ERROR'},
                f"Bridge failed: {e}. Try adjusting your selections so both "
                "zones form clean, roughly similar-sized boundary loops.")
            return {'CANCELLED'}

        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.object.mode_set(mode='OBJECT')

        # Clean up coincident geometry left by the join/bridge (dedupe verts,
        # close any small boundary holes, unify normals) so the result is a
        # single tidy watertight-as-possible mesh - the same cleanup pattern
        # already proven in component_bridge.py's merge step.
        bm2 = bmesh.new()
        bm2.from_mesh(joined_obj.data)
        bmesh.ops.remove_doubles(bm2, verts=bm2.verts, dist=0.05)
        open_edges = [e for e in bm2.edges if len(e.link_faces) == 1]
        if open_edges:
            bmesh.ops.holes_fill(bm2, edges=open_edges, sides=0)
        bmesh.ops.recalc_face_normals(bm2, faces=bm2.faces[:])
        bm2.to_mesh(joined_obj.data)
        bm2.free()
        joined_obj.data.update()

        context.scene["dynax_manual_bridge_built"] = True
        self.report({'INFO'},
            "Bridge built as 'DynaX_Bridge_Result'. The original socket and "
            "component objects were left untouched - hide or delete them "
            "before export if you don't need them. Review the result, then "
            "proceed to Export.")
        return {'FINISHED'}
