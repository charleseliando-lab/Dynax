# operators/sculpt_brushes.py - Clean WASP-Med-style brush system (v1.9.9)
#
# 9 curated brushes, each a clean button. When active, the panel shows
# Radius + Strength sliders (WASP Med style). Brush activation works across
# Blender 3.x / 4.x / 5.x via three fallback methods.

import bpy
from bpy.types import Operator

# Each brush: (operator_id, label, icon, sculpt_tool, essentials_asset_name)
# sculpt_tool = the Brush.sculpt_tool enum value (for direct assignment)
# essentials_asset_name = the asset name in Blender 5.0's essentials library
BRUSHES = [
    ("dynax.brush_grab",    "Grab / Move", "BRUSH_GRAB",       "GRAB",    "Grab"),
    ("dynax.brush_draw",    "Draw",        "BRUSH_ADD",        "DRAW",    "Draw"),
    ("dynax.brush_smooth",  "Smooth",      "MOD_SMOOTH",       "SMOOTH",  "Smooth"),
    ("dynax.brush_inflate", "Inflate",     "BRUSH_INFLATE",    "INFLATE", "Inflate/Deflate"),
    ("dynax.brush_flatten", "Flatten",     "MOD_SMOOTH",       "FLATTEN", "Flatten"),
    ("dynax.brush_mask",    "Mask",        "MOD_MASK",         "MASK",    "Mask"),
    ("dynax.brush_trim",    "Trim / Cut",  "MOD_BOOLEAN",      "DRAW_SHARP", "Draw Sharp"),
    ("dynax.brush_crease",  "Crease",      "LINCURVE",         "CREASE",  "Crease"),
    ("dynax.brush_pinch",   "Pinch",       "FULLSCREEN_ENTER", "PINCH",   "Pinch/Magnify"),
]

# Map operator id -> (sculpt_tool, asset_name) for the activation function
_BRUSH_MAP = {b[0]: (b[3], b[4]) for b in BRUSHES}


def _ensure_sculpt_mode(context):
    obj = context.active_object
    if not obj or obj.type != 'MESH':
        return False
    if context.mode != 'SCULPT':
        if context.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass
        try:
            bpy.ops.object.mode_set(mode='SCULPT')
        except Exception:
            return False
    # O&P meshes are asymmetric — no symmetry
    try:
        sc = context.tool_settings.sculpt
        sc.use_symmetry_x = False
        sc.use_symmetry_y = False
        sc.use_symmetry_z = False
    except Exception:
        pass
    return True


def _activate_brush(context, sculpt_tool, asset_name):
    """
    Activate a sculpt brush by name. Tries three methods for cross-version support.
    Returns True on success.
    """
    # Method 1 (Blender 5.0 / 4.3+): asset-based brush activation
    try:
        bpy.ops.brush.asset_activate(
            asset_library_type='ESSENTIALS',
            relative_asset_identifier=(
                f"brushes/essentials_brushes-mesh_sculpt.blend/Brush/{asset_name}"
            ),
        )
        return True
    except Exception:
        pass

    # Method 2 (Blender 3.6–4.2): tool_set_by_id
    candidates = [
        f"builtin_brush.{asset_name}",
        f"builtin.{asset_name.lower().replace('/', '_').replace(' ', '_')}",
    ]
    for tool_name in candidates:
        try:
            bpy.ops.wm.tool_set_by_id(name=tool_name)
            return True
        except Exception:
            continue

    # Method 3 (fallback): direct brush data assignment by sculpt_tool
    try:
        target = None
        for b in bpy.data.brushes:
            if getattr(b, 'sculpt_tool', None) == sculpt_tool:
                target = b
                break
        if target:
            context.tool_settings.sculpt.brush = target
            return True
    except Exception:
        pass

    return False


def _apply_radius_strength(context):
    """Apply the panel's radius/strength to the active brush"""
    props = context.scene.dynax_props
    try:
        ts = context.tool_settings.sculpt
        ups = ts.unified_paint_settings
        brush = ts.brush
        # Radius
        if ups.use_unified_size:
            ups.size = props.brush_radius
        elif brush:
            brush.size = props.brush_radius
        # Strength
        if ups.use_unified_strength:
            ups.strength = props.brush_strength
        elif brush:
            brush.strength = props.brush_strength
    except Exception:
        pass


def _activate_and_track(context, op_id):
    """Activate a brush and remember which one is active for the panel"""
    if not _ensure_sculpt_mode(context):
        return False
    sculpt_tool, asset_name = _BRUSH_MAP[op_id]
    ok = _activate_brush(context, sculpt_tool, asset_name)
    _apply_radius_strength(context)
    # Track active brush label for the panel
    label = next((b[1] for b in BRUSHES if b[0] == op_id), "")
    context.scene["dynax_active_brush"] = label
    return ok


# ── Brush operators (one per brush) ────────────────────────────────────────────

class DynaxBrushGrab(Operator):
    bl_idname = "dynax.brush_grab"
    bl_label = "Grab / Move"
    bl_description = "Grab and pull part of the mesh"
    bl_options = {'REGISTER'}
    def execute(self, context):
        if not _activate_and_track(context, self.bl_idname):
            self.report({'WARNING'}, "Could not activate Grab — pick it from the brush list")
        return {'FINISHED'}

class DynaxBrushDraw(Operator):
    bl_idname = "dynax.brush_draw"
    bl_label = "Draw"
    bl_description = "Add or subtract volume"
    bl_options = {'REGISTER'}
    def execute(self, context):
        _activate_and_track(context, self.bl_idname)
        return {'FINISHED'}

class DynaxBrushSmooth(Operator):
    bl_idname = "dynax.brush_smooth"
    bl_label = "Smooth"
    bl_description = "Smooth out bumps and noise"
    bl_options = {'REGISTER'}
    def execute(self, context):
        _activate_and_track(context, self.bl_idname)
        return {'FINISHED'}

class DynaxBrushInflate(Operator):
    bl_idname = "dynax.brush_inflate"
    bl_label = "Inflate"
    bl_description = "Inflate or deflate along normals"
    bl_options = {'REGISTER'}
    def execute(self, context):
        _activate_and_track(context, self.bl_idname)
        return {'FINISHED'}

class DynaxBrushFlatten(Operator):
    bl_idname = "dynax.brush_flatten"
    bl_label = "Flatten"
    bl_description = "Flatten raised areas"
    bl_options = {'REGISTER'}
    def execute(self, context):
        _activate_and_track(context, self.bl_idname)
        return {'FINISHED'}

class DynaxBrushMask(Operator):
    bl_idname = "dynax.brush_mask"
    bl_label = "Mask"
    bl_description = "Paint a mask to protect areas"
    bl_options = {'REGISTER'}
    def execute(self, context):
        _activate_and_track(context, self.bl_idname)
        return {'FINISHED'}

class DynaxBrushTrim(Operator):
    bl_idname = "dynax.brush_trim"
    bl_label = "Trim / Cut"
    bl_description = "Sharp draw for trimming detail"
    bl_options = {'REGISTER'}
    def execute(self, context):
        _activate_and_track(context, self.bl_idname)
        return {'FINISHED'}

class DynaxBrushCrease(Operator):
    bl_idname = "dynax.brush_crease"
    bl_label = "Crease"
    bl_description = "Create sharp creases or ridges"
    bl_options = {'REGISTER'}
    def execute(self, context):
        _activate_and_track(context, self.bl_idname)
        return {'FINISHED'}

class DynaxBrushPinch(Operator):
    bl_idname = "dynax.brush_pinch"
    bl_label = "Pinch"
    bl_description = "Pinch vertices together"
    bl_options = {'REGISTER'}
    def execute(self, context):
        _activate_and_track(context, self.bl_idname)
        return {'FINISHED'}


class DynaxBrushUpdateSettings(Operator):
    """Apply the Radius/Strength sliders to the active brush"""
    bl_idname = "dynax.brush_update_settings"
    bl_label = "Apply brush settings"
    bl_options = {'REGISTER'}
    def execute(self, context):
        _apply_radius_strength(context)
        return {'FINISHED'}
