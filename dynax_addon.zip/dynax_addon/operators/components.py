# operators/components.py - Component library and alignment (v1.3)

import bpy
import os
from bpy.types import Operator
from bpy.props import StringProperty, EnumProperty, FloatProperty, BoolProperty

# Collection names
COLLECTION_PROSTHETIC = "DynaX_Prosthetic_Components"
COLLECTION_ORTHOTIC   = "DynaX_Orthotic_Components"
COLLECTION_SCAN       = "DynaX_Scan"


def _ensure_collection(name):
    """Get or create a named collection and link to scene"""
    col = bpy.data.collections.get(name)
    if not col:
        col = bpy.data.collections.new(name)
        bpy.context.scene.collection.children.link(col)
    return col


def _move_to_collection(obj, col):
    """Move object to a specific collection"""
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    col.objects.link(obj)


class DynaxImportComponent(Operator):
    """Import a component STL (adapter, pylon, foot, hinge…) into the component library"""
    bl_idname = "dynax.import_component"
    bl_label = "Import component STL"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: StringProperty(subtype='FILE_PATH')
    filter_glob: StringProperty(default="*.stl;*.STL", options={'HIDDEN'})

    category: EnumProperty(
        name="Category",
        items=[
            ('PROSTHETIC', "Prosthetic", ""),
            ('ORTHOTIC',   "Orthotic",   ""),
        ],
        default='PROSTHETIC',
    )

    def execute(self, context):
        if not self.filepath or not os.path.exists(self.filepath):
            self.report({'ERROR'}, "File not found")
            return {'CANCELLED'}

        before = set(bpy.data.objects.keys())

        try:
            if hasattr(bpy.ops.wm, 'stl_import'):
                bpy.ops.wm.stl_import(filepath=self.filepath)
            else:
                bpy.ops.import_mesh.stl(filepath=self.filepath)
        except Exception as e:
            self.report({'ERROR'}, f"Import failed: {e}")
            return {'CANCELLED'}

        after = set(bpy.data.objects.keys())
        new_names = after - before
        if not new_names:
            self.report({'ERROR'}, "No object was imported")
            return {'CANCELLED'}

        col_name = COLLECTION_PROSTHETIC if self.category == 'PROSTHETIC' else COLLECTION_ORTHOTIC
        col = _ensure_collection(col_name)

        for name in new_names:
            obj = bpy.data.objects.get(name)
            if obj:
                _move_to_collection(obj, col)
                # Tag as component
                obj["dynax_component"] = True
                obj["dynax_component_category"] = self.category

        self.report({'INFO'}, f"✓ Component imported to {col_name}")
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class DynaxOrganiseCollections(Operator):
    """Set up DynaX collections and move selected scan into Scan collection"""
    bl_idname = "dynax.organise_collections"
    bl_label = "Organise collections"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        _ensure_collection(COLLECTION_SCAN)
        _ensure_collection(COLLECTION_PROSTHETIC)
        _ensure_collection(COLLECTION_ORTHOTIC)

        # Move active object to scan collection if it's not a component
        obj = context.active_object
        if obj and obj.type == 'MESH' and not obj.get("dynax_component"):
            col = _ensure_collection(COLLECTION_SCAN)
            _move_to_collection(obj, col)
            self.report({'INFO'}, f"✓ Collections ready. Scan moved to {COLLECTION_SCAN}")
        else:
            self.report({'INFO'}, "✓ DynaX collections created")
        return {'FINISHED'}


class DynaxAttachComponent(Operator):
    """Boolean-union the selected component onto the active socket/scan"""
    bl_idname = "dynax.attach_component"
    bl_label = "Attach component (boolean join)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected = [o for o in context.selected_objects if o.type == 'MESH']
        active = context.active_object

        if not active or active.type != 'MESH':
            self.report({'ERROR'}, "Set the socket/scan as the active object")
            return {'CANCELLED'}

        components = [o for o in selected if o != active and o.get("dynax_component")]
        if not components:
            self.report({'ERROR'}, "Select at least one component object (and the socket)")
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        for idx, comp in enumerate(components, 1):
            # Apply transforms on both
            for obj in [active, comp]:
                bpy.ops.object.select_all(action='DESELECT')
                obj.select_set(True)
                context.view_layer.objects.active = obj
                bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

            # Boolean union
            bpy.ops.object.select_all(action='DESELECT')
            active.select_set(True)
            context.view_layer.objects.active = active

            mod = active.modifiers.new(name=f"DYNAX_ATTACH_{idx}", type='BOOLEAN')
            mod.operation = 'UNION'
            mod.object = comp
            try:
                mod.solver = 'EXACT'
            except Exception:
                pass

            try:
                bpy.ops.object.modifier_apply(modifier=mod.name)
            except Exception as e:
                self.report({'ERROR'}, f"Boolean failed: {e}")
                return {'CANCELLED'}

            bpy.data.objects.remove(comp, do_unlink=True)

        self.report({'INFO'}, f"✓ {len(components)} component(s) attached")
        return {'FINISHED'}


class DynaxAlignComponentZ(Operator):
    """Snap selected component to the bottom of the active socket (for preview)"""
    bl_idname = "dynax.align_component_z"
    bl_label = "Align component to socket base"
    bl_options = {'REGISTER', 'UNDO'}

    offset_mm: FloatProperty(name="Z offset (mm)", default=0.0, min=-50.0, max=50.0)

    def execute(self, context):
        selected = [o for o in context.selected_objects if o.type == 'MESH']
        active = context.active_object

        if not active or active.type != 'MESH' or len(selected) < 2:
            self.report({'ERROR'}, "Select the socket (active) and a component")
            return {'CANCELLED'}

        component = next((o for o in selected if o != active), None)
        if not component:
            self.report({'ERROR'}, "No component found in selection")
            return {'CANCELLED'}

        # Find bottom of socket in world space
        import mathutils
        socket_verts = [active.matrix_world @ v.co for v in active.data.vertices]
        socket_z_min = min(v.z for v in socket_verts)

        comp_verts = [component.matrix_world @ v.co for v in component.data.vertices]
        comp_z_max = max(v.z for v in comp_verts)

        # Move component so its top aligns with socket bottom.
        # mm-space scene (scale_length=0.001): the offset is already in scene units
        # (mm), so no /1000.
        delta_z = socket_z_min - comp_z_max + self.offset_mm
        component.location.z += delta_z

        self.report({'INFO'}, f"✓ Component aligned below socket (+{self.offset_mm:.0f} mm offset)")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=250)
