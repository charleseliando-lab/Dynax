# operators/align_gizmo.py - Auto-align with gizmo + numeric controls (v1.8)

import bpy
import math
from bpy.types import Operator
from bpy.props import FloatProperty


class DynaxAlignGizmoMove(Operator):
    """Activate the move gizmo for whole-mesh positioning"""
    bl_idname = "dynax.align_gizmo_move"
    bl_label = "Move gizmo"
    bl_options = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        try:
            bpy.ops.wm.tool_set_by_id(name='builtin.move')
        except Exception:
            pass
        self.report({'INFO'}, "Move gizmo active — drag to reposition the scan")
        return {'FINISHED'}


class DynaxAlignGizmoRotate(Operator):
    """Activate the rotate gizmo for whole-mesh orientation"""
    bl_idname = "dynax.align_gizmo_rotate"
    bl_label = "Rotate gizmo"
    bl_options = {'REGISTER'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        try:
            bpy.ops.wm.tool_set_by_id(name='builtin.rotate')
        except Exception:
            pass
        self.report({'INFO'}, "Rotate gizmo active — drag the rings to orient the scan")
        return {'FINISHED'}


class DynaxAlignNumeric(Operator):
    """Apply a precise numeric rotation around an axis (like uFit's controls)"""
    bl_idname = "dynax.align_numeric"
    bl_label = "Apply rotation"
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.EnumProperty(
        items=[
            ('X', "Flexion/Extension (X)", "Tilt forward/backward"),
            ('Y', "Adduction/Abduction (Y)", "Tilt left/right"),
            ('Z', "Rotation (Z)", "Spin around vertical axis"),
        ],
        default='X',
    )
    angle_deg: FloatProperty(
        name="Angle (degrees)",
        default=5.0, min=-180.0, max=180.0,
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        axis_idx = {'X': 0, 'Y': 1, 'Z': 2}[self.axis]
        obj.rotation_euler[axis_idx] += math.radians(self.angle_deg)
        bpy.ops.object.transform_apply(rotation=True, location=False, scale=False)

        self.report({'INFO'},
            f"Applied {self.angle_deg:.1f}° around {self.axis} axis")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class DynaxAlignReset(Operator):
    """Reset all rotation to zero"""
    bl_idname = "dynax.align_reset"
    bl_label = "Reset rotation"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        obj.rotation_euler = (0, 0, 0)
        self.report({'INFO'}, "Rotation reset")
        return {'FINISHED'}


class DynaxApplyNumericRotation(Operator):
    """Apply numeric rotation from the panel sliders"""
    bl_idname = "dynax.apply_numeric_rotation"
    bl_label = "Apply numeric rotation"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        props = context.scene.dynax_props
        obj.rotation_euler[0] += math.radians(props.align_flexion)
        obj.rotation_euler[1] += math.radians(props.align_abduction)
        obj.rotation_euler[2] += math.radians(props.align_rotation)
        bpy.ops.object.transform_apply(rotation=True, location=False, scale=False)

        # Reset the sliders after applying
        props.align_flexion = 0.0
        props.align_abduction = 0.0
        props.align_rotation = 0.0

        self.report({'INFO'}, "✓ Rotation applied")
        return {'FINISHED'}
