# operators/paralink_ops.py
# Blender operators exposing ParaLink to the DynaX panel.

import bpy
from bpy.props import EnumProperty
from bpy.types import Operator
from .paralink import (
    extract_socket_boundary, extract_component_boundary,
    map_boundaries, draw_boundary_curve, draw_mapping_lines,
    clear_diagnostics, print_diagnostics,
    SOCKET_BOUNDARY_NAME, COMPONENT_BOUNDARY_NAME,
    BoundaryExtractionError,
)
# Read-only use of Module 3 (envelope analysis) to estimate Guided-mode
# metrics for display. Does not modify envelope_analyser.py or any other
# geometry module, and never itself mutates the socket/component meshes.
from .paralink.envelope_analyser import analyse_envelope

try:
    from ..analytics.collector import record_event
except ImportError:
    def record_event(*_args, **_kwargs):
        return None


class DynaxParaLinkDiagnostics(Operator):
    """Sprint 0: Draw boundaries and mapping. No geometry generated."""
    bl_idname = "dynax.paralink_diagnostics"
    bl_label = "ParaLink Diagnostics"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        socket_name = context.scene.get("dynax_bridge_socket_obj")
        socket_obj = bpy.data.objects.get(socket_name) if socket_name else None
        comp_obj = bpy.data.objects.get("dynax_component")

        if socket_obj is None:
            self.report({'ERROR'}, "No active socket found.")
            return {'CANCELLED'}
        if comp_obj is None:
            self.report({'ERROR'}, "No component loaded.")
            return {'CANCELLED'}

        clear_diagnostics()

        try:
            # v1.21.0 test-feedback fix #4: visualise the SAME boundary the
            # actual join will use. dynax_paralink_boundary_offset==0.0 makes
            # _resolve_user_transition_z() return None, so this is byte-for-
            # byte the previous behaviour in that case.
            user_z = _resolve_user_transition_z(context.scene, socket_obj, comp_obj)
            socket_b = extract_socket_boundary(socket_obj, user_z)
            component_b = extract_component_boundary(comp_obj)
            mapping = map_boundaries(socket_b, component_b)
        except BoundaryExtractionError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        draw_boundary_curve(socket_b.positions, SOCKET_BOUNDARY_NAME,
                             color=(1.0, 0.55, 0.0))   # orange
        draw_boundary_curve(component_b.positions, COMPONENT_BOUNDARY_NAME,
                             color=(0.2, 0.6, 1.0))    # blue
        draw_mapping_lines(mapping.socket_resampled,
                            mapping.component_resampled)

        print_diagnostics(socket_b, component_b, mapping)

        q = mapping.diagnostics["mapping_quality"]
        self.report(
            {'INFO'},
            f"ParaLink: boundaries drawn. "
            f"Mapping quality {q*100:.0f}%. "
            f"Check console for full diagnostics."
        )
        return {'FINISHED'}


class DynaxParaLinkClearDiagnostics(Operator):
    """Remove ParaLink diagnostic objects from scene."""
    bl_idname = "dynax.paralink_clear_diagnostics"
    bl_label = "Clear Diagnostics"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        clear_diagnostics()
        self.report({'INFO'}, "ParaLink diagnostic objects removed.")
        return {'FINISHED'}


class DynaxParaLinkConnect(Operator):
    """Run full ParaLink pipeline."""
    bl_idname = "dynax.paralink_connect"
    bl_label = "Connect Component (ParaLink)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from .paralink import run_paralink

        socket_name = context.scene.get("dynax_bridge_socket_obj")
        socket_obj = bpy.data.objects.get(socket_name) if socket_name else None
        comp_obj = bpy.data.objects.get("dynax_component")

        if socket_obj is None:
            self.report({'ERROR'}, "No active socket.")
            return {'CANCELLED'}
        if comp_obj is None:
            self.report({'ERROR'}, "No component loaded.")
            return {'CANCELLED'}

        style = getattr(context.scene, 'dynax_paralink_style', 'HYBRID')

        try:
            user_z = _resolve_user_transition_z(context.scene, socket_obj, comp_obj)
            validation = run_paralink(
                context, socket_obj, comp_obj,
                connection_style=style,
                user_transition_z=user_z,
            )
        except Exception as e:
            self.report({'ERROR'}, f"ParaLink failed: {e}")
            import traceback
            traceback.print_exc()
            return {'CANCELLED'}

        if validation.is_watertight:
            self.report({'INFO'}, "ParaLink: complete and watertight.")
        else:
            self.report(
                {'WARNING'},
                f"ParaLink: complete - {validation.open_edge_count} open edges. "
                f"Use Quick Bridge for a print-safe result."
            )
        record_event("paralink_connect_used", value=style)
        try:
            from ..utils.session_recorder import get_recorder
            mode = getattr(context.scene, 'dynax_paralink_mode', 'AUTO')
            get_recorder().log_paralink(mode.lower(), validation.is_watertight)
        except Exception:
            pass
        return {'FINISHED'}


# ── Involvement Levels (v1.21.0) ───────────────────────────────────────────
# Four-mode ParaLink UI (AUTO/GUIDED/SEMI/MANUAL). None of these operators
# modify surface_generator.py, join_engine.py or any other geometry module —
# they only call the SAME existing run_paralink()/diagnostics entry points
# that DynaxParaLinkConnect and DynaxParaLinkDiagnostics above already use.
# See panels/components_section.py for the mode selector + per-mode UI.

class DynaxParaLinkSetMode(Operator):
    """Switch the ParaLink Connection Mode."""
    bl_idname = "dynax.paralink_set_mode"
    bl_label = "Set ParaLink Mode"
    bl_options = {'REGISTER', 'UNDO'}

    mode: EnumProperty(
        items=[
            ('AUTO', 'Auto', ''),
            ('GUIDED', 'Guided', ''),
            ('SEMI', 'Semi-Manual', ''),
            ('MANUAL', 'Manual', ''),
        ],
        default='AUTO',
    )

    def execute(self, context):
        context.scene.dynax_paralink_mode = self.mode
        # No slider pre-fill needed: dynax_paralink_boundary_offset (v1.21.0
        # test-feedback fix #2) is a single property shared by Guided, Semi
        # and Manual mode, so switching between them already shows the same
        # value with nothing to carry over.
        return {'FINISHED'}


def _clamp(value, lo, hi):
    return max(lo, min(hi, value))


def _resolve_user_transition_z(scene, socket_obj, comp_obj):
    """Upper-boundary control (v1.21.0 test-feedback fix #2):
    dynax_paralink_boundary_offset is a +/- mm nudge on TOP of the
    auto-detected cut height, not an absolute override - 0.0 (the default)
    means fully automatic, matching Auto mode's untouched behaviour. Reuses
    the same Module 1/2/3 calls (extract_socket_boundary, map_boundaries,
    analyse_envelope) already used elsewhere in this file, read-only - does
    not modify boundary_extractor.py, boundary_mapper.py or
    envelope_analyser.py."""
    boundary_offset = getattr(scene, 'dynax_paralink_boundary_offset', 0.0)
    if boundary_offset == 0.0:
        return None
    prelim = extract_socket_boundary(socket_obj, None)
    comp_b = extract_component_boundary(comp_obj)
    mapping = map_boundaries(prelim, comp_b)
    envelope = analyse_envelope(socket_obj, comp_obj, None, mapping)
    return envelope.transition_z + boundary_offset


def _loop_length(positions):
    """Perimeter of a closed boundary loop (mm) — pure geometry math on
    already-extracted positions, not a change to boundary_extractor.py."""
    if not positions:
        return 0.0
    n = len(positions)
    return sum((positions[i] - positions[(i + 1) % n]).length for i in range(n))


class DynaxParaLinkAnalyseGuided(Operator):
    """Guided mode: analyse both boundaries and show a metrics preview.

    Read-only — extracts and maps boundaries exactly like Run Diagnostics
    (Module 1/2/3), draws the same boundary overlay, and estimates display
    metrics from the resulting envelope. No geometry is created or joined.
    """
    bl_idname = "dynax.paralink_analyse_guided"
    bl_label = "Analyse Boundaries"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        socket_name = scene.get("dynax_bridge_socket_obj")
        socket_obj = bpy.data.objects.get(socket_name) if socket_name else None
        comp_obj = bpy.data.objects.get("dynax_component")

        if socket_obj is None:
            self.report({'ERROR'}, "No active socket found.")
            return {'CANCELLED'}
        if comp_obj is None:
            self.report({'ERROR'}, "No component loaded.")
            return {'CANCELLED'}

        clear_diagnostics()
        try:
            # v1.21.0 test-feedback fix #5: all three displayed metrics
            # (loop length, offset distance, quality) must come from the
            # SAME offset-adjusted boundary Connect/Validate & Join will
            # actually use, not a separate always-auto extraction.
            # dynax_paralink_boundary_offset==0.0 makes
            # _resolve_user_transition_z() return None, so this is
            # byte-for-byte the previous behaviour in that case.
            user_z = _resolve_user_transition_z(context.scene, socket_obj, comp_obj)
            socket_b = extract_socket_boundary(socket_obj, user_z)
            component_b = extract_component_boundary(comp_obj)
            mapping = map_boundaries(socket_b, component_b)
            envelope = analyse_envelope(socket_obj, comp_obj, user_z, mapping)
        except BoundaryExtractionError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        draw_boundary_curve(socket_b.positions, SOCKET_BOUNDARY_NAME,
                             color=(1.0, 0.55, 0.0))
        draw_boundary_curve(component_b.positions, COMPONENT_BOUNDARY_NAME,
                             color=(0.2, 0.6, 1.0))
        draw_mapping_lines(mapping.socket_resampled, mapping.component_resampled)

        quality = _clamp(mapping.diagnostics["mapping_quality"] * 100.0, 0.0, 100.0)
        loop_length = _loop_length(socket_b.positions)
        offset_distance = envelope.offset_mm  # real envelope_analyser.py output field

        scene.dynax_paralink_guided_quality = quality
        scene.dynax_paralink_guided_loop_length = loop_length
        scene.dynax_paralink_guided_offset_distance = offset_distance
        scene.dynax_paralink_guided_transition_z = envelope.transition_z
        scene.dynax_paralink_guided_ready = True

        self.report({'INFO'}, f"ParaLink: boundaries analysed. Quality {quality:.0f}/100.")
        return {'FINISHED'}


class DynaxParaLinkValidateJoin(Operator):
    """Manual mode fallback: run the join + validation pipeline directly.

    NOTE (documented deviation, see CLAUDE.md's registration-discipline
    lesson and the "do not modify surface_generator.py / geometry code"
    constraint this feature was built under): the Join Engine (Module 7)
    and Validator (Module 8) are not separable from boundary
    extraction/mapping/envelope/skin-generation (Modules 1-6) without
    editing join_engine.py's or paralink_engine.py's orchestration, which
    was explicitly out of scope. This therefore calls the SAME unmodified
    run_paralink() pipeline as Auto/Guided/Semi-Manual - it is offered as
    the "always works even if the other entry points are misconfigured"
    fallback in the sense that it takes no slider/preview state as input,
    not in the sense of skipping extraction. True selection-driven
    Join+Validate-only execution is future work.
    """
    bl_idname = "dynax.paralink_validate_join"
    bl_label = "Validate and Join"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from .paralink import run_paralink

        socket_name = context.scene.get("dynax_bridge_socket_obj")
        socket_obj = bpy.data.objects.get(socket_name) if socket_name else None
        comp_obj = bpy.data.objects.get("dynax_component")

        if socket_obj is None:
            self.report({'ERROR'}, "No active socket.")
            return {'CANCELLED'}
        if comp_obj is None:
            self.report({'ERROR'}, "No component loaded.")
            return {'CANCELLED'}

        style = getattr(context.scene, 'dynax_paralink_style', 'HYBRID')

        try:
            user_z = _resolve_user_transition_z(context.scene, socket_obj, comp_obj)
            validation = run_paralink(
                context, socket_obj, comp_obj,
                connection_style=style,
                user_transition_z=user_z,
            )
        except Exception as e:
            self.report({'ERROR'}, f"ParaLink failed: {e}")
            import traceback
            traceback.print_exc()
            return {'CANCELLED'}

        if validation.is_watertight:
            self.report({'INFO'}, "ParaLink: complete and watertight.")
        else:
            self.report(
                {'WARNING'},
                f"ParaLink: complete - {validation.open_edge_count} open edges."
            )
        record_event("paralink_connect_used", value=style)
        try:
            from ..utils.session_recorder import get_recorder
            get_recorder().log_paralink('manual', validation.is_watertight)
        except Exception:
            pass
        return {'FINISHED'}


class DynaxParaLinkResetBoundary(Operator):
    bl_idname = "dynax.paralink_reset_boundary"
    bl_label = "Reset boundary to automatic"
    bl_description = "Reset the connection boundary to automatic detection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.dynax_paralink_boundary_offset = 0.0
        return {'FINISHED'}
