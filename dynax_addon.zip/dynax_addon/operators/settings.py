# operators/settings.py - Settings panel toggle + language apply (v1.7.0)

import bpy
from bpy.types import Operator


class DynaxOpenSettings(Operator):
    bl_idname = "dynax.open_settings"
    bl_label = "Settings"
    bl_description = "Open the DynaX Settings panel"
    bl_options = {'REGISTER'}

    def execute(self, context):
        context.scene.dynax_props.dynax_showing_settings = True
        return {'FINISHED'}


class DynaxCloseSettings(Operator):
    bl_idname = "dynax.close_settings"
    bl_label = "Close Settings"
    bl_description = "Close the Settings panel and return to the welcome screen"
    bl_options = {'REGISTER'}

    def execute(self, context):
        context.scene.dynax_props.dynax_showing_settings = False
        return {'FINISHED'}


class DynaxSetLanguage(Operator):
    """Apply the selected DynaX interface language"""
    bl_idname = "dynax.set_language"
    bl_label = "Apply Language"
    bl_description = "Apply the selected interface language"
    bl_options = {'REGISTER'}

    def execute(self, context):
        props = context.scene.dynax_props
        try:
            bpy.context.preferences.view.language = props.dynax_ui_language
            bpy.context.preferences.view.use_translate_interface = True
            bpy.context.preferences.view.use_translate_tooltips = True
        except Exception as e:
            self.report({'ERROR'}, f"Could not apply language: {e}")
            return {'CANCELLED'}
        self.report({'INFO'}, "Language updated.")
        return {'FINISHED'}
