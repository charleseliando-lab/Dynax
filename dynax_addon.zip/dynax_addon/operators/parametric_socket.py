# operators/parametric_socket.py - Parametric socket sliders (Phase 2)
#
# Loads the pre-rigged reference template (band vertex groups already exist,
# created once via Phase 1 tooling, never regenerated per-user) and builds a
# Geometry Nodes rig that exposes live circumference/height controls per band.
#
# The Geometry Nodes tree is constructed entirely from Python here (the
# primary approach) — the template .blend only ships the mesh + vertex groups,
# not the node group, so this module is the single source of truth for the rig.

import bpy
import os
import math
from bpy.types import Operator
from bpy.props import StringProperty

# ── Device identity constants ─────────────────────────────────────────────────
# These identify THIS specific parametric device. When a second device type is
# added (e.g. transtibial), it gets its own operator file with its own
# constants — nothing here changes.
TEMPLATE_FILENAME   = "ak_reference_rigged.blend"
TEMPLATE_MESH_NAME  = "ak_reference_base"
DEVICE_DISPLAY_NAME = "Quadrilateral Transfemoral Socket"
DEVICE_SHORT_NAME   = "QTF_Socket"            # object/modifier naming (no spaces)
NODEGROUP_NAME      = f"DynaX_{DEVICE_SHORT_NAME}_Rig"
MODIFIER_NAME       = NODEGROUP_NAME          # modifier shares the rig name
BAND_NAMES = ["band_distal", "band_lower_mid", "band_mid", "band_upper_mid", "band_brim"]


def band_label(band_name):
    """band_lower_mid -> 'Lower Mid'"""
    return band_name.replace("band_", "").replace("_", " ").title()


def circ_socket_name(band_name):
    return f"{band_label(band_name)} Circ"


def height_socket_name(band_name):
    return f"{band_label(band_name)} Height"


def _get_template_path():
    """Resolve bundled template path relative to the dynax_addon package root.
    __file__ is operators/parametric_socket.py, so go up TWO levels to reach
    dynax_addon/, then into reference_models/."""
    operators_dir = os.path.dirname(os.path.abspath(__file__))
    addon_root = os.path.dirname(operators_dir)   # operators/ -> dynax_addon/
    path = os.path.join(addon_root, "reference_models", TEMPLATE_FILENAME)
    print(f"[DynaX ParaForge] Resolved template path: {path}")
    return path


def get_band_input_keys(node_group):
    """Map each band's friendly socket name to the modifier input KEY
    (socket.identifier, e.g. 'Socket_3') used to read/write the value via
    modifier[key]. Blender names GN modifier inputs by identifier, not by the
    label shown in the editor, so the panel needs this lookup to bind props."""
    by_name = {}
    for item in node_group.interface.items_tree:
        # items_tree includes panels too; only sockets have in_out / identifier
        if getattr(item, "item_type", "SOCKET") == "SOCKET" and getattr(item, "in_out", None) == "INPUT":
            by_name[item.name] = item.identifier
    keys = {}
    for band in BAND_NAMES:
        keys[band] = (
            by_name.get(circ_socket_name(band)),
            by_name.get(height_socket_name(band)),
        )
    return keys


# Live measurements are computed off the EVALUATED (deformed) mesh, which is
# costly to rebuild every panel redraw. Cache per object, keyed by the current
# slider-input signature, so we only recompute when a slider actually moved.
_MEAS_CACHE = {}  # obj.name -> (signature_tuple, {band: (circ_mm, height_mm)})


def _input_signature(obj):
    mod = obj.modifiers.get(MODIFIER_NAME)
    if not mod or not mod.node_group:
        return None
    keys = get_band_input_keys(mod.node_group)
    sig = []
    for band in BAND_NAMES:
        ck, hk = keys.get(band, (None, None))
        sig.append(round(mod[ck], 4) if ck else 0.0)
        sig.append(round(mod[hk], 4) if hk else 0.0)
    return tuple(sig)


def _measure(obj, band_names):
    """For each band vertex group, compute the current (post-deformation)
    average circumference (2pi x weighted-average radial distance from the
    band's XY centroid) and Z height span. Uses the evaluated mesh so the
    readout reflects the actual current shape. Set Position preserves vertex
    count/order, so original vertex-group weights map 1:1 to evaluated verts."""
    results = {}
    depsgraph = bpy.context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(depsgraph)
    mesh = eval_obj.to_mesh()
    try:
        for band_name in band_names:
            vg = obj.vertex_groups.get(band_name)
            if not vg:
                results[band_name] = (0.0, 0.0)
                continue

            weighted = []
            for v in mesh.vertices:
                try:
                    w = vg.weight(v.index)
                except RuntimeError:
                    w = 0.0
                if w > 0.01:
                    weighted.append((v.co.copy(), w))

            if not weighted:
                results[band_name] = (0.0, 0.0)
                continue

            total_w = sum(w for _, w in weighted)
            cx = sum(co.x * w for co, w in weighted) / total_w
            cy = sum(co.y * w for co, w in weighted) / total_w
            avg_radius = sum(
                ((co.x - cx) ** 2 + (co.y - cy) ** 2) ** 0.5 * w
                for co, w in weighted
            ) / total_w
            circ_mm = 2 * math.pi * avg_radius
            zs = [co.z for co, _ in weighted]
            results[band_name] = (round(circ_mm, 1), round(max(zs) - min(zs), 1))
    finally:
        eval_obj.to_mesh_clear()
    return results


def compute_band_measurements(obj, band_names, use_cache=True):
    """Cached wrapper around _measure(): recompute only when a slider moved."""
    sig = _input_signature(obj)
    if use_cache and sig is not None:
        cached = _MEAS_CACHE.get(obj.name)
        if cached and cached[0] == sig:
            return cached[1]
    results = _measure(obj, band_names)
    if sig is not None:
        _MEAS_CACHE[obj.name] = (sig, results)
    return results


def _build_node_group():
    """Construct (once) the Geometry Nodes tree that deforms the socket per
    band: a radial (circumference) scale plus a Z (height) offset, each
    weighted by that band's vertex group, summed across all bands so blended
    boundary vertices get partial contributions from two bands."""
    existing = bpy.data.node_groups.get(NODEGROUP_NAME)
    if existing:
        return existing

    ng = bpy.data.node_groups.new(NODEGROUP_NAME, 'GeometryNodeTree')
    iface = ng.interface

    iface.new_socket(name="Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    iface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    for band in BAND_NAMES:
        c = iface.new_socket(name=circ_socket_name(band), in_out='INPUT',
                             socket_type='NodeSocketFloat')
        c.default_value = 1.0
        c.min_value = 0.5
        c.max_value = 2.0
        h = iface.new_socket(name=height_socket_name(band), in_out='INPUT',
                             socket_type='NodeSocketFloat')
        h.default_value = 0.0
        h.min_value = -100.0
        h.max_value = 100.0

    nodes = ng.nodes
    links = ng.links

    gin = nodes.new('NodeGroupInput')
    gin.location = (-800, 0)
    gout = nodes.new('NodeGroupOutput')
    gout.location = (1200, 0)

    pos = nodes.new('GeometryNodeInputPosition')
    pos.location = (-800, -300)

    # Central long axis = XY centre of the mesh bounding box.
    bb = nodes.new('GeometryNodeBoundBox')
    bb.location = (-800, -500)
    links.new(gin.outputs['Geometry'], bb.inputs['Geometry'])

    minmax = nodes.new('ShaderNodeVectorMath')
    minmax.operation = 'ADD'
    minmax.location = (-600, -500)
    links.new(bb.outputs['Min'], minmax.inputs[0])
    links.new(bb.outputs['Max'], minmax.inputs[1])

    center = nodes.new('ShaderNodeVectorMath')
    center.operation = 'SCALE'
    center.location = (-450, -500)
    center.inputs['Scale'].default_value = 0.5
    links.new(minmax.outputs['Vector'], center.inputs[0])

    # radial = position - center, with Z zeroed (XY plane only).
    radial = nodes.new('ShaderNodeVectorMath')
    radial.operation = 'SUBTRACT'
    radial.location = (-450, -300)
    links.new(pos.outputs['Position'], radial.inputs[0])
    links.new(center.outputs['Vector'], radial.inputs[1])

    sep = nodes.new('ShaderNodeSeparateXYZ')
    sep.location = (-300, -300)
    links.new(radial.outputs['Vector'], sep.inputs[0])

    radial_xy = nodes.new('ShaderNodeCombineXYZ')
    radial_xy.location = (-150, -300)
    links.new(sep.outputs['X'], radial_xy.inputs['X'])
    links.new(sep.outputs['Y'], radial_xy.inputs['Y'])
    # Z input left at 0 -> purely radial in the XY plane.

    prev = None
    x = -150
    for band in BAND_NAMES:
        x += 200
        na = nodes.new('GeometryNodeInputNamedAttribute')
        na.data_type = 'FLOAT'
        na.location = (x, 300)
        na.inputs['Name'].default_value = band
        weight = na.outputs['Attribute']

        # (circ - 1.0) * weight  -> radial scale contribution for this band
        circ_minus = nodes.new('ShaderNodeMath')
        circ_minus.operation = 'SUBTRACT'
        circ_minus.location = (x, 150)
        links.new(gin.outputs[circ_socket_name(band)], circ_minus.inputs[0])
        circ_minus.inputs[1].default_value = 1.0

        circ_w = nodes.new('ShaderNodeMath')
        circ_w.operation = 'MULTIPLY'
        circ_w.location = (x + 60, 80)
        links.new(circ_minus.outputs[0], circ_w.inputs[0])
        links.new(weight, circ_w.inputs[1])

        radial_term = nodes.new('ShaderNodeVectorMath')
        radial_term.operation = 'SCALE'
        radial_term.location = (x + 120, 0)
        links.new(radial_xy.outputs['Vector'], radial_term.inputs[0])
        links.new(circ_w.outputs[0], radial_term.inputs['Scale'])

        # height * weight -> Z offset contribution
        height_w = nodes.new('ShaderNodeMath')
        height_w.operation = 'MULTIPLY'
        height_w.location = (x, -150)
        links.new(gin.outputs[height_socket_name(band)], height_w.inputs[0])
        links.new(weight, height_w.inputs[1])

        height_vec = nodes.new('ShaderNodeCombineXYZ')
        height_vec.location = (x + 60, -220)
        links.new(height_w.outputs[0], height_vec.inputs['Z'])

        band_off = nodes.new('ShaderNodeVectorMath')
        band_off.operation = 'ADD'
        band_off.location = (x + 180, -100)
        links.new(radial_term.outputs['Vector'], band_off.inputs[0])
        links.new(height_vec.outputs['Vector'], band_off.inputs[1])

        if prev is None:
            prev = band_off
        else:
            acc = nodes.new('ShaderNodeVectorMath')
            acc.operation = 'ADD'
            acc.location = (x + 250, -50)
            links.new(prev.outputs['Vector'], acc.inputs[0])
            links.new(band_off.outputs['Vector'], acc.inputs[1])
            prev = acc

    setpos = nodes.new('GeometryNodeSetPosition')
    setpos.location = (1000, 0)
    links.new(gin.outputs['Geometry'], setpos.inputs['Geometry'])
    links.new(prev.outputs['Vector'], setpos.inputs['Offset'])
    links.new(setpos.outputs['Geometry'], gout.inputs['Geometry'])

    return ng


class DynaxBuildParametricRig(Operator):
    """Build (or reuse) the Geometry Nodes modifier that exposes live
    per-band circumference/height controls. Internal — called automatically
    by DynaxLoadParametricTemplate, not normally run directly by the user."""
    bl_idname = "dynax.build_parametric_rig"
    bl_label = "Build Parametric Rig"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No active mesh object")
            return {'CANCELLED'}

        ng = _build_node_group()

        mod = obj.modifiers.get(MODIFIER_NAME)
        if mod is None:
            mod = obj.modifiers.new(MODIFIER_NAME, 'NODES')
        mod.node_group = ng

        self.report({'INFO'}, "Parametric rig ready.")
        return {'FINISHED'}


class DynaxLoadParametricTemplate(Operator):
    """Load the pre-rigged parametric socket template and set up live
    circumference/height sliders. This is the clinician-facing entry point —
    no band creation happens here, bands already exist in the template."""
    bl_idname = "dynax.load_parametric_template"
    bl_label = "New Parametric Socket"
    bl_description = "Load the pre-rigged transfemoral template with adjustable sliders"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        template_path = _get_template_path()

        # Always log the resolved path to the console so silent path failures
        # are immediately visible during testing.
        print(f"[DynaX ParaForge] Template path: {template_path}")
        print(f"[DynaX ParaForge] Path exists: {os.path.exists(template_path)}")

        if not os.path.exists(template_path):
            self.report({'ERROR'},
                f"Template not found: {template_path}\n"
                f"Make sure {TEMPLATE_FILENAME} is in the add-on's "
                f"reference_models/ folder.")
            return {'CANCELLED'}

        # Load the object from the template file.
        with bpy.data.libraries.load(template_path, link=False) as (src, dst):
            if TEMPLATE_MESH_NAME not in src.objects:
                self.report({'ERROR'},
                    f"Object '{TEMPLATE_MESH_NAME}' not found in template. "
                    f"Objects available: {list(src.objects)}")
                return {'CANCELLED'}
            dst.objects = [TEMPLATE_MESH_NAME]

        new_obj = dst.objects[0]
        if new_obj is None:
            self.report({'ERROR'}, "Object failed to load from template file.")
            return {'CANCELLED'}

        # Device-specific name so multiple device types can coexist later
        # without naming collisions.
        new_obj.name = DEVICE_DISPLAY_NAME
        new_obj.data.name = DEVICE_DISPLAY_NAME + "_mesh"

        # ── CRITICAL: link into the active scene collection AND update view ──
        # Without both of these, the object exists in bpy.data but is invisible.
        context.collection.objects.link(new_obj)
        context.view_layer.update()

        # Select + make active so the user can immediately see/interact with it.
        bpy.ops.object.select_all(action='DESELECT')
        new_obj.select_set(True)
        context.view_layer.objects.active = new_obj

        # Frame the object in the viewport so it's centered in view.
        try:
            bpy.ops.view3d.view_selected(use_all_regions=False)
        except Exception:
            pass

        # Verify vertex groups survived the append.
        missing = [b for b in BAND_NAMES if b not in new_obj.vertex_groups]
        if missing:
            self.report({'WARNING'},
                f"Template loaded but missing vertex groups: {missing}. "
                "Parametric sliders for those bands will have no effect.")

        # Build (or reuse) the Geometry Nodes rig.
        bpy.ops.dynax.build_parametric_rig()

        self.report({'INFO'},
            f"Loaded: {DEVICE_DISPLAY_NAME}. Adjust sliders to resize.")
        return {'FINISHED'}


class DynaxPreviewBand(Operator):
    """Show which region this band controls, by entering Weight Paint mode on
    that band's vertex group (uses Blender's own weight visualization — no
    custom overlay)."""
    bl_idname = "dynax.preview_band"
    bl_label = "Show Band Region"
    bl_description = (
        "Switch to Weight Paint view to highlight exactly which part of "
        "the socket this band controls (red = fully controlled, blue = "
        "unaffected). Click '← Back to editing' to return."
    )
    bl_options = {'REGISTER'}

    band_name: StringProperty()

    def execute(self, context):
        obj = context.active_object
        if not obj:
            return {'CANCELLED'}
        vg = obj.vertex_groups.get(self.band_name)
        if vg:
            obj.vertex_groups.active_index = vg.index
        if context.mode != 'WEIGHT_PAINT':
            bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
        context.scene["dynax_previewing_band"] = self.band_name
        return {'FINISHED'}


class DynaxPreviewBandEnd(Operator):
    """Return from band preview (Weight Paint) to Object Mode."""
    bl_idname = "dynax.preview_band_end"
    bl_label = "Back to Object Mode"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        if "dynax_previewing_band" in context.scene:
            del context.scene["dynax_previewing_band"]
        return {'FINISHED'}


class DynaxFinalizeParametricSocket(Operator):
    """Bake the current parametric shape into the mesh so hardware can be
    attached to it. The Component tools read the socket's BASE mesh, not the
    live Geometry-Nodes-deformed result, so the rig must be applied first —
    after this the sliders are gone and the socket is a plain, final mesh."""
    bl_idname = "dynax.finalize_parametric_socket"
    bl_label = "Finalize Shape for Components"
    bl_description = "Apply the parametric shape so a component can be attached (ends slider editing)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "No parametric socket is active")
            return {'CANCELLED'}
        mod = obj.modifiers.get(MODIFIER_NAME)
        if mod is None:
            # No rig to apply — the shape is already baked. Still stamp the flag
            # and the socket key: the panel gates the whole Components section on
            # dynax_paraform_finalized, so returning FINISHED without setting it
            # left the user permanently stuck on a socket that reports "already
            # finalized" but never shows the component tools.
            obj["dynax_paraform_finalized"] = True
            context.scene["dynax_bridge_socket_obj"] = obj.name
            self.report({'INFO'}, "Shape already finalized")
            return {'FINISHED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj
        try:
            bpy.ops.object.modifier_apply(modifier=mod.name)
        except Exception as e:
            self.report({'ERROR'}, f"Could not finalize shape: {e}")
            return {'CANCELLED'}
        obj["dynax_paraform_finalized"] = True
        # Record the socket so the ParaForm panel and DynaxLoadComponent can find
        # it even after a component becomes the active object.
        context.scene["dynax_bridge_socket_obj"] = obj.name
        self.report({'INFO'}, "Shape finalized — you can now attach a component")
        return {'FINISHED'}
