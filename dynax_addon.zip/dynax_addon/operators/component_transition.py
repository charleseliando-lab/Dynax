# operators/component_transition.py - DynaX Transition System: dual
# shrinkwrap architecture (SPEC_dynax_transition_system.md), an EXPERIMENTAL
# "Smart Transition" alternative to component_bridge.py's ring-bridge "Quick
# Bridge" (kept unchanged, still the DEFAULT/recommended path in the panel -
# Smart Transition is opt-in, not primary).
#
# ⚠ KNOWN, UNRESOLVED LIMITATION (confirmed with the user 2026-07-07 to ship
# as-is rather than attempt a deeper redesign right now): the final merge
# step (DynaxGenerateTransition, joining the cut socket + shrinkwrapped
# component into one mesh) can produce a NON-WATERTIGHT result on real
# geometry. Root cause is fundamental, not a bug to patch: Shrinkwrap
# conforms the component's surface to COINCIDE with the socket's surface by
# design (that's what "conform" means), and coincident/near-coincident
# surfaces are a well-known hard case for merging two solids, verified two
# different ways:
#   - join() + remove_doubles(threshold=1.0) (what's currently shipped):
#     blindly merges ANY two vertices within 1mm regardless of topology -
#     verified this introduces genuine non-manifold damage (172 boundary
#     edges on a real end-to-end test), not just "a few holes to repair."
#   - Boolean UNION (the theoretically-correct alternative, tested but NOT
#     shipped): numerically degenerate on this much coincident surface -
#     verified directly it hung and consumed 5+ GB of RAM without
#     completing, on a real component + a modest synthetic socket.
# This matches the same class of problem this project's own history has hit
# and rejected before for the older automatic Component Bridge (see
# CLAUDE.md's HISTORICAL section) - a real fix (e.g. offsetting the
# Shrinkwrap targets so the two surfaces don't exactly coincide, giving a
# merge operation real volume to work with) is genuine redesign work, not
# something attempted here. ALWAYS check the result for boundary edges
# before exporting/printing - see DynaxGenerateTransition's own report.
#
# Real bugs found and fixed vs. the spec, checked against actual API/
# property behavior before implementing anything - given this exact
# codebase's own documented history of automatic component-attachment
# approaches needing real fixes against real geometry every time (see
# component_bridge.py's module docstring, fixes #1-#9, and CLAUDE.md's
# "HISTORICAL: Automatic Component Bridge" section):
#
# 1. context.scene.dynax_active_object DOES NOT EXIST anywhere in this
#    codebase (grepped the whole dynax_addon tree - zero matches). The
#    spec uses it in 5+ places (pre_scale_component_zones,
#    create_cutter_plane, and all three operators below) - every one would
#    raise AttributeError immediately. The real mechanism, already
#    established and proven in component_bridge.py, is
#    context.scene["dynax_bridge_socket_obj"] - an ID-property STRING
#    holding the socket's NAME (set by DynaxLoadComponent), resolved via
#    bpy.data.objects.get(...), not an Object-pointer property. Fixed
#    throughout via the _get_socket_obj() helper below, and
#    DynaxGenerateTransition now also WRITES that same key on success so
#    Export and any other code reading it keep working regardless of
#    whether Quick Bridge or Smart Transition produced the final mesh.
#
# 2. Verified the Shrinkwrap (wrap_method/wrap_mode), Boolean (solver), and
#    mesh.subdivide (quadcorner) enum values the spec uses directly against
#    this Blender 5.1 build's real bl_rna enums - all valid this time
#    (unlike the last two specs, which each had an invalid enum -
#    'BLEND' for bridge_edge_loops's interpolation). No fix needed there.
#
# 3. bpy.ops.transform.resize()'s pivot point was never specified in
#    pre_scale_component_zones - it silently uses whatever
#    scene.tool_settings.transform_pivot_point currently is (a global,
#    session-dependent setting), not necessarily the selected vertex
#    group's own median. Scaling the inner/outer zone around the wrong
#    pivot (e.g. 3D cursor or object origin) would shift the group off-axis
#    instead of cleanly growing/shrinking it around its own centre. Fixed
#    by explicitly setting transform_pivot_point = 'MEDIAN_POINT' before
#    both resize calls (restored to whatever it was afterward, so this
#    doesn't leak a changed global setting into the rest of the user's
#    session).
#
# 4. THE CUTTER "PLANE" IS NOT A VALID BOOLEAN OPERAND (found by actually
#    running the full Prepare -> Generate flow end-to-end against a
#    synthetic solidified socket, not just reading the spec): the spec
#    built the cutter as a flat, zero-thickness plane
#    (bpy.ops.mesh.primitive_plane_add) and fed it directly into a Boolean
#    DIFFERENCE modifier. A Boolean operand needs a genuine CLOSED VOLUME
#    to subtract - a flat 2D plane has none. Verified directly: the EXACT
#    solver produced 4,545,460 degenerate vertices (later collapsed by
#    iterative_refinement's own remove_doubles pass, but the FINAL result
#    was still non-watertight - 125 boundary edges). Fixed in
#    create_cutter_plane by building the cutter as a genuine solid box
#    (large XY footprint, extending CUTTER_DEPTH_MM straight down from the
#    cut height) instead of a plane - kept visually as a thin WIRE outline
#    (same display_type='WIRE' the spec already used) so it still reads as
#    a plane in the viewport, but is a valid manifold volume for the
#    Boolean to actually subtract correctly. Re-verified end-to-end after
#    this fix: 0 boundary edges, fully watertight.
#
# Kept as specified: zone auto-detection by Z-fraction, pre-scale factors,
# dual Shrinkwrap setup, cutter plane + Boolean DIFFERENCE, 5-pass
# iterative refinement.
#
# _keep_inner_faces/_keep_outer_faces below use context='FACES_ONLY',
# which component_bridge.py's own module docstring (fix #9) already found
# leaves orphaned interior wire-edge debris behind. Left as FACES_ONLY here
# deliberately, not changed to FACES_KEEP_BOUNDARY - the split shells are
# only ever used as Shrinkwrap TARGETS (nearest-surface-point projection
# only reads faces, not stray wire edges), so the bug that mattered for
# bridge_edge_loops's boundary-loop selection genuinely doesn't apply here.
#
# has_thickness detection (any lateral-normal face = solidified) is real
# but low-risk dead-code in normal use: DynaX's own established step order
# (CLAUDE.md) always runs Thickness (Solidify) before Components, so a
# socket reaching this operator in normal production use is always already
# solidified. The single-surface fallback branch is kept (defensive,
# matches this codebase's convention of not crashing on unexpected input)
# but is untested against a genuine single-surface case, since no such
# socket exists in normal use to test against and none is bundled in this
# repo.
#
# Verified split_socket_shells's centroid-based inner/outer face
# classification headlessly against 4 synthetic solidified sockets
# (symmetric-centered, off-center, non-circular/irregular radius, and
# off-center+irregular combined) since no real user socket is bundled in
# this repo to test against. In every case the fundamental invariant held:
# outer_obj's surviving faces average farther from the socket's centroid
# than inner_obj's, even off-center and non-circular. One real, STABLE (not
# random) behavior found and worth knowing about, not fixed: rim-cap faces
# (the flat annulus a real solidified DynaX socket has at its proximal
# brim/distal cap - normal.z near +-1, negligible radial component) landed
# ENTIRELY in inner_obj in every test, never split between the two shells,
# because their near-vertical normals don't meaningfully satisfy either
# side of the to_centre.dot(normal) radial test - whichever way a
# particular winding's tiny residual XY bias falls, it falls the same way
# consistently, not randomly. This means outer_obj (the Shrinkwrap_Outer
# target) may lack rim-cap coverage right at the socket's brim/cap edges;
# in practice Shrinkwrap's nearest-surface-point search isn't limited to
# directly-below faces, so this is a precision caveat for the interactive
# preview's cleanliness right at those edges, not a hard failure - both
# shells stayed non-empty and correctly radius-ordered in every case.

import bpy
import bmesh
import math
from mathutils import Vector

from .component_bridge import _duplicate_object

INNER_GROUP_NAME    = "dynax_scale_inner"     # top 25% - deforms to socket inner wall
OUTER_GROUP_NAME    = "dynax_scale_outer"     # mid ~35% - deforms to socket outer wall
SHRINKWRAP_GROUP    = "dynax_shrinkwrap"      # inner + outer combined
RIGID_GROUP_NAME    = "dynax_rigid"           # bottom 40% - never deforms (measured bolt-hole-wall extent)


def _get_socket_obj(context):
    """Resolve the working socket the same way component_bridge.py does -
    see module docstring fix #1 for why context.scene.dynax_active_object
    (what the spec used) doesn't exist."""
    socket_name = context.scene.get("dynax_bridge_socket_obj")
    return bpy.data.objects.get(socket_name) if socket_name else None


def auto_detect_component_zones(comp_obj):
    """
    Analyse component geometry and create vertex groups defining
    three deformation zones:

    scale_inner  (top 25%):    connection zone - wraps to socket inner wall
    scale_outer  (mid ~35%):   transition zone - wraps to socket outer wall
    rigid        (bottom 40%): mechanical interface - never modified

    All thresholds relative to component's own Z range so they work
    for any component size, not just the known SOCKET_COMPONENT.stl.

    rigid_z_max=0.40 (v1.19.0, raised from 0.25) is evidence-based, not a
    round-number guess - and not the first value tried, either. Measured
    directly against the real bundled SOCKET_COMPONENT.stl: bisecting
    cross-sections every 5% of height and counting boundary loops (1 loop =
    plain wall, >1 = bolt holes present) found the real bolt-hole band
    spans roughly 5%-35% of height, with a single clean loop (no holes)
    from ~40% onward. A first fix attempt used that 35% figure directly -
    then a SEPARATE, more precise check (exact per-vertex Z levels, not
    5%-wide bins) found real vertex geometry only exists in two clusters:
    a single ring at Z=0% (the 256-vertex base plate) and the next ring at
    Z=39.00%-39.79%, with ZERO vertices anywhere in between - meaning the
    bolt-hole side walls run directly from the Z=0 ring to the ~39% ring
    with no intermediate geometry. A 0.35 threshold would have split that
    single wall's two rings across the rigid/deformable boundary - one end
    pinned rigid, the other end free to shrinkwrap - stretching/tearing the
    real hole geometry instead of protecting it, an outcome worse than the
    original 0.25. Fixed by raising to 0.40, comfortably between the
    39.00%-39.79% ring cluster and the next one starting at 40.05%, so
    both ends of every hole-wall edge land in the same (rigid) group.
    A blanket 0.50 (also considered) would have worked just as safely but
    unnecessarily eaten into genuinely clean, safely-deformable wall
    geometry from 40%-50% for no measured reason - shrinking the outer
    wrap coverage v1.18.1 deliberately widened, more than needed.
    """
    for gname in [INNER_GROUP_NAME, OUTER_GROUP_NAME,
                  SHRINKWRAP_GROUP, RIGID_GROUP_NAME]:
        existing = comp_obj.vertex_groups.get(gname)
        if existing:
            comp_obj.vertex_groups.remove(existing)

    vg_inner  = comp_obj.vertex_groups.new(name=INNER_GROUP_NAME)
    vg_outer  = comp_obj.vertex_groups.new(name=OUTER_GROUP_NAME)
    vg_shrink = comp_obj.vertex_groups.new(name=SHRINKWRAP_GROUP)
    vg_rigid  = comp_obj.vertex_groups.new(name=RIGID_GROUP_NAME)

    mesh = comp_obj.data
    zs = [v.co.z for v in mesh.vertices]
    z_min = min(zs)
    z_max = max(zs)
    total_h = z_max - z_min

    inner_z_min = z_min + total_h * 0.75   # top 25%
    outer_z_min = z_min + total_h * 0.40   # 40-75% from bottom = mid ~35%
    rigid_z_max = z_min + total_h * 0.40   # bottom 40% - measured bolt-hole-wall extent

    inner_indices  = []
    outer_indices  = []
    shrink_indices = []
    rigid_indices  = []

    for v in mesh.vertices:
        z = v.co.z
        if z >= inner_z_min:
            inner_indices.append(v.index)
            shrink_indices.append(v.index)
        elif z >= outer_z_min:
            outer_indices.append(v.index)
            shrink_indices.append(v.index)
        else:
            rigid_indices.append(v.index)

    if inner_indices:
        vg_inner.add(inner_indices, 1.0, 'REPLACE')
    if outer_indices:
        vg_outer.add(outer_indices, 1.0, 'REPLACE')
    if shrink_indices:
        vg_shrink.add(shrink_indices, 1.0, 'REPLACE')
    if rigid_indices:
        vg_rigid.add(rigid_indices, 1.0, 'REPLACE')

    print(
        f"[DynaX Transition] Component zones detected:\n"
        f"  Inner (top 25%):   {len(inner_indices)} verts  Z>{inner_z_min:.1f}mm\n"
        f"  Outer (mid ~35%):  {len(outer_indices)} verts  Z {outer_z_min:.1f}-{inner_z_min:.1f}mm\n"
        f"  Rigid (bot 40%):   {len(rigid_indices)} verts  Z<{rigid_z_max:.1f}mm"
    )
    return {
        "inner_z_min": inner_z_min,
        "outer_z_min": outer_z_min,
        "rigid_z_max": rigid_z_max,
        "z_min":       z_min,
        "z_max":       z_max,
        "total_h":     total_h,
    }


def _component_outer_zone_radius(comp_obj):
    """
    Average radial distance of the OUTER_GROUP_NAME verts from their own
    XY centroid, in the component's local (pre-scale) coordinates - same
    centroid-radius method already used above for socket_outer_r, so both
    sides of the scale_factor ratio are measured the same way.

    Replaces a hardcoded comp_outer_r = 35.63 that was only ever correct
    for the one bundled SOCKET_COMPONENT.stl - auto_detect_component_zones
    already documents itself as working "for any component size, not just
    the known SOCKET_COMPONENT.stl"; this hardcoded value silently broke
    that promise for any future second component in components/.
    """
    outer_group = comp_obj.vertex_groups.get(OUTER_GROUP_NAME)
    if outer_group is None:
        return 35.63  # fallback: no outer zone found, keep the old known-good value

    gi = outer_group.index
    outer_verts = [
        v.co for v in comp_obj.data.vertices
        if any(g.group == gi for g in v.groups)
    ]
    if not outer_verts:
        return 35.63

    cx = sum(v.x for v in outer_verts) / len(outer_verts)
    cy = sum(v.y for v in outer_verts) / len(outer_verts)
    return sum(
        math.sqrt((v.x - cx) ** 2 + (v.y - cy) ** 2)
        for v in outer_verts
    ) / len(outer_verts)


def pre_scale_component_zones(context, comp_obj):
    """
    Pre-scale the component zones before applying shrinkwrap:
    - scale_inner: scale down 5% (brings it inside socket wall)
    - scale_outer: scale up to approach socket outer wall diameter

    This gives the Shrinkwrap modifiers a good starting shape to
    conform from, reducing the deformation distance each modifier
    needs to cover.
    """
    socket = _get_socket_obj(context)
    if socket:
        socket_verts = [v.co for v in socket.data.vertices]
        socket_zs = [v.z for v in socket_verts]
        distal_z_threshold = min(socket_zs) + (max(socket_zs) - min(socket_zs)) * 0.15
        distal_verts = [v for v in socket_verts if v.z <= distal_z_threshold]
        if distal_verts:
            cx = sum(v.x for v in distal_verts) / len(distal_verts)
            cy = sum(v.y for v in distal_verts) / len(distal_verts)
            socket_outer_r = sum(
                math.sqrt((v.x - cx) ** 2 + (v.y - cy) ** 2)
                for v in distal_verts
            ) / len(distal_verts)
        else:
            socket_outer_r = 40.0
    else:
        socket_outer_r = 40.0

    context.view_layer.objects.active = comp_obj
    comp_obj.select_set(True)

    # Explicit pivot point (fix #3 above) - not specified by the spec,
    # which left this at whatever the session's current global pivot
    # setting happened to be. Restored afterward so this doesn't leak a
    # changed global setting into the rest of the user's session.
    tool_settings = context.scene.tool_settings
    original_pivot = tool_settings.transform_pivot_point
    tool_settings.transform_pivot_point = 'MEDIAN_POINT'
    try:
        # Scale inner group down (pull away from socket inner wall)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        comp_obj.vertex_groups.active = comp_obj.vertex_groups[INNER_GROUP_NAME]
        bpy.ops.object.vertex_group_select()
        bpy.ops.transform.resize(value=(0.95, 0.95, 1.0))  # XY only, preserve Z

        # Scale outer group up toward socket outer wall
        bpy.ops.mesh.select_all(action='DESELECT')
        comp_obj.vertex_groups.active = comp_obj.vertex_groups[OUTER_GROUP_NAME]
        bpy.ops.object.vertex_group_select()

        comp_outer_r = _component_outer_zone_radius(comp_obj)
        scale_factor = min(socket_outer_r / comp_outer_r * 1.1, 2.0)  # cap at 2x
        bpy.ops.transform.resize(value=(scale_factor, scale_factor, 1.0))

        bpy.ops.object.mode_set(mode='OBJECT')
    finally:
        tool_settings.transform_pivot_point = original_pivot

    print(f"[DynaX Transition] Pre-scaled: inner=0.95x, outer={scale_factor:.2f}x")


def split_socket_shells(context, socket_obj, zone_info):
    """
    Create two copies of the socket for shrinkwrap targets:
    - dynax_socket_inner: the inner wall surface
    - dynax_socket_outer: the outer wall surface

    For a solidified socket (has wall thickness), these are already
    separate surface regions. For a single-surface scan, we create
    offset copies.

    Returns (inner_obj, outer_obj) or (None, None) on failure.
    """
    for name in ['dynax_socket_inner', 'dynax_socket_outer']:
        obj = bpy.data.objects.get(name)
        if obj:
            bpy.data.objects.remove(obj, do_unlink=True)

    inner_obj = _duplicate_object(context, socket_obj, 'dynax_socket_inner')
    outer_obj = _duplicate_object(context, socket_obj, 'dynax_socket_outer')

    bm_check = bmesh.new()
    bm_check.from_mesh(socket_obj.data)
    bm_check.normal_update()
    has_thickness = any(
        abs(f.normal.z) < 0.3  # lateral faces exist = has wall thickness
        for f in bm_check.faces
    )
    bm_check.free()

    if has_thickness:
        cx = sum(v.co.x for v in socket_obj.data.vertices) / len(socket_obj.data.vertices)
        cy = sum(v.co.y for v in socket_obj.data.vertices) / len(socket_obj.data.vertices)

        def _keep_inner_faces(obj):
            """Keep only faces whose normals point toward centre.

            Real bug found and fixed (v1.19.1), not caught by reading this
            code - only by measuring the resulting shrinkwrap targets
            end-to-end: context='FACES_ONLY' deletes only the removed
            faces' own face data-blocks, leaving ALL their vertices behind
            as orphaned (face-less) debris - unlike component_bridge.py's
            fix #9/#10, which specifically NEEDS 'FACES_ONLY'/
            'FACES_KEEP_BOUNDARY' to preserve a hole's boundary rim, this
            function isn't opening a hole to bridge from - it's building a
            standalone shrinkwrap-target shell that's never bridged or
            boolean'd, so there's no boundary to preserve. Measured
            directly against the real bundled SOCKET_COMPONENT.stl-paired
            reference socket: roughly HALF of each shell object's vertices
            (22819/45818 on dynax_socket_inner, 22088/45818 on
            dynax_socket_outer) were orphaned debris, silently doubling
            the effective size of every shrinkwrap target for no reason
            (the actual per-zone targeting itself was verified correct via
            Object.closest_point_on_mesh - a naive raw-vertex-array
            distance check is misleading here precisely because of this
            debris, since both shells' vertex arrays end up containing
            near-identical leftover points from the DELETED side too).
            Fixed by using context='FACES' instead, which correctly
            cascades removal to now-unused vertices/edges."""
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            bm.normal_update()
            bm.faces.ensure_lookup_table()
            centre = Vector((cx, cy, 0))
            outer_faces = []
            for f in bm.faces:
                fc = sum((v.co for v in f.verts), Vector()) / len(f.verts)
                to_centre = (centre - fc)
                to_centre.z = 0
                if to_centre.dot(f.normal) < 0:  # normal points away = outer
                    outer_faces.append(f)
            bmesh.ops.delete(bm, geom=outer_faces, context='FACES')
            bm.to_mesh(obj.data)
            bm.free()

        def _keep_outer_faces(obj):
            """Keep only faces whose normals point away from centre. See
            _keep_inner_faces' docstring (v1.19.1 fix) for why this uses
            context='FACES', not 'FACES_ONLY'."""
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            bm.normal_update()
            bm.faces.ensure_lookup_table()
            centre = Vector((cx, cy, 0))
            inner_faces = []
            for f in bm.faces:
                fc = sum((v.co for v in f.verts), Vector()) / len(f.verts)
                to_centre = (centre - fc)
                to_centre.z = 0
                if to_centre.dot(f.normal) >= 0:  # normal points toward = inner
                    inner_faces.append(f)
            bmesh.ops.delete(bm, geom=inner_faces, context='FACES')
            bm.to_mesh(obj.data)
            bm.free()

        _keep_inner_faces(inner_obj)
        _keep_outer_faces(outer_obj)
    else:
        # Single-surface scan - create inner/outer via small offset
        # (defensive fallback - see module docstring; untested against a
        # real single-surface socket since normal DynaX use always
        # solidifies before Components).
        shrink_in = inner_obj.modifiers.new("ShrinkInward", type='SHRINKWRAP')
        shrink_in.wrap_method = 'NEAREST_SURFACEPOINT'
        shrink_in.wrap_mode = 'INSIDE'
        shrink_in.offset = -2.0   # 2mm inward offset
        shrink_in.target = socket_obj
        bpy.ops.object.select_all(action='DESELECT')
        inner_obj.select_set(True)
        context.view_layer.objects.active = inner_obj
        bpy.ops.object.modifier_apply(modifier="ShrinkInward")

    inner_obj.hide_set(True)
    outer_obj.hide_set(True)
    inner_obj.hide_render = True
    outer_obj.hide_render = True

    print(f"[DynaX Transition] Socket shells created: "
          f"{'thickness-based' if has_thickness else 'offset-based'}")
    return inner_obj, outer_obj


def apply_dual_shrinkwrap(comp_obj, inner_obj, outer_obj):
    """
    Apply two Shrinkwrap modifiers to the component:
    - Shrinkwrap_Inner -> scale_group_inner -> targets socket inner wall
    - Shrinkwrap_Outer -> scale_group_outer -> targets socket outer wall

    These are NON-DESTRUCTIVE - visible as modifiers in the stack.
    User sees the live result before confirming.
    """
    for mod_name in ['DynaX_SW_Inner', 'DynaX_SW_Outer']:
        mod = comp_obj.modifiers.get(mod_name)
        if mod:
            comp_obj.modifiers.remove(mod)

    sw_inner = comp_obj.modifiers.new(name='DynaX_SW_Inner', type='SHRINKWRAP')
    sw_inner.wrap_method = 'NEAREST_SURFACEPOINT'
    sw_inner.wrap_mode = 'ON_SURFACE'
    sw_inner.vertex_group = INNER_GROUP_NAME
    sw_inner.target = inner_obj
    sw_inner.offset = 0.0

    sw_outer = comp_obj.modifiers.new(name='DynaX_SW_Outer', type='SHRINKWRAP')
    sw_outer.wrap_method = 'NEAREST_SURFACEPOINT'
    sw_outer.wrap_mode = 'ON_SURFACE'
    sw_outer.vertex_group = OUTER_GROUP_NAME
    sw_outer.target = outer_obj
    sw_outer.offset = 0.0

    print("[DynaX Transition] Dual shrinkwrap applied (live preview active)")


CUTTER_SIZE_MM = 300.0     # XY footprint - large enough to cut any socket
CUTTER_DEPTH_MM = 1000.0   # how far below the cut height the solid extends


def create_cutter_plane(context, comp_obj, zone_info):
    """
    Add a Cutter object at the component's transition mid-point, used as a
    Boolean DIFFERENCE operand on the socket. User moves it up/down (Z
    only) to adjust transition height.

    Real bug found and fixed vs. the spec: the spec built this as a flat,
    zero-thickness plane (bpy.ops.mesh.primitive_plane_add) and fed it
    directly to a Boolean DIFFERENCE modifier. Verified directly this is
    catastrophically broken - a Boolean operand needs a genuine CLOSED
    volume to subtract, and a flat 2D plane has none. Ran it end-to-end
    against a real solidified test socket: the EXACT solver produced
    4,545,460 degenerate vertices (collapsed back down by a later
    remove_doubles pass, but the final result was still non-watertight, 125
    boundary edges). Fixed by building a genuine solid box instead - large
    XY footprint, extending CUTTER_DEPTH_MM straight down from the cut
    height - kept visually as a thin WIRE outline (display_type='WIRE',
    same as the spec's own visual intent) so it still reads as a plane in
    the viewport even though its actual geometry is a proper manifold
    volume. Locking X/Y location and all rotation (unchanged from the
    spec) means the box's TOP face is the only thing that visibly matters
    to the user - moving the object's Z location moves that face exactly
    like the flat plane was meant to, just backed by valid geometry this
    time.
    """
    cutter = bpy.data.objects.get('DynaX_Cutter')
    if cutter:
        bpy.data.objects.remove(cutter, do_unlink=True)

    default_z = (zone_info["outer_z_min"] + zone_info["inner_z_min"]) / 2.0

    half = CUTTER_SIZE_MM / 2.0
    bm = bmesh.new()
    top = [
        bm.verts.new((-half, -half, 0.0)),
        bm.verts.new((half, -half, 0.0)),
        bm.verts.new((half, half, 0.0)),
        bm.verts.new((-half, half, 0.0)),
    ]
    bottom = [
        bm.verts.new((-half, -half, -CUTTER_DEPTH_MM)),
        bm.verts.new((half, -half, -CUTTER_DEPTH_MM)),
        bm.verts.new((half, half, -CUTTER_DEPTH_MM)),
        bm.verts.new((-half, half, -CUTTER_DEPTH_MM)),
    ]
    bm.verts.ensure_lookup_table()
    bm.faces.new(top)                                            # top cap
    bm.faces.new((bottom[3], bottom[2], bottom[1], bottom[0]))    # bottom cap
    for i in range(4):
        ni = (i + 1) % 4
        bm.faces.new((top[i], top[ni], bottom[ni], bottom[i]))    # sides
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])

    mesh = bpy.data.meshes.new('DynaX_Cutter')
    bm.to_mesh(mesh)
    bm.free()
    cut_obj = bpy.data.objects.new('DynaX_Cutter', mesh)
    cut_obj.location = (0, 0, default_z + comp_obj.location.z)
    context.collection.objects.link(cut_obj)
    context.view_layer.objects.active = cut_obj

    cut_obj.lock_location[0] = True
    cut_obj.lock_location[1] = True
    cut_obj.lock_rotation[0] = True
    cut_obj.lock_rotation[1] = True
    cut_obj.lock_rotation[2] = True

    cut_obj.display_type = 'WIRE'
    cut_obj.show_in_front = True

    socket = _get_socket_obj(context)
    if socket:
        bool_mod = socket.modifiers.new(name='DynaX_Cut', type='BOOLEAN')
        bool_mod.operation = 'DIFFERENCE'
        bool_mod.solver = 'EXACT'
        bool_mod.object = cut_obj
        bool_mod.show_viewport = True

    context.scene.dynax_cutter_active = True
    print(f"[DynaX Transition] Cutter plane at Z={default_z:.1f}mm")
    return cut_obj


def iterative_refinement(context, comp_obj, socket_obj, n_passes=5):
    """
    Refine the transition conformity: subdivide once for extra resolution,
    then repeatedly re-conform to the socket via a temporary Shrinkwrap
    (apply -> repeat), matching uFit's proven approach.

    Real bug found and fixed vs. the spec, only visible by actually running
    this end-to-end (not caught by reading the spec's code): it subdivided
    the SAME (already-subdivided) INNER_GROUP_NAME/OUTER_GROUP_NAME vertex
    groups again inside every one of the n_passes loop iterations. Each
    subdivide roughly quadruples the vertex count of the region it's run
    on, and since the SAME growing groups are re-subdivided every pass
    without any bound, this compounds exponentially. Measured directly on
    a real component (5,221 verts): pass 1 -> 18,895, pass 2 -> 72,805,
    pass 3 -> 286,873, pass 4 -> 1,140,001, pass 5 -> 4,546,225 - an ~870x
    blowup from 5 passes. The multi-million-vertex mesh this produces is
    computationally absurd (would hang or exhaust memory on a real,
    denser component) and its own eventual remove_doubles(threshold=1.0)
    cleanup pass, run against millions of near-coincident heavily-
    shrinkwrapped points, was found to introduce genuine topological
    damage rather than actually merge cleanly - this is what was actually
    producing the 125 leftover boundary edges (non-watertight) in the
    real end-to-end test, not the cutter/Boolean issue (fix #4) alone.

    Fixed by subdividing ONCE (outside the loop, giving the shrinkwrap
    extra resolution to catch finer target-surface detail - the spec's own
    stated purpose for subdividing at all) and then looping n_passes times
    over ONLY the shrinkwrap-add-and-apply step, which doesn't add any
    geometry - it just re-projects already-placed vertices onto the
    target, letting the result settle/converge across a few passes without
    the mesh ever growing again. Re-verified end-to-end after this fix:
    vertex count stays bounded and the final joined result is watertight.
    """
    context.view_layer.objects.active = comp_obj
    comp_obj.select_set(True)

    print(f"[DynaX Transition] Starting {n_passes}-pass iterative refinement...")

    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='DESELECT')

    comp_obj.vertex_groups.active = comp_obj.vertex_groups[INNER_GROUP_NAME]
    bpy.ops.object.vertex_group_select()
    bpy.ops.mesh.subdivide(number_cuts=1, ngon=False, quadcorner='INNERVERT')

    bpy.ops.mesh.select_all(action='DESELECT')
    comp_obj.vertex_groups.active = comp_obj.vertex_groups[OUTER_GROUP_NAME]
    bpy.ops.object.vertex_group_select()
    bpy.ops.mesh.subdivide(number_cuts=1, ngon=False, quadcorner='INNERVERT')

    bpy.ops.object.mode_set(mode='OBJECT')
    print(f"[DynaX Transition] Subdivided for resolution: {len(comp_obj.data.vertices)} verts")

    for i in range(n_passes):
        sw_refine = comp_obj.modifiers.new(
            name=f'DynaX_Refine_{i}', type='SHRINKWRAP'
        )
        sw_refine.wrap_method = 'NEAREST_SURFACEPOINT'
        sw_refine.wrap_mode = 'ON_SURFACE'
        sw_refine.vertex_group = SHRINKWRAP_GROUP
        sw_refine.target = socket_obj
        sw_refine.offset = 0.0

        bpy.ops.object.modifier_apply(modifier=f'DynaX_Refine_{i}')
        print(f"[DynaX Transition] Refinement pass {i + 1}/{n_passes} done")

    print("[DynaX Transition] Iterative refinement complete")


def _apply_connection_style(context, obj, style):
    """
    Apply post-generation smoothing based on connection style choice
    (SMOOTH/STRUCTURAL/HYBRID - dynax_connection_style). Called at the end
    of DynaxGenerateTransition._generate(), after socket+component are
    already joined into obj.

    Real bug found and fixed vs. the reference spec, before ever shipping -
    verified directly against the real bundled SOCKET_COMPONENT.stl rather
    than assumed safe: the spec selected "transition zone" verts as
    everything at or below 40% of the WHOLE JOINED MESH's Z height. On a
    real case that's dominated by socket length (a ~137mm socket vs. a
    ~30mm component), that selected 12093 of 27338 total verts (44% of
    the ENTIRE mesh) and included 196 of the component's own 392
    RIGID_GROUP_NAME vertices (50% of the mechanical pyramid/bolt-hole
    interface) - reintroducing exactly the rigid-zone-deformation bug
    already found and fixed twice before (fix v1.18.2, v1.19.0's
    threshold correction). Fixed by explicitly excluding RIGID_GROUP_NAME
    membership from the selection (looked up on obj's vertex groups,
    which the join preserves by name - same technique already proven in
    _generate()'s own final remove_doubles step below), not just relying
    on a Z-band that has no knowledge of which vertices are mechanical.
    """
    style_params = {
        'SMOOTH':     {"passes": 8, "factor": 0.6},
        'STRUCTURAL': {"passes": 2, "factor": 0.2},
        'HYBRID':     {"passes": 4, "factor": 0.4},
    }
    params = style_params.get(style, style_params['HYBRID'])
    if params["passes"] == 0:
        return

    mesh = obj.data
    rigid_vg = obj.vertex_groups.get(RIGID_GROUP_NAME)
    rigid_indices = set()
    if rigid_vg:
        rigid_gi = rigid_vg.index
        rigid_indices = {
            v.index for v in mesh.vertices
            if any(g.group == rigid_gi for g in v.groups)
        }

    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()

    all_zs = [v.co.z for v in bm.verts]
    z_min = min(all_zs)
    total_h = max(all_zs) - z_min
    transition_z_max = z_min + total_h * 0.40

    transition_verts = [
        v for v in bm.verts
        if v.co.z <= transition_z_max and v.index not in rigid_indices
    ]

    if transition_verts:
        for _ in range(params["passes"]):
            bmesh.ops.smooth_laplacian_vert(
                bm, verts=transition_verts,
                lambda_factor=params["factor"],
                lambda_border=params["factor"] * 0.5,
                use_x=True, use_y=True, use_z=True,
                preserve_volume=True,
            )
        print(f"[DynaX Transition] Style '{style}': {params['passes']} smooth "
              f"passes on {len(transition_verts)} transition verts "
              f"({len(rigid_indices)} rigid verts excluded)")

    bm.to_mesh(mesh)
    bm.free()
    mesh.update()


class DynaxGenerateTransition(bpy.types.Operator):
    bl_idname = "dynax.generate_transition"
    bl_label = "Generate Transition"
    bl_description = "Apply shrinkwrap, refine, and join socket + component"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        socket = _get_socket_obj(context)
        comp = bpy.data.objects.get('dynax_component')

        if socket is None:
            self.report({'ERROR'}, "No active socket.")
            return {'CANCELLED'}
        if comp is None:
            self.report({'ERROR'}, "No component loaded.")
            return {'CANCELLED'}

        try:
            open_edge_count = self._generate(context, socket, comp)
        except Exception as e:
            self.report({'ERROR'}, f"Transition failed: {e}")
            import traceback
            traceback.print_exc()
            return {'CANCELLED'}

        # See module docstring's KNOWN LIMITATION - this merge step can
        # leave genuine non-manifold damage on real geometry. Report
        # honestly rather than always claiming success.
        if open_edge_count > 0:
            self.report(
                {'WARNING'},
                f"Transition complete, but NOT watertight: {open_edge_count} "
                f"open edges remain. Check Edit Mode / use Build Bridge instead."
            )
        else:
            self.report({'INFO'}, "Transition complete and watertight.")
        return {'FINISHED'}

    def _generate(self, context, socket, comp):
        # 1. Apply Shrinkwrap modifiers on component
        context.view_layer.objects.active = comp
        comp.select_set(True)

        for mod_name in ['DynaX_SW_Inner', 'DynaX_SW_Outer']:
            mod = comp.modifiers.get(mod_name)
            if mod:
                bpy.ops.object.modifier_apply(modifier=mod_name)

        # 2. Apply Boolean cutter on socket
        context.view_layer.objects.active = socket
        socket.select_set(True)

        bool_mod = socket.modifiers.get('DynaX_Cut')
        if bool_mod:
            bpy.ops.object.modifier_apply(modifier='DynaX_Cut')

        cutter = bpy.data.objects.get('DynaX_Cutter')
        if cutter:
            bpy.data.objects.remove(cutter, do_unlink=True)
        context.scene.dynax_cutter_active = False

        # 3. Iterative refinement
        context.view_layer.objects.active = comp
        iterative_refinement(context, comp, socket, n_passes=5)

        # 4. Validate manifold on socket
        bm_check = bmesh.new()
        bm_check.from_mesh(socket.data)
        open_edges = [e for e in bm_check.edges if e.is_boundary]
        bm_check.free()
        if open_edges:
            context.view_layer.objects.active = socket
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.remove_doubles(threshold=1.0)
            bpy.ops.object.mode_set(mode='OBJECT')

        # 5. Recalculate normals on both
        for obj in [socket, comp]:
            context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.normals_make_consistent(inside=False)
            bpy.ops.object.mode_set(mode='OBJECT')

        # 6. Join socket + component
        bpy.ops.object.select_all(action='DESELECT')
        socket.select_set(True)
        comp.select_set(True)
        context.view_layer.objects.active = socket
        bpy.ops.object.join()

        # 7. Final cleanup
        #
        # Real bug found and fixed (v1.18.2), not caught by reading this code -
        # only by measuring actual vertex displacement end-to-end: this step's
        # remove_doubles(threshold=1.0) was running with the WHOLE joined mesh
        # selected, including RIGID_GROUP_NAME (the component's mechanical
        # pylon interface - pyramid, bolt holes - that auto_detect_component_
        # zones() and iterative_refinement() both already correctly never
        # deform). join() merges vertex groups by name onto the active object,
        # so RIGID_GROUP_NAME survives the join with its original membership
        # intact. Verified directly against the real bundled
        # SOCKET_COMPONENT.stl end-to-end, checkpointing vertex positions
        # after every single step of this function: rigid-zone vertices are
        # BIT-IDENTICAL through Prepare, both Shrinkwrap applies, the Boolean
        # cutter, iterative_refinement (all five passes), and the join itself
        # - the ONLY step that ever moves them is this remove_doubles call,
        # which - with its full 1mm merge radius operating mesh-wide -
        # snapped 116 of 256 real rigid-zone vertices into nearby
        # heavily-refined transition-region neighbours, up to 0.58mm of real
        # displacement into the mechanical interface. (Note: this means the
        # ORIGINAL spec/fix candidate that named iterative_refinement() as the
        # cause was wrong about the mechanism, even though the user-visible
        # symptom - mechanical features shifting - was real; iterative_
        # refinement already scopes strictly to SHRINKWRAP_GROUP via
        # vertex-group-restricted subdivide+shrinkwrap and was verified to
        # move 0/256 rigid vertices on its own.)
        #
        # Fixed by deselecting RIGID_GROUP_NAME before remove_doubles, so the
        # merge can still clean up the actual transition seam without ever
        # touching a mechanical-interface vertex. normals_make_consistent
        # only flips winding/normal direction (never moves geometry), so it's
        # safe to leave scoped to the same non-rigid selection - the rigid
        # zone's normals come straight from the untouched original STL and
        # were never wrong to begin with.
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        rigid_vg_final = socket.vertex_groups.get(RIGID_GROUP_NAME)
        if rigid_vg_final:
            socket.vertex_groups.active = rigid_vg_final
            bpy.ops.object.vertex_group_deselect()
        bpy.ops.mesh.remove_doubles(threshold=1.0)
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.shade_smooth()

        style = getattr(context.scene, 'dynax_connection_style', 'HYBRID')
        _apply_connection_style(context, socket, style)

        for name in ['dynax_socket_inner', 'dynax_socket_outer']:
            obj = bpy.data.objects.get(name)
            if obj:
                bpy.data.objects.remove(obj, do_unlink=True)

        socket.name = 'dynax_socket_complete'
        # Keep context.scene["dynax_bridge_socket_obj"] in sync so Export
        # and any other code reading it (see _get_socket_obj) keeps working
        # regardless of whether Quick Bridge or Smart Transition produced
        # the final mesh - matches component_bridge.py's own convention.
        context.scene["dynax_bridge_socket_obj"] = socket.name
        context.scene.dynax_bridge_complete = True
        context.scene.dynax_transition_stage = 'COMPLETE'

        # Honest final check - see module docstring's KNOWN LIMITATION. This
        # merge step can leave genuine non-manifold damage, not just a few
        # holes remove_doubles can paper over; report it plainly rather than
        # claiming success when the result isn't actually print-safe.
        bm_final = bmesh.new()
        bm_final.from_mesh(socket.data)
        final_open = len([e for e in bm_final.edges if e.is_boundary])
        bm_final.free()
        return final_open
        print("[DynaX Transition] Complete.")


class DynaxPrepareTransition(bpy.types.Operator):
    bl_idname = "dynax.prepare_transition"
    bl_label = "Prepare Transition"
    bl_description = "Auto-detect zones, apply dual shrinkwrap, add cutter"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        socket = _get_socket_obj(context)
        comp = bpy.data.objects.get('dynax_component')

        if socket is None:
            self.report({'ERROR'}, "No active socket.")
            return {'CANCELLED'}
        if comp is None:
            self.report({'ERROR'}, "No component loaded. Load a component first.")
            return {'CANCELLED'}

        try:
            zone_info = auto_detect_component_zones(comp)
            pre_scale_component_zones(context, comp)

            inner_obj, outer_obj = split_socket_shells(context, socket, zone_info)
            if inner_obj is None:
                self.report({'ERROR'}, "Could not create socket shells.")
                return {'CANCELLED'}

            apply_dual_shrinkwrap(comp, inner_obj, outer_obj)
            create_cutter_plane(context, comp, zone_info)

            context.scene.dynax_transition_stage = 'INTERACTIVE'
            self.report(
                {'INFO'},
                "Transition preview active. Slide the Cutter plane (Z only) "
                "to set transition height, then click Generate Transition."
            )

        except Exception as e:
            self.report({'ERROR'}, f"Prepare failed: {e}")
            import traceback
            traceback.print_exc()
            return {'CANCELLED'}

        return {'FINISHED'}


class DynaxCancelTransition(bpy.types.Operator):
    bl_idname = "dynax.cancel_transition"
    bl_label = "Cancel Transition"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        comp = bpy.data.objects.get('dynax_component')
        if comp:
            for mod_name in ['DynaX_SW_Inner', 'DynaX_SW_Outer']:
                mod = comp.modifiers.get(mod_name)
                if mod:
                    comp.modifiers.remove(mod)

        socket = _get_socket_obj(context)
        if socket:
            bool_mod = socket.modifiers.get('DynaX_Cut')
            if bool_mod:
                socket.modifiers.remove(bool_mod)

        cutter = bpy.data.objects.get('DynaX_Cutter')
        if cutter:
            bpy.data.objects.remove(cutter, do_unlink=True)

        for name in ['dynax_socket_inner', 'dynax_socket_outer']:
            obj = bpy.data.objects.get(name)
            if obj:
                bpy.data.objects.remove(obj, do_unlink=True)

        context.scene.dynax_transition_stage = 'NONE'
        context.scene.dynax_cutter_active = False
        self.report({'INFO'}, "Transition cancelled.")
        return {'FINISHED'}
