# operators/paramold/mold_trim.py - ParaMold Stage "Trim": optional cut
# plane + sculpt-mode shortcut, run on the finger scan BEFORE Generate.

import bpy


class DynaxMoldAddCutPlane(bpy.types.Operator):
    """Add a positionable cut plane above the active object"""
    bl_idname = "dynax.mold_add_cut_plane"
    bl_label = "Add Cut Plane"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select the finger scan first")
            return {'CANCELLED'}

        bpy.ops.mesh.primitive_plane_add(
            size=obj.dimensions.x * 2,
            location=(
                obj.location.x,
                obj.location.y,
                obj.location.z + obj.dimensions.z * 0.3,
            ),
        )
        cut_plane = context.active_object
        cut_plane.name = "DynaX_CutPlane"
        cut_plane.display_type = 'WIRE'
        # Remember which mesh this plane is meant to cut, rather than
        # relying on selection state at Apply-Cut time (the add operator
        # above deselects everything except the new plane, so guessing
        # from "whatever else is currently selected" is fragile UX).
        cut_plane["dynax_mold_cut_target"] = obj.name

        self.report(
            {'INFO'},
            "Move and rotate the cut plane, then click Apply Cut",
        )
        return {'FINISHED'}


class DynaxMoldApplyCut(bpy.types.Operator):
    """Bisect the finger scan along the cut plane's Z height, discarding
    whatever is above it"""
    bl_idname = "dynax.mold_apply_cut"
    bl_label = "Apply Cut"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        cut_plane = bpy.data.objects.get("DynaX_CutPlane")
        if not cut_plane:
            self.report({'ERROR'}, "No cut plane found. Add one first.")
            return {'CANCELLED'}

        target_name = cut_plane.get("dynax_mold_cut_target")
        scan = bpy.data.objects.get(target_name) if target_name else None
        if scan is None:
            # Fall back to the spec's own selection-based lookup, for a cut
            # plane created by anything other than DynaxMoldAddCutPlane.
            for obj in bpy.data.objects:
                if (obj.type == 'MESH' and obj.name != "DynaX_CutPlane"
                        and obj.select_get()):
                    scan = obj
                    break
        if scan is None:
            self.report({'ERROR'}, "Select the finger scan mesh first")
            return {'CANCELLED'}

        cut_plane_location = cut_plane.location.z
        direction = context.scene.dynax_mold_cut_direction

        bpy.ops.object.select_all(action='DESELECT')
        scan.select_set(True)
        context.view_layer.objects.active = scan
        bpy.ops.object.mode_set(mode='EDIT')

        # Guard (clinical-testing fix): confirm mesh.bisect can actually run
        # in this context before calling it, rather than letting a raw
        # RuntimeError surface to the clinician if EDIT mode didn't
        # genuinely take (e.g. scan has no mesh data, or mode_set silently
        # no-opped in some restricted context).
        if not bpy.ops.mesh.bisect.poll():
            bpy.ops.object.mode_set(mode='OBJECT')
            self.report({'ERROR'}, "Cannot cut - the scan mesh isn't in a valid state to edit")
            return {'CANCELLED'}

        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.bisect(
            plane_co=(0, 0, cut_plane_location),
            plane_no=(0, 0, 1),
            use_fill=True,
            clear_outer=(direction == 'KEEP_LOWER'),
            clear_inner=(direction == 'KEEP_UPPER'),
        )
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.data.objects.remove(cut_plane)

        # Clinical-testing fix: explicitly re-establish the scan as the
        # active AND selected object after the cut - the reported "sends
        # users back to Stage 1" symptom traced to the ParaMold panel's
        # stage detection reading context.active_object fresh on every
        # redraw, which can disagree with what this operator left active if
        # anything (a later click, a different area/window) changes it
        # before the next redraw. Also stamps a persistent
        # "dynax_mold_processed" marker so stage detection has a second,
        # independent signal beyond DYNAX_MOLD_ALIGNED.
        context.view_layer.objects.active = scan
        scan.select_set(True)
        scan["dynax_mold_processed"] = True

        self.report({'INFO'}, "Cut applied.")
        return {'FINISHED'}


class DynaxMoldEnterSculpt(bpy.types.Operator):
    """Enter Sculpt Mode on the finger scan to refine surface detail"""
    bl_idname = "dynax.mold_enter_sculpt"
    bl_label = "Enter Sculpt Mode"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select the finger scan first")
            return {'CANCELLED'}
        context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='SCULPT')
        self.report(
            {'INFO'},
            "Sculpt mode active. Use brushes to refine surface. Press Tab "
            "when done to return.",
        )
        return {'FINISHED'}
