# operators/paramold/mold_generator.py - ParaMold Stages 2-5: mold box,
# registration keys, pour/vent channels, undercut check, volume, export.
#
# "Lite" scope (per the ParaMold spec): a single automatic pass per stage,
# no manual re-editing of the split/keys/channels once generated. Follows
# this add-on's established boolean conventions (EXACT solver first, applied
# via modifier_apply - see export_stl.py / component_bridge.py / manual_
# bridge.py for the same pattern elsewhere in this codebase).

import bpy
import bmesh
import contextlib
import os
import struct
from mathutils import Vector
from mathutils.bvhtree import BVHTree


@contextlib.contextmanager
def _undo_group(context, message):
    """Clinical-testing fix: group everything an operator does inside this
    `with` block into exactly ONE undo step, instead of however many
    separate steps its internal bpy.ops.* calls (duplicate, modifier_apply,
    etc.) would otherwise each push onto Blender's global undo stack on
    their own. Reported bug this fixes: a single Ctrl+Z after "Apply Keys"
    only reverted the LAST internal call (e.g. just one modifier_apply),
    not the whole click - leaving Half A and Half B in a genuinely
    inconsistent, partially-processed state (a key's bump baked into one
    half with no matching cut, or vice versa), which then produced garbled
    results on the NEXT Apply Keys run against that already-corrupted
    state. Standard Blender scripting technique: temporarily disable
    automatic per-operator undo pushing, do all the work, then push exactly
    one combined undo step covering the whole operation."""
    prefs = context.preferences.edit
    was_global_undo = prefs.use_global_undo
    prefs.use_global_undo = False
    try:
        yield
    finally:
        prefs.use_global_undo = was_global_undo
        bpy.ops.ed.undo_push(message=message)


# ── Geometry helpers ─────────────────────────────────────────────────────

def _world_bounds(context, obj):
    """Evaluated (post-modifier) world-space bounding box min/max."""
    depsgraph = context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(depsgraph)
    mesh = eval_obj.to_mesh()
    coords = [obj.matrix_world @ v.co for v in mesh.vertices]
    eval_obj.to_mesh_clear()
    min_co = Vector((min(c.x for c in coords), min(c.y for c in coords), min(c.z for c in coords)))
    max_co = Vector((max(c.x for c in coords), max(c.y for c in coords), max(c.z for c in coords)))
    return min_co, max_co


def _boolean_apply(context, target_obj, cutter_obj, operation, keep_cutter=False):
    """Add + apply a Boolean modifier on target_obj against cutter_obj.
    EXACT solver first (this codebase's established convention). Clinical-
    testing note: this Blender build's BooleanModifier.solver enum is
    {'FLOAT', 'EXACT', 'MANIFOLD'} - there is no 'FAST' option here despite
    the ParaMold fix spec offering it as an alternative; EXACT is the valid
    member of that either/or.

    Real bug found during clinical-testing verification: EXACT silently
    produced a completely EMPTY mesh (0 vertices, no exception raised) when
    UNIONing a small sphere against the mold-box-half - a manifold, valid
    solid that had already been through two prior booleans/a bisect. This
    is the same class of "EXACT struggles with compounded/near-coincident
    boolean history" failure this codebase has hit and fixed before (see
    export_stl.py's EXACT-then-FLOAT convention, component_bridge.py's
    `_merge_all`). Fixed the same way: snapshot the mesh, try EXACT,
    validate the result is non-empty; if not, restore and retry with FLOAT;
    if that also fails, restore the original mesh and report failure so the
    caller can skip that feature rather than silently losing the object.

    Second bug found later, on a DIFFERENCE (not UNION) against a half that
    had already had keys/base-plate JOINED onto it: both solvers "succeeded"
    (non-empty result) but produced a mesh collapsed down to roughly the
    cutter's own size - a correct DIFFERENCE removes a small local bite, it
    can't shrink the target's overall bounding box by half. Added a bbox-
    diagonal sanity check (>= 60% of the pre-op diagonal) alongside the
    non-empty check for DIFFERENCE, since "non-empty" alone doesn't catch a
    wrong-but-plausible-looking result."""
    def _bbox_diagonal(obj):
        coords = [v.co for v in obj.data.vertices]
        if not coords:
            return 0.0
        min_c = Vector((min(c.x for c in coords), min(c.y for c in coords), min(c.z for c in coords)))
        max_c = Vector((max(c.x for c in coords), max(c.y for c in coords), max(c.z for c in coords)))
        return (max_c - min_c).length

    def _attempt(solver_name, pre_diagonal, pre_vert_count):
        mod = target_obj.modifiers.new(name="DYNAX_MOLD_BOOL", type='BOOLEAN')
        mod.operation = operation
        mod.object = cutter_obj
        try:
            mod.solver = solver_name
        except (TypeError, AttributeError):
            pass
        context.view_layer.objects.active = target_obj
        try:
            bpy.ops.object.modifier_apply(modifier=mod.name)
        except Exception:
            try:
                target_obj.modifiers.remove(mod)
            except Exception:
                pass
            return False
        if len(target_obj.data.vertices) == 0:
            return False
        if operation == 'DIFFERENCE' and pre_diagonal > 0.0:
            if _bbox_diagonal(target_obj) < pre_diagonal * 0.6:
                return False
            # Real bug found during clinical-testing verification: a
            # DIFFERENCE cutter that doesn't actually overlap the target
            # (e.g. a registration key moved off the split face, or a pour
            # channel repositioned away from the mold wall) makes Blender's
            # own boolean modifier "succeed" with the mesh COMPLETELY
            # UNCHANGED - no exception, non-empty result, bbox diagonal
            # unchanged (so the >=60% check above doesn't catch it either.
            # That silent no-op is exactly what was reported as "one key
            # did not work" / "edited the pour channel but saw no effect" -
            # the clinician got no feedback that the cutter never touched
            # the mesh. Treat an identical vertex count as a failed cut so
            # the caller's existing error/warning message actually fires.
            if len(target_obj.data.vertices) == pre_vert_count:
                return False
        return True

    pre_diagonal = _bbox_diagonal(target_obj)
    pre_vert_count = len(target_obj.data.vertices)
    backup_mesh = target_obj.data.copy()
    if not _attempt('EXACT', pre_diagonal, pre_vert_count):
        bad_mesh = target_obj.data
        target_obj.data = backup_mesh
        bpy.data.meshes.remove(bad_mesh, do_unlink=True)
        retry_backup = target_obj.data.copy()
        if not _attempt('FLOAT', pre_diagonal, pre_vert_count):
            bad_mesh = target_obj.data
            target_obj.data = retry_backup
            bpy.data.meshes.remove(bad_mesh, do_unlink=True)
            # Real bug found during clinical-testing verification (crash:
            # "ReferenceError: StructRNA of type Object has been removed"
            # on the NEXT boolean call against this same target_obj): the
            # line above just made retry_backup the object's LIVE mesh
            # data - it must never be removed here. The old code removed
            # it anyway, ripping the mesh out from under an object that
            # still referenced it as its only datablock, which corrupted
            # target_obj enough that a later access (even just reading
            # target_obj.data.vertices in a subsequent Apply Keys loop
            # iteration) raised a StructRNA-removed error - looking, from
            # the panel, exactly like "the other mold half got deleted".
            #
            # Real bug found during clinical-testing verification (2nd,
            # separate from the one above): this failure path used to
            # `return False` here WITHOUT ever reaching the cutter-cleanup
            # line at the bottom of this function - so a failed hole-cut
            # left `cutter_obj` (e.g. a key's duplicate sphere) orphaned in
            # the scene, AND (in DynaxMoldApplyKeys specifically) the
            # ORIGINAL key had already been consumed into Half A's bump by
            # that point regardless of whether the matching Half B hole
            # succeeded - so a failed hole meant Half A got a bump with NO
            # matching recess on Half B, silently breaking that
            # registration pair. This was reported as "the keys are no
            # more exporting with the mold." Clean up the cutter here too,
            # matching the success path below, so a failed cut doesn't
            # also leave scene debris behind.
            if not keep_cutter:
                bpy.data.objects.remove(cutter_obj, do_unlink=True)
            return False
        bpy.data.meshes.remove(retry_backup, do_unlink=True)
    else:
        bpy.data.meshes.remove(backup_mesh, do_unlink=True)

    if not keep_cutter:
        bpy.data.objects.remove(cutter_obj, do_unlink=True)
    return True


def _is_manifold(context, obj):
    """True if the evaluated mesh has no open (non-manifold) edges - a
    Boolean DIFFERENCE against an open-edged scan produces garbage/leaking
    geometry, so this must be checked BEFORE the mold box cut, not after."""
    depsgraph = context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(depsgraph)
    mesh = eval_obj.to_mesh()
    bm = bmesh.new()
    bm.from_mesh(mesh)
    non_manifold = any(not e.is_manifold for e in bm.edges)
    bm.free()
    eval_obj.to_mesh_clear()
    return not non_manifold


def _trace_boundary_loops(boundary_edges):
    """Group a flat list of boundary edges into separate connected loops
    (walking vert-to-vert). Returns a list of edge lists."""
    vert_to_edges = {}
    for e in boundary_edges:
        for v in e.verts:
            vert_to_edges.setdefault(v, []).append(e)

    remaining = set(boundary_edges)
    loops = []
    while remaining:
        start = next(iter(remaining))
        loop = [start]
        remaining.discard(start)
        first_vert = start.verts[0]
        cur_vert = start.verts[1]
        while cur_vert != first_vert:
            candidates = [e for e in vert_to_edges[cur_vert] if e in remaining]
            if not candidates:
                break
            nxt = candidates[0]
            loop.append(nxt)
            remaining.discard(nxt)
            cur_vert = nxt.verts[1] if nxt.verts[0] == cur_vert else nxt.verts[0]
        loops.append(loop)
    return loops


def _cap_split_face(bm):
    """Close the open face left by bisect_plane. Real bug found during
    clinical-testing verification: a mold box has an internal cavity, so
    bisecting it produces TWO separate boundary loops at the cut (the outer
    box outline AND the cavity outline) - verified headless (4 edges each
    on a test box). Plain `holes_fill` fills each loop independently as its
    OWN simple disk, which SEALS the cavity mouth shut with a spurious cap
    at the split face instead of leaving it open - this is the actual
    reason the generated mold looked like it "sat through" the scan rather
    than boxing it: the cavity's opening at the cut plane was being plugged.
    Fixed by bridging the outer loop to the inner loop (bmesh.ops.
    bridge_loops, the same coplanar-loop-connecting operator this codebase
    already uses via bpy.ops.mesh.bridge_edge_loops elsewhere), which
    produces the correct flat ANNULAR cap - solid box material at the rim,
    genuinely open over the cavity. Falls back to holes_fill for the
    single-loop (no cavity crossing the plane) or >2-loop cases."""
    boundary_edges = [e for e in bm.edges if e.is_boundary]
    if not boundary_edges:
        return
    loops = _trace_boundary_loops(boundary_edges)
    if len(loops) == 2:
        try:
            bmesh.ops.bridge_loops(bm, edges=loops[0] + loops[1])
            return
        except Exception:
            pass
    bmesh.ops.holes_fill(bm, edges=boundary_edges)


def _split_object(obj, plane_co, plane_no, name_a, name_b):
    """Bisect a duplicate of obj into two halves along a world-space plane,
    each capped so the halves stay closed solids with the cavity genuinely
    open (not sealed) at the split face."""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.duplicate()
    dup = bpy.context.active_object

    def _bisect_keep(o, keep_positive):
        mw_inv = o.matrix_world.inverted()
        local_co = mw_inv @ plane_co
        local_no = (mw_inv.to_3x3() @ plane_no).normalized()
        bm = bmesh.new()
        bm.from_mesh(o.data)
        bmesh.ops.bisect_plane(
            bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:],
            plane_co=local_co, plane_no=local_no,
            clear_inner=not keep_positive,
            clear_outer=keep_positive,
        )
        _cap_split_face(bm)
        bm.normal_update()
        bm.to_mesh(o.data)
        o.data.update()
        bm.free()

    _bisect_keep(obj, keep_positive=True)
    _force_unique_name(obj, name_a)
    _bisect_keep(dup, keep_positive=False)
    _force_unique_name(dup, name_b)
    return obj, dup


def _face_point(centre, axis, val1, val2):
    """A world point ON the split plane: `val1` along the remaining
    horizontal axis (Y if split axis is X, X if split axis is Y), `val2`
    along Z, and the split-axis coordinate taken from `centre` (i.e. sitting
    exactly on the plane)."""
    if axis == 'X':
        return Vector((centre.x, val1, val2))
    return Vector((val1, centre.y, val2))


def _add_bump(context, half_obj, bump_obj):
    """Add a registration bump/base-plate by appending its geometry directly
    into half_obj's mesh data via bmesh - not boolean-UNIONing, and (as of
    this clinical-testing fix) not bpy.ops.object.join() either.

    History: boolean UNIONing a sphere across the flat cap face
    _split_object creates (bisect_plane + holes_fill) silently clipped away
    the sphere's protruding cap under BOTH the EXACT solver (returned a
    completely empty mesh) and the FLOAT fallback (kept the box unchanged
    and dropped the cap) - neither raised an exception. That was first
    fixed with bpy.ops.object.join() (matching manual_bridge.py's own
    precedent for merging two already-overlapping solids), which worked in
    every headless/background verification run here, but was reported to
    raise a context/"incorrect context" error under other invocation
    contexts (join() needs `context.view_layer.objects.active` plus a
    view3d-ish context override in some call paths that a plain background
    script call doesn't reproduce). Removing the bpy.ops.object.join() call
    entirely removes that whole class of context dependency: bmesh mesh-
    data operations only need object/mesh references, never the window
    manager or an active 3D viewport.

    A join is still not needed for correctness - the bump only needs to be
    visually/physically present on the outside for a clinician to feel it
    and for a slicer to print it, it does not need to be a single
    topologically-clean manifold with the box - but the resulting mesh is
    still cleaned (remove_doubles + consistent normals) via bmesh ops
    directly, because a LATER boolean DIFFERENCE against it (e.g.
    DynaxMoldApplyPourChannel cutting the pour channel after keys/base
    plate were already added on) was verified to reproduce the same
    silent-collapse failure _boolean_apply's docstring describes if the
    seam is left dirty."""
    bm_target = bmesh.new()
    bm_target.from_mesh(half_obj.data)

    bm_bump = bmesh.new()
    bm_bump.from_mesh(bump_obj.data)

    # bump_obj's geometry is in ITS OWN local space - transform into
    # half_obj's local space (world space as the intermediate), matching
    # what join()/the boolean modifier would have done implicitly.
    mat = half_obj.matrix_world.inverted() @ bump_obj.matrix_world
    bmesh.ops.transform(bm_bump, matrix=mat, verts=bm_bump.verts)

    vert_map = {}
    for v in bm_bump.verts:
        vert_map[v] = bm_target.verts.new(v.co)
    bm_target.verts.ensure_lookup_table()

    for f in bm_bump.faces:
        try:
            bm_target.faces.new([vert_map[v] for v in f.verts])
        except ValueError:
            pass  # duplicate/degenerate face - skip, not fatal

    bmesh.ops.remove_doubles(bm_target, verts=bm_target.verts, dist=0.01)
    bmesh.ops.recalc_face_normals(bm_target, faces=bm_target.faces)
    bm_target.normal_update()

    bm_target.to_mesh(half_obj.data)
    half_obj.data.update()
    bm_target.free()
    bm_bump.free()

    bpy.data.objects.remove(bump_obj, do_unlink=True)


def _force_unique_name(obj, name):
    """Rename obj to the EXACT `name`, evicting any other object already
    holding it first. Clinical-testing fix: if a stale ParaMold object from
    an earlier session somehow survives _clear_previous_mold_objects (e.g.
    a name collision during that very cleanup, or an object created outside
    the normal flow), Blender silently auto-suffixes the freshly-created
    one to "name.001" instead of raising anything - so the clinician sees
    and repositions the NEW, correctly-placed object in the viewport, but
    every later operator's exact-name lookup (bpy.data.objects.get(name))
    finds and processes the OLD, untouched, stale one instead. Reported
    symptom: "Applied 2 key(s)" (both lookups DID find objects and finished
    without error) while a repositioned key - confirmed still bearing its
    original, un-suffixed name - was never actually processed, because it
    wasn't the object holding that name at lookup time. This guarantees the
    object this function just created/positioned is unambiguously the one
    every later `bpy.data.objects.get(name)` call will find."""
    existing = bpy.data.objects.get(name)
    if existing is not None and existing is not obj:
        bpy.data.objects.remove(existing, do_unlink=True)
    obj.name = name


def _get_or_create_material(name, rgba):
    """Shared, reused-by-name material so the moveable key/pour objects are
    clearly colour-coded regardless of viewport shading mode (relying on
    Object Color alone only shows up under specific overlay settings)."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name=name)
    mat.diffuse_color = rgba
    try:
        mat.use_nodes = True
        principled = mat.node_tree.nodes.get('Principled BSDF')
        if principled is not None:
            principled.inputs['Base Color'].default_value = rgba
    except Exception:
        pass
    return mat


def _key_face_positions(axis, box_min, box_max):
    """Default front-left / back-right positions on the split face, shared
    by the moveable-key creation and (formerly) the bake-in-place key
    placement. Clinical-testing fix: two registration keys is the correct
    clinical count (two points fully constrain the halves against sliding
    AND rotating relative to each other - a third, centre key was
    redundant and just one more thing that could fail to reach the
    surface). Reduced from 3 to 2, front-left/back-right only."""
    CORNER_INSET = 15.0
    axis1_idx = 1 if axis == 'X' else 0  # Y if split on X, X if split on Y
    min1, max1 = box_min[axis1_idx], box_max[axis1_idx]
    min2, max2 = box_min.z, box_max.z
    off1 = min(CORNER_INSET, (max1 - min1) / 4.0)
    off2 = min(CORNER_INSET, (max2 - min2) / 4.0)
    return [
        (min1 + off1, min2 + off2),                  # front-left
        (max1 - off1, max2 - off2),                   # back-right
    ]


def _create_moveable_keys(context, centre, axis, box_min, box_max):
    """Clinical-testing FIX 1: registration keys are now 3 separate,
    moveable sphere objects (DynaX_Key_1/2/3) at sensible default positions
    on the split face, rather than being baked straight into the mold
    geometry - the clinician repositions them, then clicks Apply Keys
    (DynaxMoldApplyKeys) to bake them in. Default positions reuse the same
    front-left/centre/back-right face layout the previous bake-in-place
    version used."""
    KEY_RADIUS = 4.0
    mat = _get_or_create_material("DynaX_Mold_Key_Material", (1.0, 0.5, 0.0, 1.0))
    for i, (val1, val2) in enumerate(_key_face_positions(axis, box_min, box_max), start=1):
        pos = _face_point(centre, axis, val1, val2)
        bpy.ops.mesh.primitive_uv_sphere_add(radius=KEY_RADIUS, location=pos)
        key = context.active_object
        _force_unique_name(key, f"DynaX_Key_{i}")
        key.data.materials.append(mat)
        key.color = (1.0, 0.5, 0.0, 1.0)


def _add_base_plate(context, half_obj, base_thickness=3.0):
    """Union a flat base plate onto the BOTTOM of one mold half so it sits
    stable on a print bed. Plate footprint matches the half's own XY bounds
    (not the original scan's), and overlaps 1mm up into the half so the
    union has real volumetric overlap rather than a coincident, zero-
    thickness seam (same overlap convention already used elsewhere in this
    codebase for watertight unions - see component_bridge.py). Now applied
    from DynaxMoldExport (see that operator + this file's module docstring
    history for why), so it's idempotent - re-exporting doesn't add a
    second plate."""
    if len(half_obj.data.vertices) == 0:
        return  # degenerate half (e.g. boolean collapse) - nothing to base
    if half_obj.get("dynax_mold_base_applied"):
        return

    OVERLAP = 1.0
    min_co, max_co = _world_bounds(context, half_obj)
    centre_xy = Vector(((min_co.x + max_co.x) / 2.0, (min_co.y + max_co.y) / 2.0, 0.0))
    size_x = (max_co.x - min_co.x) + 1.0   # +1mm so the plate is never
    size_y = (max_co.y - min_co.y) + 1.0   # thinner than the half's own footprint
    plate_z_centre = min_co.z - (base_thickness / 2.0) + OVERLAP

    bpy.ops.mesh.primitive_cube_add(
        size=1.0, location=(centre_xy.x, centre_xy.y, plate_z_centre))
    plate = context.active_object
    plate.name = "DynaX_MoldBase"
    plate.scale = (size_x, size_y, base_thickness + OVERLAP)
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

    # Same join-not-union fix as _add_bump - the base plate protrudes across
    # the half's own bottom face the same way a registration bump protrudes
    # across the split cap, and boolean UNION was verified to mishandle that
    # exact pattern (see _add_bump's docstring).
    _add_bump(context, half_obj, plate)
    half_obj["dynax_mold_base_applied"] = True


def _add_vent_channel(context, half_a, half_b, min_co, max_co, centre, pour_pos, wall):
    """Vent (3mm dia) at the end opposite the pour position, auto-applied
    to both halves - unlike the pour channel (see _create_pour_channel_
    object / DynaxMoldApplyPourChannel below), clinical testing only asked
    to make the POUR channel moveable, so the vent keeps its previous
    automatic behaviour."""
    vent_z = min_co.z if pour_pos == 'DISTAL' else max_co.z
    vent_loc = Vector((centre.x, centre.y, vent_z))
    bpy.ops.mesh.primitive_cylinder_add(radius=1.5, depth=(wall + 5.0) * 2.0, location=vent_loc)
    vent_cutter_a = context.active_object
    vent_cutter_a.name = "DynaX_VentChannel"
    bpy.ops.object.duplicate()
    vent_cutter_b = context.active_object
    vent_cutter_b.name = "DynaX_VentChannel_B"
    _boolean_apply(context, half_a, vent_cutter_a, 'DIFFERENCE')
    _boolean_apply(context, half_b, vent_cutter_b, 'DIFFERENCE')


def _create_pour_channel_object(context, min_co, max_co, centre, pour_pos, wall):
    """Clinical-testing FIX 3: the pour channel is now a separate, moveable/
    resizeable red cylinder object (DynaX_PourChannel) at a sensible default
    position, rather than being bored straight into the mold - the
    clinician repositions/resizes it, then clicks Apply Pour Channel
    (DynaxMoldApplyPourChannel)."""
    pour_z = max_co.z if pour_pos == 'DISTAL' else min_co.z
    pour_len = wall + 5.0
    pour_loc = Vector((centre.x, centre.y, pour_z))
    bpy.ops.mesh.primitive_cylinder_add(radius=4.0, depth=pour_len * 2.0, location=pour_loc)
    pour = context.active_object
    _force_unique_name(pour, "DynaX_PourChannel")
    mat = _get_or_create_material("DynaX_Mold_Pour_Material", (1.0, 0.0, 0.0, 1.0))
    pour.data.materials.append(mat)
    pour.color = (1.0, 0.0, 0.0, 1.0)


def _check_undercuts(context, scan_obj, plane_no):
    """Cast rays from the split-plane direction; count vertices the ray
    can't reach directly (i.e. shadowed by other geometry - an undercut
    relative to that draw direction)."""
    depsgraph = context.evaluated_depsgraph_get()
    eval_obj = scan_obj.evaluated_get(depsgraph)
    mesh = eval_obj.to_mesh()
    bvh = BVHTree.FromObject(scan_obj, depsgraph)

    direction = plane_no.normalized()
    unreachable = 0
    for v in mesh.vertices:
        world_co = scan_obj.matrix_world @ v.co
        origin = world_co + direction * 500.0
        hit, normal, index, dist = bvh.ray_cast(origin, -direction)
        if hit is None:
            unreachable += 1
            continue
        if (hit - world_co).length > 1.0:
            unreachable += 1
    eval_obj.to_mesh_clear()
    return unreachable > 0, unreachable


def _compute_cavity_volume_ml(context, scan_obj):
    """Cavity volume == the finger scan's own enclosed volume."""
    depsgraph = context.evaluated_depsgraph_get()
    eval_obj = scan_obj.evaluated_get(depsgraph)
    mesh = eval_obj.to_mesh()
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.transform(scan_obj.matrix_world)
    volume_mm3 = abs(bm.calc_volume(signed=True))
    bm.free()
    eval_obj.to_mesh_clear()
    return volume_mm3 / 1000.0  # 1 mL = 1 cm^3 = 1000 mm^3


# ── Operators ─────────────────────────────────────────────────────────────

_MOLD_OBJECT_PREFIXES = (
    "DynaX_Mold", "DynaX_Key_", "DynaX_PendingBump_", "DynaX_PourChannel",
    "DynaX_VentChannel", "DynaX_CutPlane",
)


def _repair_mesh(obj):
    """Fill holes / merge doubles / recalc normals on obj's own mesh data,
    in place, right before it's used as a boolean cutter - defense-in-depth
    alongside the existing _is_manifold() gate (which still refuses a badly
    non-manifold scan outright; this repairs minor issues a hard refusal
    would otherwise block on unnecessarily)."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bmesh.ops.holes_fill(bm, edges=[e for e in bm.edges if not e.is_manifold])
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=0.001)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(obj.data)
    obj.data.update()
    bm.free()


def _clear_previous_mold_objects(keep=None):
    """Remove every leftover ParaMold object before starting a new Generate.

    Root cause of a real reported bug: DynaxMoldGenerate never cleared
    objects from a PRIOR Generate call before creating new ones.
    _split_object just sets `.name = "DynaX_MoldHalf_A"` on the new box; if
    an object with that exact name already exists (the previous mold,
    never cleared), Blender silently auto-suffixes the NEW object to
    "DynaX_MoldHalf_A.001" instead - verified headless (running Generate
    twice without Reset left BOTH `DynaX_MoldHalf_A` and
    `DynaX_MoldHalf_A.001` in the scene). Every downstream operator
    (DynaxMoldApplyKeys, DynaxMoldApplyPourChannel, DynaxMoldExport, and
    the panel's own stage detection) looks the half up by the fixed,
    unsuffixed name - so all of them silently kept operating on the STALE
    object from the earlier run, while the real new mold sat orphaned
    under the .001 name, never getting keys/pour/base-plate applied and
    never being exported. Depending on exactly what state that stale
    object was left in (already base-plated, partially processed by an
    earlier Apply Keys/Pour call, etc.) this reproduces as anything from a
    wrong-but-plausible export to a near-empty one - the reported "84-byte
    Half_A" symptom is consistent with this, not a boolean solver failure.
    Fixed by clearing every ParaMold object at the START of Generate,
    exactly mirroring DynaxMoldReset's own object-removal logic, so the
    fixed names are always free and no .001 collision can ever happen."""
    to_remove = [
        obj for obj in bpy.data.objects
        if obj.name.startswith(_MOLD_OBJECT_PREFIXES) and obj is not keep
    ]
    for obj in to_remove:
        bpy.data.objects.remove(obj, do_unlink=True)


class DynaxMoldGenerate(bpy.types.Operator):
    """Generate the two-part silicone mold from the aligned finger scan"""
    bl_idname = "dynax.mold_generate"
    bl_label = "Generate Mold Box"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Clinical-testing fix: group every internal bpy.ops.* call this
        # operator makes (primitive_cube_add, duplicate, modifier_apply,
        # transform_apply, etc.) into ONE undo step - see _undo_group's
        # docstring for the reported bug this closes.
        with _undo_group(context, self.bl_label):
            return self._execute_impl(context)

    def _execute_impl(self, context):
        obj = context.active_object
        scene = context.scene
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select the aligned finger scan first")
            return {'CANCELLED'}

        # Clinical-testing fix (FIX 1): the scan MUST be manifold before any
        # boolean runs against it - an open-edged mesh produces a leaking,
        # garbage cavity cut rather than a clean box-with-void.
        if not _is_manifold(context, obj):
            self.report(
                {'ERROR'},
                "Mesh has open edges — please run mesh repair before "
                "generating mold",
            )
            return {'CANCELLED'}

        # Core-pipeline fix: clear any objects left over from a previous
        # Generate call BEFORE creating new ones - see
        # _clear_previous_mold_objects's docstring for the real bug this
        # closes (stale "DynaX_MoldHalf_A" causing the new mold to be
        # silently created as "DynaX_MoldHalf_A.001" and orphaned, while
        # every later step keeps operating on the old object). `obj` (the
        # finger scan being generated FROM) is explicitly kept even if its
        # own name happens to collide with a mold prefix.
        _clear_previous_mold_objects(keep=obj)
        # A fresh mold means fresh keys/pour objects (built later below) -
        # any earlier "skip Adjust, go straight to Export" override must not
        # carry over and hide THIS mold's own registration keys/pour channel.
        if "dynax_mold_skip_adjust" in scene:
            del scene["dynax_mold_skip_adjust"]

        wall = scene.dynax_mold_wall_thickness
        axis = scene.dynax_mold_split_axis
        pour_pos = scene.dynax_mold_pour_position

        # Stage 2 - Mold box: bounding box of the finger scan + wall_thickness
        # on ALL SIX sides.
        min_co, max_co = _world_bounds(context, obj)
        size = max_co - min_co
        centre = (max_co + min_co) / 2.0
        box_size = Vector((size.x + wall * 2.0, size.y + wall * 2.0, size.z + wall * 2.0))
        box_min = centre - box_size / 2.0
        box_max = centre + box_size / 2.0

        # Clinical-testing fix (FIX 1, root cause): primitive_cube_add(size=1.0)
        # creates a cube spanning -0.5..0.5 (width 1.0), so an object's
        # `.scale` maps 1:1 to its final WORLD width - verified headless
        # (scale=5 -> world span -2.5..2.5, i.e. width 5, not 2.5). The
        # previous code set scale = box_size/2, producing a box HALF the
        # intended size, which is why it sat through the finger scan instead
        # of enclosing it with real wall thickness. Scale must equal
        # box_size directly.
        bpy.ops.mesh.primitive_cube_add(size=1.0, location=centre)
        box_obj = context.active_object
        box_obj.scale = (box_size.x, box_size.y, box_size.z)
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        # Duplicate the finger scan for the boolean cutter (FIX 1 step 3) -
        # the clinician's own aligned scan object is never consumed or
        # referenced by a modifier that could leave it in an unexpected
        # state; the duplicate is deleted by _boolean_apply once applied.
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj
        bpy.ops.object.duplicate()
        scan_cutter = context.active_object
        scan_cutter.name = "DynaX_MoldCavityCutter"

        # Mesh repair (holes_fill/remove_doubles/recalc_normals) on the
        # DUPLICATE cutter, not the clinician's own scan object - this
        # add-on's established convention is to never destructively modify
        # the original scan. _is_manifold() above already refuses a badly
        # non-manifold scan outright; this is an extra pass on the copy
        # actually fed into the boolean, ahead of every boolean run on
        # either half.
        _repair_mesh(scan_cutter)

        # Boolean DIFFERENCE: outer box - finger duplicate = mold cavity
        # (a solid box with a finger-shaped void inside).
        if not _boolean_apply(context, box_obj, scan_cutter, 'DIFFERENCE'):
            self.report({'ERROR'}, "Failed to cut the mold cavity")
            return {'CANCELLED'}

        # Split the box at the split-axis plane into two halves.
        plane_no = Vector((1.0, 0.0, 0.0)) if axis == 'X' else Vector((0.0, 1.0, 0.0))
        half_a, half_b = _split_object(
            box_obj, centre, plane_no, "DynaX_MoldHalf_A", "DynaX_MoldHalf_B")

        # Clinical-testing fix: remember the split plane's exact coordinate
        # so DynaxMoldApplyKeys can snap a repositioned key back onto it
        # (see that operator's own comment for why - a key nudged even
        # slightly off the split axis during repositioning can end up
        # entirely inside one half, silently failing the DIFFERENCE cut
        # into the other half). Plain scene custom property, matching this
        # codebase's established pattern for informal ParaMold state
        # (dynax_mold_processed, DYNAX_MOLD_ALIGNED, etc.).
        context.scene["dynax_mold_split_coord"] = centre.x if axis == 'X' else centre.y

        # Clinical-testing fix: lock both halves' transforms so they can
        # never be accidentally moved/rotated/scaled in the viewport.
        # Reported bug: the key/pour-channel split-plane snap above assumes
        # Half A and Half B stay exactly where Generate put them - a
        # clinician who moves a half aside with G (e.g. to get an
        # unobstructed view of the other half's keys) and then eyeballs it
        # back to "roughly" its old position leaves it close but not
        # pixel/mm-exact, which is enough to throw off the boolean cuts
        # (confirmed: moving it back to its EXACT original position fixed
        # the same symptom). H (Hide) is the safe way to get a half out of
        # the way - hiding never touches its transform - so locking
        # location/rotation/scale forces that safe workflow instead of
        # allowing the unsafe one. "Start New Mold" replaces both objects
        # outright, so a locked half is never a dead end.
        for half in (half_a, half_b):
            half.lock_location = (True, True, True)
            half.lock_rotation = (True, True, True)
            half.lock_scale = (True, True, True)

        # Post-split sanity check. Deviation from the literal spec,
        # deliberate: reports a normal user-facing error and cancels
        # instead of `raise RuntimeError(...)` - an uncaught exception out
        # of Operator.execute() surfaces as a raw Python traceback to the
        # clinician, which this codebase's established convention
        # (utils/dynax_logging.py's creator_guard, used across every other
        # Creator operator) explicitly avoids in favour of self.report +
        # CANCELLED.
        for half, label in ((half_a, "Half_A"), (half_b, "Half_B")):
            if len(half.data.vertices) < 10:
                self.report(
                    {'ERROR'},
                    f"{label} collapsed during boolean. Try switching "
                    "split axis or check mesh for errors.",
                )
                return {'CANCELLED'}

        # Stage 3 - Vent channel (auto-applied; pour channel is now a
        # moveable object, see below). Run BEFORE the base plate join below
        # - that join leaves half_a's mesh self-intersecting/non-manifold
        # internally, and a subsequent boolean DIFFERENCE against messy
        # geometry was verified unreliable - every subtractive boolean on a
        # half must run while that half is still clean.
        _add_vent_channel(context, half_a, half_b, min_co, max_co, centre, pour_pos, wall)

        # Clinical-testing fix: the base plate join is now deferred to
        # DynaxMoldExport (applied automatically right before writing the
        # STL) instead of happening here. Reason: it's the same join-based
        # additive operation as the registration-key bumps, and joining it
        # onto half_a HERE - before the clinician has had a chance to run
        # the now-deferred Apply Keys / Apply Pour Channel (FIX 1 / FIX 3)
        # - was verified to make every later boolean DIFFERENCE against
        # half_a unreliable (both EXACT and FLOAT "succeeded" while
        # silently collapsing the mesh to roughly the cutter's own size).
        # Every subtractive boolean a clinician might still run must see a
        # clean half; the base plate carries no clinical decision of its
        # own, so it can safely wait until nothing more will be cut into it.

        # Clinical-testing FIX 1 + FIX 3: registration keys and the pour
        # channel are now created as separate, moveable/colour-coded
        # objects instead of being baked in immediately - the clinician
        # repositions them, then applies each with its own button
        # (DynaxMoldApplyKeys / DynaxMoldApplyPourChannel).
        _create_pour_channel_object(context, min_co, max_co, centre, pour_pos, wall)
        _create_moveable_keys(context, centre, axis, box_min, box_max)

        # Stage 4 - Undercut check (relative to the split-plane draw direction).
        has_undercuts, count = _check_undercuts(context, obj, plane_no)
        scene.dynax_mold_has_undercuts = has_undercuts
        if has_undercuts:
            self.report({'WARNING'}, f"{count} undercut vertex/vertices detected")

        # Stage 5 - Volume calculation.
        scene.dynax_mold_volume_ml = _compute_cavity_volume_ml(context, obj)

        self.report(
            {'INFO'},
            f"Mold generated. Volume: {scene.dynax_mold_volume_ml:.1f} mL",
        )
        return {'FINISHED'}


class DynaxMoldApplyKeys(bpy.types.Operator):
    """Cut a matching hole into Half B immediately; the Half A bump is
    deferred and joined in at Export time (see DynaxMoldExport) so no later
    boolean (e.g. Apply Pour Channel) can ever run over it"""
    bl_idname = "dynax.mold_apply_keys"
    bl_label = "Apply Keys to Mold"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Clinical-testing fix: group every internal bpy.ops.* call this
        # operator makes (per key: select_all, duplicate, modifier_apply
        # EXACT then possibly FLOAT) into ONE undo step - see _undo_group's
        # docstring for the reported bug this closes.
        with _undo_group(context, self.bl_label):
            return self._execute_impl(context)

    def _execute_impl(self, context):
        half_a = bpy.data.objects.get("DynaX_MoldHalf_A")
        half_b = bpy.data.objects.get("DynaX_MoldHalf_B")
        if half_a is None or half_b is None:
            self.report({'ERROR'}, "Generate the mold first")
            return {'CANCELLED'}

        axis = context.scene.dynax_mold_split_axis
        split_coord = context.scene.get("dynax_mold_split_coord")

        applied = 0
        for i in range(1, 3):
            key = bpy.data.objects.get(f"DynaX_Key_{i}")
            if not key:
                continue

            # Clinical-testing fix: snap the key's position back onto the
            # exact split plane along the split axis before baking it in -
            # reported bug: repositioning a key (dragging it with G in the
            # viewport) can easily introduce a small, easy-to-miss drift
            # PERPENDICULAR to the split face even while the clinician only
            # meant to slide it sideways along the face. Since the bump
            # (_add_bump, always targets Half A, no overlap check at all)
            # bakes in regardless of position, but the hole
            # (_boolean_apply DIFFERENCE against Half B) only succeeds if
            # the key geometrically overlaps Half B, that drift alone was
            # enough to silently break the pairing on one half - "once
            # repositioned one of the mold has an issue." Only the
            # split-axis coordinate is forced back onto the plane; the two
            # in-plane axes (where the clinician actually wants to move the
            # key) are left exactly as positioned.
            if split_coord is not None:
                if axis == 'X':
                    key.location.x = split_coord
                else:
                    key.location.y = split_coord

            # Deviation from the literal spec, deliberate: a raw
            # `modifier_apply` UNION/DIFFERENCE here reproduces the exact
            # silent-failure class already found and fixed for the
            # auto-generated keys (_add_bump's docstring) - EXACT and FLOAT
            # both mishandle a boolean against a half that already has the
            # base plate joined onto it. Hole uses the validated EXACT-then-
            # FLOAT _boolean_apply, which needs its own duplicate of the key
            # since the bump join (deferred - see below) would otherwise
            # consume the original before the hole cutter is made.
            bpy.ops.object.select_all(action='DESELECT')
            key.select_set(True)
            context.view_layer.objects.active = key
            bpy.ops.object.duplicate()
            key_dup = context.active_object

            # Clinical-testing fix: the Half A bump join is now DEFERRED to
            # DynaxMoldExport, exactly mirroring how the base plate join is
            # already deferred there (see _add_base_plate's docstring) -
            # and for the identical reason. Reported bug: clicking Apply
            # Pour Channel AFTER Apply Keys ran its DIFFERENCE cut directly
            # over the freshly-joined, still-messy bump seam on Half A,
            # which this codebase has already documented (_add_bump's own
            # docstring) as a class of boolean solver failure - "why is the
            # pour channel affecting keys." A join must always be the LAST
            # thing done to a half, never something a later boolean can run
            # over. Instead of joining now, the key is renamed/hidden as a
            # pending bump and its actual join happens at Export time,
            # after every possible cut (pour, vent) has already run.
            key.hide_set(True)
            key.hide_render = True
            _force_unique_name(key, f"DynaX_PendingBump_{i}")

            if not _boolean_apply(context, half_b, key_dup, 'DIFFERENCE'):
                self.report(
                    {'WARNING'},
                    f"Key {i}: no hole cut into Half B - the key doesn't "
                    "reach Half B's surface. Move it closer to the split "
                    "line (the flat cut face) and Apply again.",
                )
            applied += 1

        if applied == 0:
            self.report({'WARNING'}, "No key objects found to apply")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Applied {applied} key(s) to mold halves.")
        return {'FINISHED'}


class DynaxMoldApplyPourChannel(bpy.types.Operator):
    """Bake the (possibly repositioned/resized) DynaX_PourChannel object
    into BOTH mold halves (matches the auto-applied vent channel's own
    both-halves behaviour - see _add_vent_channel)"""
    bl_idname = "dynax.mold_apply_pour"
    bl_label = "Apply Pour Channel"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Clinical-testing fix: group every internal bpy.ops.* call this
        # operator makes (select_all, duplicate, modifier_apply EXACT then
        # possibly FLOAT, twice - once per half) into ONE undo step - see
        # _undo_group's docstring for the reported bug this closes.
        with _undo_group(context, self.bl_label):
            return self._execute_impl(context)

    def _execute_impl(self, context):
        pour = bpy.data.objects.get("DynaX_PourChannel")
        if not pour:
            self.report({'ERROR'}, "No pour channel found")
            return {'CANCELLED'}

        half_a = bpy.data.objects.get("DynaX_MoldHalf_A")
        half_b = bpy.data.objects.get("DynaX_MoldHalf_B")
        if not half_a or not half_b:
            self.report({'ERROR'}, "Generate the mold first")
            return {'CANCELLED'}

        # Clinical-testing fix: same split-plane snap as DynaxMoldApplyKeys
        # (see that operator's own comment) - the pour channel is centred
        # on BOTH the X and Y split-box centre by construction
        # (_create_pour_channel_object), so a repositioning drag that
        # nudges it off the split axis can just as easily push it entirely
        # into one half, breaking the "cuts both halves" fix above. Only
        # the split-axis coordinate is corrected; height (Z) and the other
        # in-plane axis are left exactly as the clinician positioned them.
        axis = context.scene.dynax_mold_split_axis
        split_coord = context.scene.get("dynax_mold_split_coord")
        if split_coord is not None:
            if axis == 'X':
                pour.location.x = split_coord
            else:
                pour.location.y = split_coord

        # Clinical-testing fix: cut into BOTH halves, not just Half A. The
        # pour channel sits at the split-plane end (same default location as
        # the auto-applied vent channel - see _add_vent_channel, which
        # already cuts both halves for exactly this reason) so it must punch
        # through both halves to form one continuous funnel once the mold is
        # assembled; cutting only Half A left Half B's side of the channel
        # sealed shut, which is what was reported as "pour channel changes
        # only happening on Mold A." Duplicate the cutter first (matching
        # _add_vent_channel's own pattern) since _boolean_apply consumes its
        # cutter object.
        bpy.ops.object.select_all(action='DESELECT')
        pour.select_set(True)
        context.view_layer.objects.active = pour
        bpy.ops.object.duplicate()
        pour_dup_b = context.active_object

        # Deviation from the literal spec, deliberate: a raw
        # `modifier_apply` DIFFERENCE here reproduces the same silent-
        # failure class documented in _boolean_apply's own docstring
        # (EXACT/FLOAT both mishandling a boolean against a half that
        # already has other joins/booleans baked in) - using the validated
        # helper instead of a bare modifier_apply.
        ok_a = _boolean_apply(context, half_a, pour, 'DIFFERENCE')
        ok_b = _boolean_apply(context, half_b, pour_dup_b, 'DIFFERENCE')

        if not ok_a and not ok_b:
            self.report(
                {'ERROR'},
                "No cut made on either half - the pour channel doesn't "
                "reach the mold wall. Move/resize it so it overlaps both "
                "halves, then Apply again.",
            )
            return {'CANCELLED'}
        if not ok_a:
            self.report(
                {'WARNING'},
                "Pour channel cut into Half B, but not Half A - reposition "
                "it to also overlap Half A and Apply again.",
            )
        elif not ok_b:
            self.report(
                {'WARNING'},
                "Pour channel cut into Half A, but not Half B - reposition "
                "it to also overlap Half B and Apply again.",
            )
        else:
            self.report({'INFO'}, "Pour channel applied to both halves.")
        return {'FINISHED'}


class DynaxMoldReset(bpy.types.Operator):
    """Clear all ParaMold objects and scene state, back to Stage 1"""
    bl_idname = "dynax.mold_reset"
    bl_label = "Start New Mold"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Deviation from the literal spec, deliberate: a bare
        # `obj.name.startswith("DynaX_")` matches every ParaFly/Creator/
        # TLSO-lattice/trimline object too (DynaX_SpineLattice,
        # DynaX_Selection, DynaX_Remainder, DynaX_Level_*, checkpoints,
        # etc. all share the "DynaX_" prefix), so it would delete unrelated
        # work from other workflows in the same scene. Scoped to the actual
        # ParaMold object name prefixes instead - same helper
        # DynaxMoldGenerate now calls at its own start (see
        # _clear_previous_mold_objects's docstring).
        _clear_previous_mold_objects()

        scene = context.scene
        scene.dynax_mold_has_undercuts = False
        scene.dynax_mold_volume_ml = 0.0
        if "dynax_mold_skip_adjust" in scene:
            del scene["dynax_mold_skip_adjust"]

        self.report({'INFO'}, "Mold reset. Import a new scan.")
        return {'FINISHED'}


class DynaxMoldSkipAlign(bpy.types.Operator):
    """Mark the active scan as aligned WITHOUT running the auto-align
    transform - for a scan already correctly oriented (e.g. positioned by
    hand), so Align isn't forced just to advance the stage indicator"""
    bl_idname = "dynax.mold_skip_align"
    bl_label = "Next Stage (Skip Align)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select the finger scan mesh first")
            return {'CANCELLED'}
        obj["DYNAX_MOLD_ALIGNED"] = True
        self.report({'INFO'}, "Marked as aligned — moving to Trim/Generate.")
        return {'FINISHED'}


class DynaxMoldSkipAdjust(bpy.types.Operator):
    """Move on to Export while leaving any unapplied registration keys /
    pour channel exactly as they are - for a mold that doesn't need them"""
    bl_idname = "dynax.mold_skip_adjust"
    bl_label = "Next Stage (Skip Adjust)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene["dynax_mold_skip_adjust"] = True
        self.report({'INFO'}, "Moving to Export — unapplied keys/pour channel left as-is.")
        return {'FINISHED'}


def _write_binary_stl(filepath, obj):
    """Hand-rolled binary STL writer - same always-available fallback
    already proven in operators/export_stl.py."""
    me = obj.data
    me.calc_loop_triangles()
    mw = obj.matrix_world
    tris = me.loop_triangles
    with open(filepath, 'wb') as f:
        f.write(b'\0' * 80)
        f.write(struct.pack('<I', len(tris)))
        for t in tris:
            n = t.normal
            f.write(struct.pack('<fff', n.x, n.y, n.z))
            for vi in t.vertices:
                co = mw @ me.vertices[vi].co
                f.write(struct.pack('<fff', co.x, co.y, co.z))
            f.write(struct.pack('<H', 0))


def _export_object_stl(context, obj, filepath):
    """Export a single object to STL, version-safe (Blender 4.2+ wm.stl_export,
    legacy export_mesh.stl, or the manual fallback) - mirrors export_stl.py's
    already-proven pattern, scoped to one named object/path instead of the
    Downloads-folder auto-naming Creator uses."""
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    context.view_layer.objects.active = obj

    exported = False
    try:
        if hasattr(bpy.ops.wm, "stl_export"):
            kwargs = dict(
                filepath=filepath, export_selected_objects=True,
                apply_modifiers=True, use_scene_unit=False,
            )
            props_keys = bpy.ops.wm.stl_export.get_rna_type().properties.keys()
            kwargs = {k: v for k, v in kwargs.items() if k in props_keys}
            bpy.ops.wm.stl_export(**kwargs)
            exported = True
        elif hasattr(bpy.ops, "export_mesh") and hasattr(bpy.ops.export_mesh, "stl"):
            bpy.ops.export_mesh.stl(
                filepath=filepath, use_selection=True,
                use_mesh_modifiers=True, use_scene_unit=False, global_scale=1.0,
            )
            exported = True
    except Exception:
        exported = False

    if not exported or not os.path.exists(filepath):
        _write_binary_stl(filepath, obj)


class DynaxMoldExport(bpy.types.Operator):
    """Export both mold halves as separate STL files"""
    bl_idname = "dynax.mold_export"
    bl_label = "Export Mold Halves"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: bpy.props.StringProperty(subtype='DIR_PATH')

    def execute(self, context):
        # Pre-export validation: catches a collapsed/missing half before
        # writing a garbage or empty STL, rather than after.
        for name in ("DynaX_MoldHalf_A", "DynaX_MoldHalf_B"):
            obj = bpy.data.objects.get(name)
            if not obj:
                self.report({'ERROR'}, f"{name} not found. Generate the mold first.")
                return {'CANCELLED'}
            if len(obj.data.vertices) < 10:
                self.report(
                    {'ERROR'},
                    f"{name} has collapsed geometry. Try regenerating with "
                    "a different split axis.",
                )
                return {'CANCELLED'}

        half_a = bpy.data.objects.get("DynaX_MoldHalf_A")
        half_b = bpy.data.objects.get("DynaX_MoldHalf_B")

        # Clinical-testing fix (FIX 2): refuse to export while any key or
        # pour-channel object is still unapplied - these are user-
        # controlled moveable objects (FIX 1 / FIX 3 of an earlier round)
        # and must be explicitly baked in via Apply Keys / Apply Pour
        # Channel before export, not silently left out of (or worse,
        # accidentally swept into) the exported STL.
        keys_exist = any(bpy.data.objects.get(f"DynaX_Key_{i}") for i in range(1, 4))
        pour_exists = bpy.data.objects.get("DynaX_PourChannel") is not None
        if keys_exist or pour_exists:
            self.report(
                {'WARNING'},
                "Apply keys and pour channel before exporting. Click "
                "'Apply Keys' and 'Apply Pour Channel' first.",
            )
            return {'CANCELLED'}

        # Clinical-testing fix: join every deferred key bump (see
        # DynaxMoldApplyKeys - "DynaX_PendingBump_i") into Half A now,
        # BEFORE the base plate join below - both are joins, and this must
        # run before Export's own later joins, but AFTER every possible cut
        # (pour channel, vent) has already happened at this point in the
        # workflow, which is the entire reason the bump was deferred this
        # far in the first place. Consumes/removes each pending object.
        for i in range(1, 3):
            pending = bpy.data.objects.get(f"DynaX_PendingBump_{i}")
            if pending is not None:
                _add_bump(context, half_a, pending)

        # Base plate is applied here, not at Generate time - see this
        # file's _add_base_plate docstring for why. Idempotent (custom-prop
        # guarded), so exporting more than once never adds a second plate.
        _add_base_plate(context, half_a)
        _add_base_plate(context, half_b)

        out_dir = self.filepath or bpy.path.abspath("//")
        if not os.path.isdir(out_dir):
            try:
                os.makedirs(out_dir)
            except OSError:
                self.report({'ERROR'}, f"Could not create directory: {out_dir}")
                return {'CANCELLED'}

        original_selected = list(context.selected_objects)
        original_active = context.view_layer.objects.active

        _export_object_stl(context, half_a, os.path.join(out_dir, "MoldHalf_A.stl"))
        _export_object_stl(context, half_b, os.path.join(out_dir, "MoldHalf_B.stl"))

        bpy.ops.object.select_all(action='DESELECT')
        for o in original_selected:
            try:
                o.select_set(True)
            except Exception:
                pass
        context.view_layer.objects.active = original_active

        self.report({'INFO'}, f"Exported mold halves to {out_dir}")
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}
