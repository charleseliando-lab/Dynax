# operators/paramold/mold_aligner.py - ParaMold Stage 1: anatomical alignment
#
# Auto-aligns a finger scan to a canonical Z-up pose (long axis -> Z, distal
# end assumed to be the min-Z end, XY centred on world origin) so downstream
# mold-box/split/channel generation in mold_generator.py can assume a known
# orientation. The long axis is found via PCA (power iteration on the
# vertex-position covariance matrix in object-local space) rather than a
# numpy dependency - fine for the small, well-conditioned point sets a
# finger scan produces.

import bpy
import bmesh
from mathutils import Vector, Matrix


def _principal_eigenvector(mat):
    """Largest-eigenvalue eigenvector of a symmetric 3x3 matrix via power
    iteration."""
    v = Vector((1.0, 1.0, 1.0))
    for _ in range(64):
        v = mat @ v
        if v.length < 1e-12:
            return Vector((0.0, 0.0, 1.0))
        v.normalize()
    return v


class DynaxMoldAlign(bpy.types.Operator):
    """Auto-align finger scan to canonical Z-up position for mold generation"""
    bl_idname = "dynax.mold_align"
    bl_label = "Align Finger Scan"
    bl_description = (
        "Auto-align finger scan to canonical Z-up position for mold "
        "generation"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select the finger scan mesh first")
            return {'CANCELLED'}

        bm = bmesh.new()
        bm.from_mesh(obj.data)
        verts = [v.co.copy() for v in bm.verts]
        bm.free()

        if len(verts) < 3:
            self.report({'ERROR'}, "Mesh has too few vertices to align")
            return {'CANCELLED'}

        # 1. Find long axis via PCA on vertex positions (object-local space).
        centroid = sum(verts, Vector()) / len(verts)
        xx = xy = xz = yy = yz = zz = 0.0
        for v in verts:
            d = v - centroid
            xx += d.x * d.x
            xy += d.x * d.y
            xz += d.x * d.z
            yy += d.y * d.y
            yz += d.y * d.z
            zz += d.z * d.z
        n = float(len(verts))
        cov = Matrix((
            (xx / n, xy / n, xz / n),
            (xy / n, yy / n, yz / n),
            (xz / n, yz / n, zz / n),
        ))
        long_axis = _principal_eigenvector(cov)

        # 2. Align long axis to Z.
        z_axis = Vector((0.0, 0.0, 1.0))
        rot_quat = long_axis.rotation_difference(z_axis)
        obj.rotation_mode = 'QUATERNION'
        obj.rotation_quaternion = rot_quat @ obj.rotation_quaternion
        obj.rotation_mode = 'XYZ'
        context.view_layer.update()

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj
        bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)

        # 3-4. Place proximal end at Z=0 (assumed to be the min-Z end after
        # rotation - PCA gives an axis, not a direction, so this is the
        # documented convention rather than a detected fact) and centre X/Y
        # on world origin.
        depsgraph = context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        mesh = eval_obj.to_mesh()
        coords = [obj.matrix_world @ v.co for v in mesh.vertices]
        eval_obj.to_mesh_clear()

        min_x = min(c.x for c in coords)
        max_x = max(c.x for c in coords)
        min_y = min(c.y for c in coords)
        max_y = max(c.y for c in coords)
        min_z = min(c.z for c in coords)

        obj.location.x -= (min_x + max_x) / 2.0
        obj.location.y -= (min_y + max_y) / 2.0
        obj.location.z -= min_z

        # Stage-detection marker (ParaMold panel FIX 3) - lets the panel
        # tell "a mesh is active" apart from "this mesh has actually been
        # through Align", so the stage indicator can show Stage 2 correctly.
        obj["DYNAX_MOLD_ALIGNED"] = True

        self.report(
            {'INFO'},
            "Finger scan aligned. Check orientation and confirm before "
            "generating mold.",
        )
        return {'FINISHED'}


class DynaxMoldRotate90(bpy.types.Operator):
    """Rotate the active object 90 degrees around Z for manual fine-tuning"""
    bl_idname = "dynax.mold_rotate_90"
    bl_label = "Rotate 90°"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj:
            self.report({'ERROR'}, "Select the finger scan first")
            return {'CANCELLED'}
        obj.rotation_euler.z += 1.5708
        return {'FINISHED'}


class DynaxMoldFlip(bpy.types.Operator):
    """Flip the active object 180 degrees around X for manual fine-tuning"""
    bl_idname = "dynax.mold_flip"
    bl_label = "Flip orientation"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj:
            self.report({'ERROR'}, "Select the finger scan first")
            return {'CANCELLED'}
        obj.rotation_euler.x += 3.14159
        return {'FINISHED'}
