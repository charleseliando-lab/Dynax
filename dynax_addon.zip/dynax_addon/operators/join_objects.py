# operators/join_objects.py - Join Objects (Ctrl+J)

import bpy
from bpy.types import Operator


class JoinObjects(Operator):
    """Join selected mesh objects into one object (Ctrl+J)"""
    bl_idname = "dynax.join_objects"
    bl_label = "Join Objects"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        selected_meshes = [o for o in context.selected_objects if o.type == 'MESH']
        if len(selected_meshes) < 2:
            self.report({'ERROR'}, "Select at least two mesh objects")
            return {'CANCELLED'}

        target = context.active_object if context.active_object in selected_meshes else None
        if not target:
            target = selected_meshes[-1]
            context.view_layer.objects.active = target

        # Ensure all selected meshes are selected and target is active before join.
        bpy.ops.object.select_all(action='DESELECT')
        for o in selected_meshes:
            o.select_set(True)
        context.view_layer.objects.active = target

        try:
            # Use a VIEW_3D override to avoid context issues.
            area = next((a for a in context.window.screen.areas if a.type == 'VIEW_3D'), None)
            region = None
            if area:
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if area and region:
                with context.temp_override(
                    area=area,
                    region=region,
                    active_object=target,
                    object=target,
                    selected_objects=selected_meshes,
                    selected_editable_objects=selected_meshes,
                ):
                    result = bpy.ops.object.join()
            else:
                result = bpy.ops.object.join()
            if 'CANCELLED' in result:
                self.report({'ERROR'}, "Join failed (operator cancelled)")
                return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, f"Join failed: {e}")
            return {'CANCELLED'}

        context.view_layer.update()
        self.report({'INFO'}, "Objects joined")
        return {'FINISHED'}
