# operators/auto_remesh.py - Density reduction via Decimate (stable, deterministic)
#
# HISTORY: this file originally used the Remesh modifier's VOXEL mode, driven
# by a surface-area-based voxel-size estimate. That approach was abandoned
# after extensive real-scan debugging (see dynax_source/CLAUDE.md's Auto
# Remesh sections for the full investigation): Voxel Remesh builds a
# volumetric signed-distance field, which starves on thin, curved, elongated
# anatomical scans that fill only a few percent of their own bounding-box
# volume — no voxel-size formula can reliably hit a face-count target for
# that shape class without going below the safety floor needed to avoid a
# voxel-count explosion on a 700k+ face mesh. Measured on a real 768,570-face
# scan: voxel remesh produced 292-1,426 faces against a 15k-80k target.
#
# DECIMATE (COLLAPSE mode, ratio = target_faces / current_faces) solves this
# directly: it reduces triangle count on the EXISTING topology without ever
# needing a valid enclosed volume, so it's insensitive to the thin/curved/
# low-fill-ratio problem entirely. Measured on the same real scan: Decimate
# hit 14,999 / 40,000 / 79,999 faces against 15k / 40k / 80k targets (exact),
# preserved dimensions to within 0.1% per axis, and preserved volume to
# within ~1% — a categorical improvement over voxel remesh's near-total
# collapse on this shape class, with no formula/calibration needed at all.

import bpy
from bpy.types import Operator
from bpy.props import EnumProperty


# Target face counts — same labels as before; now hit deterministically.
DETAIL_PRESETS = {
    'LOW':    15000,
    'MEDIUM': 40000,
    'HIGH':   80000,
}

# Hard safety cap — never target more faces than this (manual override too).
MAX_SAFE_FACES = 120000
# Floor for a manual target-face override — a ratio computed toward too few
# faces can produce a degenerate/near-empty result.
MIN_TARGET_FACES = 500

# ── Post-remesh validation ──────────────────────────────────────────────────
# PROPOSED, not clinically validated — flagged for review. Decimate hits its
# face-count target deterministically (see module docstring), so the old
# "did auto fall far short of target" gate is no longer the primary risk;
# kept as a loose sanity net (a big miss would mean something genuinely
# degenerate about the input, not just an under-calibrated formula). The
# bbox check catches a different failure mode — spatial distortion — and
# stays independent of the face-count outcome.
FACE_COUNT_FAIL_FRACTION = 0.5   # achieved < 50% of target -> restore, don't accept
BBOX_MIN_RATIO = 0.5             # any axis shrinking below 50% of original -> restore
BBOX_MAX_RATIO = 2.0             # any axis growing beyond 200% of original -> restore


def classify_remesh_result(achieved_faces, target_faces, orig_dims, result_dims):
    """Pure decision function (no bpy/bmesh) so it can be unit tested directly.

    orig_dims / result_dims: (x, y, z) tuples in mm, or None if unavailable.
    Returns (status, reason) where status is 'OK' | 'FAIL'.
    'FAIL' means: restore the pre-remesh backup, do not accept this result.
    """
    if orig_dims is not None and result_dims is not None:
        for axis, (o, r) in enumerate(zip(orig_dims, result_dims)):
            if o <= 0:
                continue
            ratio = r / o
            if ratio < BBOX_MIN_RATIO or ratio > BBOX_MAX_RATIO:
                axis_name = "XYZ"[axis] if axis < 3 else str(axis)
                return ('FAIL',
                    f"bounding box axis {axis_name} changed to {ratio:.0%} of "
                    "original — spatial distortion, not just decimation")

    if target_faces:
        fraction = achieved_faces / target_faces if target_faces else 0.0
        if fraction < FACE_COUNT_FAIL_FRACTION:
            return ('FAIL',
                f"only reached {achieved_faces:,} faces "
                f"({fraction:.0%} of the ~{target_faces:,} target) — the "
                "input mesh may be degenerate")

    return ('OK', '')


class DynaxAutoRemesh(Operator):
    """Reduce mesh density via Decimate — pick a detail level (or a manual
    target face count), preserving overall shape/dimensions."""
    bl_idname = "dynax.auto_remesh"
    bl_label = "Auto remesh"
    bl_options = {'REGISTER', 'UNDO'}

    detail_level: EnumProperty(
        name="Detail level",
        items=[
            ('LOW',    "Low (~15k faces) — fastest, safest", "Best for slower computers"),
            ('MEDIUM', "Medium (~40k faces) — balanced",     "Good default for most scans"),
            ('HIGH',   "High (~80k faces) — more detail",    "Slower; only on capable computers"),
        ],
        default='MEDIUM',
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}

        if len(obj.data.vertices) == 0:
            self.report({'ERROR'}, "Mesh has no vertices")
            return {'CANCELLED'}

        print(f"[AutoRemesh] before backup: {len(obj.data.vertices)} verts")

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # transform_apply operates on SELECTED objects — being merely the
        # ACTIVE object is not enough. Force selection explicitly so it
        # always has something to act on, regardless of the caller's state.
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        # Decimate's `ratio` is dimensionless (final/original triangle count)
        # and does not depend on world-space scale the way a voxel size
        # would, but transform is still applied here for consistency with
        # the rest of the pipeline (dimension readouts, Align & Rotate order).
        try:
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
        except Exception as e:
            self.report({'ERROR'},
                f"Could not apply object transform before remeshing: {e}. "
                "Remesh aborted.")
            return {'CANCELLED'}

        print(f"[AutoRemesh] after transform: {len(obj.data.vertices)} verts, "
              f"scale={tuple(obj.scale)}")

        # Back up the mesh datablock before the destructive operation.
        # Guarded against ReferenceError: repeated operator invocations in
        # the same session have been observed to leave a stale `obj`
        # reference in real usage.
        try:
            backup_name = f"{obj.name}_PRE_REMESH_BACKUP"
            existing_backup = bpy.data.meshes.get(backup_name)
            if existing_backup:
                bpy.data.meshes.remove(existing_backup)
            backup_mesh = obj.data.copy()
        except ReferenceError:
            self.report({'ERROR'},
                "Auto Remesh could not access the mesh object (it may have "
                "been removed or replaced by a previous operation). Please "
                "reselect your scan and try again.")
            return {'CANCELLED'}
        backup_mesh.name = backup_name
        if len(backup_mesh.vertices) == 0:
            bpy.data.meshes.remove(backup_mesh)
            self.report({'ERROR'}, "Failed to create pre-remesh backup. Aborting remesh.")
            return {'CANCELLED'}
        obj["dynax_pre_remesh_mesh"] = backup_mesh.name

        print(f"[AutoRemesh] backup created: {len(backup_mesh.vertices)} verts")

        current_faces = len(obj.data.polygons)

        # Manual override (props.dynax_remesh_target_faces, 0 = auto) takes
        # priority over the detail-preset target when the clinician has set
        # one explicitly.
        manual_target = getattr(context.scene.dynax_props, "dynax_remesh_target_faces", 0)
        if manual_target > 0:
            target_faces = min(manual_target, MAX_SAFE_FACES)
        else:
            target_faces = DETAIL_PRESETS.get(self.detail_level, 40000)
        target_faces = max(target_faces, MIN_TARGET_FACES)

        orig_dims = tuple(obj.dimensions)

        print(f"[AutoRemesh] current_faces={current_faces:,}, target_faces={target_faces:,}, "
              f"dims={orig_dims}")
        print(f"[AutoRemesh] user override (dynax_remesh_target_faces)={manual_target}")

        if current_faces <= target_faces:
            del obj["dynax_pre_remesh_mesh"]
            bpy.data.meshes.remove(backup_mesh)
            self.report({'INFO'},
                f"Mesh already has {current_faces:,} faces — at or below the "
                f"~{target_faces:,} target. No change needed.")
            return {'FINISHED'}

        ratio = target_faces / current_faces

        self.report({'INFO'},
            f"Reducing density: {current_faces:,} -> ~{target_faces:,} faces "
            f"(ratio {ratio:.4f}). If this fails, the original will be restored.")

        decimate_mod = obj.modifiers.new(name="DynaX_Decimate", type='DECIMATE')
        decimate_mod.decimate_type = 'COLLAPSE'
        decimate_mod.ratio = ratio

        try:
            bpy.ops.object.modifier_apply(modifier=decimate_mod.name)
        except Exception as e:
            try:
                if decimate_mod.name in obj.modifiers:
                    obj.modifiers.remove(decimate_mod)
                obj.data = backup_mesh
                del obj["dynax_pre_remesh_mesh"]
                self.report({'ERROR'}, f"Remesh failed: {e}. Original restored.")
            except ReferenceError:
                self.report({'ERROR'},
                    "Remesh failed and the object could not be restored "
                    "automatically. Please undo (Ctrl+Z) to recover your mesh.")
            return {'CANCELLED'}

        print(f"[AutoRemesh] after remesh: {len(obj.data.vertices)} verts")

        verts = len(obj.data.vertices)
        faces = len(obj.data.polygons)
        result_dims = tuple(obj.dimensions)

        status, reason = classify_remesh_result(faces, target_faces, orig_dims, result_dims)
        print(f"[AutoRemesh] validation: status={status} reason={reason!r} "
              f"result_dims={result_dims}")

        if status == 'FAIL' or verts < 100:
            detail = reason or "produced a near-empty result"
            try:
                _ = obj.name  # raises ReferenceError if the object is stale
                old_mesh = obj.data
                obj.data = backup_mesh
                bpy.data.meshes.remove(old_mesh, do_unlink=True)
                del obj["dynax_pre_remesh_mesh"]
                self.report({'ERROR'},
                    f"Auto Remesh cancelled — {detail}. Original mesh preserved. "
                    "Try a different detail level or a manual target face count.")
            except ReferenceError:
                self.report({'ERROR'},
                    f"Auto Remesh cancelled — {detail} — and the object "
                    "reference was lost, so it could not be restored "
                    "automatically. Please undo (Ctrl+Z) to recover your mesh.")
            return {'CANCELLED'}

        dims_preserved = all(
            o <= 0 or (0.9 <= r / o <= 1.1) for o, r in zip(orig_dims, result_dims))

        self.report({'INFO'},
            f"✓ Remesh ({self.detail_level.title()}): {current_faces:,} -> "
            f"{verts:,} verts / {faces:,} faces. "
            f"Dimensions preserved: {'Yes' if dims_preserved else 'Approximately'}. "
            "Use 'Restore pre-remesh mesh' if you want to undo this.")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Choose detail level:", icon='MOD_REMESH')
        layout.prop(self, "detail_level", text="")
        layout.separator()

        box = layout.box()
        box.label(text="Reduces face count while preserving shape.", icon='INFO')
        box.label(text="Dimensions and volume are checked afterward;")
        box.label(text="a bad result is automatically restored.")

        obj = context.active_object
        if obj and obj.type == 'MESH':
            cur = layout.box()
            cur.label(
                text=f"Current: {len(obj.data.vertices):,} verts / "
                     f"{len(obj.data.polygons):,} faces",
                icon='MESH_DATA',
            )


class DynaxRemeshUndo(Operator):
    """Undo the last action"""
    bl_idname = "dynax.undo"
    bl_label = "Undo"
    bl_options = {'REGISTER'}

    def execute(self, context):
        try:
            bpy.ops.ed.undo()
        except Exception:
            pass
        return {'FINISHED'}


class DynaxRemeshRedo(Operator):
    """Redo the last undone action"""
    bl_idname = "dynax.redo"
    bl_label = "Redo"
    bl_options = {'REGISTER'}

    def execute(self, context):
        try:
            bpy.ops.ed.redo()
        except Exception:
            pass
        return {'FINISHED'}
