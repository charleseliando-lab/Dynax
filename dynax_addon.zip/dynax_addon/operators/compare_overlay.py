# operators/compare_overlay.py - Before/after comparison overlay
#
# Shows the original (pre-modification) scan as a wireframe outline on top of
# the current working mesh, so the prosthetist can visually see exactly what
# has changed during Cleanup/Align/Sculpt/Trim/Thickness, plus a click-to-
# measure tool that reports the radial mm offset at a chosen height.
#
# v1.20.8 (Creator Stabilization Sprint):
#
# 1. Default overlay opacity is exactly COMPARE_OPACITY = 0.200 (was 1.0, a
#    fully opaque wireframe that read as a second solid mesh).
#
# 2. The comparison now STAYS ALIGNED when the working mesh is moved or
#    rotated. The snapshot's matrix_world was copied once at import time
#    (operators/import_stl.py) and never updated, so any later object-level
#    transform left the overlay stranded at the import pose.
#    Fix: a Blender-native COPY_TRANSFORMS constraint on the snapshot,
#    targeting the working object, added when the overlay is shown and removed
#    when it is hidden.
#    Why a constraint and not the alternatives:
#      * parenting re-homes the snapshot in the outliner hierarchy and leaves a
#        parent-inverse matrix that survives toggling in confusing ways - and
#        the outliner is now visible to clinicians (Creator workspace),
#      * manually syncing matrix_world on a depsgraph handler re-implements what
#        the constraint system already does correctly, and drifts whenever a
#        handler is missed,
#      * a constraint is evaluated, non-destructive, applies NO transform to
#        either mesh's data, and is removed cleanly with the overlay.
#    Because the constraint is evaluated (not baked into matrix_world), any
#    consumer of the snapshot's transform must read the EVALUATED object - see
#    _snapshot_world_matrix below, which is what keeps click-to-measure correct
#    after a move.

import bpy
import bmesh
from bpy.types import Operator

from ..utils import measurement_helpers as mh
from ..utils.dynax_logging import (
    creator_guard, log_operator_error, validate_mesh_object,
)

# Wireframe overlay alpha. Exactly 0.200 per the Creator UI specification.
COMPARE_OPACITY = 0.200
COMPARE_COLOR = (1.0, 0.6, 0.0, COMPARE_OPACITY)   # DynaX orange
# Name of the constraint that keeps the snapshot glued to the working mesh.
COMPARE_CONSTRAINT_NAME = "DYNAX_COMPARE_ALIGN"


def _find_snapshot(obj):
    """Return the original-scan snapshot object for `obj`, or None."""
    if obj is None:
        return None
    name = obj.get("dynax_snapshot_name", "")
    return bpy.data.objects.get(name) if name else None


def _attach_alignment(snap_obj, work_obj):
    """Glue `snap_obj` to `work_obj` with a single COPY_TRANSFORMS constraint.

    Idempotent: re-showing the overlay re-uses the existing constraint rather
    than stacking duplicates (a second constraint would silently double-apply
    the transform). Nothing is baked - the snapshot's own matrix_world and mesh
    data are left exactly as they were.
    """
    if snap_obj is None or work_obj is None:
        return None
    constraint = snap_obj.constraints.get(COMPARE_CONSTRAINT_NAME)
    if constraint is None:
        constraint = snap_obj.constraints.new(type='COPY_TRANSFORMS')
        constraint.name = COMPARE_CONSTRAINT_NAME
    constraint.target = work_obj
    # The snapshot was taken in the working object's ORIGINAL pose, so it must
    # follow the object's transform delta, not be re-placed at its origin: the
    # snapshot's own matrix already equals the import-time matrix, and
    # COPY_TRANSFORMS makes it track the live one from there.
    constraint.mute = False
    return constraint


def _detach_alignment(snap_obj):
    """Remove the alignment constraint (and nothing else) from `snap_obj`."""
    if snap_obj is None:
        return
    constraint = snap_obj.constraints.get(COMPARE_CONSTRAINT_NAME)
    if constraint is not None:
        snap_obj.constraints.remove(constraint)


def _snapshot_world_matrix(context, snap_obj):
    """World matrix of the snapshot AS EVALUATED (constraint applied).

    Reading snap_obj.matrix_world directly would return the un-constrained
    import-time matrix and silently measure against the wrong pose once the
    working mesh has been moved.
    """
    try:
        depsgraph = context.evaluated_depsgraph_get()
        return snap_obj.evaluated_get(depsgraph).matrix_world.copy()
    except Exception:  # noqa: BLE001 - fall back to the raw matrix
        return snap_obj.matrix_world.copy()


def _find_view3d_under_cursor(context, event):
    """Return (region, rv3d, (mx, my)) for the VIEW_3D *window* region under
    the mouse, or (None, None, None). Uses absolute window coords so it works
    no matter which region the modal was launched from (a panel button gives
    context.region == the panel, not the viewport) - same pattern already
    proven in operators/trimline.py."""
    x, y = event.mouse_x, event.mouse_y
    for area in context.screen.areas:
        if area.type != 'VIEW_3D':
            continue
        rv3d = area.spaces.active.region_3d
        for region in area.regions:
            if region.type == 'WINDOW' \
                    and region.x <= x < region.x + region.width \
                    and region.y <= y < region.y + region.height:
                return region, rv3d, (x - region.x, y - region.y)
    return None, None, None


class DynaxToggleCompareOverlay(Operator):
    """Show/hide the original scan as a wireframe overlay for comparison"""
    bl_idname = "dynax.toggle_compare_overlay"
    bl_label = "Toggle Original Overlay"
    bl_description = ("Show the original scan as a thin outline over the "
                       "current mesh, so you can see what's changed")
    bl_options = {'REGISTER'}

    @creator_guard("Could not toggle the comparison. See the DynaX log for details.")
    def execute(self, context):
        obj = validate_mesh_object(self, context, require_mesh=False)
        if obj is None:
            return {'CANCELLED'}

        snap_obj = _find_snapshot(obj)
        if not snap_obj:
            self.report({'WARNING'},
                "No original snapshot found for this object. Snapshots are "
                "only taken at import time — re-import if you need one.")
            return {'CANCELLED'}

        was_hidden = snap_obj.hide_get()
        snap_obj.hide_set(not was_hidden)

        if was_hidden:
            # Now showing it — set up wireframe display so it reads as a thin
            # outline rather than a solid duplicate mesh.
            snap_obj.display_type = 'WIRE'
            snap_obj.show_in_front = True
            # Distinct color so it's visually distinguishable from the
            # working mesh (orange, matching the reference image), at the
            # specified 0.200 opacity.
            snap_obj.color = COMPARE_COLOR
            # Keep it glued to the working mesh for as long as it is shown, so
            # moving/rotating the socket can't strand the overlay.
            _attach_alignment(snap_obj, obj)
            self.report({'INFO'},
                        f"Original overlay shown (orange wireframe, "
                        f"{COMPARE_OPACITY:.3f} opacity).")
        else:
            # Toggling off hides the comparison and drops its constraint. It
            # never deletes the snapshot and never touches either mesh, so the
            # overlay can be brought back at any time.
            _detach_alignment(snap_obj)
            self.report({'INFO'}, "Original overlay hidden.")

        return {'FINISHED'}


def _compute_radial_offset(snap_obj, location, z_tolerance=3.0, snap_matrix=None):
    """Given a world-space `location` on the working mesh, return
    (offset_mm, clicked_z) versus the original snapshot, or None if the
    snapshot has no geometry at all.

    offset_mm is the SIGNED distance from `location` to the nearest point on
    the original snapshot surface: negative = surface moved inward (material
    removed), positive = moved outward (material added), sign taken from
    which side of the original surface the point now sits on (dot product
    against the original surface's normal at the nearest point).

    Why nearest-surface-distance and not "radius from an estimated central
    axis" (the reference spec's original approach): real prosthetic sockets
    are scanned limb shapes, not cylinders — cross-sections are asymmetric.
    Verified headless on a real transtibial socket that the radius-from-
    local-centroid approximation reports 4-10mm of spurious "offset" at
    points that were never touched, simply from cross-sectional asymmetry —
    unusable for a clinical measurement. Nearest-surface-distance via BVHTree
    is shape-agnostic and reads ~0mm at a genuinely unmodified point
    regardless of how irregular the cross-section is, because an unmodified
    point IS a point on the original surface (distance to itself is exactly
    zero); `z_tolerance` is kept only as the parameter name clients already
    pass, but is unused by this implementation.

    `snap_matrix` is the snapshot's world matrix to measure against. Callers
    pass the EVALUATED matrix (see _snapshot_world_matrix): with the v1.20.8
    alignment constraint the snapshot's raw matrix_world is still the
    import-time pose, so using it here would measure against a stale pose the
    moment the working mesh is moved. Defaults to the raw matrix for any caller
    that has no constraint in play."""
    from mathutils.bvhtree import BVHTree

    snap_mesh = snap_obj.data
    if not snap_mesh.vertices:
        return None
    snap_wm = snap_matrix if snap_matrix is not None else snap_obj.matrix_world

    bm = bmesh.new()
    try:
        bm.from_mesh(snap_mesh)
        bm.transform(snap_wm)   # bring the snapshot into world space once
        bvh = BVHTree.FromBMesh(bm)
    finally:
        bm.free()

    nearest, normal, index, dist = bvh.find_nearest(location)
    if nearest is None:
        return None

    to_point = location - nearest
    sign = 1.0 if to_point.dot(normal) >= 0.0 else -1.0
    offset_mm = sign * dist
    return offset_mm, location.z


class DynaxMeasureCompareOffset(Operator):
    """Click a point on the working mesh to measure how far the surface has
    moved (inward/outward) compared to the original scan at that height, in
    mm. Modal: the button starts it, the NEXT left-click in the 3D viewport
    is what's measured (a plain execute()/invoke() can't do this — a panel
    button's own invoke() event lives in the sidebar region, which has no
    valid 3D region_data, so a one-shot raycast off that event would raycast
    from the wrong region and fail; see _find_view3d_under_cursor)."""
    bl_idname = "dynax.measure_compare_offset"
    bl_label = "Measure Change at Point"
    bl_description = ("Click a point on the socket to see how much it has "
                       "changed from the original scan at that height")
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        obj = validate_mesh_object(self, context)
        if obj is None:
            return {'CANCELLED'}

        snap_obj = _find_snapshot(obj)
        if not snap_obj:
            self.report({'WARNING'},
                "No original snapshot found. Snapshots are only taken at "
                "import time — re-import if you need one.")
            return {'CANCELLED'}

        # Remember by NAME: the object can be deleted while the modal is live,
        # and a stale Python reference crashes on access.
        self._target_name = obj.name
        context.workspace.status_text_set(
            "Left-click a point on the socket to measure  |  Right-click or Esc = cancel")
        context.window_manager.modal_handler_add(self)
        self.report({'INFO'}, "Click a point on the socket surface to measure.")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        # Shared classifier: also treats a MODIFIED left-click (Alt/Ctrl/Shift +
        # LMB = orbit gestures) as navigation, so navigation can never register
        # as a measurement click.
        if mh.is_navigation_event(event):
            return {'PASS_THROUGH'}

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            context.workspace.status_text_set(None)
            try:
                done = self._measure_at(context, event)
            except Exception as exc:  # noqa: BLE001 - never traceback at a user
                log_operator_error(self.bl_idname, exc)
                self.report({'ERROR'},
                            "Could not measure there. See the DynaX log for details.")
                return {'CANCELLED'}
            return {'FINISHED'} if done else {'CANCELLED'}

        if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == 'PRESS':
            context.workspace.status_text_set(None)
            self.report({'INFO'}, "Measurement cancelled.")
            return {'CANCELLED'}

        return {'PASS_THROUGH'}

    def _measure_at(self, context, event):
        obj = bpy.data.objects.get(getattr(self, "_target_name", ""))
        if obj is None or obj.type != 'MESH':
            self.report({'WARNING'}, "The working object is no longer available.")
            return False
        snap_obj = _find_snapshot(obj)
        if not snap_obj:
            self.report({'WARNING'}, "No original snapshot found.")
            return False

        # Shared raycast helper: finds the viewport under the cursor, casts
        # against the evaluated mesh in local space and returns a WORLD hit.
        location = mh.raycast_surface(context, obj, event)
        if location is None:
            self.report({'WARNING'}, "Click landed off the socket surface — try again.")
            return False

        # Measure against the snapshot's EVALUATED pose so the reading stays
        # correct after the working mesh (and thus the constrained snapshot)
        # has been moved or rotated.
        result = _compute_radial_offset(
            snap_obj, location, snap_matrix=_snapshot_world_matrix(context, snap_obj))
        if result is None:
            self.report({'WARNING'},
                "No original geometry found at this height to compare against.")
            return False
        offset_mm, clicked_z = result

        context.scene["dynax_last_compare_offset"] = offset_mm
        context.scene["dynax_last_compare_z"] = clicked_z

        direction = "outward (added)" if offset_mm > 0 else "inward (removed)"
        self.report({'INFO'},
            f"At Z={clicked_z:.1f}mm: {abs(offset_mm):.2f}mm {direction} "
            f"compared to the original scan.")
        return True
