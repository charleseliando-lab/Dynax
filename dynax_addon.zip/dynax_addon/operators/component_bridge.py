# operators/component_bridge.py - Automatic Component Bridge
# (SPEC_component_bridge_correct.md).
#
# Confirmed with the user before rebuilding this: CLAUDE.md documents 8 versions
# (v1.5.0-v1.5.8) of automatic bridge attempts, all eventually abandoned in
# v1.6.0 for the manual zone-selection workflow (operators/manual_bridge.py,
# now superseded — kept on disk but no longer registered, see __init__.py),
# because real limb scans aren't circular and every automatic ring-matching
# approach broke on real clinical geometry. The user asked to try again with
# this spec's approach but fix the specific issues found before implementing —
# several were found only by actually running this against a real component
# STL, not just reading the spec:
#
# 1. TRIANGULATED TOP FACE: the spec picked ONE face with the highest average
#    Z as "the component's flat top face" and deleted only that one face.
#    STL files are always triangulated, so a real component's flat top is
#    dozens of coplanar triangles — deleting a single triangle punches a tiny
#    hole, not a real boundary loop. Fixed using this project's own
#    already-proven technique from the historical DynaxAutoDetectComponentFace
#    (v1.5.1): collect every face within a Z-tolerance of the true top AND
#    with an upward-facing normal, delete all of them together.
#
# 2. CUSTOM RESAMPLED-RING BRIDGING DOESN'T ACTUALLY WELD: the spec (and my
#    first pass at fixing it) built an entirely new "bridge" mesh object whose
#    top/bottom rings were independently resampled points approximating the
#    socket/component boundaries, then relied on remove_doubles to weld them
#    to the real mesh. Verified by actually building one on a real component:
#    the resampled ring points are NEAR but not coincident with the real
#    boundary vertices (arc-spacing gaps of several mm on a real ~80mm-radius
#    socket with a 48-64 point loop), so remove_doubles at any sane mm-scale
#    threshold can't close the gap — confirmed 273 leftover boundary
#    (non-manifold) edges on a real test build, i.e. NOT watertight. Also,
#    independently resampling each loop by angle (my first fix for the
#    v1.5.2 "spike-fan" bug) only fixes index-pairing between two *synthetic*
#    ring point-lists — it doesn't make either ring coincide with the real
#    mesh it's supposed to weld onto.
#
#    Fixed by dropping the custom bridge-mesh approach entirely and reusing
#    this exact codebase's own already-proven technique instead (see
#    operators/manual_bridge.py, kept for reference): join the socket and
#    component duplicates into ONE object first, so the "bridge" only has to
#    connect two boundary loops that are already real edges on the SAME mesh
#    (zero coincidence gap by construction), then call Blender's native
#    bpy.ops.mesh.bridge_edge_loops() — which already handles arbitrary
#    mismatched vertex counts robustly (that's the entire reason v1.6.0
#    switched to it for the manual workflow) instead of hand-rolled
#    index-pairing math. The two loops to bridge are found via
#    select_non_manifold() right after the join, since at that point the
#    ONLY non-manifold edges in the combined mesh are the socket's distal
#    opening and the component's newly-opened top.
#
# 3. SCALING THE COMPONENT TO MATCH THE SOCKET'S RADIUS IS WRONG: the spec
#    (and my first pass) rescaled the component's connection loop to match
#    the socket's outer diameter. Real prosthetic components have fixed,
#    manufactured dimensions that must stay physically accurate to mate with
#    real pylons/hardware — forcibly resizing them to match an arbitrary
#    socket's outer wall would silently break that compatibility. The
#    user-controlled Component Scale (Section 5, for paediatric cases) is the
#    only sanctioned resizing mechanism; the automatic bridge no longer
#    rescales anything on its own. bridge_edge_loops connecting a large
#    socket opening to a much smaller real component will naturally taper,
#    and — matching this exact codebase's own documented, ACCEPTED
#    characteristic of that operator on mismatched loop sizes (see
#    CLAUDE.md "Manual Bridge" section) — may show a bristly fringe if the
#    size difference is large. That's an inherent property of bridging very
#    different real sizes, not a bug to paper over by distorting the
#    component's true dimensions.
#
# 4. UNIT (mm-space): remove_doubles(threshold=0.001) was commented "0.001m =
#    1mm" but used as a raw value in this addon's mm-space (1 Blender unit =
#    1 mm — see CLAUDE.md "Unit System Architecture"), making the actual
#    threshold 0.001 mm. Fixed to a proper mm-scale threshold (matches
#    clean_slice.py's established 1 mm convention for seam-weld cleanup).
#
# 5. NON-DESTRUCTIVE MERGE: the spec applied transforms and joined directly
#    into the original socket object with no validation step — the exact
#    pattern that already caused a real incident in this project once before
#    (v1.5.3, "the socket disappeared" — see CLAUDE.md), fixed in v1.5.4 by
#    doing the merge on a DUPLICATE, validating the result, and only then
#    adopting it. Reused that exact pattern here.
#
# 6. REAL SOCKETS ARE COMMONLY FULLY CLOSED AT THE DISTAL END, NOT OPEN: found
#    by actually running this against a real transtibial scan (which reported
#    "Mesh is watertight (Manifold)" on import) rather than a synthetic test
#    mesh with a deliberately-removed cap. The spec assumed the socket already
#    has an open distal boundary loop to bridge from. DynaX's own Thickness
#    step solidifies with "Cap open edges" on by default, so a real finished
#    socket has NO boundary edges at all — CLAUDE.md documents this exact
#    problem already being solved once before for the old automatic bridge's
#    distal-ring detection ("boundary-edge method found nothing... Z-threshold
#    approach works whether the distal end is capped or open"). Applied the
#    same fix here: if the socket has no boundary edges at all, open one by
#    deleting the downward-facing faces near its lowest Z (mirroring
#    _open_component_top's technique, aimed at the opposite end).
#
# 7. PARAMETRIC TRANSITION SURFACE (SPEC_component_bridge_parametric_transition.md):
#    replaces the single direct socket-to-component bridge with N intermediate
#    rings (S-curve/taper profiles), aiming to fix the "bristly fringe"
#    documented as an accepted characteristic in fix #3 above when the two
#    real loops are very different sizes. The spec's own core design (join
#    socket + all N rings + component into ONE object, then a SINGLE
#    select_non_manifold()+bridge_edge_loops() call across all N+1 open
#    boundary loops at once, claiming it "connects each adjacent pair
#    automatically") was NOT trusted and was tested directly rather than
#    assumed correct, given this exact file's own fix #2 finding about custom
#    ring/bridge geometry. Empirically verified headless (synthetic 4-loop
#    mesh, 128 boundary edges): a single multi-loop bridge_edge_loops() call
#    returns {'FINISHED'} with NO error while silently leaving 64 of the 128
#    edges non-manifold — i.e. it does NOT correctly pair adjacent loops, it
#    produces a broken result while reporting success. This is exactly the
#    "exploded spike" failure mode _build_bridge's own existing "Expected
#    exactly 2 boundary loops... found N" hard guard exists to prevent (see
#    the bridge_edge_loops call further down) — the spec's design violates
#    that already-proven, already-necessary constraint.
#
#    Fixed by bridging SEQUENTIALLY, one adjacent pair at a time, reusing
#    this file's own proven "exactly 2 loops" invariant on every single step
#    instead of once (_bridge_chain below) — also verified headless
#    end-to-end (socket -> 3 rings -> component, 4 sequential bridges): every
#    step found exactly 2 loops, every bridge_edge_loops call returned
#    {'FINISHED'}, final result had 0 non-manifold edges. Each intermediate
#    ring is built as its own standalone closed loop of edges with ZERO
#    faces (a bmesh "wire" loop, not a pre-connected tube of quads like the
#    spec's _build_transition_mesh built). Bridge-vertex tracking for the
#    Laplacian smoothing pass (spec's Section 7) is done by recording the
#    actual vertex index ranges created during this chain, not by the
#    spec's "top/bottom 15% of the whole mesh's Z range" heuristic, which
#    breaks for asymmetric socket/component proportions and doesn't
#    generalize past a fixed ring count.
#
#    Also: the spec's bridge_edge_loops(interpolation='BLEND', ...) call
#    isn't a valid enum on this Blender build (verified directly - real
#    values are 'LINEAR'/'PATH'/'SURFACE', no 'BLEND') - kept this file's
#    own already-correct 'SURFACE'.
#
# 8. select_non_manifold() TO FIND "THE CURRENT 2 LOOPS" IS NOT SAFE ON REAL
#    GEOMETRY (found from an actual real-GUI bug report, 2026-07-07, on the
#    real bundled SOCKET_COMPONENT.stl - not caught by the synthetic-mesh
#    testing that validated fix #7 above): the first version of the
#    sequential chain (fix #7) still selected each step's 2 loops via
#    select_non_manifold(use_wire=True, use_boundary=True) — a GLOBAL scan
#    of the whole mesh. Verified directly that a single deliberate stray
#    wire edge added anywhere else on a synthetic test socket (simulating
#    debris a real, processed/solidified DynaX socket plausibly has - seam
#    gaps, degenerate slivers) reproduces the exact real failure ("Expected
#    exactly 2 open loops to bridge but found 3") on the very first ring
#    bridge, even though the socket's real opening and the fresh ring were
#    both completely fine on their own - ANY unrelated non-manifold edge
#    anywhere else in the mesh gets swept into the same selection. (Ruled
#    out _open_component_top's face-detection itself as the cause of THIS
#    specific crash first - verified directly against the real
#    SOCKET_COMPONENT.stl that it already produces exactly one clean
#    464-edge BOUNDARY loop; the deeper problem it does have is fix #9,
#    found next, once this crash was out of the way.)
#
#    Fixed by selecting purely by explicit vertex-index-set membership
#    instead (_bridge_two_loops now takes the two loops' known vertex
#    indices directly, not wire/boundary flags) - deterministic and immune
#    to anything else in the mesh, since every loop's identity is already
#    known exactly at the point it's created or discovered
#    (_get_boundary_loop_info's vert_indices for the socket/component's own
#    openings, computed once before the chain starts; each ring's own
#    RING_VERT_COUNT-sized index range, known the instant it's joined in).
#    Same principle already used for _smooth_bridge_region's tracked index
#    ranges instead of a Z-heuristic - "known and tracked" beats "re-derived
#    by scanning current topology" throughout this redesign. Verified fixed
#    against the same deliberately-dirty synthetic mesh that reproduced the
#    bug (now bridges cleanly, ignoring the stray wire edge entirely) - but
#    this alone was NOT sufficient against the real component, see fix #9.
#
# 9. FACES_ONLY DELETE LEAVES ORPHANED INTERIOR WIRE DEBRIS, WHICH set-
#    MEMBERSHIP SELECTION (fix #8) CANNOT DISTINGUISH FROM A REAL LOOP EDGE:
#    fix #8 alone stopped the crash but the real SOCKET_COMPONENT.stl bridge
#    still came out non-watertight (~230-260 leftover non-manifold edges,
#    every profile). Root cause, found by checking non-manifold edges with
#    both endpoints inside the component's own opened-boundary vertex set:
#    _open_component_top's (and _open_socket_distal's) bmesh.ops.delete(...,
#    context='FACES_ONLY') deletes only the face data-blocks, leaving the
#    deleted patch's INTERIOR edges behind as orphaned wire debris (0 linked
#    faces) - on the real component's non-trivially-shaped opening, some of
#    those interior debris edges land with BOTH endpoints on the true
#    boundary loop (a direct chord straight across the hole), which fix #8's
#    "both endpoints in the loop's vertex set" test cannot tell apart from a
#    genuine loop edge.
#
#    Fixed two ways: (a) at the source, both _open_socket_distal and
#    _open_component_top now delete with context='FACES_KEEP_BOUNDARY'
#    instead of 'FACES_ONLY' - the built-in bmesh mode for exactly this
#    "open a hole, discard the patch's interior, keep its boundary intact"
#    case; verified directly on the real component this produces 0 wire
#    debris and the same single clean 464-edge loop as before. (b)
#    defensively, _bridge_two_loops/_loop_edge_pairs now select by EXACT
#    edge-pair identity (consecutive vertices in each loop's own known walk
#    order), which can never match a chord edge regardless of what debris
#    exists elsewhere in the mesh, even if some future code path
#    reintroduces orphaned wire edges some other way. Verified end-to-end
#    against the real SOCKET_COMPONENT.stl across all 7 profiles: 0
#    non-manifold edges, originals correctly removed, every profile
#    produces a genuinely different transition shape.
#
# 10. BRIDGE ATTACHED RIGHT AT THE SOCKET'S DISTAL TIP INSTEAD OF WRAPPING UP
#     THE WALL: after fix #9 the bridge was watertight but visually attached
#     at the very bottom edge of the socket, since _open_socket_distal only
#     opens a thin cap band (SOCKET_DISTAL_Z_TOLERANCE_MM = 10mm) - too
#     narrow a loop to read as "wrapped around" the socket exterior. Fixed by
#     _extend_socket_opening, run immediately after the socket's single
#     boundary loop is established (_open_socket_distal + _close_minor_holes,
#     matching fix #9's "exactly one loop before doing anything else"
#     invariant).
#
#     First implementation attempt (a blanket Z-band delete over the whole
#     mesh, up to SOCKET_OPENING_EXTENSION_PCT of socket height) was NOT
#     trusted and was tested directly rather than assumed correct, given
#     this file's own fix #7/#8 findings about geometry that "reports
#     success" while actually being broken. Verified headless on a
#     synthetic double-walled socket (a real solidified socket has both an
#     outer AND inner wall layer): the blanket band touched faces on BOTH
#     layers, silently punching an unwanted SECOND hole in the inner
#     wall's still-closed distal tip - left 2 separate boundary loops (64
#     edges) instead of 1 enlarged loop, exactly the "found N loops,
#     expected 2" failure mode fix #8 already exists to catch, just
#     deferred to the next bridge step instead of caught here.
#
#     Fixed by flood-filling OUTWARD FROM THE CURRENT BOUNDARY LOOP instead
#     of scanning the whole mesh by Z alone - only faces actually reachable
#     from the already-open edge, and below the Z threshold, are removed,
#     so a separate closed surface a few mm away is never touched even
#     though it occupies the same Z range. Verified against the same
#     synthetic double-walled mesh: exactly 1 boundary loop remains at the
#     expected height, 0 stray loops.
#
#     Also: the delete uses context='FACES', not 'FACES_KEEP_BOUNDARY' (fix
#     #9's choice for opening an ISLAND patch surrounded by kept geometry).
#     Here the removed region touches the PRE-EXISTING boundary loop on
#     purpose (that's what "extend" means) - verified headless that
#     'FACES_KEEP_BOUNDARY' preserves edges flagged as "boundary of the
#     deleted patch" even once their only remaining face is gone, leaving
#     the old loop behind as 32 orphaned wire edges. Plain 'FACES' correctly
#     deletes geometry that ends up with zero remaining faces either way,
#     0 debris.
#
# 11. TRANSITION RINGS NEVER ACTUALLY MOVED TOWARD AN OFF-CENTRE COMPONENT
#     (v1.18.2): _generate_transition_rings' every ring used
#     socket_info["centre"] alone for its XY position, so all N rings
#     stayed pinned to the socket's own centroid regardless of t, never
#     moving toward the component - a real component's load axis isn't
#     always the same as the socket's own outer-wall centroid. Verified
#     against the real bundled SOCKET_COMPONENT.stl deliberately offset
#     25mm in X: every ring, including the last (t~=0.89), still measured
#     the full 31.3mm from the component's own boundary centroid, forcing
#     the final ring-to-component bridge to span that entire gap in one
#     step. Fixed by interpolating XY centre from socket_info["centre"] to
#     comp_info["centre"] linearly in t, matching the existing Z
#     interpolation. Re-verified end-to-end (25mm offset, PrusaSlicer):
#     manifold, 1 part, degenerate-face count unchanged from centred.
#
# 12. RING[0] WAS ALSO A SYNTHETIC PERFECT CIRCLE, EVEN THOUGH THE REAL
#     SOCKET LOOP NEVER IS (v1.19.1): fix #11 fixed WHERE every ring's
#     centre sits, but every ring - including ring[0], the one directly
#     bridged FROM the real socket - was still built from socket_info
#     ["radius"] (the socket loop's AVERAGE radius) as a perfect circle.
#     Measured directly against the real bundled reference socket: the
#     real opened distal loop deviates -5.7mm to +9.1mm from its own
#     average radius (14.8mm peak-to-peak), i.e. up to 9mm between a real
#     loop vertex and where a same-angle point on the "equivalent" circle
#     would sit - not a watertightness bug (bridge_edge_loops already
#     handles mismatched loop shapes/counts robustly, see fix #2/#7), but
#     a real shape-fidelity one: the socket->ring[0] bridge was always
#     connecting a genuinely irregular real loop straight to an idealised
#     circle, which can pinch or look gapped wherever the real loop
#     deviates most from circular. Fixed by making ring[0] the socket's
#     OWN real loop (socket_info["world_positions"], added to
#     _get_boundary_loop_info's return value for this), scaled by a single
#     uniform factor toward the component's average radius - preserves the
#     real loop's actual shape (safe: a uniform 2D scale of an
#     already-simple closed curve about its own centroid can't introduce
#     self-intersection) instead of discarding it for a circle. Rings
#     1..N-1 stay synthetic circles - by ring 1 the socket->ring[0] bridge
#     has already regularised the shape, so a circle is a reasonable
#     idealisation for the rest of the taper. Also required generalising
#     _bridge_chain's ring_loop tracking from the RING_VERT_COUNT constant
#     to len(ring_pts), since ring[0] now has however many vertices the
#     real socket loop has, not RING_VERT_COUNT.
#
# 13. SOCKET_OPENING_EXTENSION_PCT WAS A SINGLE FIXED CONSTANT REGARDLESS OF
#     GEOMETRY (v1.19.2): a flat 20% either removes too much wall on a
#     small/centred diff (weakening the socket for no benefit) or too
#     little on a large/offset one (not enough coverage to actually close
#     the gap fix #11/#12 target). Fixed by _compute_extension_pct(),
#     driven by how much smaller the component is than the socket
#     (diff_term) and how far it's laterally offset (offset_term), added
#     to a 0.10 base and clamped to [0.10, 0.35]. Computed from a
#     PRELIMINARY loop analysis (socket_info_prelim/comp_info) taken right
#     after the socket's distal opening and the component's top are both
#     established but BEFORE the socket is extended - the socket's own
#     boundary loop changes shape once extended, so the pct calculation
#     needs the pre-extension starting geometry, not a self-referential
#     post-extension one. _extend_socket_opening's existing
#     extension_pct=SOCKET_OPENING_EXTENSION_PCT default already supported
#     an explicit override with no signature change needed.
#
# 14. RING COUNT ONLY CONSIDERED DIAMETER DIFFERENCE, NOT OFFSET (v1.19.2):
#     a 20mm lateral offset needs more intermediate geometry to blend
#     gracefully than a centred component with the same diameter diff, but
#     _adaptive_ring_count() never saw the offset distance at all. Fixed
#     by adding an offset_mm parameter (+1 ring past 10mm offset, +2 past
#     20mm), computed in _build_bridge from the same socket_info/comp_info
#     centres fix #11 already interpolates rings between.
#
# 15. RING[0] PRESERVED THE REAL SOCKET LOOP'S OWN MM-SCALE SURFACE NOISE,
#     NOT JUST ITS REAL SHAPE (v1.19.3): fix #12 made ring[0] the socket's
#     actual boundary loop instead of a synthetic circle, to preserve its
#     real large-scale (many-vertices-apart) asymmetry. Only found by
#     actually rendering the result (a real user reported "deformed"/wavy
#     geometry that every boundary-edge/manifold/degenerate-face check
#     kept missing, since none of those measure "looks lumpy"): using the
#     RAW real loop verbatim also preserved the socket scan's own
#     adjacent-vertex-scale wobble into ring[0], producing a visibly wavy
#     transition surface despite being perfectly watertight.
#     _smooth_bridge_region's existing Laplacian pass wasn't strong enough
#     to remove it either. Fixed by _smooth_loop_xy() - a circular
#     moving-average low-pass filter applied to the real loop's XY
#     positions (never Z, never vertex count/order) before scaling them
#     into ring[0] - measured directly to cut adjacent-vertex XY deviation
#     from ~0.75mm average to ~0.08mm while leaving the loop's real
#     large-scale shape (the actual asymmetry fix #12 exists to preserve)
#     untouched.
#
# 16. RING COUNT'S OFFSET BONUS (FIX #14) USED FLAT MM THRESHOLDS, MEANING-
#     LESS WITHOUT KNOWING THE SOCKET'S OWN SIZE (v1.19.3): found by
#     reproducing an actual real user's pre-bridge socket plus a
#     deliberately large offset and rendering the result, not by any
#     topology check (the mesh stayed watertight throughout - the defect
#     is a shape problem, not a hole). 20mm is a huge fraction of a real
#     transtibial socket's ~50-60mm opening radius (measured directly from
#     the real case) but negligible for a larger one. At offset=99mm on a
#     real socket with radius=60.1mm (offset > radius - the component's
#     centre sits outside the socket's own opening), fix #14 still only
#     granted 7 rings (its effective cap), and the result showed severe
#     tearing: individual ring-to-ring bridge segments become extremely
#     lopsided (compressed on the near side toward the socket, stretched
#     thin on the far side) when the offset is large relative to the
#     socket's radius, and 7 rings isn't enough steps to keep any single
#     segment's lopsidedness small. Fixed by making the offset bonus scale
#     with offset_mm/socket_r (a dimensionless ratio meaningful across any
#     socket size) instead of flat mm thresholds. A first multiplier of 12
#     (20 rings on the real ratio~1.65 case) visibly reduced but did not
#     fully eliminate the tearing - a small torn patch remained on the
#     near side, again only visible by re-rendering. Multiplier 22 (41
#     rings on the same case) was verified to remove the remaining patch
#     entirely. Capped at +45 rings so a truly pathological ratio can't
#     produce an unbounded ring count.

import bpy
import bmesh
import math
import os
from bpy.types import Operator
from bpy.props import StringProperty
from mathutils import Vector

try:
    from ..analytics.collector import record_event
except ImportError:
    def record_event(*_args, **_kwargs):
        return None


def _get_components_folder():
    return os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "components")


MERGE_THRESHOLD_MM = 1.0          # mm-space (see fix #4 above)
TOP_FACE_Z_TOLERANCE_MM = 3.0     # how thick a "flat top" band counts as the component's top
TOP_FACE_NORMAL_Z_MIN = 0.5       # matches the historical auto-detect-face normal.z threshold family
SOCKET_DISTAL_Z_TOLERANCE_MM = 10.0   # how thick a "distal cap" band counts as the socket's tip
SOCKET_DISTAL_NORMAL_Z_MAX = -0.3     # downward-facing normal threshold for the distal cap
SOCKET_OPENING_EXTENSION_PCT = 0.20   # fraction of socket height dissolved above the distal
                                       # opening (see fix #10) so the bridge attaches further
                                       # up the wall instead of right at the tip

RING_VERT_COUNT = 64  # consistent vertex count for every synthetic transition ring

# Per-profile transition parameters (SPEC_component_bridge_parametric_transition.md
# Section 2, kept as authored - only the geometry-construction code around
# these was redesigned, see fix #7 above).
PROFILE_PARAMS = {
    'SMOOTH_FILLET': {
        "curve":         "SMOOTH",
        "rings_small":   3,
        "rings_medium":  5,
        "rings_large":   8,
        "collar_width":  0.0,
        "smooth_passes": 5,
        "smooth_factor": 0.5,
        "fillet_radius": 3.0,
    },
    'STANDARD': {
        "curve":         "EASE",
        "rings_small":   2,
        "rings_medium":  4,
        "rings_large":   6,
        "collar_width":  0.0,
        "smooth_passes": 3,
        "smooth_factor": 0.4,
        "fillet_radius": 1.5,
    },
    'STRAIGHT_TAPER': {
        "curve":         "LINEAR",
        "rings_small":   2,
        "rings_medium":  3,
        "rings_large":   4,
        "collar_width":  0.0,
        "smooth_passes": 1,
        "smooth_factor": 0.3,
        "fillet_radius": 0.0,
    },
    'CURVED_TAPER': {
        "curve":         "EASE_IN",
        "rings_small":   3,
        "rings_medium":  5,
        "rings_large":   7,
        "collar_width":  0.0,
        "smooth_passes": 3,
        "smooth_factor": 0.4,
        "fillet_radius": 1.0,
    },
    'REINFORCED_COLLAR': {
        "curve":         "SMOOTH",
        "rings_small":   4,
        "rings_medium":  6,
        "rings_large":   8,
        "collar_width":  5.0,
        "smooth_passes": 4,
        "smooth_factor": 0.45,
        "fillet_radius": 4.0,
    },
    'PEDIATRIC': {
        "curve":         "SMOOTH",
        "rings_small":   3,
        "rings_medium":  4,
        "rings_large":   5,
        "collar_width":  0.0,
        "smooth_passes": 6,
        "smooth_factor": 0.55,
        "fillet_radius": 4.0,
    },
    'HEAVY_DUTY': {
        "curve":         "EASE_OUT",
        "rings_small":   4,
        "rings_medium":  6,
        "rings_large":   9,
        "collar_width":  8.0,
        "smooth_passes": 2,
        "smooth_factor": 0.3,
        "fillet_radius": 2.0,
    },
}


def _curve_t(t, curve_type):
    """
    Map t in [0,1] through the specified interpolation curve.
    Returns a value in [0,1] representing the diameter fraction
    at this position along the transition.

    t=0 -> socket end (large), t=1 -> component end (small).
    """
    if curve_type == 'LINEAR':
        return t
    elif curve_type == 'SMOOTH':
        return t * t * (3 - 2 * t)  # smoothstep
    elif curve_type == 'EASE_IN':
        return t * t
    elif curve_type == 'EASE_OUT':
        return 1 - (1 - t) * (1 - t)
    elif curve_type == 'EASE':
        if t < 0.5:
            return 4 * t * t * t
        p = 2 * t - 2
        return 0.5 * p * p * p + 1
    return t  # fallback: linear


def _get_boundary_loop_info(obj):
    """
    Find the (largest) boundary loop on obj, return centre/radius/Z-average/
    vertex-index-list. Same adjacency-walk technique already proven in
    _close_minor_holes above (module docstring fix #7 - implemented
    separately here since it returns different info: centroid/radius/Z, not
    just which loops to fill). Returns None if no boundary loop is found.
    """
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()

    boundary_edges = [e for e in bm.edges if e.is_boundary]
    if not boundary_edges:
        bm.free()
        return None

    adj = {}
    for e in boundary_edges:
        v0, v1 = e.verts[0].index, e.verts[1].index
        adj.setdefault(v0, []).append(v1)
        adj.setdefault(v1, []).append(v0)

    visited = set()
    loops = []
    for start in adj:
        if start in visited:
            continue
        loop = []
        current, prev = start, None
        while True:
            visited.add(current)
            loop.append(current)
            neighbors = [n for n in adj[current] if n != prev and n not in visited]
            if not neighbors:
                break
            prev, current = current, neighbors[0]
        if len(loop) >= 3:
            loops.append(loop)

    if not loops:
        bm.free()
        return None

    loop_indices = max(loops, key=len)
    if len(loop_indices) < 4:
        bm.free()
        return None

    positions = [obj.matrix_world @ bm.verts[i].co for i in loop_indices]
    centre = sum(positions, Vector()) / len(positions)
    radius = sum((p - centre).length for p in positions) / len(positions)
    z_avg = sum(p.z for p in positions) / len(positions)

    bm.free()
    return {
        "centre":          centre,
        "radius":          radius,
        "z_avg":           z_avg,
        "vert_count":      len(loop_indices),
        "vert_indices":    loop_indices,
        "world_positions": positions,   # same order as vert_indices - see fix #12
    }


def _adaptive_ring_count(diameter_diff_mm, params, offset_mm=0.0, socket_r=None):
    """Choose number of intermediate rings based on diameter difference
    AND component offset distance - an offset transition needs more
    geometry to blend gracefully without visible stretching than a
    centred one with the same diameter diff (see module docstring
    fix #14).

    Real bug found and fixed (fix #16), not caught by any topology check -
    only by reproducing a real user's actual pre-bridge socket + a
    deliberately large offset and rendering the result: fix #14's flat
    offset_mm thresholds (+1 past 10mm, +2 past 20mm) are meaningless
    without knowing the socket's own size - 20mm is a huge fraction of a
    real transtibial socket's ~50-60mm opening radius (as measured
    directly from a real user-submitted case) but negligible for a much
    larger one. Verified directly: at offset=99mm on a REAL socket with
    radius=60.1mm (offset > radius, i.e. the component's centre sits
    outside the socket's own opening), fix #14's formula still only
    granted 7 rings (its cap), and the result showed severe visible
    tearing - individual ring-to-ring bridge segments become extremely
    lopsided (compressed on the near side toward the socket, stretched
    thin on the far side) when the offset is large relative to the
    socket's radius, and 7 rings isn't enough steps to keep any single
    segment's lopsidedness small. Fixed by making the offset bonus scale
    with offset_mm/socket_r (a dimensionless ratio meaningful across any
    socket size) instead of flat mm thresholds. A first multiplier of 12
    (20 rings on the real ratio~1.65 case) visibly reduced but did not
    fully eliminate the tearing - a small torn patch remained on the near
    side; only found by re-rendering, not by the boundary-edge/watertight
    check, which passed at every multiplier tried since the mesh was
    never actually open. Multiplier 22 (41 rings on the same case) was
    verified to remove the remaining patch entirely. Capped at +45 rings
    so a truly pathological ratio can't produce an unbounded ring count."""
    if diameter_diff_mm < 20.0:
        base = params["rings_small"]
    elif diameter_diff_mm < 50.0:
        base = params["rings_medium"]
    else:
        base = params["rings_large"]

    if socket_r and socket_r > 1.0:
        offset_ratio = offset_mm / socket_r
        extra = min(round(offset_ratio * 22), 45)
    else:
        extra = 0

    return base + extra


def _open_socket_distal(obj):
    """Ensure the socket has an open boundary loop at its distal (lowest Z)
    end, opening it first if needed (see module docstring fix #6 — a real
    finished DynaX socket is commonly fully closed there). Mutates obj.data
    if a cap needs opening. Returns True on success, False if there's nothing
    to work with."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()

    if any(e.is_boundary for e in bm.edges):
        # Already has an opening somewhere (assumed to be the distal end).
        bm.free()
        return True

    bm.faces.ensure_lookup_table()
    bm.normal_update()
    if not bm.faces:
        bm.free()
        return False

    min_z = min(v.co.z for v in bm.verts)

    def face_avg_z(f):
        return sum(v.co.z for v in f.verts) / len(f.verts)

    cap_faces = [
        f for f in bm.faces
        if f.normal.z < SOCKET_DISTAL_NORMAL_Z_MAX
        and (face_avg_z(f) - min_z) <= SOCKET_DISTAL_Z_TOLERANCE_MM
    ]
    if not cap_faces:
        # Relax to "close to min Z" regardless of normal, matching
        # _open_component_top's own fallback for oddly-modeled geometry.
        cap_faces = [f for f in bm.faces if (face_avg_z(f) - min_z) <= SOCKET_DISTAL_Z_TOLERANCE_MM]
    if not cap_faces:
        bm.free()
        return False

    # FACES_KEEP_BOUNDARY, not FACES_ONLY (fix #9 below) - deletes the cap
    # faces AND their now-orphaned INTERIOR edges/verts, while explicitly
    # preserving the boundary loop intact.
    bmesh.ops.delete(bm, geom=cap_faces, context='FACES_KEEP_BOUNDARY')
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    return True


def _open_component_top(obj):
    """Find the component's flat top (every face within Z-tolerance of the
    max-Z point with an upward-facing normal — NOT a single face; see module
    docstring fix #1), delete all of them together. Mutates obj.data (writes
    the modified mesh back). Returns True on success, False if no faces were
    found to open."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.faces.ensure_lookup_table()
    bm.verts.ensure_lookup_table()
    bm.normal_update()

    if not bm.faces:
        bm.free()
        return False

    max_z = max(v.co.z for v in bm.verts)

    def face_avg_z(f):
        return sum(v.co.z for v in f.verts) / len(f.verts)

    top_faces = [
        f for f in bm.faces
        if f.normal.z > TOP_FACE_NORMAL_Z_MIN
        and (max_z - face_avg_z(f)) <= TOP_FACE_Z_TOLERANCE_MM
    ]
    if not top_faces:
        # Relax to "close to max Z" regardless of normal, matching the
        # historical auto-detect-face fallback for oddly-modeled components.
        top_faces = [f for f in bm.faces if (max_z - face_avg_z(f)) <= TOP_FACE_Z_TOLERANCE_MM]
    if not top_faces:
        bm.free()
        return False

    # FACES_KEEP_BOUNDARY, not FACES_ONLY - see _open_socket_distal's
    # matching comment and module docstring fix #9.
    bmesh.ops.delete(bm, geom=top_faces, context='FACES_KEEP_BOUNDARY')

    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    return True


def _close_minor_holes(obj):
    """Fill every boundary loop on obj.data except the largest one.

    _open_socket_distal / _open_component_top assume the object has exactly
    one boundary loop after opening (the intended distal/top opening). Real
    solidified sockets commonly have additional small boundary loops from
    seam gaps left by the thickness pass — select_non_manifold() picks those
    up too once the two objects are joined, and feeding bridge_edge_loops()
    more than two loops produces a degenerate "exploded spike" mesh instead
    of a clean connection (this is what actually crashed the Components
    step). Keeping only the largest loop open per-object here guarantees
    exactly two loops remain by the time socket_dup and comp_dup are joined.
    """
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.edges.ensure_lookup_table()
    bm.verts.ensure_lookup_table()

    boundary_edges = [e for e in bm.edges if e.is_boundary]
    if not boundary_edges:
        bm.free()
        return

    adj = {}
    for e in boundary_edges:
        v0, v1 = e.verts[0].index, e.verts[1].index
        adj.setdefault(v0, []).append(v1)
        adj.setdefault(v1, []).append(v0)

    visited = set()
    loops = []
    for start in adj:
        if start in visited:
            continue
        loop = []
        current, prev = start, None
        while True:
            visited.add(current)
            loop.append(current)
            neighbors = [n for n in adj[current] if n != prev and n not in visited]
            if not neighbors:
                break
            prev, current = current, neighbors[0]
        if len(loop) >= 3:
            loops.append(loop)

    if len(loops) <= 1:
        bm.free()
        return

    loops.sort(key=len, reverse=True)
    for loop in loops[1:]:
        loop_verts = set(loop)
        loop_edges = [
            e for e in boundary_edges
            if e.verts[0].index in loop_verts and e.verts[1].index in loop_verts
        ]
        if loop_edges:
            bmesh.ops.holes_fill(bm, edges=loop_edges, sides=0)

    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    print(f"[DynaX Bridge] Closed {len(loops) - 1} minor hole(s) on {obj.name}, kept the largest opening")


def _compute_extension_pct(socket_info, comp_info):
    """
    Calculate how far up the socket wall to extend the opening, driven by
    actual geometry rather than the fixed SOCKET_OPENING_EXTENSION_PCT
    (see module docstring fix #13 for why this exists and what changed vs.
    the original spec's version).

    Formula components:
    - base:        minimum extension to always get some wall coverage
    - diff_term:   more extension when component is much smaller than socket
                   (larger taper = more wall needed to blend gracefully)
    - offset_term: more extension when component is laterally offset
                   (offset side needs more coverage to close the gap)

    Clamped to [0.10, 0.35] so it never removes too little or too much of
    the socket wall regardless of extreme geometry.
    """
    socket_r = socket_info["radius"]
    comp_r   = comp_info["radius"]

    if socket_r < 1.0:
        return 0.15  # degenerate case fallback

    diff_r = max(socket_r - comp_r, 0.0)
    diff_term = (diff_r / socket_r) * 0.15

    socket_ctr = socket_info["centre"]
    comp_ctr   = comp_info["centre"]
    offset_dist = math.sqrt(
        (comp_ctr.x - socket_ctr.x) ** 2 +
        (comp_ctr.y - socket_ctr.y) ** 2
    )
    offset_term = (offset_dist / socket_r) * 0.10

    base = 0.10
    pct = base + diff_term + offset_term
    pct = max(0.10, min(0.35, pct))

    print(f"[DynaX Bridge] Geometry-driven extension: "
          f"base={base:.2f} diff={diff_term:.2f} offset={offset_term:.2f} "
          f"-> {pct:.2f} ({pct*100:.0f}% of socket height)")
    return pct


def _extend_socket_opening(obj, extension_pct=SOCKET_OPENING_EXTENSION_PCT):
    """Enlarge the socket's distal opening by dissolving wall faces above
    it, up to extension_pct of socket height, so the bridge/rings attach
    higher up the wall instead of right at the tip (see module docstring
    fix #10). Must run after _open_socket_distal/_close_minor_holes, when
    there's exactly one boundary loop to extend from. Mutates obj.data.
    No-op if the object has no boundary or faces.

    Selects the region to remove by flooding OUTWARD FROM THE CURRENT
    BOUNDARY LOOP, staying below the Z threshold - not a blanket Z-band
    over the whole mesh. A solidified socket has two wall layers (outer +
    inner); the inner wall's own distal tip is still fully closed at this
    point (only the outer wall has been opened so far). A blanket Z-band
    delete would remove faces on BOTH layers, silently punching an
    unwanted second hole in the still-closed inner wall - verified headless
    on a synthetic double-walled socket: a plain Z-band delete left 2
    separate boundary loops (64 edges) instead of 1 enlarged loop. The
    flood-fill only ever touches faces reachable from the already-open
    boundary, so a separate closed surface nearby is never disturbed -
    verified against the same synthetic mesh: exactly 1 boundary loop
    remains, 0 orphaned wire edges."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    boundary_edges = [e for e in bm.edges if e.is_boundary]
    if not boundary_edges or not bm.faces:
        bm.free()
        return

    z_min = min(v.co.z for v in bm.verts)
    z_max = max(v.co.z for v in bm.verts)
    extension_z = z_min + (z_max - z_min) * extension_pct

    def face_avg_z(f):
        return sum(v.co.z for v in f.verts) / len(f.verts)

    start_faces = set()
    for e in boundary_edges:
        start_faces.update(e.link_faces)

    to_remove = {f for f in start_faces if face_avg_z(f) < extension_z}
    frontier = list(to_remove)
    while frontier:
        next_frontier = []
        for f in frontier:
            for e in f.edges:
                for nf in e.link_faces:
                    if nf not in to_remove and face_avg_z(nf) < extension_z:
                        to_remove.add(nf)
                        next_frontier.append(nf)
        frontier = next_frontier

    if to_remove and len(to_remove) < len(bm.faces):
        # context='FACES', not 'FACES_KEEP_BOUNDARY' (contrast fix #9 above)
        # - here the removed region touches the PRE-EXISTING boundary loop
        # on purpose (that's what "extend" means), and FACES_KEEP_BOUNDARY
        # preserves edges that were already boundary before the delete even
        # once their only face is gone, leaving them as orphaned wire
        # debris. Verified headless: 'FACES_KEEP_BOUNDARY' left 32 wire
        # edges from the old loop; plain 'FACES' cleans them up, 0 debris.
        bmesh.ops.delete(bm, geom=list(to_remove), context='FACES')
        bm.to_mesh(obj.data)
        print(f"[DynaX Bridge] Extended socket opening to Z={extension_z:.1f}mm "
              f"({len(to_remove)} faces removed)")

    bm.free()
    obj.data.update()


def _smooth_loop_xy(positions, centre, passes=3, window=3):
    """Circular moving-average smooth of a closed loop's XY positions (Z and
    the loop's own vertex order/count are untouched) - a low-pass filter
    that removes mm-scale scan noise while preserving the loop's real,
    large-scale (many-vertices-apart) shape. See module docstring fix #15
    for why this exists: fix #12 preserved the RAW real socket loop
    verbatim for ring[0], which turned out to also preserve the scan's own
    high-frequency surface noise into the bridge, producing a visibly
    wavy/jagged transition - confirmed by actually rendering the result,
    not just checking watertightness (topology checks can't detect
    "looks lumpy"). Deliberately only smooths XY (never Z, never vertex
    count/order), so it can't affect _bridge_chain's ring_loop tracking or
    reintroduce fix #9-class debris."""
    n = len(positions)
    if n < 3 or window < 1:
        return list(positions)

    xy = [(p.x, p.y) for p in positions]
    for _ in range(passes):
        smoothed = []
        for i in range(n):
            sx = sy = 0.0
            count = 0
            for k in range(-window, window + 1):
                x, y = xy[(i + k) % n]
                sx += x
                sy += y
                count += 1
            smoothed.append((sx / count, sy / count))
        xy = smoothed

    return [Vector((x, y, p.z)) for (x, y), p in zip(xy, positions)]


def _generate_transition_rings(socket_info, comp_info, n_rings, curve_type, collar_width_mm):
    """
    Generate N intermediate ring vertex-position lists between the socket
    opening and the component opening (SPEC Section 5, kept as authored -
    only how these rings get turned into geometry/bridged was redesigned,
    see fix #7). Rings 1..N-1 have RING_VERT_COUNT vertices, evenly spaced
    around a circle at the interpolated diameter and Z height.

    Real bug found and fixed (v1.18.2), not caught by reading this code -
    only by measuring actual ring positions against a deliberately offset
    component: every ring's XY centre used socket_info["centre"] alone, so
    ALL n_rings stayed pinned to the socket's own centroid regardless of t,
    never actually moving toward the component. Real components aren't
    always perfectly centred under the socket's own geometric centroid
    (the residual limb's load axis and the socket's outer-wall centroid
    aren't the same thing) - verified end-to-end against the real bundled
    SOCKET_COMPONENT.stl deliberately offset 25mm in X: every one of 8
    rings, including the LAST one (t~=0.89, meant to be nearly at the
    component), measured 31.3mm from the component's own boundary-loop
    centroid - the final ring-to-component bridge (_bridge_two_loops) had
    to span that entire lateral gap in one step, producing far more
    skewed/strained connecting geometry than the radius taper alone
    explains. Fixed by interpolating XY centre from the socket's centroid
    to the component's own centroid (comp_info["centre"], already the real
    boundary-loop centroid - see _get_boundary_loop_info) using the same
    linear t as Z, so the last ring actually approaches the component's
    true position instead of the socket's.

    Real bug found and fixed (v1.19.1): ring[0] was ALSO a synthetic
    perfect circle (radius = socket_r, i.e. the socket's AVERAGE radius),
    even though a real socket's boundary loop is never actually circular.
    Measured directly against the real bundled reference socket: the real
    opened distal loop deviates -5.7mm to +9.1mm from its own average
    radius (14.8mm peak-to-peak), i.e. up to 9mm between a real loop vertex
    and where a same-angle point on the "equivalent" circle would sit. The
    socket->ring[0] bridge was therefore always bridging a genuinely
    irregular real loop straight to an idealised circle, which can pinch
    or gap-looking at whichever points deviate most from circular - not a
    watertightness bug (bridge_edge_loops already handles mismatched loop
    shapes/counts robustly - see fix #2/#7), but a real shape-fidelity one.
    Fixed by making ring[0] the socket's OWN real loop, scaled by a single
    uniform factor toward the component's average radius (preserves the
    real loop's shape - no self-intersection risk since a uniform 2D scale
    of an already-simple closed curve about its own centroid stays simple)
    instead of discarding its shape for a circle. Rings 1..N-1 stay
    synthetic circles - once the socket->ring[0] bridge has regularised the
    shape by ring 1, a circle is a reasonable idealisation for the rest of
    the taper.

    Real bug found and fixed (fix #15), not caught by any topology check -
    only by actually rendering the result: using the RAW real loop
    verbatim preserves the socket scan's own mm-scale surface noise into
    ring[0], not just its real large-scale shape, producing a visibly
    wavy/jagged transition surface even though the mesh is still perfectly
    watertight and manifold (confirmed screenshots from real use showed
    this; boundary-edge/manifold/degenerate-face checks all pass regardless
    of how lumpy the surface looks - "watertight" and "smooth-looking" are
    unrelated properties). _smooth_bridge_region's existing Laplacian pass
    (5 passes, factor 0.5) wasn't enough to remove it either. Fixed by
    _smooth_loop_xy() - a circular moving-average low-pass filter applied
    to the real loop's positions BEFORE scaling them into ring[0] - which
    removes adjacent-vertex-scale noise while preserving the loop's real,
    many-vertices-apart shape (the actual ±15mm-scale asymmetry fix #12 was
    added to preserve in the first place).
    """
    socket_r  = socket_info["radius"]
    comp_r    = comp_info["radius"] + (collar_width_mm / 2.0)
    socket_z  = socket_info["z_avg"]
    comp_z    = comp_info["z_avg"]
    socket_ctr = socket_info["centre"]
    comp_ctr   = comp_info["centre"]
    socket_world_positions = socket_info.get("world_positions")
    if socket_world_positions:
        socket_world_positions = _smooth_loop_xy(socket_world_positions, socket_ctr)

    rings = []
    for i in range(n_rings):
        t = (i + 1) / (n_rings + 1)
        t_curved = _curve_t(t, curve_type)

        z = socket_z + t * (comp_z - socket_z)
        centre_x = socket_ctr.x + t * (comp_ctr.x - socket_ctr.x)
        centre_y = socket_ctr.y + t * (comp_ctr.y - socket_ctr.y)

        if i == 0 and socket_world_positions:
            scale = 1.0 - t_curved * (1.0 - comp_r / max(socket_r, 0.01))
            ring_pts = []
            for pos in socket_world_positions:
                offset_x = (pos.x - socket_ctr.x) * scale
                offset_y = (pos.y - socket_ctr.y) * scale
                ring_pts.append(Vector((centre_x + offset_x, centre_y + offset_y, z)))
        else:
            radius = socket_r + t_curved * (comp_r - socket_r)
            ring_pts = []
            for j in range(RING_VERT_COUNT):
                angle = 2 * math.pi * j / RING_VERT_COUNT
                x = centre_x + radius * math.cos(angle)
                y = centre_y + radius * math.sin(angle)
                ring_pts.append(Vector((x, y, z)))

        rings.append(ring_pts)

    return rings


def _make_wire_ring_object(name, ring_pts):
    """Build a standalone object containing ONLY a closed loop of edges (zero
    faces) at the given points - a bmesh 'wire' loop."""
    bm = bmesh.new()
    verts = [bm.verts.new(p) for p in ring_pts]
    bm.verts.ensure_lookup_table()
    n = len(verts)
    for i in range(n):
        bm.edges.new((verts[i], verts[(i + 1) % n]))

    mesh = bpy.data.meshes.new(name)
    bm.to_mesh(mesh)
    bm.free()
    obj = bpy.data.objects.new(name, mesh)
    return obj


def _loop_edge_pairs(ordered_indices):
    """Return the exact set of {v_i, v_i+1} edge pairs (as frozensets) for a
    CLOSED loop given in walk order - see fix #9's docstring for why "any
    edge whose both endpoints happen to lie somewhere in the loop's vertex
    set" is NOT the same thing and is unsafe on real geometry."""
    n = len(ordered_indices)
    return {frozenset((ordered_indices[i], ordered_indices[(i + 1) % n])) for i in range(n)}


def _bridge_two_loops(working_obj, loop_a_ordered, loop_b_ordered):
    """Select EXACTLY the edges belonging to the two given loops (each an
    ORDERED, walk-order vertex sequence - see _loop_edge_pairs) and bridge
    them.

    Real bug found and fixed (2026-07-07, real GUI report, two layers):

    1. The first version of this function used select_non_manifold(
       use_wire=True, use_boundary=True) to find "the current 2 open loops"
       instead of selecting by known vertex identity. Verified directly this
       is NOT safe on real geometry: a single deliberate stray wire edge
       added anywhere else on a synthetic test socket (simulating debris a
       real, processed/solidified DynaX socket plausibly has - seam gaps,
       degenerate slivers) reproduced the exact real failure ("Expected
       exactly 2 open loops to bridge but found 3") on the very first ring
       bridge - select_non_manifold(use_wire=True) is a GLOBAL scan of the
       whole mesh, so ANY unrelated non-manifold edge anywhere else gets
       swept in too.

    2. Fixing #1 by selecting "both endpoints in the same loop's vertex
       INDEX SET" (not select_non_manifold) removed the crash but still left
       the real bundled SOCKET_COMPONENT.stl non-watertight (~230-260
       leftover non-manifold edges every profile). Root cause (see fix #9):
       _open_component_top's bmesh.ops.delete(..., context='FACES_ONLY')
       deletes only the face data-blocks, leaving the deleted patch's
       INTERIOR edges behind as orphaned wire debris - and on a real,
       non-trivially-shaped opening, some of those interior debris edges
       have BOTH endpoints coincidentally on the true boundary loop (a
       direct chord across the hole), which a plain "both endpoints in set"
       test cannot distinguish from a genuine loop edge. Fixed at the
       source (fix #9, FACES_KEEP_BOUNDARY instead of FACES_ONLY) AND
       defensively here: selecting by EXACT edge-pair identity (consecutive
       vertices in the loop's own known walk order) can never match a chord
       edge, regardless of what debris exists elsewhere in the mesh."""
    edge_pairs = _loop_edge_pairs(loop_a_ordered) | _loop_edge_pairs(loop_b_ordered)

    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(type='EDGE')
    bpy.ops.mesh.select_all(action='DESELECT')

    bm = bmesh.from_edit_mesh(working_obj.data)
    bm.edges.ensure_lookup_table()
    selected_count = 0
    for e in bm.edges:
        pair = frozenset((e.verts[0].index, e.verts[1].index))
        if pair in edge_pairs:
            e.select = True
            selected_count += 1
    bmesh.update_edit_mesh(working_obj.data)

    if selected_count == 0:
        bpy.ops.object.mode_set(mode='OBJECT')
        raise RuntimeError("No edges found for the two loops to bridge.")

    result = bpy.ops.mesh.bridge_edge_loops(
        type='CLOSED',
        use_merge=False,
        merge_factor=0.5,
        twist_offset=0,
        number_cuts=0,
        interpolation='SURFACE',  # NOT the spec's invalid 'BLEND' - see fix #7
        smoothness=1.0,
        profile_shape_factor=0.0,
    )
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.normals_make_consistent(inside=False)
    bpy.ops.object.mode_set(mode='OBJECT')

    if 'FINISHED' not in result:
        raise RuntimeError(f"bridge_edge_loops did not complete (result={result}).")


def _bridge_chain(context, socket_dup, comp_dup, rings, socket_loop_indices, comp_loop_indices):
    """
    Sequentially bridge socket_dup -> ring[0] -> ring[1] -> ... ->
    ring[N-1] -> comp_dup, one adjacent pair at a time (see module docstring
    fix #7 for why this replaces a single bulk multi-loop bridge call).

    socket_loop_indices / comp_loop_indices are socket_dup's / comp_dup's OWN
    boundary loop's LOCAL vertex indices (from _get_boundary_loop_info,
    called on each BEFORE this function ever joins anything - join() only
    appends new vertices after existing ones, verified directly, so
    socket_dup's own indices never change, and comp_dup's need only a fixed
    offset once it's finally joined in - see fix #8 below for why these are
    passed in explicitly rather than re-detected here).

    Returns (working_obj, bridge_vert_indices) where bridge_vert_indices is
    the set of vertex indices in the FINAL mesh belonging to the synthetic
    transition rings ONLY - tracked directly during construction (each
    ring's vertex range is known exactly when it's created) rather than
    re-derived from a Z-range heuristic, for _smooth_bridge_region.

    Deliberately does NOT include socket_dup's or comp_dup's own vertices in
    this set, even though they're also touched by the two end bridges - the
    component has fixed manufactured dimensions that must not be distorted
    (module docstring fix #3) and the socket's real geometry should only be
    smoothed by an explicit, separate, narrowly-scoped step if ever asked
    for - the rings themselves (fully synthetic, S-curve-interpolated) are
    where the "ribs" this feature targets actually come from.
    """
    working = socket_dup
    bridge_vert_indices = set()
    # ORDERED sequences throughout (not sets) - _bridge_two_loops needs the
    # walk order to reconstruct each loop's exact edge pairs (fix #9's
    # defensive layer); a plain vertex-index set can't distinguish a real
    # loop edge from a chord that happens to connect two set members.
    current_loop = list(socket_loop_indices)

    for i, ring_pts in enumerate(rings):
        ring_obj = _make_wire_ring_object(f"dynax_bridge_ring_{i}", ring_pts)
        context.collection.objects.link(ring_obj)

        # Captured BEFORE the join: the ring's own RING_VERT_COUNT vertices
        # will land at exactly [pre_join_count, pre_join_count+RING_VERT_COUNT)
        # in the joined mesh (join() appends each source object's vertices
        # in order, after the active object's existing ones) - this is the
        # ONLY thing tracked as a "bridge vert" (see docstring above; NOT the
        # bridge_edge_loops face-strip vertices either, since with
        # number_cuts=0/use_merge=False it reuses the two loops' existing
        # vertices and creates no new ones of its own).
        pre_join_count = len(working.data.vertices)

        bpy.ops.object.select_all(action='DESELECT')
        ring_obj.select_set(True)
        working.select_set(True)
        context.view_layer.objects.active = working
        bpy.ops.object.join()

        # _make_wire_ring_object creates verts in exactly this cyclic order
        # (index 0..len(ring_pts)-1), so this offset range IS the ring's
        # walk order, not just its membership set. len(ring_pts), not the
        # RING_VERT_COUNT constant (v1.19.1 fix #12) - ring[0] is the real
        # socket loop's own vertex count when scaled from real geometry,
        # not the synthetic-circle count every other ring uses.
        ring_loop = list(range(pre_join_count, pre_join_count + len(ring_pts)))
        bridge_vert_indices.update(ring_loop)

        _bridge_two_loops(working, current_loop, ring_loop)

        # The ring's own vertices are now the new open boundary (the far
        # side of the just-completed bridge) - same indices, just now
        # boundary-type instead of wire-type.
        current_loop = ring_loop

    pre_join_count = len(working.data.vertices)
    bpy.ops.object.select_all(action='DESELECT')
    comp_dup.select_set(True)
    working.select_set(True)
    context.view_layer.objects.active = working
    bpy.ops.object.join()

    # comp_loop_indices is comp_dup's OWN walk-order list (from
    # _get_boundary_loop_info, called before this function ever ran) -
    # offset, preserving order, not just membership.
    comp_loop = [pre_join_count + local_idx for local_idx in comp_loop_indices]
    _bridge_two_loops(working, current_loop, comp_loop)

    return working, bridge_vert_indices


def _smooth_bridge_region(obj, bridge_vert_indices, smooth_passes, smooth_factor):
    """
    Apply Laplacian smoothing only to the tracked bridge/transition
    vertices (see _bridge_chain - NOT the spec's "top/bottom 15% of the
    whole mesh's Z range" heuristic, which breaks for asymmetric socket/
    component proportions - fix #7). Uses bmesh Laplacian smooth
    (volume-preserving).
    """
    if smooth_passes == 0 or not bridge_vert_indices:
        return

    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.verts.ensure_lookup_table()

    max_index = len(bm.verts) - 1
    bridge_verts = [bm.verts[i] for i in bridge_vert_indices if i <= max_index]
    if not bridge_verts:
        bm.free()
        return

    for _ in range(smooth_passes):
        bmesh.ops.smooth_laplacian_vert(
            bm,
            verts=bridge_verts,
            lambda_factor=smooth_factor,
            lambda_border=smooth_factor * 0.5,
            use_x=True, use_y=True, use_z=True,
            preserve_volume=True,
        )

    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    print(f"[DynaX Bridge] Smoothed {len(bridge_verts)} bridge verts "
          f"({smooth_passes} passes, factor={smooth_factor})")


def _duplicate_object(context, obj, name):
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    context.view_layer.objects.active = obj
    bpy.ops.object.duplicate()
    dup = context.view_layer.objects.active
    dup.name = name
    return dup


def _cleanup_temp(objects):
    for obj in objects:
        if obj and obj.name in bpy.data.objects:
            bpy.data.objects.remove(obj, do_unlink=True)


# ── Step 1: Load Component ────────────────────────────────────────────────────

class DynaxLoadComponent(Operator):
    """Load a component STL from the DynaX library, auto-positioned below the socket"""
    bl_idname = "dynax.load_component"
    bl_label = "Load Component"
    bl_description = "Import a prosthetic component from the DynaX library"
    bl_options = {'REGISTER', 'UNDO'}

    component_name: StringProperty(
        name="Component",
        description=("Component file, relative to the DynaX component library "
                     "(e.g. 'SOCKET_COMPONENT.stl' or 'feet/sach_foot.stl')"),
        default="",
    )

    def execute(self, context):
        if not self.component_name:
            self.report({'ERROR'}, "No component selected")
            return {'CANCELLED'}

        folder = _get_components_folder()
        # v1.20.8: the library is now category subfolders, so component_name is a
        # RELATIVE path, not a bare filename. It is normally supplied by the
        # library enum, but this is a plain StringProperty any caller can set, so
        # confirm the resolved path really is inside the library before opening
        # it - a '../..' value must never reach the importer.
        filepath = os.path.abspath(os.path.join(folder, self.component_name))
        library_root = os.path.abspath(folder)
        if os.path.commonpath([library_root, filepath]) != library_root:
            self.report({'ERROR'}, "Invalid component path")
            return {'CANCELLED'}
        if not os.path.exists(filepath):
            self.report({'ERROR'}, f"Component file not found: {filepath}")
            return {'CANCELLED'}

        # Capture the socket BEFORE importing changes what's active/selected.
        # Creator's socket is the active object; ParaFly (TT/TLSO/AFO) and
        # ParaForm host this same Components UI, so fall back to the workflow's
        # own working object (scene.paraforge_active_object) if the active object
        # isn't a valid socket — then make it active so the rest of this operator
        # (which reads `socket`) and the auto-position logic operate on it.
        socket = context.active_object
        if not socket or socket.type != 'MESH' or socket.get("dynax_is_component"):
            # Fall back to the workflow's working object: ParaFly sets
            # scene.paraforge_active_object; ParaForm records its finalized socket
            # in scene["dynax_bridge_socket_obj"]. Either way, re-activate it so
            # the rest of this operator (which reads `socket`) targets it.
            alt = getattr(context.scene, "paraforge_active_object", None)
            if not (alt and alt.type == 'MESH' and not alt.get("dynax_is_component")):
                name = context.scene.get("dynax_bridge_socket_obj")
                cand = bpy.data.objects.get(name) if name else None
                if cand and cand.type == 'MESH' and not cand.get("dynax_is_component"):
                    alt = cand
                else:
                    alt = None
            if alt is not None:
                socket = alt
                bpy.ops.object.select_all(action='DESELECT')
                socket.select_set(True)
                context.view_layer.objects.active = socket
            else:
                self.report({'ERROR'}, "Select the SOCKET object (not a component) before loading a component.")
                return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Remove any previously loaded component so re-loading starts fresh.
        existing = bpy.data.objects.get("dynax_component")
        if existing:
            bpy.data.objects.remove(existing, do_unlink=True)

        bpy.ops.object.select_all(action='DESELECT')
        ext = os.path.splitext(filepath)[1].lower()
        if ext == '.blend':
            comp = self._load_blend_component(context, filepath)
            if comp is None:
                self.report({'ERROR'}, "No mesh object found in component .blend")
                return {'CANCELLED'}
        else:
            try:
                bpy.ops.wm.stl_import(filepath=filepath)
            except AttributeError:
                try:
                    bpy.ops.import_mesh.stl(filepath=filepath)
                except Exception as e:
                    self.report({'ERROR'}, f"STL import failed: {e}")
                    return {'CANCELLED'}

            imported = context.selected_objects
            if not imported:
                self.report({'ERROR'}, "No object was imported")
                return {'CANCELLED'}
            comp = imported[0]
        comp.name = "dynax_component"
        comp["dynax_is_component"] = True

        # Children's-prosthesis scale (Section 5) — the ONLY sanctioned
        # resizing of the component (see module docstring fix #3). Applied
        # and baked before auto-positioning so the height/centre math below
        # uses the real (scaled) size.
        scale = getattr(context.scene, "dynax_component_scale", 1.0)
        if abs(scale - 1.0) > 1e-6:
            comp.scale = (scale, scale, scale)
            bpy.ops.object.select_all(action='DESELECT')
            comp.select_set(True)
            context.view_layer.objects.active = comp
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        # Auto-position: component top aligns with the socket's distal (lowest
        # Z) point, centred in XY on the socket's centroid.
        world_verts = [socket.matrix_world @ v.co for v in socket.data.vertices]
        min_z = min(v.z for v in world_verts)
        socket_centre = sum(world_verts, Vector()) / len(world_verts)

        comp_verts = [comp.matrix_world @ v.co for v in comp.data.vertices]
        comp_max_z = max(v.z for v in comp_verts)
        comp_centre = sum(comp_verts, Vector()) / len(comp_verts)

        # Relative deltas, not the spec's absolute assignment (comp.location.z
        # = min_z - comp_height, comp.location.x = socket_centre.x) — the
        # spec's absolute form is only correct if the component's local origin
        # happens to sit exactly at its own base/centroid, which isn't
        # guaranteed for an arbitrary imported STL. A delta added to the
        # CURRENT location works regardless of where the origin actually is,
        # and centres on the component's real mesh centroid rather than
        # wherever its origin happens to be.
        comp.location.z += (min_z - comp_max_z)
        comp.location.x += (socket_centre.x - comp_centre.x)
        comp.location.y += (socket_centre.y - comp_centre.y)

        comp.display_type = 'SOLID'
        comp.color = (0.2, 0.5, 1.0, 0.4)
        comp.show_transparent = True

        context.scene["dynax_bridge_socket_obj"] = socket.name
        context.scene.dynax_component_loaded = True
        context.scene.dynax_bridge_complete = False
        self.report({'INFO'}, f"Loaded component: {self.component_name}")
        return {'FINISHED'}

    def _load_blend_component(self, context, filepath):
        """Append the mesh object(s) from a .blend component library file and
        return a single selected, active mesh object (joined if the blend
        holds more than one mesh). Returns None if the blend has no mesh."""
        with bpy.data.libraries.load(filepath, link=False) as (data_from, data_to):
            data_to.objects = list(data_from.objects)

        loaded = list(data_to.objects)
        appended = [o for o in loaded if o is not None and o.type == 'MESH']
        # Drop any non-mesh datablocks that came in (empties, curves, etc.)
        for o in loaded:
            if o is not None and o.type != 'MESH':
                bpy.data.objects.remove(o, do_unlink=True)
        if not appended:
            return None

        for o in appended:
            if o.name not in context.collection.objects:
                context.collection.objects.link(o)

        bpy.ops.object.select_all(action='DESELECT')
        for o in appended:
            o.select_set(True)
        context.view_layer.objects.active = appended[0]

        if len(appended) > 1:
            bpy.ops.object.join()   # collapse multi-part connectors into one mesh

        comp = context.view_layer.objects.active

        # Unit conversion: the DynaX scene is mm-space (1 BU == 1 mm, sockets
        # import at ~hundreds of BU). The bundled .blend components are NOT
        # consistently authored: some are in SI metres (a real 82mm connector
        # is 0.082 BU, e.g. universal_4_hole_circ), some already in mm
        # (universal_4_hole_circ_child measures ~76 BU). A blanket x1000 would
        # blow the mm-authored ones up to tens of metres. A real connector is
        # never smaller than 1mm, so treat a sub-1-BU largest dimension as
        # metres and convert to mm; leave anything already sized in mm alone.
        # STL parts skip this entirely - they import in mm already.
        # Measure the largest extent straight from mesh vertices, not
        # comp.dimensions - the latter is derived from the object bound_box,
        # which reads stale (often 0) right after a library append/join
        # before a depsgraph update, and would misfire the test.
        verts = comp.data.vertices
        if verts:
            co = [v.co for v in verts]
            extent = max(
                max(c.x for c in co) - min(c.x for c in co),
                max(c.y for c in co) - min(c.y for c in co),
                max(c.z for c in co) - min(c.z for c in co),
            )
        else:
            extent = None
        if extent is not None and extent < 1.0:
            comp.scale = (1000.0, 1000.0, 1000.0)
            bpy.ops.object.select_all(action='DESELECT')
            comp.select_set(True)
            context.view_layer.objects.active = comp
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        return comp


# ── Step 2: Build Bridge ──────────────────────────────────────────────────────

class DynaxBuildComponentBridge(Operator):
    """Connect the component to the socket base as one watertight mesh"""
    bl_idname = "dynax.build_component_bridge"
    bl_label = "Build Component Bridge"
    bl_description = "Connect the component to the socket base as one watertight mesh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        socket_name = context.scene.get("dynax_bridge_socket_obj")
        socket = bpy.data.objects.get(socket_name) if socket_name else None
        comp = bpy.data.objects.get("dynax_component")

        if socket is None:
            self.report({'ERROR'}, "No socket object found. Load a component first.")
            return {'CANCELLED'}
        if comp is None:
            self.report({'ERROR'}, "No component loaded. Load a component first.")
            return {'CANCELLED'}

        # The build DELETES the original socket and adopts a new merged object,
        # so any workflow that tracked the socket would lose it. Capture how each
        # workflow referenced it, then re-point that reference at the result.
        was_parafly_socket = (
            getattr(context.scene, "paraforge_active_object", None) is socket)
        was_paraform_socket = bool(socket.get("dynax_paraform_finalized"))

        try:
            result_name = self._build_bridge(context, socket, comp)
        except Exception as e:
            self.report({'ERROR'}, f"Bridge failed: {e}")
            return {'CANCELLED'}

        context.scene["dynax_bridge_socket_obj"] = result_name
        context.scene.dynax_bridge_complete = True

        result = bpy.data.objects.get(result_name)
        if result is not None:
            if was_parafly_socket:
                context.scene.paraforge_active_object = result
            if was_paraform_socket:
                result["dynax_paraform_finalized"] = True

        self.report({'INFO'}, "Component bridge built successfully.")
        record_event(
            "quick_bridge_used",
            value=getattr(context.scene, 'dynax_transition_profile', 'SMOOTH_FILLET'),
        )
        return {'FINISHED'}

    def _build_bridge(self, context, socket, comp):
        """
        Parametric transition surface bridge (SPEC_component_bridge_parametric_
        transition.md, redesigned per module docstring fix #7):

        1. Duplicate socket + component (originals untouched until validated —
           fix #5)
        2. Apply transforms on the duplicates
        3. Open the socket's distal end if it's fully capped (fix #6) and the
           component's top (all near-top upward faces, not one triangle —
           fix #1); close any minor extra holes on each
        4. Analyse both openings (centre/radius/Z) and choose a profile-driven
           adaptive ring count from the diameter difference
        5. Generate N intermediate S-curve/taper-interpolated rings
        6. Bridge SEQUENTIALLY, one adjacent pair at a time: socket -> ring[0]
           -> ring[1] -> ... -> ring[N-1] -> component (fix #7 — NOT one bulk
           multi-loop bridge call, which was empirically verified broken)
        7. Laplacian-smooth only the synthetic ring vertices (bridge-only
           smoothing, tracked exactly during construction — fix #7)
        8. Recalculate normals; validate watertight (same fallback repair as
           before) and non-collapsed; only then remove the true originals and
           adopt the result
        """
        profile_name = getattr(context.scene, 'dynax_transition_profile', 'SMOOTH_FILLET')
        params = PROFILE_PARAMS.get(profile_name, PROFILE_PARAMS['SMOOTH_FILLET'])
        print(f"[DynaX Bridge] Profile: {profile_name} | Params: {params}")

        temp_objects = []
        try:
            socket_dup = _duplicate_object(context, socket, "dynax_bridge_socket_tmp")
            temp_objects.append(socket_dup)
            comp_dup = _duplicate_object(context, comp, "dynax_bridge_comp_tmp")
            temp_objects.append(comp_dup)

            for obj in (socket_dup, comp_dup):
                bpy.ops.object.select_all(action='DESELECT')
                obj.select_set(True)
                context.view_layer.objects.active = obj
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

            pre_join_diag = socket_dup.dimensions.length

            if not _open_socket_distal(socket_dup):
                raise RuntimeError(
                    "Could not find or open the socket's distal end. "
                    "Ensure the socket has a distal region near its lowest point."
                )
            _close_minor_holes(socket_dup)
            if not _open_component_top(comp_dup):
                raise RuntimeError(
                    "Could not open the component's top face. "
                    "Ensure the component STL has a reasonably flat top."
                )
            _close_minor_holes(comp_dup)

            # Geometry-driven extension (fix #13): needs both loops analysed
            # BEFORE extending, since the pct depends on the socket's
            # starting radius and how far the component sits from it - a
            # preliminary pass, not the final one used for ring generation
            # (comp_info doesn't change; socket_info does, since extending
            # changes the socket's own boundary loop).
            socket_info_prelim = _get_boundary_loop_info(socket_dup)
            comp_info = _get_boundary_loop_info(comp_dup)
            if socket_info_prelim is None:
                raise RuntimeError("Could not find socket boundary loop before extension.")
            if comp_info is None:
                raise RuntimeError("Could not analyse the component's opened boundary loop.")

            ext_pct = _compute_extension_pct(socket_info_prelim, comp_info)
            _extend_socket_opening(socket_dup, extension_pct=ext_pct)

            socket_info = _get_boundary_loop_info(socket_dup)
            if socket_info is None:
                raise RuntimeError("Could not analyse the socket's opened boundary loop.")

            diameter_diff = abs((socket_info["radius"] - comp_info["radius"]) * 2.0)
            offset_mm = math.sqrt(
                (socket_info["centre"].x - comp_info["centre"].x) ** 2 +
                (socket_info["centre"].y - comp_info["centre"].y) ** 2
            )
            n_rings = _adaptive_ring_count(diameter_diff, params, offset_mm=offset_mm,
                                            socket_r=socket_info["radius"])
            print(f"[DynaX Bridge] Socket radius: {socket_info['radius']:.1f}mm | "
                  f"Component radius: {comp_info['radius']:.1f}mm | "
                  f"Diff: {diameter_diff:.1f}mm | Offset: {offset_mm:.1f}mm | "
                  f"Rings: {n_rings}")

            rings = _generate_transition_rings(
                socket_info, comp_info, n_rings, params["curve"], params["collar_width"],
            )

            # Sequential chain bridge (fix #7/#8) — replaces the old single
            # join+bridge (both socket_dup and comp_dup get consumed into the
            # returned working object; temp_objects tracks only that one
            # object from here on, matching the original pattern). Loop
            # vertex-index sets passed explicitly (fix #8) rather than
            # re-detected inside the chain via select_non_manifold.
            working, bridge_vert_indices = _bridge_chain(
                context, socket_dup, comp_dup, rings,
                socket_info["vert_indices"], comp_info["vert_indices"],
            )
            temp_objects = [working]

            _smooth_bridge_region(
                working, bridge_vert_indices, params["smooth_passes"], params["smooth_factor"],
            )

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.normals_make_consistent(inside=False)
            bpy.ops.object.mode_set(mode='OBJECT')

            # A successful chain bridge is already watertight on its own —
            # verified directly (see module docstring fix #7). Unconditionally
            # running remove_doubles+holes_fill here (proven actively harmful
            # for the single-bridge case — its 1mm merge threshold collapses
            # legitimately-close vertices) is still only a fallback repair,
            # never unconditional.
            bm_check = bmesh.new()
            bm_check.from_mesh(working.data)
            still_open = [e for e in bm_check.edges if len(e.link_faces) == 1]
            if still_open:
                bmesh.ops.remove_doubles(bm_check, verts=bm_check.verts, dist=MERGE_THRESHOLD_MM)
                still_open = [e for e in bm_check.edges if len(e.link_faces) == 1]
                if still_open:
                    bmesh.ops.holes_fill(bm_check, edges=still_open, sides=0)
                bmesh.ops.recalc_face_normals(bm_check, faces=bm_check.faces[:])
                bm_check.to_mesh(working.data)
                working.data.update()
            bm_check.free()
            bpy.ops.object.shade_smooth()

            post_vert_count = len(working.data.vertices)
            post_diag = working.dimensions.length
            if post_vert_count == 0:
                raise RuntimeError("Bridge result is empty — originals left untouched.")
            if post_diag < 0.9 * pre_join_diag:
                raise RuntimeError(
                    "Bridge result collapsed (bounding box shrank) — originals left untouched."
                )

            # Success — remove the TRUE originals only now, and adopt the
            # validated duplicate as the working object.
            bpy.data.objects.remove(socket, do_unlink=True)
            bpy.data.objects.remove(comp, do_unlink=True)
            working.name = "dynax_socket_complete"
            bpy.ops.object.select_all(action='DESELECT')
            working.select_set(True)
            context.view_layer.objects.active = working
            print(f"[DynaX Bridge] Complete. Profile: {profile_name}. Verts: {post_vert_count}")
            return working.name

        except Exception:
            if bpy.context.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            _cleanup_temp(temp_objects)
            raise
