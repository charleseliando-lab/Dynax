# operators/fuse_voxel.py - Fuse Objects via Voxel Remesh

import bpy
import bmesh
from bpy.types import Operator


class FuseVoxel(Operator):
    """Join selected meshes and fuse them using a voxel remesh"""
    bl_idname = "dynax.fuse_voxel"
    bl_label = "Fuse (Voxel Remesh)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = getattr(context.scene, "dynax_props", None)
        voxel_size = props.fuse_voxel_size if props else 2.0   # mm (mm-space)
        auto_expand = props.fuse_auto_expand if props else True

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        selected_meshes = [o for o in context.selected_objects if o.type == 'MESH']
        if len(selected_meshes) < 2:
            self.report({'ERROR'}, "Select at least two mesh objects")
            return {'CANCELLED'}

        # Compute the minimum gap between object AABBs (world space).
        def aabb_world(obj):
            coords = [obj.matrix_world @ v.co for v in obj.data.vertices]
            min_x = min(v.x for v in coords)
            min_y = min(v.y for v in coords)
            min_z = min(v.z for v in coords)
            max_x = max(v.x for v in coords)
            max_y = max(v.y for v in coords)
            max_z = max(v.z for v in coords)
            return (min_x, min_y, min_z), (max_x, max_y, max_z)

        aabbs = [aabb_world(o) for o in selected_meshes]
        min_gap = 0.0
        for i in range(len(aabbs)):
            for j in range(i + 1, len(aabbs)):
                (min_a, max_a) = aabbs[i]
                (min_b, max_b) = aabbs[j]
                dx = max(0.0, max(min_b[0] - max_a[0], min_a[0] - max_b[0]))
                dy = max(0.0, max(min_b[1] - max_a[1], min_a[1] - max_b[1]))
                dz = max(0.0, max(min_b[2] - max_a[2], min_a[2] - max_b[2]))
                gap = (dx * dx + dy * dy + dz * dz) ** 0.5
                if min_gap == 0.0 or gap < min_gap:
                    min_gap = gap

        if auto_expand and min_gap > voxel_size:
            voxel_size = min_gap * 1.5
        elif min_gap > voxel_size:
            self.report({'WARNING'}, "Objects are too far apart to fuse at this voxel size")

        target = context.active_object if context.active_object in selected_meshes else None
        if not target:
            target = selected_meshes[-1]
            context.view_layer.objects.active = target

        # Ensure all selected meshes are selected and target is active before join.
        bpy.ops.object.select_all(action='DESELECT')
        for o in selected_meshes:
            o.select_set(True)
        context.view_layer.objects.active = target

        try:
            area = next((a for a in context.window.screen.areas if a.type == 'VIEW_3D'), None)
            region = None
            if area:
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if area and region:
                with context.temp_override(
                    area=area,
                    region=region,
                    active_object=target,
                    object=target,
                    selected_objects=selected_meshes,
                    selected_editable_objects=selected_meshes,
                ):
                    result = bpy.ops.object.join()
            else:
                result = bpy.ops.object.join()
            if 'CANCELLED' in result:
                self.report({'ERROR'}, "Join failed (operator cancelled)")
                return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, f"Join failed: {e}")
            return {'CANCELLED'}

        # Apply scale so voxel size is consistent in world units.
        try:
            if area and region:
                with context.temp_override(
                    area=area,
                    region=region,
                    active_object=target,
                    object=target,
                ):
                    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
            else:
                bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
        except Exception:
            pass

        def count_islands(mesh):
            bm = bmesh.new()
            bm.from_mesh(mesh)
            bm.verts.ensure_lookup_table()
            visited = set()
            islands = 0
            for v in bm.verts:
                if v.index in visited:
                    continue
                islands += 1
                stack = [v]
                visited.add(v.index)
                while stack:
                    cur = stack.pop()
                    for e in cur.link_edges:
                        ov = e.other_vert(cur)
                        if ov.index not in visited:
                            visited.add(ov.index)
                            stack.append(ov)
            bm.free()
            return islands

        # Apply voxel remesh to fuse disconnected islands, retrying if needed.
        area = next((a for a in context.window.screen.areas if a.type == 'VIEW_3D'), None)
        region = None
        if area:
            region = next((r for r in area.regions if r.type == 'WINDOW'), None)

        success = False
        for attempt in range(3):
            remesh = target.modifiers.new(name=f"DYNAX_FUSE_VOXEL_{attempt+1}", type='REMESH')
            remesh.mode = 'VOXEL'
            remesh.voxel_size = voxel_size
            remesh.use_smooth_shade = True

            try:
                if area and region:
                    with context.temp_override(
                        area=area,
                        region=region,
                        active_object=target,
                        object=target,
                    ):
                        result = bpy.ops.object.modifier_apply(modifier=remesh.name)
                else:
                    result = bpy.ops.object.modifier_apply(modifier=remesh.name)
                if 'CANCELLED' in result:
                    self.report({'ERROR'}, "Voxel remesh failed (operator cancelled)")
                    return {'CANCELLED'}
            except Exception as e:
                self.report({'ERROR'}, f"Voxel remesh failed: {e}")
                return {'CANCELLED'}

            context.view_layer.update()
            if count_islands(target.data) <= 1:
                success = True
                break
            voxel_size *= 2.0

        if not success:
            self.report({'WARNING'}, "Still disconnected after voxel remesh; try larger voxel size")

        context.view_layer.update()
        self.report({'INFO'}, "Fused with voxel remesh")
        return {'FINISHED'}
