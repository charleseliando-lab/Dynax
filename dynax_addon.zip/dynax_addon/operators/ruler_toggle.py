# operators/ruler_toggle.py - Ruler Tool and Clear All Measurements

import bpy
from bpy.types import Operator

class RulerToggle(Operator):
    """Toggle the Measure Tool on/off"""
    bl_idname = "dynax.ruler_toggle"
    bl_label = "Toggle Ruler"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # Check current tool in the 3D View
        current_tool = context.workspace.tools.from_space_view3d_mode(context.mode).idname
        
        if current_tool == 'builtin.measure':
            # Turn OFF: Switch back to Select Box
            bpy.ops.wm.tool_set_by_id(name='builtin.select_box')
            self.report({'INFO'}, "Ruler Deactivated")
        else:
            # Turn ON: Switch to Measure Tool
            bpy.ops.wm.tool_set_by_id(name='builtin.measure')
            self.report({'INFO'}, "Ruler Activated")
        
        return {'FINISHED'}

class ClearMeasurements(Operator):
    """Safely removes all measurements (Exits tool first to prevent crash)"""
    bl_idname = "dynax.clear_measurements"
    bl_label = "Clear All Measurements"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        # 1. CRITICAL: Switch to Select Tool first
        # If we delete data while the Measure tool is active, Blender crashes.
        bpy.ops.wm.tool_set_by_id(name='builtin.select_box')
        
        # 2. Find the Annotation Data (Handles Blender 4.2 vs 5.0+)
        gp = None
        
        # Blender 5.0 / 4.3+ (New API)
        if hasattr(context.scene, "annotation"):
            gp = context.scene.annotation
            
        # Blender 4.2 and older (Old API)
        elif hasattr(context.scene, "grease_pencil"):
            gp = context.scene.grease_pencil
            
        # 3. Clear the Data
        cleared_count = 0
        
        if gp:
            # Remove all layers (this clears all existing measurements/notes)
            # We iterate backwards to safely remove items from a list
            for layer in list(gp.layers):
                gp.layers.remove(layer)
                cleared_count += 1
        
        # 4. Force a Viewport Update
        context.view_layer.update()
        
        if cleared_count > 0:
            self.report({'INFO'}, "All measurements cleared")
        else:
            self.report({'INFO'}, "No measurements found (Clean)")
            
        return {'FINISHED'}