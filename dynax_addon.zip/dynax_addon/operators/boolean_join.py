# operators/boolean_join.py - Boolean Join (Union)

import bpy
from bpy.types import Operator


class BooleanJoin(Operator):
    """Boolean union of selected meshes into the active mesh"""
    bl_idname = "dynax.boolean_join"
    bl_label = "Boolean Join (Union)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = getattr(context.scene, "dynax_props", None)

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        selected_meshes = [o for o in context.selected_objects if o.type == 'MESH']
        if len(selected_meshes) < 2:
            selected_meshes = [
                o for o in context.view_layer.objects
                if o.select_get() and o.type == 'MESH'
            ]
        if len(selected_meshes) < 2:
            self.report({'ERROR'}, "Select at least two mesh objects")
            return {'CANCELLED'}

        target = context.active_object if context.active_object in selected_meshes else None
        if not target:
            target = selected_meshes[-1]
            context.view_layer.objects.active = target
        if target.type != 'MESH':
            self.report({'ERROR'}, "Active object must be a mesh")
            return {'CANCELLED'}

        operands = [o for o in selected_meshes if o != target]
        if not operands:
            self.report({'ERROR'}, "No operand meshes found")
            return {'CANCELLED'}

        apply_transforms = props.bool_apply_transforms if props else True
        delete_operands = props.bool_delete_operands if props else True

        # Preserve user selection/active so we can restore at the end.
        original_active = context.view_layer.objects.active
        original_selected = [o for o in context.view_layer.objects if o.select_get()]
        # Store names to avoid ReferenceError if objects get removed.
        original_selected_names = [o.name for o in original_selected]
        original_active_name = original_active.name if original_active else None

        if apply_transforms:
            for o in [target] + operands:
                bpy.ops.object.select_all(action='DESELECT')
                o.select_set(True)
                context.view_layer.objects.active = o
                bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

        bpy.ops.object.select_all(action='DESELECT')
        target.select_set(True)
        context.view_layer.objects.active = target

        for idx, operand in enumerate(operands, start=1):
            mod = target.modifiers.new(name=f"DYNAX_BOOL_{idx}", type='BOOLEAN')
            mod.operation = 'UNION'
            mod.object = operand
            try:
                mod.solver = 'EXACT'
            except Exception:
                pass

            try:
                bpy.ops.object.modifier_apply(modifier=mod.name)
            except Exception as e:
                # Restore selection/active before reporting.
                bpy.ops.object.select_all(action='DESELECT')
                for name in original_selected_names:
                    obj = bpy.data.objects.get(name)
                    if obj:
                        obj.select_set(True)
                if original_active_name:
                    obj = bpy.data.objects.get(original_active_name)
                    if obj:
                        context.view_layer.objects.active = obj
                self.report({'ERROR'}, f"Boolean failed: {e}")
                return {'CANCELLED'}

            if delete_operands:
                bpy.data.objects.remove(operand, do_unlink=True)

        # Restore selection/active for user convenience (skip removed objects).
        bpy.ops.object.select_all(action='DESELECT')
        for name in original_selected_names:
            obj = bpy.data.objects.get(name)
            if obj:
                obj.select_set(True)
        if original_active_name:
            obj = bpy.data.objects.get(original_active_name)
            if obj:
                context.view_layer.objects.active = obj
            else:
                context.view_layer.objects.active = target
        else:
            context.view_layer.objects.active = target

        context.view_layer.update()
        self.report({'INFO'}, "Boolean join complete")
        return {'FINISHED'}
