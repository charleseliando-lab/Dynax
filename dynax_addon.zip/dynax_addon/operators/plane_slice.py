# operators/plane_slice.py - Plane Slice Operator

import bpy
import bmesh
import math
from mathutils import Vector
from bpy.types import Operator


class PlaneSlice(Operator):
    """Step 1: Create a plane to slice the object"""
    bl_idname = "dynax.plane_slice"
    bl_label = "Start Plane Slice"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a Mesh object first")
            return {'CANCELLED'}

        max_dim = max(obj.dimensions) if obj.dimensions.length > 0 else 1.0
        plane_size = max_dim * 2.0

        bpy.ops.mesh.primitive_plane_add(size=plane_size, location=obj.location)
        plane = context.active_object
        plane.name = "Dynax_Slicer"
        plane.rotation_euler[0] = 1.5708
        plane["dynax_slice_target"] = obj.name

        bpy.ops.object.select_all(action='DESELECT')
        plane.select_set(True)
        context.view_layer.objects.active = plane
        bpy.ops.wm.tool_set_by_id(name='builtin.transform')

        self.report({'INFO'}, "Position the plane and click Apply Slice")
        return {'FINISHED'}


class PlaneSliceApply(Operator):
    """Step 2: Apply the slice using high precision"""
    bl_idname = "dynax.plane_slice_apply"
    bl_label = "Apply Slice"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        plane = bpy.data.objects.get("Dynax_Slicer")
        if not plane:
            self.report({'ERROR'}, "Could not find the Slicer or Target Object")
            return {'CANCELLED'}

        target_name = plane.get("dynax_slice_target")
        target_obj = bpy.data.objects.get(target_name) if target_name else None
        if not target_obj or target_obj.type != 'MESH':
            self.report({'ERROR'}, "Could not find the Slicer or Target Object")
            return {'CANCELLED'}

        context.view_layer.objects.active = target_obj
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        plane_co = plane.matrix_world.translation
        plane_no = (plane.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))).normalized()
        # Convert plane world space to target object local space for bmesh ops.
        inv = target_obj.matrix_world.inverted()
        plane_co_local = inv @ plane_co
        plane_no_local = (inv.to_3x3() @ plane_no).normalized()

        # Bisect with bmesh for reliability
        try:
            bpy.ops.object.mode_set(mode='EDIT')
            bm = bmesh.from_edit_mesh(target_obj.data)
            geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
            props = getattr(context.scene, "dynax_props", None)
            keep_side = props.slice_keep_side if props else 'OUTER'
            clear_inner = (keep_side == 'OUTER')
            clear_outer = (keep_side == 'INNER')
            bmesh.ops.bisect_plane(
                bm,
                geom=geom,
                plane_co=plane_co_local,
                plane_no=plane_no_local,
                clear_inner=clear_inner,
                clear_outer=clear_outer,
            )
            if keep_side != 'BOTH':
                bmesh.ops.holes_fill(bm, edges=[e for e in bm.edges if e.is_boundary])
            bmesh.update_edit_mesh(target_obj.data, loop_triangles=False, destructive=True)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to slice: {e}")
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.data.objects.remove(plane, do_unlink=True)

        if hasattr(bpy.ops.object, "shade_smooth_by_angle"):
            bpy.ops.object.shade_smooth_by_angle(angle=math.radians(30))
        else:
            bpy.ops.object.shade_smooth()
            target_obj.data.use_auto_smooth = True
            target_obj.data.auto_smooth_angle = math.radians(30)

        bpy.ops.wm.tool_set_by_id(name='builtin.select_box')
        self.report({'INFO'}, "Slice Applied")
        return {'FINISHED'}
