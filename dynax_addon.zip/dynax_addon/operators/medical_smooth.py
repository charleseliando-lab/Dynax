# operators/medical_smooth.py - Medical Smooth Operator

import bpy
import bmesh
import math
from bpy.types import Operator

class MedicalSmooth(Operator):
    """Smart Smooth: Heals mesh, checks status, and applies smoothing"""
    bl_idname = "dynax.medical_smooth"
    bl_label = "Medical Smooth"
    bl_options = {'REGISTER', 'UNDO'}

    def _build_cap_vertex_set(self, obj, angle_rad, min_area_ratio=0.01):
        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bm.faces.ensure_lookup_table()

        total_area = 0.0
        clusters = []
        for face in bm.faces:
            area = face.calc_area()
            total_area += area
            if area == 0.0:
                continue
            nrm = face.normal.normalized()
            placed = False
            for cluster in clusters:
                if nrm.angle(cluster["normal"]) <= angle_rad:
                    cluster["normal"] = (cluster["normal"] * cluster["area"] + nrm * area).normalized()
                    cluster["area"] += area
                    cluster["faces"].append(face)
                    placed = True
                    break
            if not placed:
                clusters.append({"normal": nrm.copy(), "area": area, "faces": [face]})

        if total_area <= 0.0 or not clusters:
            bm.free()
            return None

        clusters.sort(key=lambda c: c["area"], reverse=True)
        cap = clusters[0]
        if cap["area"] < total_area * min_area_ratio:
            bm.free()
            return None

        cap_verts = {v.index for f in cap["faces"] for v in f.verts}
        bm.free()
        return cap_verts

    def execute(self, context):
        scene = context.scene
        props = getattr(scene, "dynax_props", None)

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not selected_meshes:
            self.report({'ERROR'}, "Please select at least one Mesh object")
            return {'CANCELLED'}

        use_selected = props.apply_to_selected if props else True
        targets = selected_meshes if use_selected else [context.active_object]
        targets = [obj for obj in targets if obj and obj.type == 'MESH']
        if not targets:
            self.report({'ERROR'}, "No valid Mesh object to process")
            return {'CANCELLED'}

        weld_threshold_mm = props.weld_threshold_mm if props else 0.1
        smooth_angle = props.smooth_angle if props else math.radians(35.0)
        smooth_iterations = props.smooth_iterations if props else 10
        smooth_factor = props.smooth_factor if props else 0.8
        skip_if_smoothed = props.skip_if_smoothed if props else True
        protect_caps = props.protect_caps if props else True
        cap_angle = props.cap_angle if props else math.radians(6.0)

        original_active = context.view_layer.objects.active
        original_selected = [obj for obj in context.selected_objects]

        processed = 0
        skipped = 0

        for obj in targets:
            if skip_if_smoothed and "DynaxSmooth" in obj.modifiers:
                skipped += 1
                continue

            for sel in context.selected_objects:
                sel.select_set(False)
            obj.select_set(True)
            context.view_layer.objects.active = obj

            scale_factor = max(abs(obj.scale.x), abs(obj.scale.y), abs(obj.scale.z), 1.0)
            # mm-space scene (scale_length=0.001): 1 unit = 1 mm, so the weld
            # threshold is the mm value directly (no /1000), times any un-applied scale.
            weld_threshold = weld_threshold_mm * scale_factor

            # Apply scale/rotation (crucial for modifiers)
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

            # Weld vertices without entering edit mode
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=weld_threshold)
            bm.to_mesh(obj.data)
            bm.free()
            obj.data.update()

            # Smooth shading + auto smooth angle (version-safe)
            for poly in obj.data.polygons:
                poly.use_smooth = True
            if hasattr(obj.data, "use_auto_smooth"):
                obj.data.use_auto_smooth = True
                obj.data.auto_smooth_angle = smooth_angle
            elif hasattr(bpy.ops.object, "shade_smooth_by_angle"):
                bpy.ops.object.shade_smooth_by_angle(angle=smooth_angle)

            # Add or update corrective smooth modifier
            mod = obj.modifiers.get("DynaxSmooth")
            if not mod:
                mod = obj.modifiers.new(name="DynaxSmooth", type='CORRECTIVE_SMOOTH')

            mod.smooth_type = 'LENGTH_WEIGHTED'
            mod.use_only_smooth = True
            mod.use_pin_boundary = True  # Keep ends sharp
            mod.iterations = smooth_iterations
            mod.factor = smooth_factor

            if protect_caps:
                cap_verts = self._build_cap_vertex_set(obj, cap_angle)
                if cap_verts:
                    vg = obj.vertex_groups.get("DynaxSmoothMask")
                    if not vg:
                        vg = obj.vertex_groups.new(name="DynaxSmoothMask")

                    all_verts = [v.index for v in obj.data.vertices]
                    vg.add(all_verts, 1.0, 'REPLACE')
                    vg.add(list(cap_verts), 0.0, 'REPLACE')
                    mod.vertex_group = vg.name
                else:
                    mod.vertex_group = ""
            else:
                mod.vertex_group = ""

            processed += 1

        for sel in context.selected_objects:
            sel.select_set(False)
        for obj in original_selected:
            obj.select_set(True)
        context.view_layer.objects.active = original_active

        if processed == 0 and skipped > 0:
            self.report({'WARNING'}, "All selected meshes already have DynaxSmooth")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Smoothed {processed} mesh(es); skipped {skipped}")
        return {'FINISHED'}
