# operators/scale_to_size.py - Scale selected mesh to target size (restored v1.2)

import bpy
from bpy.types import Operator


class ScaleToSize(Operator):
    """Scale active mesh so its max dimension matches target size (mm)"""
    bl_idname = "dynax.scale_to_size"
    bl_label = "Scale to size"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = getattr(context.scene, "dynax_props", None)
        target_size_mm = props.scale_target_size_mm if props else 400.0

        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a mesh object")
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        dims = obj.dimensions
        max_dim = max(dims)
        if max_dim <= 0.0:
            self.report({'ERROR'}, "Object has zero size")
            return {'CANCELLED'}

        # mm-space scene (scale_length=0.001): dimensions are already in mm, so the
        # target compares directly - no /1000.
        factor = target_size_mm / max_dim
        obj.scale = [s * factor for s in obj.scale]

        try:
            area = next((a for a in context.window.screen.areas if a.type == 'VIEW_3D'), None)
            region = None
            if area:
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if area and region:
                with context.temp_override(
                    area=area, region=region,
                    active_object=obj, object=obj,
                ):
                    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            else:
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        except Exception:
            pass

        self.report({'INFO'}, f"✓ Scaled to {target_size_mm:.0f} mm max dimension")
        return {'FINISHED'}
