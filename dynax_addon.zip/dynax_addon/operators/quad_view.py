# operators/quad_view.py - Quad viewport toggle
#
# Wraps Blender's built-in region_quadview operator so it's accessible from
# the DynaX panel as a simple on/off toggle, available at every step.

import bpy
from bpy.types import Operator


def _get_view3d_area_region(context):
    """Find a VIEW_3D area and its WINDOW region for a context override."""
    for area in context.window.screen.areas:
        if area.type == 'VIEW_3D':
            for region in area.regions:
                if region.type == 'WINDOW':
                    return area, region
    return None, None


class DynaxQuadViewToggle(Operator):
    """Toggle Blender's 4-pane Quad View (Front/Side/Top/Perspective)"""
    bl_idname = "dynax.quad_view_toggle"
    bl_label = "Toggle Quad View"
    bl_description = "Switch between single viewport and 4-pane quad view"
    bl_options = {'REGISTER'}

    def execute(self, context):
        area, region = _get_view3d_area_region(context)
        if not area or not region:
            self.report({'ERROR'}, "No 3D viewport found")
            return {'CANCELLED'}

        try:
            with context.temp_override(area=area, region=region):
                bpy.ops.screen.region_quadview()
        except Exception as e:
            self.report({'ERROR'}, f"Could not toggle quad view: {e}")
            return {'CANCELLED'}

        # Track state on the scene so the panel can show the current on/off
        # status accurately (Blender doesn't expose a direct "is quad view
        # active" property, so we track it ourselves alongside the toggle).
        context.scene["dynax_quad_view_on"] = not context.scene.get("dynax_quad_view_on", False)

        state = "ON" if context.scene["dynax_quad_view_on"] else "OFF"
        self.report({'INFO'}, f"Quad view {state}")
        return {'FINISHED'}
