# operators/height_band_groups.py - Auto-generate height-band vertex groups
#
# First step toward parametric socket control. Creates vertex groups along the
# mesh's Z (height) axis, e.g. "distal", "lower_mid", "mid", "upper_mid", "brim",
# with smooth weight blending between adjacent bands so later region-based
# deformation (radial scale per band) doesn't create hard seams.
#
# This does NOT deform the mesh. It only creates and weights vertex groups.

import bpy
from bpy.types import Operator
from bpy.props import IntProperty, FloatProperty, StringProperty


DEFAULT_BAND_NAMES = ["distal", "lower_mid", "mid", "upper_mid", "brim"]


def _compute_band_boundaries(z_min, z_max, num_bands):
    """Equal-width band boundaries as a simple, predictable v1 default.
    Returns a list of (low, high) tuples, one per band, covering the full
    Z range with no gaps."""
    span = z_max - z_min
    band_height = span / num_bands
    boundaries = []
    for i in range(num_bands):
        lo = z_min + i * band_height
        hi = z_min + (i + 1) * band_height
        boundaries.append((lo, hi))
    return boundaries


def _band_weight(z, lo, hi, blend_mm):
    """Smooth weight (0..1) for how strongly a vertex at height z belongs to
    a band spanning [lo, hi], with linear falloff over `blend_mm` on each
    side of the band's boundaries. Vertices well inside the band get weight
    1.0; vertices in the blend zone get a partial weight; vertices far
    outside get 0.0. This is what prevents a hard seam when adjacent bands
    are later driven by different slider values."""
    if z < lo - blend_mm or z > hi + blend_mm:
        return 0.0
    if lo <= z <= hi:
        return 1.0
    if z < lo:
        # in the blend zone below this band
        return max(0.0, 1.0 - (lo - z) / blend_mm)
    # z > hi: in the blend zone above this band
    return max(0.0, 1.0 - (z - hi) / blend_mm)


class DynaxCreateHeightBandGroups(Operator):
    """Auto-generate height-band vertex groups along the mesh's Z axis, with
    smooth weight blending between adjacent bands. First step toward
    parametric region-based deformation (not yet wired to any slider)."""
    bl_idname = "dynax.create_height_band_groups"
    bl_label = "Create Height-Band Vertex Groups"
    bl_description = ("Auto-detect height bands (distal/mid/brim, etc.) and "
                       "create smoothly-blended vertex groups for each")
    bl_options = {'REGISTER', 'UNDO'}

    num_bands: IntProperty(
        name="Number of Bands",
        description="How many height regions to create",
        default=5, min=2, max=10,
    )
    blend_mm: FloatProperty(
        name="Blend Zone (mm)",
        description="Smooth transition distance between adjacent bands",
        default=20.0, min=0.0, max=100.0,
    )
    group_prefix: StringProperty(
        name="Group Name Prefix",
        description="Prefix for created vertex group names",
        default="band_",
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a Mesh object first")
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        mesh = obj.data
        if not mesh.vertices:
            self.report({'ERROR'}, "Mesh has no vertices")
            return {'CANCELLED'}

        # Z bounding box in LOCAL space (vertex groups operate on local
        # vertex coordinates, consistent with how DynaX's mm-space meshes
        # are already structured — see CLAUDE.md unit architecture section).
        z_values = [v.co.z for v in mesh.vertices]
        z_min, z_max = min(z_values), max(z_values)
        if z_max - z_min < 1.0:
            self.report({'ERROR'},
                "Mesh has almost no height variation along Z — check the "
                "mesh is oriented with its long axis along Z (use Align & "
                "Rotate first if needed).")
            return {'CANCELLED'}

        boundaries = _compute_band_boundaries(z_min, z_max, self.num_bands)

        # Remove any existing bands from a previous run, so re-running this
        # operator is safe and doesn't stack duplicate groups.
        names = []
        for i in range(self.num_bands):
            if i < len(DEFAULT_BAND_NAMES) and self.num_bands == len(DEFAULT_BAND_NAMES):
                name = f"{self.group_prefix}{DEFAULT_BAND_NAMES[i]}"
            else:
                name = f"{self.group_prefix}{i:02d}"
            names.append(name)
            existing = obj.vertex_groups.get(name)
            if existing:
                obj.vertex_groups.remove(existing)

        groups = [obj.vertex_groups.new(name=n) for n in names]

        # Assign weights per vertex per band. For meshes with tens of
        # thousands of verts this is O(verts * bands) which is fine at this
        # scale (5 bands x ~25k verts = ~125k weight calls, sub-second).
        for vi, v in enumerate(mesh.vertices):
            z = v.co.z
            for band_idx, (lo, hi) in enumerate(boundaries):
                w = _band_weight(z, lo, hi, self.blend_mm)
                if w > 0.0:
                    groups[band_idx].add([vi], w, 'REPLACE')

        band_summary = ", ".join(
            f"{names[i]} ({boundaries[i][0]:.0f} to {boundaries[i][1]:.0f}mm)"
            for i in range(self.num_bands)
        )
        self.report({'INFO'}, f"Created {self.num_bands} height-band groups: {band_summary}")
        return {'FINISHED'}


class DynaxClearHeightBandGroups(Operator):
    """Remove all DynaX height-band vertex groups from the active object"""
    bl_idname = "dynax.clear_height_band_groups"
    bl_label = "Clear Height-Band Groups"
    bl_description = "Remove all height-band vertex groups created by DynaX"
    bl_options = {'REGISTER', 'UNDO'}

    group_prefix: StringProperty(default="band_")

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a Mesh object first")
            return {'CANCELLED'}

        removed = 0
        for vg in list(obj.vertex_groups):
            if vg.name.startswith(self.group_prefix):
                obj.vertex_groups.remove(vg)
                removed += 1

        self.report({'INFO'}, f"Removed {removed} height-band group(s).")
        return {'FINISHED'}
