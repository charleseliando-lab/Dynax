# operators/extrude_faces.py - Extrude selected faces

import bpy
import bmesh
from bpy.types import Operator


def _mm_to_blender(val_mm: float) -> float:
    """mm-space scene (scale_length=0.001): 1 Blender unit = 1 mm, so a millimetre
    distance is passed straight through with no conversion."""
    return val_mm


class ExtrudeSelectedFaces(Operator):
    """Extrude selected faces by distance (mm)"""
    bl_idname = "dynax.extrude_faces"
    bl_label = "Extrude Selection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = getattr(context.scene, "dynax_props", None)
        obj = context.active_object

        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Active object must be a Mesh")
            return {'CANCELLED'}
        if obj.mode != 'EDIT':
            try:
                bpy.ops.object.mode_set(mode='EDIT')
            except Exception:
                self.report({'ERROR'}, "Must be in Edit Mode to extrude faces")
                return {'CANCELLED'}

        bm = bmesh.from_edit_mesh(obj.data)
        selected_faces = [f for f in bm.faces if f.select]
        if not selected_faces:
            self.report({'ERROR'}, "Select at least one face to extrude")
            return {'CANCELLED'}

        dist_mm = props.extrude_distance_mm if props else 10.0
        dist_m = _mm_to_blender(dist_mm)   # scene units (= mm in mm-space)
        direction = props.extrude_direction if props else 'NORMAL'

        area = next((a for a in context.window.screen.areas if a.type == 'VIEW_3D'), None)
        region = None
        if area:
            region = next((r for r in area.regions if r.type == 'WINDOW'), None)

        def _do_extrude():
            if direction == 'NORMAL':
                return bpy.ops.mesh.extrude_region_move(
                    TRANSFORM_OT_translate={
                        "value": (0.0, 0.0, dist_m),
                        "orient_type": 'NORMAL',
                        "constraint_axis": (False, False, True),
                    }
                )
            axis_vec = (dist_m, 0.0, 0.0)
            if direction == 'Y':
                axis_vec = (0.0, dist_m, 0.0)
            elif direction == 'Z':
                axis_vec = (0.0, 0.0, dist_m)
            return bpy.ops.mesh.extrude_region_move(
                TRANSFORM_OT_translate={
                    "value": axis_vec,
                    "orient_type": 'GLOBAL',
                }
            )

        if area and region:
            with context.temp_override(
                area=area,
                region=region,
                active_object=obj,
                object=obj,
            ):
                result = _do_extrude()
        else:
            result = _do_extrude()

        if 'CANCELLED' in result:
            self.report({'ERROR'}, "Extrude failed (operator cancelled)")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Extruded {dist_mm:.2f} mm")
        return {'FINISHED'}
