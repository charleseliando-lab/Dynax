# operators/import_stl.py - Smart STL & OBJ Import Operator

import bpy
import bmesh
import math
import os
from bpy.types import Operator
from bpy.props import StringProperty
from bpy_extras.io_utils import ImportHelper

try:
    from ..analytics.collector import record_event, workflow_from_context
except ImportError:
    def record_event(*_args, **_kwargs):
        return None

    def workflow_from_context(_context):
        return None

try:
    from ..utils.session_recorder import get_recorder
except ImportError:
    def get_recorder():
        class _NullRecorder:
            def __getattr__(self, _name):
                return lambda *a, **k: None
        return _NullRecorder()


_SESSION_WORKFLOW_MAP = {
    "creator": "creator",
    "paraform": "paraforge",
    "parafly_afo": "parafly_afo",
    "parafly_tlso": "parafly_tlso",
    "paralink_tt": "paralink_tt",
}

def _session_workflow_and_device(context):
    raw_workflow = workflow_from_context(context)
    workflow = _SESSION_WORKFLOW_MAP.get(raw_workflow, raw_workflow or "creator")
    device_type = "unknown"
    try:
        scene = context.scene
        mode = scene.dynax_props.dynax_mode
        if mode == "PARAFORGE":
            device_type = "transfemoral"
        elif mode == "PARAFORGE_ZONES":
            device_type = {
                "TT": "transtibial", "AFO": "afo", "TLSO": "tlso",
            }.get(getattr(scene, "parafly_device_type", ""), "unknown")
    except (AttributeError, TypeError):
        pass
    return workflow, device_type


_ORTHO_VIEW_ROTATIONS = {
    'FRONT':  (math.radians(90), 0, 0),
    'BACK':   (math.radians(90), 0, math.radians(180)),
    'LEFT':   (math.radians(90), 0, math.radians(-90)),
    'RIGHT':  (math.radians(90), 0, math.radians(90)),
    'TOP':    (0, 0, 0),
    'BOTTOM': (math.radians(180), 0, 0),
}

def _set_orthographic_view(view='FRONT'):
    import mathutils
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            space = area.spaces.active
            if not (space and space.type == 'VIEW_3D'):
                continue
            rv3d = space.region_3d
            if rv3d is None:
                continue
            rv3d.view_perspective = 'ORTHO'
            if view and view in _ORTHO_VIEW_ROTATIONS:
                rv3d.view_rotation = mathutils.Euler(_ORTHO_VIEW_ROTATIONS[view]).to_quaternion()
    print(f"[DynaX] Viewport set to orthographic ({view or 'current direction'})")


def _setup_mm_viewport():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            space = area.spaces.active
            if space and space.type == 'VIEW_3D':
                space.clip_start = 0.1
                space.clip_end = 1_000_000.0
                if space.region_3d:
                    space.region_3d.view_perspective = 'ORTHO'


def _auto_scale_factor(raw_max):
    if raw_max <= 0.0:
        return 1.0
    if 30.0 <= raw_max <= 3000.0:
        return 1.0
    if 0.03 <= raw_max <= 3.0:
        return 1000.0
    if 3.0 < raw_max < 30.0:
        return 10.0
    factor, val = 1.0, raw_max
    while val < 30.0 and factor < 1e6:
        factor *= 10.0
        val *= 10.0
    while val > 3000.0 and factor > 1e-6:
        factor /= 10.0
        val /= 10.0
    return factor


def _snapshot_original(context, obj):
    snapshot_name = f"{obj.name}_ORIGINAL_SNAPSHOT"
    for stale_name in {obj.get("dynax_snapshot_name", ""), snapshot_name}:
        if not stale_name:
            continue
        existing = bpy.data.objects.get(stale_name)
        if existing is None:
            continue
        old_mesh = existing.data
        bpy.data.objects.remove(existing, do_unlink=True)
        if old_mesh and old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)

    snap_mesh = obj.data.copy()
    snap_mesh.name = snapshot_name + "_mesh"
    snap_obj = bpy.data.objects.new(snapshot_name, snap_mesh)
    snap_obj.matrix_world = obj.matrix_world.copy()
    context.collection.objects.link(snap_obj)

    snap_obj.hide_set(True)
    snap_obj.hide_render = True
    snap_obj.hide_select = True
    snap_obj["dynax_is_original_snapshot"] = True
    obj["dynax_snapshot_name"] = snapshot_name
    return snap_obj


def _frame_object(context, obj):
    if not obj:
        return
    area = next((a for a in context.window.screen.areas if a.type == 'VIEW_3D'), None) \
        if context.window else None
    region = next((r for r in area.regions if r.type == 'WINDOW'), None) if area else None
    if not (area and region):
        return
    try:
        with context.temp_override(area=area, region=region,
                                   active_object=obj, object=obj,
                                   selected_objects=[obj]):
            bpy.ops.view3d.view_selected()
    except Exception:
        pass


class ImportMeshSmart(Operator, ImportHelper):
    """Smart Import STL & OBJ - Auto-centers, scales, and checks mesh quality"""
    bl_idname = "dynax.import_stl"
    bl_label = "Import Model (Smart)"
    bl_options = {'REGISTER', 'UNDO'}
    
    # File browser properties for STL and OBJ
    filename_ext = ""
    filter_glob: StringProperty(
        default="*.stl;*.obj",
        options={'HIDDEN'},
    )
    
    def execute(self, context):
        filepath = self.filepath
        props = getattr(context.scene, "dynax_props", None)
        
        # 1. Validation
        if not os.path.exists(filepath):
            self.report({'ERROR'}, f"File not found: {filepath}")
            return {'CANCELLED'}
            
        ext = os.path.splitext(filepath)[1].lower()
        if ext not in [".stl", ".obj"]:
            self.report({'ERROR'}, f"Unsupported file type: {ext}. Use .stl or .obj.")
            return {'CANCELLED'}
        
        # 2. Deselect everything to ensure we identify the new import correctly
        if context.active_object and context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        
        # 3. Import Logic (Handles Blender versions and formats)
        try:
            if ext == ".stl":
                if hasattr(bpy.ops.wm, "stl_import"):
                    bpy.ops.wm.stl_import(filepath=filepath)
                else:
                    if "io_mesh_stl" not in context.preferences.addons:
                        bpy.ops.preferences.addon_enable(module="io_mesh_stl")
                    bpy.ops.import_mesh.stl(filepath=filepath)
            elif ext == ".obj":
                if hasattr(bpy.ops.wm, "obj_import"):
                    # Blender 3.2+ / 4.0+ (New C++ System)
                    bpy.ops.wm.obj_import(filepath=filepath, forward_axis='Y', up_axis='Z')
                else:
                    # Blender 3.1 and older (Legacy System)
                    bpy.ops.import_scene.obj(filepath=filepath, axis_forward='Y', axis_up='Z')
            
            self.report({'INFO'}, f"Imported: {os.path.basename(filepath)}")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to import file: {str(e)}")
            return {'CANCELLED'}
        
        # 4. Get the imported object (Filtering for MESH just in case OBJ imports Empty containers)
        selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not selected_meshes:
            self.report({'ERROR'}, "No mesh data was imported")
            return {'CANCELLED'}
        
        # Assume the main part is the active object (if mesh) or the first imported mesh
        imported_obj = context.active_object if context.active_object in selected_meshes else selected_meshes[0]
        
        # Ensure only the main mesh is active and selected for the next operations
        bpy.ops.object.select_all(action='DESELECT')
        imported_obj.select_set(True)
        context.view_layer.objects.active = imported_obj

        # --- MEDICAL LOGIC: Auto-Center ---
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        imported_obj.location = (0, 0, 0)
        self.report({'INFO'}, "Auto-centered to world origin")
        
        # --- MEDICAL LOGIC: Set scene to mm-space ---
        scene = context.scene
        scene.unit_settings.system = 'METRIC'
        scene.unit_settings.scale_length = 0.001
        scene.unit_settings.length_unit = 'MILLIMETERS'

        # --- MEDICAL LOGIC: Unit scaling INTO mm-space (SINGLE pass) ---
        unit = props.import_units if props else 'MM'
        raw_max = max(imported_obj.dimensions)

        EXPLICIT_TO_MM = {'MM': 1.0, 'CM': 10.0, 'M': 1000.0, 'IN': 25.4}
        if unit in EXPLICIT_TO_MM:
            factor = EXPLICIT_TO_MM[unit]
        else:
            factor = _auto_scale_factor(raw_max)

        if factor != 1.0:
            imported_obj.scale = [s * factor for s in imported_obj.scale]
            self.report({'INFO'}, f"Import unit {unit}: scaled x{factor:g} into mm")

        # Bake the scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        # --- Validate final size (mm-space) ---
        max_dim = max(imported_obj.dimensions)
        if max_dim > 5000:
            self.report({'WARNING'}, f"Model is {max_dim:.0f} mm - larger than a typical device.")
        elif max_dim < 10:
            self.report({'WARNING'}, f"Model is {max_dim:.1f} mm - smaller than a typical device.")
        else:
            self.report({'INFO'}, f"Imported at {max_dim:.0f} mm max size")
        
        # --- MEDICAL LOGIC: Check for Non-Manifold Geometry ---
        bm = bmesh.new()
        bm.from_mesh(imported_obj.data)
        
        non_manifold_count = 0
        for edge in bm.edges:
            if not edge.is_manifold:
                non_manifold_count += 1
        
        bm.free()
        
        if non_manifold_count > 0:
            self.report({'WARNING'}, f"Mesh is not watertight! Found {non_manifold_count} open edges.")
        else:
            self.report({'INFO'}, "Mesh is watertight (Manifold)")

        # --- mm-space view fix ---
        _setup_mm_viewport()
        _frame_object(context, imported_obj)

        if props and getattr(props, "white_viewport", False):
            try:
                from ..utils.branding import set_white_viewport
                set_white_viewport()
            except Exception:
                pass

        # --- Before/after comparison snapshot ---
        _snapshot_original(context, imported_obj)

        record_event("workflow_started", workflow=workflow_from_context(context))
        try:
            workflow, device_type = _session_workflow_and_device(context)
            get_recorder().start(workflow, device_type)
        except Exception:
            pass

        return {'FINISHED'}


class CenterModel(Operator):
    """Center the active model on the world origin and frame it in the view"""
    bl_idname = "dynax.center_model"
    bl_label = "Center model"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Select a mesh object first")
            return {'CANCELLED'}

        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj

        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        obj.location = (0, 0, 0)

        _setup_mm_viewport()
        _frame_object(context, obj)

        self.report({'INFO'}, "Centered on world origin and framed view")
        return {'FINISHED'}
