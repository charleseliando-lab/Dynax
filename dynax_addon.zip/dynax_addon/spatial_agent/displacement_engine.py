"""
DynaX Spatial Agent — Displacement Engine
Applies geodesic-approximated influence fields to mesh vertices.
"""

import math

import bpy
import bmesh
from mathutils import Vector, kdtree

from .landmark_manager import get_stored_zones, get_target_mesh, ALL_LANDMARK_IDS, get_zone_meta
from .ruleset.ruleset_engine import DynaXRuleset

# Zones the ruleset's own agent_rules explicitly forbid ever pushing inward
# ("Never apply inward displacement over FH, TC, DTT, DFT, HT, or PAT" —
# transtibial_ruleset.json's agent_rules + the "sensitive_clearance"
# validation gate). Enforced in apply_all_zones' _safety_clamp regardless of
# what a clinician's slider delta computes to, since a large negative delta
# on top of one of these zones' positive base target_mm could otherwise
# flip it inward.
_NEVER_INWARD_ZONE_IDS = {"FH", "TC", "DTT", "DFT", "HT", "PAT"}

# "All proximal zone displacement fields (MC, LC, FH) must decay to 0.0mm
# at the top edge of the model" — transtibial_ruleset.json's agent_rules
# and the "proximal_edge_decay" validation gate. See compute_displacement_
# field's decay_band handling.
_PROXIMAL_DECAY_ZONE_IDS = {"MC", "LC", "FH"}

# "Lateral condyle addition must blend continuously toward fibular head —
# peroneal nerve pathway between them must not be pinched" — agent_rules +
# the "peroneal_nerve_clearance" validation gate. Enforced geometrically in
# apply_all_zones by an extra, stronger smoothing pass across the UNION of
# these two zones' vertices after both are individually applied — this is
# the only pair of zones the ruleset calls out an explicit cross-zone
# `interaction_rule` for (LC's own `interactions: ["FH"]`).
_BLEND_LINKED_ZONE_PAIRS = [("LC", "FH")]

# Smoothing strength scales with the ruleset's own `sensitivity` field
# (already authored per landmark — critical/high for bony prominences that
# a sharp-edged relief field would turn into a NEW pressure point at its
# own boundary; medium/low for broader soft-tissue zones where a seam is a
# cosmetic, not a safety, concern). More iterations + a gentler blend
# factor per pass make a high-sensitivity zone's edge ease in over more of
# its own falloff distance rather than stepping between smooth_zone/
# smooth_mesh's flat single-pass default.
_SMOOTH_ITERATIONS_BY_SENSITIVITY = {"critical": 3, "high": 2, "medium": 1, "low": 1}
_SMOOTH_FACTOR_BY_SENSITIVITY = {"critical": 0.25, "high": 0.28, "medium": 0.3, "low": 0.3}


def smooth_falloff(distance: float, blend_radius: float) -> float:
    """Cosine falloff: 1.0 at distance=0, 0.0 at distance>=blend_radius."""
    if blend_radius <= 0:
        return 0.0
    if distance <= 0:
        return 1.0
    if distance >= blend_radius:
        return 0.0
    return 0.5 * (1.0 + math.cos(math.pi * distance / blend_radius))


def _smoothstep(edge0: float, edge1: float, x: float) -> float:
    if edge1 <= edge0:
        return 0.0 if x < edge0 else 1.0
    t = max(0.0, min(1.0, (x - edge0) / (edge1 - edge0)))
    return t * t * (3.0 - 2.0 * t)


def compute_displacement_field(obj, zone, rule: dict) -> dict:
    """
    For each vertex in obj.data.vertices, compute a displacement vector
    (in WORLD space — apply_displacement_field converts each one back to a
    local-space delta before adding it to the mesh).

    When the zone has real vertex_indices (the mesh-selection zone-mapping
    system, v1.23.5+), distance is measured to the NEAREST vertex actually
    painted as part of the zone — so an irregularly-shaped painted area
    gets a matching irregular influence field, with every painted vertex
    itself at full weight (distance 0), and the field only falls off
    beyond the zone's own boundary. Falls back to Euclidean distance from
    the zone centroid (geodesic deferred to a later version) for any older
    zone stored without vertex_indices.

    `rule` is a plain {"target_mm": ..., "blend_radius_mm": ...} dict — kept
    decoupled from any one metadata source so this function itself never
    needs to change if the ruleset schema does; apply_all_zones is what
    actually builds it (ruleset target_mm + slider delta, ruleset
    blend_radius_mm, both safety-clamped).

    A real unit bug lived here in an earlier version (found by reading the
    ruleset data, not assumed): target/blend_radius were divided by 1000 as
    if the scene were in metres — this addon's whole codebase is mm-space
    (1 Blender unit = 1mm, see CLAUDE.md's "Unit System Architecture";
    compare operators/offset.py's _mm_to_blender, which explicitly does NOT
    divide by 1000), so a real 3mm push was being applied as 0.003mm
    (invisible). Values passed in here are plain mm, no conversion.
    """
    mesh = obj.data
    mat_world = obj.matrix_world
    mat_world_inv = mat_world.inverted()
    normal_matrix = mat_world_inv.transposed().to_3x3()

    blend_radius = rule["blend_radius_mm"]
    target = rule["target_mm"]

    zone_indices = set(getattr(zone, "vertex_indices", None) or [])
    kd = None
    if zone_indices:
        kd = kdtree.KDTree(len(zone_indices))
        for i, idx in enumerate(zone_indices):
            if idx < len(mesh.vertices):
                kd.insert(mesh.vertices[idx].co, i)
        kd.balance()

    centroid_local = mat_world_inv @ Vector(zone.centroid)

    # Proximal trimline decay (v1.24.4) — transtibial_ruleset.json's
    # agent_rules: "All proximal zone displacement fields (MC, LC, FH) must
    # decay to 0.0mm at the top edge of the model — trimline boundary."
    # Approximated geometrically as a smoothstep ramp from full weight at
    # (rim − proximal_decay_band_mm) down to exactly 0 at the rim itself,
    # where "rim" is the mesh's own highest local-Z vertex — this add-on's
    # established Z-up proximal/distal convention (see e.g.
    # utils/measurement_helpers.py's height-band logic). apply_all_zones
    # sets proximal_decay_band_mm only for MC/LC/FH; every other zone leaves
    # it unset and this block is skipped entirely (no behavior change).
    decay_band = rule.get("proximal_decay_band_mm")
    rim_z = None
    if decay_band:
        rim_z = max(v.co.z for v in mesh.vertices)

    field = {}
    for v in mesh.vertices:
        if kd is not None:
            distance = 0.0 if v.index in zone_indices else kd.find(v.co)[2]
        else:
            distance = (v.co - centroid_local).length
        w = smooth_falloff(distance, blend_radius)
        if w <= 0.0:
            continue
        if decay_band:
            # 1.0 well below the rim, ramping smoothly to 0.0 exactly at it.
            w *= 1.0 - _smoothstep(rim_z - decay_band, rim_z, v.co.z)
            if w <= 0.0:
                continue
        d = target * w

        # World-space outward normal — a local-space normal is only
        # correct if the object has no rotation/non-uniform scale; this is
        # the general-correct transform (inverse-transpose of the world
        # matrix) regardless of the object's current transform.
        world_normal = (normal_matrix @ v.normal).normalized()

        field[v.index] = world_normal * d

    return field


def apply_displacement_field(obj, field: dict):
    """Apply world-space displacement vectors to vertices (converted to
    local-space deltas first — vertex .co is always local). Does NOT smooth;
    smoothing must run once after every zone has been applied (see
    DYNAX_OT_apply_landmark_rules.execute) — smoothing after each individual
    zone was washing out earlier zones' displacement before the next zone
    could add to it.

    Works directly on the mesh datablock via bmesh.new()/to_mesh() — NEVER
    enters Edit Mode. A real, measured performance bug lived here: this
    used bpy.ops.object.mode_set(mode='EDIT'/'OBJECT') around every call,
    and apply_all_zones calls this once PER ZONE — a real ruleset landmark
    set (8 required zones) meant 16 mode-switch operator calls on every
    single slider tick. Each bpy.ops.object.mode_set() call is expensive
    (depsgraph sync, undo-stack push, viewport redraw) — in the live GUI
    (not the headless profiling that first measured ~0.42s/tick here) this
    compounds into the sliders feeling unresponsive/laggy enough to read as
    "not clickable". smooth_zone() and apply_global_compression() in this
    same file already used the mode-free bmesh.new()/to_mesh() pattern —
    this now matches them, and needs no mode_set calls at all since bmesh
    operating on a copy of the mesh datablock works identically in Object
    Mode."""
    if not field:
        return

    normal_matrix_inv = obj.matrix_world.inverted().to_3x3()

    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    for idx, world_disp in field.items():
        if idx < len(bm.verts):
            bm.verts[idx].co += normal_matrix_inv @ world_disp
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()


def smooth_mesh(obj, iterations: int = 3):
    """Apply a vertex smooth pass to the WHOLE mesh, `iterations` times.
    bmesh.ops.smooth_vert() directly, not bpy.ops.mesh.vertices_smooth() +
    mode_set(EDIT/OBJECT) — see apply_displacement_field's docstring for the
    measured mode-switch performance cost this avoids (this function was
    the other remaining mode_set pair in the per-slider-tick path)."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    for _ in range(iterations):
        bmesh.ops.smooth_vert(bm, verts=bm.verts, factor=0.5)
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()


def smooth_zone(obj, vertex_indices, iterations: int = 1, factor: float = 0.3):
    """Smooth ONLY the given vertices toward their connected-neighbour
    average, in local space — used per-zone right after that zone's
    displacement is applied, so a zone's own jagged edge (from the
    cosine-falloff field being sampled on discrete real scan topology) gets
    gently relaxed without blurring across into neighbouring zones the way
    a whole-mesh smooth would. Deliberately gentler (factor 0.3, default 1
    iteration) than smooth_mesh's whole-mesh pass (factor 0.5, 3
    iterations) — a zone's boundary vertices need to stay close to their
    computed weight, not converge toward the (undisplaced) exterior."""
    if not vertex_indices:
        return
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    _smooth_zone_verts(bm, vertex_indices, iterations, factor)
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()


def _smooth_zone_verts(bm, vertex_indices, iterations: int, factor: float):
    """Same math as smooth_zone, operating on an ALREADY-OPEN bmesh without
    its own from_mesh/to_mesh round-trip — the shared-bm half of
    _apply_and_smooth_zone's fused per-zone pass (see that function's
    docstring)."""
    zone_set = set(vertex_indices)
    bm.verts.ensure_lookup_table()
    for _ in range(iterations):
        deltas = {}
        for idx in zone_set:
            if idx >= len(bm.verts):
                continue
            v = bm.verts[idx]
            neighbour_cos = [e.other_vert(v).co for e in v.link_edges]
            if neighbour_cos:
                avg = sum(neighbour_cos, Vector()) / len(neighbour_cos)
                deltas[idx] = v.co.lerp(avg, factor)
        for idx, new_co in deltas.items():
            bm.verts[idx].co = new_co


def _apply_and_smooth_zone(obj, field: dict, iterations: int, factor: float):
    """Fused apply_displacement_field() + smooth_zone() for ONE zone, in a
    SINGLE bmesh.new()/from_mesh()/to_mesh() round-trip instead of two back
    to back. Real, measured perf fix: apply_all_zones calls this once per
    stored zone (8 for the ruleset's required set) on every single slider
    tick — the previous apply-then-smooth pair meant 2 full mesh
    read/write conversions per zone, 16 per tick, for a purely internal
    hand-off between two steps that never needed to leave bmesh at all.
    Flushes to obj.data at exactly the same point the old two-call sequence
    did (once, after both steps) — zero behavior change versus calling
    apply_displacement_field() then smooth_zone() separately, verified
    against this session's existing exact-mm slider tests."""
    if not field:
        return
    normal_matrix_inv = obj.matrix_world.inverted().to_3x3()

    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    for idx, world_disp in field.items():
        if idx < len(bm.verts):
            bm.verts[idx].co += normal_matrix_inv @ world_disp
    _smooth_zone_verts(bm, list(field.keys()), iterations, factor)
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()


BASELINE_SUFFIX = "_spatial_baseline"
COMPARE_SUFFIX = "_SPATIAL_BASELINE_SNAPSHOT"
ZONE_ADJUST_PREFIX = "dynax_zone_adjust_"


def _slider_prop_name(zone_id: str) -> str:
    return ZONE_ADJUST_PREFIX + zone_id.lower()


def store_baseline_snapshot(obj):
    """Snapshot the mesh as it is RIGHT NOW into a hidden mesh datablock,
    never assigned as any object's data — the pristine pre-displacement
    reference every per-zone slider re-applies from, AND (via
    _ensure_spatial_compare_object) the source for the visual "compare to
    before the Spatial Agent" overlay. Must be called BEFORE any zone
    displacement runs (see DYNAX_OT_apply_landmark_rules.execute), not
    after — every slider's value IS that zone's total displacement from the
    untouched mesh (see apply_all_zones), so the baseline has to actually
    BE the untouched mesh."""
    name = obj.name + BASELINE_SUFFIX
    existing = bpy.data.meshes.get(name)
    if existing is not None:
        bpy.data.meshes.remove(existing)
    snapshot = obj.data.copy()
    snapshot.name = name
    _ensure_spatial_compare_object(obj, snapshot)


def restore_from_baseline(obj) -> bool:
    """Restore obj.data's vertex positions to the stored baseline snapshot,
    in place (topology/vertex count must match — this only ever moves
    vertices, never adds/removes them, so it always does). Returns False
    (no-op) if no baseline was ever stored."""
    snapshot = bpy.data.meshes.get(obj.name + BASELINE_SUFFIX)
    if snapshot is None or len(snapshot.vertices) != len(obj.data.vertices):
        return False
    coords = [0.0] * (len(snapshot.vertices) * 3)
    snapshot.vertices.foreach_get("co", coords)
    obj.data.vertices.foreach_set("co", coords)
    obj.data.update()
    return True


def zone_current_offset_mm(obj, zone) -> float:
    """Average distance (mm) the zone's own vertices currently sit from
    where they were in the pre-adjustment baseline — the real, MEASURED
    result of a slider's target_mm after falloff + smoothing have both been
    applied (which is never bit-exact with the requested target_mm — see
    smooth_zone/smooth_mesh), shown next to each slider in the panel so the
    clinician sees actual mm moved, not just the requested value. Returns
    0.0 if there is no baseline yet or the zone has no vertices."""
    snapshot = bpy.data.meshes.get(obj.name + BASELINE_SUFFIX)
    indices = getattr(zone, "vertex_indices", None) or []
    if snapshot is None or not indices:
        return 0.0
    wm = obj.matrix_world
    total = 0.0
    count = 0
    for idx in indices:
        if idx >= len(snapshot.vertices) or idx >= len(obj.data.vertices):
            continue
        before = wm @ snapshot.vertices[idx].co
        after = wm @ obj.data.vertices[idx].co
        total += (after - before).length
        count += 1
    return (total / count) if count else 0.0


def apply_global_compression(obj, pct: float):
    """Uniformly scale the mesh about its OWN local-space centroid so its
    volume shrinks by `pct` percent — transtibial_ruleset.json's TSB
    global_preprocessing step ("apply uniform global volume compression
    across entire mesh before local rectification"). A uniform 3-axis scale
    factor `f` shrinks volume by f**3, so f = (1 - pct/100) ** (1/3) is the
    factor that shrinks volume by exactly pct%. Called ONCE per object (see
    the dynax_spatial_compression_applied guard in
    DYNAX_OT_apply_landmark_rules) — this is real, permanent geometry
    change, not a per-zone field, so it must never be replayed inside
    apply_all_zones (which restore_from_baseline + apply_all_zones DOES
    re-run every time a slider moves — compression has to already be baked
    into the baseline by the time that loop starts, not re-applied on top
    of itself every slider tick)."""
    if pct <= 0:
        return
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    if not bm.verts:
        bm.free()
        return
    centroid = sum((v.co for v in bm.verts), Vector()) / len(bm.verts)
    factor = (1.0 - pct / 100.0) ** (1.0 / 3.0)
    for v in bm.verts:
        v.co = centroid + (v.co - centroid) * factor
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()


def _safety_clamp(zone_id: str, target_mm: float, base_rule: dict) -> float:
    """Two safety clamps grounded directly in the ruleset's own text, not
    invented: (1) never let target_mm exceed boundary_max_mm in magnitude —
    the ruleset's documented absolute safety limit, distinct from the
    tighter min_mm/max_mm "normal" range a slider can reach; (2) never let
    a zone in _NEVER_INWARD_ZONE_IDS go negative, regardless of how a
    slider delta computes — agent_rules: "Never apply inward displacement
    over FH, TC, DTT, DFT, HT, or PAT.\""""
    boundary = base_rule.get("boundary_max_mm")
    if boundary is not None:
        if boundary >= 0:
            target_mm = max(0.0, min(target_mm, boundary))
        else:
            target_mm = min(0.0, max(target_mm, boundary))
    if zone_id in _NEVER_INWARD_ZONE_IDS:
        target_mm = max(0.0, target_mm)
    return target_mm


def apply_all_zones(context, obj, report=None) -> list:
    """Re-apply EVERY stored zone's displacement from scratch: each zone's
    target_mm is the ruleset's own signed value for the active concept
    (TSB/PTB) PLUS that zone's slider delta (0.0 until a clinician adjusts
    it), safety-clamped (see _safety_clamp). Shared by
    DYNAX_OT_apply_landmark_rules (first run, every slider still at its
    default 0.0 delta — so the FIRST Apply already produces the ruleset's
    recommended starting shape) and the per-zone slider callback (every
    re-run) so both paths compute the exact same way — a slider MUST
    restore the pristine baseline and replay every zone together, not patch
    just the one that moved: zones' blend radii can overlap the same
    vertices, so reapplying only one zone on top of an already-multi-zone-
    displaced mesh would double-count the overlap. Returns the list of
    landmark_ids actually applied (i.e. produced a non-zero, non-empty
    field)."""
    scene = context.scene
    zones = get_stored_zones(scene)
    if not zones:
        return []

    concept = getattr(scene, "dynax_spatial_concept", "TSB")
    ruleset = DynaXRuleset()
    ruleset.set_concept(concept)

    covariates = ruleset.get_patient_covariate_modifiers(
        getattr(scene, "dynax_stump_type", "NONE"),
        getattr(scene, "dynax_prominence_depth", "NONE"),
    )

    zones_by_id = {z.landmark_id: z for z in zones}
    applied = []
    for zone in zones:
        try:
            base_rule = ruleset.get_landmark_rule(zone.landmark_id, concept)
        except KeyError:
            if report:
                report({'WARNING'}, f"Zone {zone.landmark_id}: no rule for concept {concept}")
            continue

        # Patient covariate scaling (v3.2.0's "ASK FIRST" agent_rule) —
        # applied to the ruleset's own target_mm BEFORE the clinician's
        # slider delta, so the delta always reads as "N more/fewer mm on
        # top of the (already patient-adjusted) recommended shape", not a
        # value that silently shifts meaning depending on covariate answers.
        base_target = base_rule["target_mm"]
        if base_target < 0:
            base_target *= covariates["reduction_modifier"]
        else:
            base_target *= covariates["addition_modifier"]
            if "lateral" in base_rule.get("location_description", "").lower():
                base_target *= covariates["addition_modifier_lateral"]

        delta = getattr(scene, _slider_prop_name(zone.landmark_id), 0.0) or 0.0
        target_mm = _safety_clamp(zone.landmark_id, base_target + delta, base_rule)
        if target_mm == 0.0:
            # Skip entirely — a zero-target zone must leave the mesh exactly
            # as the baseline, not just "displace by zero". Measured this as
            # a real bug: applying a field of zero-length vectors and then
            # smoothing on top of it still moves real (curved) geometry
            # ~0.5mm toward the local neighbour average.
            continue

        rule = {"target_mm": target_mm, "blend_radius_mm": base_rule["blend_radius_mm"]}
        if zone.landmark_id in _PROXIMAL_DECAY_ZONE_IDS:
            rule["proximal_decay_band_mm"] = base_rule["blend_radius_mm"]

        field = compute_displacement_field(obj, zone, rule)
        if not field:
            continue
        sensitivity = base_rule.get("sensitivity", "medium")
        _apply_and_smooth_zone(
            obj, field,
            iterations=_SMOOTH_ITERATIONS_BY_SENSITIVITY.get(sensitivity, 1),
            factor=_SMOOTH_FACTOR_BY_SENSITIVITY.get(sensitivity, 0.3),
        )
        applied.append(zone.landmark_id)

    # LC/FH blend continuity — an extra smoothing pass across the union of
    # both zones' vertices, only when both were actually applied this pass.
    for zone_a_id, zone_b_id in _BLEND_LINKED_ZONE_PAIRS:
        if zone_a_id in applied and zone_b_id in applied:
            linked_verts = list(set(
                (zones_by_id[zone_a_id].vertex_indices or [])
                + (zones_by_id[zone_b_id].vertex_indices or [])
            ))
            smooth_zone(obj, linked_verts, iterations=2, factor=0.35)

    # One light global smooth at the very end — blends the seams between
    # zones (and between zones and untouched mesh) without erasing the
    # per-zone shape smooth_zone already preserved.
    if applied:
        smooth_mesh(obj, iterations=1)

    return applied


class DYNAX_OT_apply_landmark_rules(bpy.types.Operator):
    """Apply the ruleset displacement for every stored landmark zone"""
    bl_idname = "dynax.apply_landmark_rules"
    bl_label = "Apply Landmark Rules"

    def execute(self, context):
        scene = context.scene
        obj = get_target_mesh(context)
        if obj is None:
            self.report({'ERROR'}, "Select the socket mesh first")
            return {'CANCELLED'}

        zones = get_stored_zones(scene)
        if not zones:
            self.report({'WARNING'}, "No landmark zones stored")
            return {'CANCELLED'}

        # Ruleset's own "ASK FIRST" agent_rule: both patient-constraint
        # questions must be answered before any displacement runs, every
        # time (not just once per session) — a clinician could otherwise
        # change patient/scan without re-confirming, and every zone's
        # target_mm depends on these answers (see apply_all_zones'
        # covariate scaling).
        if getattr(scene, "dynax_stump_type", "NONE") == "NONE" or \
                getattr(scene, "dynax_prominence_depth", "NONE") == "NONE":
            self.report({'ERROR'},
                "Set patient constraints (stump type + prominence depth) before applying rules.")
            return {'CANCELLED'}

        concept = getattr(scene, "dynax_spatial_concept", "TSB")
        ruleset = DynaXRuleset()
        ruleset.set_concept(concept)

        # Global volume compression (TSB only, real geometry change, applied
        # ONCE — see apply_global_compression's docstring for why this must
        # happen before the baseline snapshot and never be replayed by
        # apply_all_zones). Guarded by a custom property so a second click
        # of this button doesn't compound compression on an already-
        # compressed mesh.
        if not obj.get("dynax_spatial_compression_applied"):
            compression = ruleset.get_global_compression(concept)
            if compression.get("apply_before_landmarks"):
                apply_global_compression(obj, compression.get("volume_compression_pct", 0.0))
            obj["dynax_spatial_compression_applied"] = True

        # Snapshot AFTER compression, BEFORE any per-zone displacement — see
        # store_baseline_snapshot's docstring for why this ordering matters.
        store_baseline_snapshot(obj)

        applied = apply_all_zones(context, obj, report=self.report)
        scene.dynax_spatial_rules_applied = True

        if applied:
            self.report({'INFO'}, f"Applied {len(applied)}/{len(zones)} zones: {', '.join(applied)}. "
                                   "Use the sliders below to fine-tune.")
        else:
            self.report({'WARNING'}, "No zones could be applied — check that a rule exists for each "
                                      f"landmark under the {concept} concept.")
        return {'FINISHED'}


def on_zone_slider_update(context, landmark_id: str):
    """Property update callback for a dynax_zone_adjust_<id> slider: restore
    the pristine pre-displacement baseline, then replay every zone (this
    one now carrying its new delta) in one pass. See apply_all_zones'
    docstring for why every zone must be replayed together, not just this
    one landmark."""
    obj = context.active_object
    if obj is None:
        return
    if not restore_from_baseline(obj):
        return
    apply_all_zones(context, obj)


class DYNAX_OT_reset_zone_adjustments(bpy.types.Operator):
    """Reset every per-zone adjustment slider to 0 and restore the mesh to
    its state right after Apply Landmark Rules (before any slider moved)"""
    bl_idname = "dynax.reset_zone_adjustments"
    bl_label = "Reset Zone Adjustments"

    def execute(self, context):
        scene = context.scene
        obj = context.active_object

        # Plain attribute assignment (not the scene["prop"] = 0.0 ID-property
        # bracket form) — verified directly that for a simple registered
        # FloatProperty, bracket assignment writes a SEPARATE raw ID-property
        # storage that scene.<prop> never reads back from, so it silently
        # doesn't reset the value at all. Each assignment below fires
        # on_zone_slider_update, which is harmless busywork (every call
        # restores the same baseline and replays every zone with whatever
        # values are currently set — self-consistent regardless of order)
        # rather than something that needs suppressing.
        for zone_id in ALL_LANDMARK_IDS:
            prop = _slider_prop_name(zone_id)
            if hasattr(scene, prop):
                setattr(scene, prop, 0.0)

        if obj is not None:
            restore_from_baseline(obj)
            apply_all_zones(context, obj, report=self.report)

        self.report({'INFO'}, "Zone adjustments reset")
        return {'FINISHED'}


# ── Compare to pre-adjustment (v1.24.1) ──────────────────────────────────
#
# Reuses operators/compare_overlay.py's proven alignment-constraint pattern
# (COPY_TRANSFORMS, attached only while the overlay is shown) rather than
# re-implementing wireframe-overlay plumbing — see that module for why a
# constraint was chosen over parenting/depsgraph-handler syncing. This is a
# SEPARATE snapshot from Creator's own "Compare with Original" (which
# captures the mesh at IMPORT time — the raw scan, before Cleanup/Align/
# Sculpt/Trim/Thickness ever touch it): this one specifically answers "what
# did the Spatial Agent itself change", i.e. the state right before
# DYNAX_OT_apply_landmark_rules's first run.

def _ensure_spatial_compare_object(obj, baseline_mesh):
    """Create/refresh a hidden object wrapping a COPY of baseline_mesh, for
    the visual compare-overlay toggle. Kept separate from baseline_mesh
    itself (which restore_from_baseline mutates-by-reading, never writes to
    obj.data) so the overlay object's own mesh is never at risk of being
    reassigned elsewhere."""
    name = obj.name + COMPARE_SUFFIX
    existing = bpy.data.objects.get(name)
    if existing is not None:
        old_mesh = existing.data
        bpy.data.objects.remove(existing, do_unlink=True)
        if old_mesh is not None and old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)

    snap_mesh = baseline_mesh.copy()
    snap_mesh.name = name
    snap_obj = bpy.data.objects.new(name, snap_mesh)
    snap_obj.matrix_world = obj.matrix_world.copy()
    snap_obj["dynax_is_spatial_baseline_snapshot"] = True
    snap_obj.hide_render = True
    # Must link into the view layer BEFORE hide_set() — hide_set() operates
    # on the object's view-layer state and raises if the object isn't in
    # one yet (verified: "cannot be hidden because it is not in View Layer").
    bpy.context.collection.objects.link(snap_obj)
    snap_obj.hide_set(True)
    obj["dynax_spatial_snapshot_name"] = snap_obj.name
    return snap_obj


class DYNAX_OT_toggle_spatial_compare(bpy.types.Operator):
    """Show/hide the mesh as it looked before the Spatial Agent made any
    adjustment, as an orange wireframe overlay"""
    bl_idname = "dynax.toggle_spatial_compare"
    bl_label = "Compare to Pre-Adjustment"
    bl_description = ("Show the mesh as it looked before Apply Landmark "
                       "Rules first ran, as a thin outline over the current mesh")
    bl_options = {'REGISTER'}

    def execute(self, context):
        from ..operators.compare_overlay import (
            _attach_alignment, _detach_alignment, COMPARE_COLOR, COMPARE_OPACITY,
        )

        obj = get_target_mesh(context)
        if obj is None:
            self.report({'ERROR'}, "Select the socket mesh first")
            return {'CANCELLED'}

        name = obj.get("dynax_spatial_snapshot_name", "")
        snap_obj = bpy.data.objects.get(name) if name else None
        if snap_obj is None:
            self.report({'WARNING'},
                "No pre-adjustment snapshot found. Run Apply Landmark Rules first.")
            return {'CANCELLED'}

        was_hidden = snap_obj.hide_get()
        snap_obj.hide_set(not was_hidden)

        if was_hidden:
            snap_obj.display_type = 'WIRE'
            snap_obj.show_in_front = True
            snap_obj.color = COMPARE_COLOR
            _attach_alignment(snap_obj, obj)
            self.report({'INFO'},
                f"Pre-adjustment overlay shown (orange wireframe, {COMPARE_OPACITY:.3f} opacity).")
        else:
            _detach_alignment(snap_obj)
            self.report({'INFO'}, "Pre-adjustment overlay hidden.")

        return {'FINISHED'}


# ── Per-zone slider property registration ────────────────────────────────
#
# ALL_LANDMARK_IDS comes from a plain JSON read (DynaXRuleset), not
# bpy.data.libraries.load, so — unlike ParaFly TT/TLSO/AFO's zone sliders —
# this registration doesn't strictly need to be deferred past Blender's
# restricted STARTUP auto-load. It's still called from __init__.py's
# existing _register_sliders_deferred timer anyway, purely to keep one
# registration entry point for every dynamic per-zone Scene property in
# this add-on rather than a second, differently-timed one.

def _make_zone_slider_update(zone_id):
    def _update(self, context):
        on_zone_slider_update(context, zone_id)
    return _update


# Fine-tune delta range — a slider's value is added to the ruleset's own
# signed target_mm for that zone/concept (see apply_all_zones), not the
# zone's absolute displacement, so its range only needs to cover a
# reasonable adjustment on top of that starting point, not the zone's full
# clinical span (which is already respected by _safety_clamp's
# boundary_max_mm check regardless of what a slider allows).
ZONE_ADJUST_DELTA_RANGE_MM = 10.0


def register_zone_adjust_properties():
    unregister_zone_adjust_properties()
    for zone_id in ALL_LANDMARK_IDS:
        meta = get_zone_meta(zone_id)
        attr = _slider_prop_name(zone_id)
        setattr(bpy.types.Scene, attr, bpy.props.FloatProperty(
            name=meta["display_name"],
            description=f"Fine-tune {meta['display_name']}'s displacement, "
                         "on top of the ruleset's default (mm)",
            soft_min=-ZONE_ADJUST_DELTA_RANGE_MM,
            soft_max=ZONE_ADJUST_DELTA_RANGE_MM,
            default=0.0,
            precision=1,
            subtype='DISTANCE',
            unit='LENGTH',
            update=_make_zone_slider_update(zone_id),
        ))


def unregister_zone_adjust_properties():
    for zone_id in ALL_LANDMARK_IDS:
        attr = _slider_prop_name(zone_id)
        if hasattr(bpy.types.Scene, attr):
            try:
                delattr(bpy.types.Scene, attr)
            except Exception:
                pass
