"""
DynaX Spatial Agent — UI Panel

SUPERSEDED (v1.23.1): DYNAX_PT_spatial_agent as a standalone N-panel entry
was not reachable/visible where clinicians look for DynaX AI. The Spatial
Agent UI now lives inside the existing DYNAX_PT_ai_section popover
(panels/ai_assistant.py's `_draw_spatial_agent`), behind a Chat/Spatial
Agent mode toggle. This class is kept on disk for reference but is no
longer imported/registered in __init__.py.
"""

import bpy

from .landmark_manager import get_stored_zones


class DYNAX_PT_spatial_agent(bpy.types.Panel):
    bl_label = "Spatial Agent"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'DynaX'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.label(text="Transtibial Socket", icon='ARMATURE_DATA')

        row = layout.row()
        row.prop(scene, "dynax_spatial_concept", expand=True)

        layout.separator()
        box = layout.box()
        box.label(text="Landmark Zones")
        box.prop(scene, "dynax_spatial_landmark_id", text="")

        row = box.row(align=True)
        row.operator("dynax.landmark_start_zone", icon='GREASEPENCIL')
        row.operator("dynax.landmark_confirm_zone", icon='CHECKMARK')

        zones = get_stored_zones(scene)
        if zones:
            box.label(text="Placed zones:")
            col = box.column(align=True)
            for zone in zones:
                col.label(text=f"• {zone.landmark_name}", icon='CHECKMARK')

        box.operator("dynax.landmark_clear_all", icon='TRASH')

        layout.separator()
        box = layout.box()
        box.label(text="Apply Rules")
        box.operator("dynax.apply_landmark_rules", icon='MOD_SIMPLEDEFORM')

        layout.separator()
        box = layout.box()
        box.label(text="Trimline")
        box.label(text="(placeholder — v1.24)")

        layout.separator()
        box = layout.box()
        box.label(text="Export")
        box.label(text="(placeholder — v1.24)")
