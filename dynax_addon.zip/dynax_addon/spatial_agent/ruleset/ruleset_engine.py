"""
DynaX Spatial Agent — Ruleset Engine
Loads and queries the transtibial socket ruleset.
The agent reasons over these rules; the geometry engine executes them.

v3.0.0 (2026-08-23): replaced the ruleset with a clinician-authored 11-
landmark CAD Modification Matrix (transtibial_ruleset.json, "source":
"Transtibial Socket CAD Modification Matrix — AI Training Reference").
Two real schema differences from the earlier ruleset this class was written
against, found by reading the actual file rather than assuming the old
shape still applied:

1. Per-landmark concept rules are now FLAT keys `"TSB"` / `"PTB"` directly
   on the landmark dict, not nested under a `"concept_rules"` wrapper.
   get_landmark_rule() reads `lm[concept]` accordingly.
2. There is no `trimline_rules` key and no per-landmark `"interactions"`
   list in this version of the file — both were speculative fields in the
   old ruleset that nothing else in this add-on ever actually read (grepped
   the whole tree; only this file's own old code referenced them). Removed
   rather than defended with a `.get(..., {})` fallback, since a silently-
   empty trimline/interactions query would be worse than the AttributeError
   that flags a real caller needs adding one back.

New in v3: `global_preprocessing` (a one-time uniform volume-compression
step applied before any per-landmark displacement, TSB only — see
get_global_compression and displacement_engine.apply_global_compression),
and `required_landmarks` / `recommended_landmarks` / `optional_landmarks`
tier lists (surfaced in the panel — see landmark_manager.py).

v3.1.0 (2026-08-23): 2 landmarks added (MC "Medial Femoral Condyle", LC
"Lateral Femoral Condyle" — both now in required_landmarks, 13 landmarks
total) and `trimline_rules` reappeared with a DIFFERENT shape than the
pre-v3 version this class used to read (segments keyed by
`reference_landmarks` + free-text `constraint`, not `default_offset_mm` +
`constraints`) — deliberately NOT wired up here, since nothing in this
add-on consumes it yet; adding a getter for an unused field would be
speculative. Some landmarks (MC, LC) also carry optional
`trimline_role`/`trimline_note`/`interactions`/`interaction_rule` keys this
class does not read — get_landmark_rule() only ever copies the concept
sub-dict plus a fixed set of known top-level fields, so extra keys on a
landmark are silently harmless, not an error.

v3.2.0 (2026-08-24): 1 landmark added (EOS "End of Stump" — now also in
required_landmarks, 12 landmarks total; required tier is PT/TC/FH/DTT/
DFT/MC/LC/EOS). Every landmark gained a real clinician-facing
`description` field (see landmark_manager.get_zone_meta, which now prefers
it over `agent_note` for the panel's description box). New
`patient_covariates.bony_or_fleshy` / `.prominence_depth` blocks —
get_patient_covariate_modifiers() reads them; see
displacement_engine.apply_all_zones for how the modifiers are applied to
target_mm before displacement.
"""

import json
import os
from typing import Optional


RULESET_PATH = os.path.join(os.path.dirname(__file__), "transtibial_ruleset.json")


class DynaXRuleset:
    """
    Loads the versioned DynaX transtibial socket ruleset and exposes
    clean query methods for the spatial agent.
    """

    def __init__(self, path: str = RULESET_PATH):
        with open(path, "r") as f:
            self._data = json.load(f)

        # Index landmarks by ID for fast lookup
        self._landmarks = {lm["id"]: lm for lm in self._data["landmarks"]}

        self.concept = self._data["meta"]["default_concept"]

    # ------------------------------------------------------------------
    # Concept
    # ------------------------------------------------------------------

    def set_concept(self, concept: str):
        """Set PTB or TSB. Affects all subsequent rule queries."""
        supported = self._data["meta"]["supported_concepts"]
        if concept not in supported:
            raise ValueError(f"Concept must be one of {supported}")
        self.concept = concept

    # ------------------------------------------------------------------
    # Landmark queries
    # ------------------------------------------------------------------

    def get_all_landmark_ids(self) -> list:
        """Return every landmark id in file order (insertion order of the
        JSON's "landmarks" array)."""
        return list(self._landmarks.keys())

    def get_landmark(self, landmark_id: str) -> dict:
        """Return full landmark definition including rules for active concept."""
        lm = self._landmarks.get(landmark_id)
        if not lm:
            raise KeyError(f"Landmark '{landmark_id}' not found in ruleset.")
        return lm

    def get_landmark_rule(self, landmark_id: str, concept: Optional[str] = None) -> dict:
        """
        Return the active rule for a landmark under the current (or specified)
        concept — a flat dict ready for the geometry engine. `concept`'s rule
        block (`"TSB"` / `"PTB"`) sits directly on the landmark dict (v3
        schema — see this module's docstring).
        """
        concept = concept or self.concept
        lm = self.get_landmark(landmark_id)

        if concept not in lm:
            raise KeyError(f"Landmark '{landmark_id}' has no rule for concept '{concept}'.")

        rule = lm[concept].copy()
        rule["landmark_id"]   = landmark_id
        rule["landmark_name"] = lm["name"]
        rule["classification"] = lm["classification"]
        rule["modification"]  = lm["modification"]
        rule["color_category"] = lm["color_category"]
        rule["sensitivity"]   = lm["sensitivity"]
        rule["priority"]      = lm["priority"]
        rule["agent_note"]    = lm["agent_note"]
        rule["zone_type"]     = lm["zone_type"]
        rule["description"]   = lm.get("description", "")
        rule["location_description"] = lm.get("location_description", "")
        return rule

    def get_all_landmark_rules(self, concept: Optional[str] = None) -> list:
        """Return rules for all landmarks under the active concept, sorted by priority."""
        concept = concept or self.concept
        priority_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        rules = [self.get_landmark_rule(lm_id, concept) for lm_id in self._landmarks]
        rules.sort(key=lambda r: priority_order.get(r["priority"], 99))
        return rules

    def get_sensitive_landmarks(self) -> list:
        """Return landmark IDs flagged as high or critical sensitivity."""
        return [
            lm_id for lm_id, lm in self._landmarks.items()
            if lm["sensitivity"] in ("high", "critical")
        ]

    def get_critical_landmarks(self) -> list:
        """Return landmark IDs flagged as critical — these are never inward by default."""
        return [
            lm_id for lm_id, lm in self._landmarks.items()
            if lm["sensitivity"] == "critical"
        ]

    # ------------------------------------------------------------------
    # Landmark tiers (v3: required / recommended / optional)
    # ------------------------------------------------------------------

    def get_required_landmarks(self) -> list:
        return list(self._data.get("required_landmarks", []))

    def get_recommended_landmarks(self) -> list:
        return list(self._data.get("recommended_landmarks", []))

    def get_optional_landmarks(self) -> list:
        return list(self._data.get("optional_landmarks", []))

    # ------------------------------------------------------------------
    # Global preprocessing (v3)
    # ------------------------------------------------------------------

    def get_global_compression(self, concept: Optional[str] = None) -> dict:
        """Return the global_preprocessing block for a concept — a
        {"volume_compression_pct", "apply_before_landmarks", ...} dict, e.g.
        TSB's uniform 4% (3-5%) whole-mesh volume compression applied once
        before any per-landmark displacement. PTB's block has
        apply_before_landmarks=False (0% compression) — TSB and PTB are
        clinically different suspension concepts, not the same rule scaled
        down. Returns {"volume_compression_pct": 0.0,
        "apply_before_landmarks": False} for any concept missing from the
        ruleset's global_preprocessing block, rather than raising — this is
        a preprocessing nicety, not a required per-landmark rule."""
        concept = concept or self.concept
        return self._data.get("global_preprocessing", {}).get(
            concept, {"volume_compression_pct": 0.0, "apply_before_landmarks": False})

    # ------------------------------------------------------------------
    # Patient covariates (v3.2.0)
    # ------------------------------------------------------------------

    def get_patient_covariate_modifiers(self, stump_type: str, prominence_depth: str) -> dict:
        """Return the combined modifier dict for a clinician's two answers
        to the ruleset's own "ASK FIRST" agent_rule (bony/fleshy limb,
        superficial/covered prominences). `stump_type` is "BONY"/"FLESHY",
        `prominence_depth` is "SUPERFICIAL"/"COVERED" — matches the Scene
        EnumProperty identifiers (see __init__.py), lower-cased here to
        match the ruleset's own lower-case keys. Returns
        {"reduction_modifier": 1.0, "addition_modifier": 1.0,
        "addition_modifier_lateral": 1.0} (fully neutral — no covariate
        applied) if either answer is unset/unrecognized, so an incomplete
        answer never silently changes displacement magnitudes."""
        covariates = self._data.get("patient_covariates", {})
        bf = covariates.get("bony_or_fleshy", {}).get((stump_type or "").lower(), {})
        pd = covariates.get("prominence_depth", {}).get((prominence_depth or "").lower(), {})
        return {
            "reduction_modifier": bf.get("reduction_modifier", 1.0),
            "addition_modifier": bf.get("addition_modifier", 1.0),
            "addition_modifier_lateral": pd.get("addition_modifier_lateral", 1.0),
            "stump_note": bf.get("note", ""),
            "prominence_note": pd.get("note", ""),
        }

    # ------------------------------------------------------------------
    # Validation gates
    # ------------------------------------------------------------------

    def get_validation_gates(self) -> list:
        """Return all validation gates in order."""
        return self._data["validation_gates"]

    def get_blocking_gates(self) -> list:
        """Return only blocking validation gates."""
        return [g for g in self._data["validation_gates"] if g.get("blocking")]

    # ------------------------------------------------------------------
    # Agent rules
    # ------------------------------------------------------------------

    def get_agent_rules(self) -> list:
        """Return the agent behavioural rules as a list of strings."""
        return self._data["agent_rules"]

    def get_agent_rules_as_prompt(self) -> str:
        """Return agent rules formatted for injection into an LLM system prompt."""
        rules = self._data["agent_rules"]
        return "AGENT RULES:\n" + "\n".join(f"- {r}" for r in rules)

    # ------------------------------------------------------------------
    # Geometry helpers
    # ------------------------------------------------------------------

    def get_geometry_spec(self) -> dict:
        """Return geometry implementation spec for the geometry engine."""
        return self._data["geometry"]

    def build_displacement_params(self, landmark_id: str, concept: Optional[str] = None) -> dict:
        """
        Build the displacement parameter dict the geometry engine needs
        to apply a landmark influence field.
        """
        rule = self.get_landmark_rule(landmark_id, concept)
        return {
            "landmark_id":      rule["landmark_id"],
            "direction":        rule["direction"],
            "target_mm":        rule["target_mm"],
            "min_mm":           rule["min_mm"],
            "max_mm":           rule["max_mm"],
            "blend_radius_mm":  rule["blend_radius_mm"],
            "distance_method":  self._data["geometry"]["distance_method"],
            "falloff_function": self._data["geometry"]["falloff_function"],
        }

    # ------------------------------------------------------------------
    # Meta
    # ------------------------------------------------------------------

    def describe(self) -> str:
        """Return a human-readable summary of the loaded ruleset."""
        meta = self._data["meta"]
        return (
            f"DynaX Ruleset · {meta['device']} · v{meta['version']}\n"
            f"Active concept  : {self.concept}\n"
            f"Landmarks       : {len(self._landmarks)}\n"
            f"Validation gates: {len(self._data['validation_gates'])}\n"
            f"Agent rules     : {len(self._data['agent_rules'])}"
        )
