"""
DynaX Spatial Agent — Landmark Manager
Handles landmark zone selection and registration on the mesh surface.

Selection system (v1.23.5 replacement): the original design used grease
pencil surface-stuck strokes to mark a zone. In real use this proved
fragile across several Blender-version-specific failures (legacy vs GPv3
mode enums, missing material, missing frame-at-playhead) and the popover
UI made every failure hard to diagnose. Replaced with the SAME mesh
face-selection system this add-on already uses everywhere else a
clinician needs to mark a region — Sculpt & Modify's "Adjust part of the
mesh" and the Manual Bridge zone picker (`operators/select_tools.py`'s
Box/Lasso/Circle select, already proven reliable across this whole
codebase) — instead of a second, GP-based mechanism. A landmark "zone" is
now literally the set of selected faces/vertices, which is both more
robust AND more accurate for the displacement engine (it has real
vertex_indices to work from instead of only a centroid + blend radius).
"""

import json
from dataclasses import dataclass, field

import bpy
from bpy.props import StringProperty
from mathutils import Vector

from ..operators.select_tools import _enter_edit_select
from .ruleset.ruleset_engine import DynaXRuleset


@dataclass
class LandmarkZone:
    landmark_id: str          # e.g. "FH", "TC", "PT" — see transtibial_ruleset.json
    landmark_name: str        # human label from the ruleset
    spline_points: list       # list of [x, y, z] world coordinates of the selected verts
    centroid: list            # [x, y, z] average of spline_points
    vertex_indices: list = field(default_factory=list)  # selected mesh vertex indices


# v3.0.0 (2026-08-23): landmark identity comes from the clinician-authored
# CAD Modification Matrix (spatial_agent/ruleset/transtibial_ruleset.json),
# 11 real clinical zones with signed target_mm/blend_radius per concept —
# replacing an earlier attempt to source zone identity from ParaFly TT's
# reference-blend vertex groups (that was a different, less complete data
# source with no signed push amounts). A single ruleset instance is loaded
# once at import time (the file only changes when this add-on is updated,
# same lifetime as any other module-level constant here).
_RULESET = DynaXRuleset()

ALL_LANDMARK_IDS = _RULESET.get_all_landmark_ids()
REQUIRED_ZONE_IDS = _RULESET.get_required_landmarks()       # PT, TC, FH, DTT, DFT
RECOMMENDED_ZONE_IDS = _RULESET.get_recommended_landmarks() # PC, HT, PAT
OPTIONAL_ZONE_IDS = _RULESET.get_optional_landmarks()       # MTF, ATS, FS

ZONE_COLOR_ATTRIBUTE = "DynaX_Zones"

# color_category from the ruleset ("addition" = pressure-sensitive bony area
# that needs material pushed OUTWARD for relief; "reduction" = pressure-
# tolerant soft tissue that can have material pulled INWARD to bear load —
# see transtibial_ruleset.json's own "coordinate_convention"). Green for
# addition/outward/relief, red-orange for reduction/inward/load — matches
# this add-on's earlier (v1.23.9) direction-color convention.
_CATEGORY_COLORS = {
    "addition":  (0.2, 0.75, 0.2, 1.0),    # green — relief, pushed outward
    "reduction": (0.9, 0.25, 0.1, 1.0),    # red-orange — load-bearing, pulled inward
}
_DEFAULT_ZONE_COLOR = (0.5, 0.5, 0.55, 1.0)


def zone_color_for(zone_id: str) -> tuple:
    try:
        category = _RULESET.get_landmark(zone_id).get("color_category")
    except KeyError:
        category = None
    return _CATEGORY_COLORS.get(category, _DEFAULT_ZONE_COLOR)


def get_zone_meta(zone_id: str) -> dict:
    """Static metadata for a zone id — {"display_name", "description",
    "agent_note", "category" ("Pressure Sensitive"/"Pressure Tolerant"),
    "minimum", "maximum"} — shaped for the panel, built from the ruleset's
    landmark + concept-agnostic min/max span (the union of TSB and PTB's
    min_mm/max_mm, since a slider's soft range shouldn't change out from
    under the clinician when they switch concept).

    v3.2.0 added a real clinician-facing `description` field per landmark
    (plain-language anatomy + why it matters), separate from `agent_note`
    (the terser implementation/geometry-engine note this file already
    surfaced here pre-v3.2.0). `description` now prefers the real field,
    falling back to agent_note only for a landmark from an older ruleset
    version that predates it."""
    try:
        lm = _RULESET.get_landmark(zone_id)
    except KeyError:
        return {"display_name": zone_id, "description": "", "agent_note": "",
                "category": "General", "minimum": -20.0, "maximum": 20.0}
    spans = [lm[c] for c in ("TSB", "PTB") if c in lm]
    lo = min((s["min_mm"] for s in spans), default=-20.0)
    hi = max((s["max_mm"] for s in spans), default=20.0)
    category = "Pressure Sensitive" if lm.get("classification") == "pressure_sensitive" else "Pressure Tolerant"
    return {
        "display_name": lm["name"],
        "description": lm.get("description") or lm.get("agent_note", ""),
        "agent_note": lm.get("agent_note", ""),
        "category": category,
        "minimum": min(lo, hi),
        "maximum": max(lo, hi),
    }


_ZONE_ENUM_ITEMS_CACHE = []


def spatial_zone_enum_items(self, context):
    """Static list wrapped as an EnumProperty items callback (not a plain
    static `items=[...]`) purely for the module-level GC-safety pattern
    already used by this add-on's other dynamic dropdowns
    (properties/dynax_properties.py's _component_items) — Blender can crash
    if an enum's item strings are garbage-collected."""
    global _ZONE_ENUM_ITEMS_CACHE
    _ZONE_ENUM_ITEMS_CACHE = [
        (zid, _RULESET.get_landmark(zid)["name"], _RULESET.get_landmark(zid).get("agent_note", ""))
        for zid in ALL_LANDMARK_IDS
    ]
    return _ZONE_ENUM_ITEMS_CACHE


def get_stored_zones(scene) -> list:
    """Read and deserialise the stored landmark zones from the scene property."""
    raw = getattr(scene, "dynax_landmark_zones", "[]")
    try:
        data = json.loads(raw)
    except Exception:
        return []
    return [LandmarkZone(**z) for z in data]


def store_zone(scene, zone: LandmarkZone):
    """Serialise and store a LandmarkZone, REPLACING any existing zone with
    the same landmark_id rather than appending a duplicate — this is what
    makes re-painting a landmark (edit workflow) safe. A real bug fixed
    here: the old append-only version let a clinician confirm the same
    landmark twice and silently double-apply it (apply_all_zones has no way
    to know two stored entries are "the same" zone re-painted vs. two
    genuinely different zones, so both would displace)."""
    zones = [z for z in get_stored_zones(scene) if z.landmark_id != zone.landmark_id]
    zones.append(zone)
    scene.dynax_landmark_zones = json.dumps([z.__dict__ for z in zones])


def delete_zone(scene, landmark_id: str) -> bool:
    """Remove one stored zone by landmark_id. Returns True if a zone was
    actually removed."""
    zones = get_stored_zones(scene)
    kept = [z for z in zones if z.landmark_id != landmark_id]
    if len(kept) == len(zones):
        return False
    scene.dynax_landmark_zones = json.dumps([z.__dict__ for z in kept])
    return True


def clear_zones(scene):
    """Reset the stored landmark zones to an empty list."""
    scene.dynax_landmark_zones = "[]"


def get_target_mesh(context):
    """Resolve the socket mesh being annotated, robust to the active object
    having changed away from it between panel interactions. Prefers the
    current active mesh (and remembers it for next time); falls back to the
    mesh remembered from the last successful resolution."""
    obj = context.active_object
    if obj is not None and obj.type == 'MESH':
        context.scene["dynax_landmark_target_mesh"] = obj.name
        return obj

    name = context.scene.get("dynax_landmark_target_mesh")
    if name:
        remembered = bpy.data.objects.get(name)
        if remembered is not None and remembered.type == 'MESH':
            return remembered

    return None


def apply_zone_vertex_color(obj, zone: "LandmarkZone"):
    """Bake the zone's clinical direction color into a vertex color layer
    so a confirmed zone stays visually marked on the mesh (Edit-mode's own
    orange selection highlight only exists while actively selecting — it
    disappears the moment the user moves to the next landmark or leaves
    Edit Mode). Uses the legacy `vertex_colors` API (still functional in
    Blender 5.1, verified) rather than the newer color_attributes API, to
    keep this addon's minimum-supported-Blender footprint unchanged."""
    zone_verts = set(zone.vertex_indices) if zone.vertex_indices else set()
    if not zone_verts:
        # Defensive fallback for a zone stored without vertex_indices (an
        # older zone, or a caller that only supplied a centroid) — mm-space
        # radius, NOT divided by 1000 (see displacement_engine.py's unit
        # fix; this codebase is 1 Blender unit = 1mm throughout).
        blend_radius = 25.0
        centroid = Vector(zone.centroid)
        wm = obj.matrix_world
        for v in obj.data.vertices:
            if (wm @ v.co - centroid).length < blend_radius:
                zone_verts.add(v.index)

    _paint_vertices(obj, zone_verts, zone_color_for(zone.landmark_id))
    _show_vertex_colors_in_viewport()


NEUTRAL_VERTEX_COLOR = (0.8, 0.8, 0.8, 1.0)


def clear_zone_vertex_color(obj, vertex_indices):
    """Paint the given vertices back to a neutral color — used when a zone
    is deleted or replaced (re-painted), so the old selection doesn't stay
    visually marked as if it were still an active zone."""
    _paint_vertices(obj, vertex_indices, NEUTRAL_VERTEX_COLOR)


def _paint_vertices(obj, vertex_indices, color):
    mesh = obj.data
    if ZONE_COLOR_ATTRIBUTE not in mesh.vertex_colors:
        mesh.vertex_colors.new(name=ZONE_COLOR_ATTRIBUTE)
    color_layer = mesh.vertex_colors[ZONE_COLOR_ATTRIBUTE]

    vert_to_loops = {}
    for poly in mesh.polygons:
        for loop_idx in poly.loop_indices:
            vi = mesh.loops[loop_idx].vertex_index
            vert_to_loops.setdefault(vi, []).append(loop_idx)

    for vi in vertex_indices:
        for li in vert_to_loops.get(vi, []):
            color_layer.data[li].color = color

    mesh.update()


def _show_vertex_colors_in_viewport():
    """Switch every visible VIEW_3D's Solid-shading color source to the
    baked vertex colors, so apply_zone_vertex_color's result is actually
    visible rather than silently present-but-hidden (Solid shading defaults
    to 'MATERIAL'/'SINGLE', neither of which reads a vertex color layer)."""
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    space.shading.type = 'SOLID'
                    space.shading.color_type = 'VERTEX'


def _get_landmark_label(landmark_id: str) -> str:
    """Human display name for a landmark id, straight from the ruleset."""
    try:
        return _RULESET.get_landmark(landmark_id)["name"]
    except KeyError:
        return landmark_id


class DYNAX_OT_landmark_start_zone(bpy.types.Operator):
    """Enter face-select mode on the socket mesh so a landmark zone can be
    painted with the Box/Lasso/Circle select tools. If this landmark
    already has a stored zone, its existing vertices are pre-selected —
    Box/Lasso/Circle add to or Ctrl-subtract from that starting selection,
    so a clinician can EDIT an already-confirmed zone (extend, shrink, or
    just re-paint it) instead of only ever starting blank."""
    bl_idname = "dynax.landmark_start_zone"
    bl_label = "Start / Edit Zone Selection"

    def execute(self, context):
        scene = context.scene
        landmark_id = getattr(scene, "dynax_spatial_landmark_id", "")

        mesh_obj = get_target_mesh(context)
        if mesh_obj is None:
            self.report({'ERROR'}, "Select the socket mesh first")
            return {'CANCELLED'}

        context.view_layer.objects.active = mesh_obj
        mesh_obj.select_set(True)

        if not _enter_edit_select(context, select_through=False):
            self.report({'ERROR'}, "Could not enter selection mode. Hover the 3D viewport and try again.")
            return {'CANCELLED'}

        bpy.ops.mesh.select_all(action='DESELECT')

        existing = next((z for z in get_stored_zones(scene) if z.landmark_id == landmark_id), None)
        if existing is not None and existing.vertex_indices:
            import bmesh
            bm = bmesh.from_edit_mesh(mesh_obj.data)
            bm.verts.ensure_lookup_table()
            existing_set = set(existing.vertex_indices)
            for v in bm.verts:
                if v.index in existing_set:
                    v.select = True
            bmesh.update_edit_mesh(mesh_obj.data)
            self.report({'INFO'},
                f"Editing {_get_landmark_label(landmark_id)} — existing selection loaded. "
                "Box/Lasso/Circle to extend, Ctrl+drag to remove, then Confirm Zone.")
        else:
            self.report({'INFO'}, f"Paint the {_get_landmark_label(landmark_id)} zone, then Confirm Zone")
        return {'FINISHED'}


class DYNAX_OT_landmark_confirm_zone(bpy.types.Operator):
    """Read the current mesh selection and store it as a landmark zone"""
    bl_idname = "dynax.landmark_confirm_zone"
    bl_label = "Confirm Zone"

    def execute(self, context):
        scene = context.scene
        # Always the LIVE dropdown value, not a snapshot taken back at Start
        # Zone Selection time — Box/Lasso/Circle already enter edit-select
        # selection on their own, so a user who changes the landmark dropdown
        # and paints directly (without re-clicking Start Zone Selection) must
        # still get the landmark they actually have selected right now, not
        # whichever one was picked when Start Zone Selection was last clicked.
        landmark_id = getattr(scene, "dynax_spatial_landmark_id", "")

        mesh_name = scene.get("dynax_landmark_target_mesh")
        mesh_obj = bpy.data.objects.get(mesh_name) if mesh_name else get_target_mesh(context)
        if mesh_obj is None or mesh_obj.type != 'MESH':
            self.report({'ERROR'}, "No socket mesh found — click Start Zone Selection first")
            return {'CANCELLED'}

        if mesh_obj.mode != 'EDIT':
            self.report({'ERROR'}, "No active selection — click Start Zone Selection, paint a zone, then Confirm")
            return {'CANCELLED'}

        import bmesh
        bm = bmesh.from_edit_mesh(mesh_obj.data)
        selected_verts = [v for v in bm.verts if v.select]

        if not selected_verts:
            self.report({'ERROR'}, "Nothing selected — paint a zone before confirming")
            return {'CANCELLED'}

        mat = mesh_obj.matrix_world
        points = [list(mat @ v.co) for v in selected_verts]
        indices = [v.index for v in selected_verts]

        centroid = [
            sum(p[0] for p in points) / len(points),
            sum(p[1] for p in points) / len(points),
            sum(p[2] for p in points) / len(points),
        ]

        zone = LandmarkZone(
            landmark_id=landmark_id,
            landmark_name=_get_landmark_label(landmark_id),
            spline_points=points,
            centroid=centroid,
            vertex_indices=indices,
        )

        # If this landmark was already painted, clear ITS OLD vertex set's
        # color before store_zone replaces the entry — otherwise a smaller
        # re-paint leaves the old (now-orphaned) vertices still showing the
        # zone color, even though they're no longer part of it.
        existing = next((z for z in get_stored_zones(scene) if z.landmark_id == landmark_id), None)

        store_zone(scene, zone)

        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')

        # Bake the zone color AFTER leaving Edit Mode, not before — while in
        # Edit Mode the mesh's displayed/live geometry is owned by the
        # bmesh, and writing mesh.vertex_colors directly under that would
        # get silently discarded the moment mode_set(OBJECT) syncs the
        # bmesh back to the mesh datablock.
        if existing is not None and existing.vertex_indices:
            stale = set(existing.vertex_indices) - set(indices)
            if stale:
                clear_zone_vertex_color(mesh_obj, stale)
        apply_zone_vertex_color(mesh_obj, zone)

        context.view_layer.objects.active = mesh_obj
        mesh_obj.select_set(True)

        self.report({'INFO'}, f"Zone stored: {zone.landmark_name} ({len(indices)} verts)")
        return {'FINISHED'}


class DYNAX_OT_landmark_clear_all(bpy.types.Operator):
    """Clear all stored landmark zones and the current mesh selection"""
    bl_idname = "dynax.landmark_clear_all"
    bl_label = "Clear All Landmarks"

    def execute(self, context):
        scene = context.scene
        clear_zones(scene)

        mesh_name = scene.get("dynax_landmark_target_mesh")
        mesh_obj = bpy.data.objects.get(mesh_name) if mesh_name else None
        if mesh_obj is not None and mesh_obj.mode == 'EDIT':
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')

        self.report({'INFO'}, "All landmark zones cleared")
        return {'FINISHED'}


class DYNAX_OT_landmark_delete_zone(bpy.types.Operator):
    """Delete one placed landmark zone (its vertex color is cleared too)"""
    bl_idname = "dynax.landmark_delete_zone"
    bl_label = "Delete Zone"
    bl_options = {'REGISTER', 'UNDO'}

    landmark_id: StringProperty()

    def execute(self, context):
        scene = context.scene
        zones = get_stored_zones(scene)
        zone = next((z for z in zones if z.landmark_id == self.landmark_id), None)
        if zone is None:
            self.report({'WARNING'}, "Zone not found — already deleted?")
            return {'CANCELLED'}

        mesh_name = scene.get("dynax_landmark_target_mesh")
        mesh_obj = bpy.data.objects.get(mesh_name) if mesh_name else None
        if mesh_obj is not None and zone.vertex_indices:
            clear_zone_vertex_color(mesh_obj, zone.vertex_indices)

        delete_zone(scene, self.landmark_id)
        self.report({'INFO'}, f"Deleted zone: {zone.landmark_name}")
        return {'FINISHED'}
