"""Consent and local analytics-data management.

Analytics is opt-in. An unreadable or missing setting is treated as disabled.
When disabled, collectors and sync clients must neither write nor transmit.
"""

from __future__ import annotations

import json
import os
from pathlib import Path


def analytics_enabled() -> bool:
    try:
        return _load_settings().get("analytics_enabled") is True
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return False


def set_analytics_enabled(enabled: bool) -> bool:
    """Persist explicit consent atomically. Return whether persistence worked."""
    try:
        settings = _load_settings()
        settings["analytics_enabled"] = bool(enabled)
        path = _settings_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(settings, indent=2), encoding="utf-8")
        os.replace(tmp, path)
        return True
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return False


def _settings_path() -> Path:
    override = os.environ.get("DYNAX_STUDIO_CONFIG_DIR")
    if override:
        return Path(override) / "settings.json"
    appdata = os.environ.get("APPDATA")
    base = Path(appdata) if appdata else Path.home() / ".dynax_studio"
    return base / "DynaX Studio" / "settings.json"


def _load_settings() -> dict:
    path = _settings_path()
    if not path.exists():
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("settings root must be an object")
    return data

