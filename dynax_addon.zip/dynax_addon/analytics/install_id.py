"""Create and persist the pseudonymous DynaX installation UUID.

The UUID is not anonymous in the legal sense: it is a stable pseudonymous
identifier and can remain personal data under applicable privacy law. It is
stored only after analytics consent and survives reinstall while AppData is
preserved. Legal review is required before public deployment.
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from pathlib import Path


log = logging.getLogger("dynax.analytics")
_cached_install_id: str | None = None


def get_install_id() -> str:
    """Return a valid UUID4, persisting a new one with an atomic replacement."""
    global _cached_install_id
    if _cached_install_id:
        return _cached_install_id

    path = _install_id_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        candidate = str(data["install_id"])
        parsed = uuid.UUID(candidate)
        if parsed.version == 4 and str(parsed) == candidate:
            _cached_install_id = candidate
            return candidate
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
        pass

    new_id = str(uuid.uuid4())
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps({"install_id": new_id}, indent=2), encoding="utf-8")
        os.replace(tmp, path)
    except OSError as exc:
        log.warning("[DynaX Analytics] Could not persist install_id: %s", exc)

    _cached_install_id = new_id
    return new_id


def _install_id_path() -> Path:
    override = os.environ.get("DYNAX_STUDIO_CONFIG_DIR")
    if override:
        return Path(override) / "install_id.json"
    appdata = os.environ.get("APPDATA")
    base = Path(appdata) if appdata else Path.home() / ".dynax_studio"
    return base / "DynaX Studio" / "install_id.json"

