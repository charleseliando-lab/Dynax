"""Shared, closed analytics vocabulary for the Blender collector."""

ALLOWED_EVENT_TYPES = frozenset({
    "workflow_started",
    "workflow_completed",
    "stage_completed",
    "stage_skipped",
    "operator_used",
    "export_completed",
    "error_occurred",
    "paralink_connect_used",
    "quick_bridge_used",
    "session_started",
    "session_ended",
})

ALLOWED_WORKFLOWS = frozenset({
    "creator",
    "paraform",
    "parafly_afo",
    "paralink_tt",
    "parafly_tlso",
})

ALLOWED_PLATFORMS = frozenset({"Windows", "macOS", "Linux"})

ALLOWED_VALUES = {
    "paralink_connect_used": frozenset({"SMOOTH", "STRUCTURAL", "HYBRID"}),
    "quick_bridge_used": frozenset({
        "SMOOTH_FILLET",
        "STANDARD",
        "STRAIGHT_TAPER",
        "CURVED_TAPER",
        "REINFORCED_COLLAR",
        "PEDIATRIC",
        "HEAVY_DUTY",
    }),
    "export_completed": frozenset({"stl", "obj"}),
    "session_started": frozenset({"studio", "standalone"}),
}

FORBIDDEN_CHARS = frozenset({"/", "\\", "@", "\n", "\r", "\t"})
MAX_FIELD_LENGTH = 64

