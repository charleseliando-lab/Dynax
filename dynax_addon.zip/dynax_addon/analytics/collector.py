"""Privacy-bounded, append-only event collection for DynaX.

Only internal identifiers from a closed vocabulary are accepted. Patient
names, project paths, filenames, scan data, free-form error messages and
operator arguments are never accepted. All public entry points are fail-open
for clinical work: analytics failure can never fail an operator.
"""

from __future__ import annotations

import json
import logging
import math
import os
import re
import sys
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path

from .event_types import (
    ALLOWED_EVENT_TYPES,
    ALLOWED_PLATFORMS,
    ALLOWED_VALUES,
    ALLOWED_WORKFLOWS,
    FORBIDDEN_CHARS,
    MAX_FIELD_LENGTH,
)
from .install_id import get_install_id
from .privacy import analytics_enabled


log = logging.getLogger("dynax.analytics")
_write_lock = threading.Lock()
_session_id = str(uuid.uuid4())
_SAFE_IDENTIFIER = re.compile(r"^[A-Za-z0-9_.:-]{1,64}$")
_MAX_DURATION_SECONDS = 7 * 24 * 60 * 60


def record_event(
    event_type: str,
    workflow: str | None = None,
    stage: str | None = None,
    value: str | None = None,
    duration_s: float | None = None,
) -> None:
    """Append one valid event. Never raise and never touch clinical state."""
    try:
        if os.environ.get("DYNAX_TESTING") or not analytics_enabled():
            return
        event = _build_event(event_type, workflow, stage, value, duration_s)
        if event is not None:
            _append_event(event)
    except Exception as exc:  # analytics must never interrupt clinical work
        try:
            log.debug("[DynaX Analytics] record_event failed: %s", exc)
        except Exception:
            return


def workflow_from_context(context) -> str | None:
    """Map existing DynaX routing properties to the public workflow key."""
    try:
        scene = context.scene
        props = scene.dynax_props
        mode = props.dynax_mode
        if mode == "CREATOR":
            return "creator"
        if mode == "PARAFORGE":
            return "paraform"
        if mode == "PARAFORGE_ZONES":
            return {
                "AFO": "parafly_afo",
                "TT": "paralink_tt",
                "TLSO": "parafly_tlso",
            }.get(getattr(scene, "parafly_device_type", ""))
    except (AttributeError, TypeError):
        return None
    return None


def _build_event(event_type, workflow, stage, value, duration_s):
    if event_type not in ALLOWED_EVENT_TYPES:
        return None
    if workflow is not None and workflow not in ALLOWED_WORKFLOWS:
        return None
    if stage is not None and _validate_identifier(stage) is None:
        return None
    validated_value = _validate_value(event_type, value)
    if value is not None and validated_value is None:
        return None
    validated_duration = _validate_duration(duration_s)
    if duration_s is not None and validated_duration is None:
        return None
    if event_type in {"workflow_started", "workflow_completed"} and workflow is None:
        return None
    if event_type in {"stage_completed", "stage_skipped"} and stage is None:
        return None
    if event_type in ALLOWED_VALUES and validated_value is None:
        return None

    platform = (
        "Windows" if sys.platform == "win32"
        else "macOS" if sys.platform == "darwin"
        else "Linux"
    )
    if platform not in ALLOWED_PLATFORMS:
        return None
    try:
        import bpy
        blender_version = _validate_identifier(bpy.app.version_string) or "unknown"
    except (ImportError, AttributeError):
        blender_version = "unknown"

    return {
        "event_id": str(uuid.uuid4()),
        "install_id": get_install_id(),
        "session_id": _session_id,
        "event_type": event_type,
        "workflow": workflow,
        "stage": stage,
        "value": validated_value,
        "duration_s": validated_duration,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "addon_version": _addon_version(),
        "blender_version": blender_version,
        "os_platform": platform,
    }


def _validate_value(event_type: str, value) -> str | None:
    if value is None:
        return None
    text = str(value)
    allowed = ALLOWED_VALUES.get(event_type)
    if allowed is not None:
        return text if text in allowed else None
    return _validate_identifier(text)


def _validate_identifier(value) -> str | None:
    if value is None:
        return None
    text = str(value)
    if len(text) > MAX_FIELD_LENGTH:
        return None
    if any(char in FORBIDDEN_CHARS for char in text):
        return None
    return text if _SAFE_IDENTIFIER.fullmatch(text) else None


def _validate_duration(value) -> float | None:
    if value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(number) or number < 0 or number > _MAX_DURATION_SECONDS:
        return None
    return round(number, 2)


def _append_event(event: dict) -> None:
    path = _pending_dir() / f"events_{_today()}.jsonl"
    line = json.dumps(event, ensure_ascii=True, separators=(",", ":")) + "\n"
    with _write_lock:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(line)


def _pending_dir() -> Path:
    override = os.environ.get("DYNAX_STUDIO_CONFIG_DIR")
    if override:
        return Path(override) / "analytics" / "pending"
    appdata = os.environ.get("APPDATA")
    base = Path(appdata) if appdata else Path.home() / ".dynax_studio"
    return base / "DynaX Studio" / "analytics" / "pending"


def _today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def _addon_version() -> str:
    try:
        from .. import bl_info
        return ".".join(str(item) for item in bl_info["version"])
    except (ImportError, KeyError, TypeError):
        return "unknown"

