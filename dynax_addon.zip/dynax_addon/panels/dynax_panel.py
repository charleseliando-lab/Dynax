# panels/dynax_panel.py - DynaX v1.6 — Option B UI (icon toolbar + compact tools)

import bpy
import json
import math
import os
from ..operators.component_bridge import _get_components_folder
from .components_section import draw_component_connection
from .ui_helpers import (
    draw_advanced_section,
    draw_completion_status,
    draw_stage_progress,
    draw_workflow_header,
)
from ..properties.dynax_properties import (
    get_active_steps, get_step_ids,
    PROSTHETIST_STEPS, ORTHOTIST_STEPS,
)
from ..operators.trimline import CURVE_NAME
from ..operators.circumference import get_ring_data
from ..operators.parametric_socket import (
    BAND_NAMES as PARAM_BAND_NAMES, MODIFIER_NAME as PARAM_MODIFIER_NAME,
    get_band_input_keys, band_label, compute_band_measurements,
)
from ..utils.translations import dx_text

# Step icons — one per step id
STEP_ICONS = {
    "import":      "IMPORT",
    "cleanup":     "BRUSH_DATA",
    "align":       "ORIENTATION_GLOBAL",
    "measure":     "DRIVER_DISTANCE",
    "sculpt":      "SCULPTMODE_HLT",
    "trimline":    "CURVE_BEZCIRCLE",
    "thickness":   "MOD_SOLIDIFY",
    "components":  "PACKAGE",
    "export":      "EXPORT",
}

PARAFORM_STAGES = ["Select Device", "Adjust Shape", "Components", "Export"]


def _step_index(props):
    ids = get_step_ids()
    try:
        return ids.index(props.active_step)
    except ValueError:
        return 0


def _is_studio_session(scene):
    """True only for scenes launched through the DynaX Studio bootstrap."""
    return bool(scene.get("dynax_studio_session", False))


def _active_obj(context):
    obj = context.active_object
    return obj if (obj and obj.type == 'MESH') else None


def _find_paraform_socket(context):
    """Find the ParaForm working socket regardless of what's currently active.

    Loading/attaching a component makes the COMPONENT the active object, so a
    panel that keyed off context.active_object would lose the socket and snap
    back to the 'load a device' screen (the reported bug). The socket is the
    mesh carrying the parametric rig modifier, or — once finalized — the one
    flagged dynax_paraform_finalized. Prefer the active object if it already
    qualifies, then the last-used bridge socket, then a scene scan."""
    def is_socket(o):
        return (o is not None and o.type == 'MESH'
                and not o.get("dynax_is_component")
                and (o.get("dynax_paraform_finalized")
                     or o.modifiers.get(PARAM_MODIFIER_NAME) is not None))

    obj = _active_obj(context)
    if is_socket(obj):
        return obj
    name = context.scene.get("dynax_bridge_socket_obj")
    cand = bpy.data.objects.get(name) if name else None
    if is_socket(cand):
        return cand
    for o in context.scene.objects:
        if is_socket(o):
            return o
    return None


def _draw_instructions_header(context, layout):
    """Draw the shared collapsible 'Instructions' toggle row (one property
    for all steps, not per-step - matches the spec's single-toggle ask).
    Returns True if the caller should draw its instruction box below this,
    False if collapsed. Same TRIA_DOWN/TRIA_RIGHT + emboss=False convention
    as Compare/Checkpoints above and parafly_advanced_open elsewhere."""
    open_ = context.scene.dynax_ui_instructions_open
    row = layout.row()
    row.prop(context.scene, "dynax_ui_instructions_open",
             text="Instructions",
             icon='TRIA_DOWN' if open_ else 'TRIA_RIGHT',
             emboss=False)
    return open_


# ── Panel 0: Role header (always visible, very compact) ───────────────────────

class DYNAX_PT_header(bpy.types.Panel):
    bl_label = "DynaX"
    bl_idname = "DYNAX_PT_header"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "DynaX"
    bl_order       = 0

    def draw(self, context):
        layout = self.layout

        # ── Logo banner ───────────────────────────────────────────────────────
        from ..utils.branding import get_logo_icon_id
        logo_id = get_logo_icon_id()
        if logo_id:
            logo_row = layout.row()
            logo_row.alignment = 'CENTER'
            logo_row.template_icon(icon_value=logo_id, scale=4.0)

        # ── Welcome header ────────────────────────────────────────────────────
        # Hidden while the Settings panel is open (below, in DYNAX_PT_tools) so
        # the sidebar reads as one clean "Settings" screen instead of a welcome
        # banner sitting on top of it.
        props = getattr(context.scene, "dynax_props", None)
        if not (props and props.dynax_showing_settings):
            welcome = layout.row()
            welcome.alignment = 'CENTER'
            welcome.scale_y = 1.2
            welcome.label(text=dx_text(context, "Welcome Dr, Let's Build."))
            layout.separator(factor=0.5)


# ── Panel 1: Icon step toolbar (compact, above tools) ─────────────────────────

class DYNAX_PT_toolbar(bpy.types.Panel):
    bl_label       = "Steps"
    bl_idname      = "DYNAX_PT_toolbar"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "DynaX"
    bl_order       = 1
    bl_options     = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        if not hasattr(context.scene, "dynax_props"):
            return False
        # Hidden while Settings is open (drawn in DYNAX_PT_tools) so the step
        # icon grid doesn't clutter what should read as a dedicated screen.
        return not context.scene.dynax_props.dynax_showing_settings

    def draw_header(self, context):
        props = context.scene.dynax_props
        idx   = _step_index(props)
        steps = get_active_steps()
        label = steps[idx][1] if idx < len(steps) else "—"
        self.layout.label(text=f"▶ {label}")

    def draw(self, context):
        layout = self.layout
        props  = context.scene.dynax_props
        steps  = get_active_steps()
        cur    = _step_index(props)

        # Progress fraction
        total   = len(steps)
        done    = cur
        pct     = int(done / max(total - 1, 1) * 100)

        # Progress bar via a disabled slider
        row = layout.row()
        row.enabled = False
        row.prop(
            bpy.context.scene, "dynax_progress_display",
            text=f"Progress  {pct}%",
            slider=True,
        )

        layout.separator(factor=0.3)

        # Icon grid — 3 columns
        grid = layout.grid_flow(
            row_major=True, columns=3,
            even_columns=True, even_rows=False, align=True,
        )
        for i, (step_id, label, _) in enumerate(steps):
            icon = STEP_ICONS.get(step_id, 'DOT')
            is_done   = i < cur
            is_active = i == cur

            cell = grid.column(align=True)
            cell.scale_y = 1.0

            if is_done:
                op = cell.operator(
                    "dynax.goto_step",
                    text=label[:10],
                    icon='CHECKMARK',
                    depress=False,
                )
            elif is_active:
                op = cell.operator(
                    "dynax.goto_step",
                    text=label[:10],
                    icon=icon,
                    depress=True,
                )
            else:
                cell.enabled = True
                op = cell.operator(
                    "dynax.goto_step",
                    text=label[:10],
                    icon=icon,
                    depress=False,
                )
            op.step_id = step_id



# ── Panel 2: Step tools (below toolbar) ───────────────────────────────────────

class DYNAX_PT_tools(bpy.types.Panel):
    bl_label       = "Tools"
    bl_idname      = "DYNAX_PT_tools"
    bl_space_type  = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category    = "DynaX"
    bl_order       = 2

    @classmethod
    def poll(cls, context):
        return hasattr(context.scene, "dynax_props")

    def draw_header(self, context):
        props = context.scene.dynax_props
        step  = props.active_step
        icon  = STEP_ICONS.get(step, 'TOOL_SETTINGS')
        self.layout.label(text="", icon=icon)

    def draw(self, context):
        layout = self.layout
        props  = context.scene.dynax_props

        # ── Settings panel (reachable only from the welcome screen) ───────────
        if props.dynax_showing_settings:
            self._draw_settings_panel(context, layout, props)
            return

        mode = props.dynax_mode

        # ── Start Menu (front screen — Creator/ParaForge not visible here) ────
        if mode == 'NONE':
            self._draw_mode_selection(context, layout)
            return

        # ── New Case (Creator vs ParaForge choice, reached via "New Case") ────
        if mode == 'NEW_CASE':
            self._draw_new_case_screen(context, layout)
            return

        # ── ParaForge sub-menu (ParaForm vs ParaFly, reached via "ParaForge") ──
        if mode == 'PARAFORGE_MENU':
            self._draw_paraforge_menu_screen(context, layout)
            return

        # ── Session lock: every active workflow (Creator, ParaForm, ParaFly) is
        # locked in for the session — the only way to a different workflow is
        # all the way back to the Start Menu, not a same-level "switch" shortcut.
        if not _is_studio_session(context.scene):
            back = layout.row()
            back.scale_y = 0.85
            back.operator("dynax.set_mode", text="← Back to Menu",
                          icon='BACK').mode = 'NONE'

        # ── Quick orthographic view controls — shown once a workflow is
        # active (a mesh is actually in the scene to view). Perspective
        # distortion misrepresents socket shape/symmetry, so DynaX nudges
        # toward ortho at entry points (import, centre, auto-align) but
        # never locks it - these buttons are for switching direction or
        # getting back to ortho anytime after a manual perspective switch.
        view_row = layout.row(align=True)
        view_row.scale_x = 0.85
        for view_name, icon in [
            ('FRONT', 'AXIS_FRONT'),
            ('BACK',  'AXIS_SIDE'),
            ('LEFT',  'AXIS_SIDE'),
            ('RIGHT', 'AXIS_SIDE'),
            ('TOP',   'AXIS_TOP'),
        ]:
            op = view_row.operator("dynax.set_ortho_view", text=view_name[0], icon=icon)
            op.view = view_name

        layout.separator(factor=0.3)

        if mode == 'PARAFORGE':
            self._draw_paraforge_panel(context, layout, props)
        elif mode == 'PARAFORGE_ZONES':
            from .paraforge_panel import draw_paraforge_zones_panel
            draw_paraforge_zones_panel(context, layout)
        elif mode == 'PARAMOLD':
            from .paramold_panel import draw_paramold_panel
            draw_paramold_panel(context, layout)
        else:
            self._draw_creator_panel(context, layout, props)

    # ──────────────────────────────────────────────────────────────────────────
    def _draw_mode_selection(self, context, layout):
        """Start Menu — front screen. Creator/ParaForge are NOT shown here;
        they only appear after "New Case" is clicked (New Case screen, below)."""
        layout.separator(factor=0.5)
        gear = layout.row()
        gear.alignment = 'RIGHT'
        gear.operator("dynax.open_settings", text="", icon='PREFERENCES')

        layout.separator(factor=0.7)

        menu_col = layout.column(align=True)
        menu_col.scale_y = 1.5
        menu_col.operator("dynax.set_mode", text="New Case",
                           icon='ADD').mode = 'NEW_CASE'

        layout.separator(factor=0.5)
        footer = layout.row()
        footer.alignment = 'CENTER'
        footer.scale_y = 0.75
        footer.label(text="Dynalimb Technologies")

    # ──────────────────────────────────────────────────────────────────────────
    def _draw_new_case_screen(self, context, layout):
        """New Case screen — the Creator/ParaForge choice, reached only via
        the Start Menu's "New Case" button."""
        back_row = layout.row()
        back_row.scale_y = 0.85
        back_row.operator("dynax.set_mode", text="← Start Menu",
                           icon='BACK').mode = 'NONE'
        layout.separator(factor=0.3)

        title = layout.row()
        title.alignment = 'CENTER'
        title.label(text="Choose Your Workflow")
        layout.separator(factor=0.5)

        cbox = layout.box()
        cbox.label(text=dx_text(context, "Creator"), icon='OUTLINER_OB_ARMATURE')
        crow = cbox.row()
        crow.scale_y = 1.4
        crow.operator("dynax.set_mode", text="Creator  —  Scan-based fitting",
                      icon='OUTLINER_OB_ARMATURE').mode = 'CREATOR'
        cdesc = cbox.column(align=True)
        cdesc.scale_y = 0.75
        cdesc.label(text="Import a patient scan and follow the guided")
        cdesc.label(text="workflow: align, trim, thicken, export.")

        layout.separator(factor=0.3)

        pbox = layout.box()
        pbox.label(text=dx_text(context, "ParaForge"), icon='MOD_LATTICE')
        prow = pbox.row()
        prow.scale_y = 1.4
        prow.operator("dynax.set_mode",
                      text="ParaForge  —  Parametric workflows",
                      icon='MOD_LATTICE').mode = 'PARAFORGE_MENU'
        pdesc = pbox.column(align=True)
        pdesc.scale_y = 0.75
        pdesc.label(text="ParaForm (template sliders) or ParaFly")
        pdesc.label(text="(scan + clinical zone painting).")

        layout.separator(factor=0.3)

        mbox = layout.box()
        mbox.label(text=dx_text(context, "ParaMold"), icon='MESH_UVSPHERE')
        mrow = mbox.row()
        mrow.scale_y = 1.4
        mrow.operator("dynax.set_mode",
                      text="ParaMold  —  Silicone finger molds",
                      icon='MESH_UVSPHERE').mode = 'PARAMOLD'
        mdesc = mbox.column(align=True)
        mdesc.scale_y = 0.75
        mdesc.label(text="Align a finger scan and generate a")
        mdesc.label(text="two-part silicone prosthesis mold.")

    # ──────────────────────────────────────────────────────────────────────────
    def _draw_paraforge_menu_screen(self, context, layout):
        """ParaForge sub-menu — the ParaForm/ParaFly choice, reached only via
        the New Case screen's "ParaForge" card."""
        back_row = layout.row()
        back_row.scale_y = 0.85
        back_row.operator("dynax.set_mode", text="← New Case",
                           icon='BACK').mode = 'NEW_CASE'
        layout.separator(factor=0.3)

        title = layout.row()
        title.alignment = 'CENTER'
        title.label(text="ParaForge — Choose a Workflow")
        layout.separator(factor=0.5)

        fbox = layout.box()
        fbox.label(text="ParaForm (Beta)", icon='MOD_LATTICE')
        frow = fbox.row()
        frow.scale_y = 1.4
        frow.operator("dynax.set_mode",
                      text="ParaForm  —  Parametric design (Beta)",
                      icon='MOD_LATTICE').mode = 'PARAFORGE'
        fdesc = fbox.column(align=True)
        fdesc.scale_y = 0.75
        fdesc.label(text="Load a parametric base template and adjust")
        fdesc.label(text="circumference and height per region.")

        layout.separator(factor=0.3)

        zbox = layout.box()
        zbox.label(text="ParaFly (Beta)", icon='GROUP_VERTEX')
        zrow = zbox.row()
        zrow.scale_y = 1.4
        zrow.operator("dynax.set_mode",
                      text="ParaFly  —  Scan + zone sliders (Beta)",
                      icon='GROUP_VERTEX').mode = 'PARAFORGE_ZONES'
        zdesc = zbox.column(align=True)
        zdesc.scale_y = 0.75
        zdesc.label(text="Import your own scan, paint clinical zones,")
        zdesc.label(text="then adjust each region with its own slider.")

        layout.separator(factor=0.3)
        load_row = layout.row()
        load_row.scale_y = 1.2
        load_row.operator("paraforge.load_project", text="Load Saved Project", icon='FILE_FOLDER')

    # ──────────────────────────────────────────────────────────────────────────
    def _draw_settings_panel(self, context, layout, props):
        header = layout.row()
        header.label(text=dx_text(context, "Settings"), icon='PREFERENCES')
        header.operator("dynax.close_settings", text="", icon='X')

        layout.separator(factor=0.5)

        lang_box = layout.box()
        lang_box.label(text=dx_text(context, "Language"), icon='WORLD')
        lang_box.prop(props, "dynax_ui_language", text="")
        lang_box.operator("dynax.set_language", text="Apply", icon='CHECKMARK')
        note = lang_box.column(align=True)
        note.scale_y = 0.75
        note.label(text="Arabic: text displays correctly; panel")
        note.label(text="layout does not mirror right-to-left.")

        layout.separator(factor=0.3)

        export_box = layout.box()
        export_box.label(text="Default Export Filename", icon='EXPORT')
        export_box.prop(props, "export_filename", text="")

        layout.separator(factor=0.3)

        material_box = layout.box()
        material_box.label(text="Material Defaults", icon='PACKAGE')
        material_box.prop(props, "material_density_g_cm3", text="Density (g/cm³)")
        material_box.prop(props, "material_cost_per_kg", text="Cost per kg")
        material_box.prop(props, "material_currency_symbol", text="Currency Symbol")

        layout.separator(factor=0.5)
        about_box = layout.box()
        about_box.scale_y = 0.8
        about_box.label(text="DynaX — Dynalimb Technologies")
        from .. import bl_info
        v = bl_info.get("version", (0, 0, 0))
        about_box.label(text=f"Version {v[0]}.{v[1]}.{v[2]}")

    # ──────────────────────────────────────────────────────────────────────────
    def _draw_paraforge_panel(self, context, layout, props):
        # Resolve the socket independent of the active object so loading a
        # component (which becomes active) doesn't bounce the panel back to the
        # device-load screen.
        obj = _find_paraform_socket(context)

        rig_mod = obj.modifiers.get(PARAM_MODIFIER_NAME) if obj else None
        finalized = bool(obj and obj.get("dynax_paraform_finalized"))
        if finalized:
            paraform_index = 3 if context.scene.dynax_bridge_complete else 2
        elif rig_mod and rig_mod.node_group:
            paraform_index = 1
        else:
            paraform_index = 0

        draw_workflow_header(
            layout, "ParaForm Socket", paraform_index + 1,
            len(PARAFORM_STAGES))
        draw_stage_progress(layout, PARAFORM_STAGES, paraform_index)
        draw_completion_status(layout, obj is not None, "Device loaded")

        head = layout.box()
        head.label(text="Parametric Design", icon='MOD_LATTICE')
        # Device selection (v1: one device, structured for future expansion).
        head.label(text="Device:", icon='OUTLINER_OB_ARMATURE')
        nb = head.column(align=True)
        nb.scale_y = 1.3
        nb.operator("dynax.load_parametric_template",
                    text="+ Quadrilateral Transfemoral Socket", icon='ADD')

        # After Finalize Shape the GN rig is applied and gone, so the socket is a
        # plain final mesh — switch to the Components + Export view instead of the
        # (now-unavailable) sliders.
        if finalized:
            info = layout.box()
            info.label(text=f"Socket: {obj.name}", icon='CHECKMARK')
            info.label(text="Shape finalized — attach hardware below.", icon='INFO')
            comp_box = layout.box()
            draw_component_connection(context, comp_box, props, export_step=None)
            layout.separator(factor=0.5)
            ex = layout.row()
            ex.scale_y = 1.4
            ex.operator("dynax.export_stl", text="Export STL", icon='EXPORT')
            return

        if not (rig_mod and rig_mod.node_group):
            tip = layout.box()
            tip.scale_y = 0.85
            tip.label(text="Click a device above to begin.", icon='INFO')
            return

        keys = get_band_input_keys(rig_mod.node_group)
        meas = compute_band_measurements(obj, PARAM_BAND_NAMES)
        previewing = context.scene.get("dynax_previewing_band", "")

        # Show the actual device name as a sub-header.
        info = layout.box()
        info.label(text=f"Adjusting: {obj.name}", icon='EDITMODE_HLT')
        info.label(text="Adjust Socket Shape", icon='MOD_LATTICE')

        for band in PARAM_BAND_NAMES:
            ck, hk = keys.get(band, (None, None))
            circ_mm, height_mm = meas.get(band, (0.0, 0.0))

            bx = layout.box()
            h = bx.row(align=True)
            h.label(text=band_label(band), icon='MESH_CIRCLE')
            h.label(text=f"{circ_mm:.0f}mm circ · {height_mm:.0f}mm H")

            r1 = bx.row(align=True)
            r1.label(text="Circ (×):")
            if ck:
                r1.prop(rig_mod, f'["{ck}"]', text="")
                r1.label(text=f"→ {circ_mm:.0f} mm")
            r2 = bx.row(align=True)
            r2.label(text="Height (mm):")
            if hk:
                r2.prop(rig_mod, f'["{hk}"]', text="")

            # Labelled preview button so its purpose is clear before clicking.
            preview_row = bx.row(align=True)
            preview_row.scale_y = 0.85
            pv = preview_row.operator("dynax.preview_band",
                                      text="Preview region in viewport",
                                      icon='HIDE_OFF')
            pv.band_name = band
            if previewing == band:
                back_row = bx.row()
                back_row.alert = True
                back_row.scale_y = 1.1
                back_row.operator("dynax.preview_band_end",
                                  text="← Done previewing — back to sliders",
                                  icon='BACK')

        # Components entry: attaching hardware needs the shape baked first
        # (the bridge reads the base mesh, not the live GN result).
        layout.separator(factor=0.5)
        comp = layout.box()
        comp.label(text="Add Components", icon='OUTLINER_OB_MESH')
        comp.label(text="Finalizes the shape, then attach hardware.", icon='INFO')
        cf = comp.row()
        cf.scale_y = 1.2
        cf.operator("dynax.finalize_parametric_socket",
                    text="Finalize Shape for Components", icon='MOD_LATTICE')

        layout.separator(factor=0.5)
        ex = layout.row()
        ex.scale_y = 1.4
        ex.operator("dynax.export_stl", text="Export STL", icon='EXPORT')

    # ──────────────────────────────────────────────────────────────────────────
    def _draw_creator_panel(self, context, layout, props):
        step   = props.active_step
        obj    = _active_obj(context)

        creator_steps = get_active_steps()
        creator_index = _step_index(props)
        draw_workflow_header(
            layout, "Creator Socket", creator_index + 1, len(creator_steps))
        draw_stage_progress(
            layout, [label for _key, label, _tip in creator_steps], creator_index)

        # ── Navigation + Undo/Redo (top of tools) ─────────────────────────────
        nav = layout.row(align=True)
        nav.scale_y = 1.15
        b = nav.operator("dynax.step_nav", text="◀ Back", icon='BACK')
        b.direction = 'PREV'
        n = nav.operator("dynax.step_nav", text="Next ▶", icon='FORWARD')
        n.direction = 'NEXT'

        ur = layout.row(align=True)
        ur.operator("dynax.undo", text="Undo", icon='LOOP_BACK')
        ur.operator("dynax.redo", text="Redo", icon='LOOP_FORWARDS')

        # ── Compare with Original (shared — available at every step) ──────────
        # Lets the prosthetist check progress against the untouched import at
        # any point, not just at the end. Only meaningful once a snapshot
        # exists (taken automatically at import — operators/import_stl.py).
        # Collapsed by default (v1.19.0) - reference tool, not primary
        # workflow - matching the existing TRIA_DOWN/TRIA_RIGHT + emboss=False
        # convention already used by panels/parafly_afo_panel.py and
        # panels/paraforge_panel.py's "Advanced Tools" sections, rather than
        # inventing a new pattern.
        def _draw_view_compare(_context, compare_box):
            qv_row = compare_box.row(align=True)
            is_qv_on = context.scene.get("dynax_quad_view_on", False)
            qv_row.operator(
                "dynax.quad_view_toggle",
                text="Quad View: ON" if is_qv_on else "Quad View: OFF",
                icon='MESH_GRID',
                depress=is_qv_on,
            )

            is_showing = False
            if obj:
                snap_name = obj.get("dynax_snapshot_name", "")
                snap_obj = bpy.data.objects.get(snap_name) if snap_name else None
                if snap_obj:
                    is_showing = not snap_obj.hide_get()

            cc = compare_box.column(align=True)
            cc.operator("dynax.toggle_compare_overlay",
                        text="Compare with Original: ON" if is_showing else "Compare with Original: OFF",
                        icon='MOD_WIREFRAME',
                        depress=is_showing)
            cc.operator("dynax.measure_compare_offset",
                        text="Click Point to Measure Change", icon='DRIVER_DISTANCE')

            last_offset = context.scene.get("dynax_last_compare_offset")
            if last_offset is not None:
                result_box = compare_box.box()
                z = context.scene.get("dynax_last_compare_z", 0)
                direction = "outward" if last_offset > 0 else "inward"
                result_box.label(
                    text=f"At Z={z:.1f}mm: {abs(last_offset):.2f}mm {direction}",
                    icon='INFO')

        draw_advanced_section(
            layout,
            context.scene,
            "dynax_ui_compare_open",
            "View & Comparison Tools",
            _draw_view_compare,
            context=context,
        )

        # ── Version Checkpoints (shared — available at every step) ────────────
        # A checkpoint is auto-saved (dynax.step_nav) whenever "Next" leaves a
        # step in CHECKPOINT_STEPS; this list lets the user jump back to any
        # of them without manually undoing every action in between. Collapsed
        # by default (v1.19.0) - same reasoning as Compare above.
        cp_open = context.scene.dynax_ui_checkpoints_open
        cp_header = layout.row()
        cp_header.prop(
            context.scene, "dynax_ui_checkpoints_open",
            text="Version Checkpoints",
            icon='TRIA_DOWN' if cp_open else 'TRIA_RIGHT',
            emboss=False)
        if cp_open:
            cp_box = layout.box()
            if obj:
                checkpoint_list = obj.get("dynax_checkpoint_list", "")
                steps_saved = checkpoint_list.split(",") if checkpoint_list else []
                if steps_saved:
                    for cstep in steps_saved:
                        row = cp_box.row(align=True)
                        row.label(text=f"After {cstep.title()}")
                        restore_op = row.operator("dynax.restore_checkpoint",
                                                   text="Restore", icon='LOOP_BACK')
                        restore_op.step_name = cstep
                    cp_box.operator("dynax.clear_checkpoints",
                                     text="Clear All Checkpoints", icon='X')
                else:
                    cp_box.label(text="No checkpoints yet.", icon='INFO')
            else:
                cp_box.label(text="No checkpoints yet.", icon='INFO')

        layout.separator(factor=0.5)

        # ── IMPORT ────────────────────────────────────────────────────────────
        if step == 'import':
            col = layout.column(align=True)
            col.scale_y = 1.3
            col.operator("dynax.import_stl", text="Import STL/OBJ scan", icon='IMPORT')
            col.prop(props, "import_units", text="Units")
            col.operator("dynax.center_model", text="Center & frame model", icon='PIVOT_BOUNDBOX')

            if _draw_instructions_header(context, layout):
                note = layout.box()
                note.label(text="After importing:", icon='INFO')
                note.label(text="• Typical limb: 300–500 mm tall")
                note.label(text="• Imported at true mm size (1:1)")
                note.label(text="• If tiny/huge → check Units / Scale below")

            s = layout.column(align=True)
            s.prop(props, "scale_target_size_mm", text="Target max size (mm)")
            s.scale_y = 1.2
            s.operator("dynax.scale_to_size", text="Scale to size", icon='FULLSCREEN_ENTER')

        # ── CLEAN UP ──────────────────────────────────────────────────────────
        elif step == 'cleanup':
            if obj:
                layout.label(text=f"  {obj.name}", icon='MESH_DATA')
            else:
                layout.label(text="No mesh selected", icon='ERROR')

            # 1 — Auto remesh
            r_box = layout.box()
            r_box.label(text="1 — Auto remesh", icon='MOD_REMESH')
            col = r_box.column(align=True)
            col.prop(props, "dynax_remesh_target_faces", text="Target Faces (0=auto)")
            col.scale_y = 1.2
            col.operator("dynax.auto_remesh", text="Auto remesh", icon='MOD_REMESH')
            col.operator("dynax.quad_remesh_restore",
                         text="Restore pre-remesh mesh", icon='LOOP_BACK')
            if obj:
                col.label(
                    text=f"  {len(obj.data.vertices):,} verts / "
                         f"{len(obj.data.polygons):,} faces",
                    icon='INFO',
                )

            # 2 — Auto smooth
            s_box = layout.box()
            s_box.label(text="2 — Auto smooth", icon='MOD_SMOOTH')
            col2 = s_box.column(align=True)
            col2.scale_y = 1.2
            col2.operator("dynax.medical_smooth", text="Auto smooth", icon='MOD_SMOOTH')
            col2.operator("dynax.clean_slice",    text="Fix open edges", icon='MODIFIER')
            col2.prop(props, "smooth_iterations", text="Iterations")
            col2.prop(props, "smooth_factor",     text="Factor")
            col2.prop(props, "protect_caps",      text="Protect cut surfaces")

            # 3 — Manual smooth (Smooth brush ONLY)
            m_box = layout.box()
            m_box.label(text="3 — Manual smooth (sculpt)", icon='SCULPTMODE_HLT')
            col3 = m_box.column(align=True)
            if context.mode == 'SCULPT':
                col3.label(text="Smooth brush active", icon='BRUSH_DATA')
                col3.label(text="Paint on the mesh to smooth")
                col3.separator()
                # Radius / Strength controls
                col3.prop(props, "smooth_brush_radius",   text="Radius (px)")
                col3.prop(props, "smooth_brush_strength", text="Strength")
                col3.operator("dynax.update_smooth_brush", text="Apply brush settings", icon='FILE_REFRESH')
                col3.separator()
                # Re-select smooth in case user changed brush
                col3.operator("dynax.sculpt_start_smooth", text="Re-select Smooth brush", icon='MOD_SMOOTH')
                col3.separator()
                done = col3.row()
                done.scale_y = 1.4
                done.operator("dynax.sculpt_end", text="✓ Done smoothing", icon='CHECKMARK')
            else:
                col3.scale_y = 1.2
                col3.prop(props, "smooth_brush_radius",   text="Radius (px)")
                col3.prop(props, "smooth_brush_strength", text="Strength")
                col3.operator("dynax.sculpt_start_smooth",
                              text="Enter smooth mode", icon='SCULPTMODE_HLT')

            # 4 — Quad remesh (clean quad topology for parametric/sculpt work)
            qr_box = layout.box()
            qr_box.label(text="4 — Quad Remesh", icon='MOD_REMESH')
            qr_col = qr_box.column(align=True)
            warn = qr_col.box()
            warn.scale_y = 0.8
            warn.alert = True
            warn.label(text="Destructive — rebuilds all topology.", icon='ERROR')
            warn.label(text="A backup is kept; use Restore if needed.")
            qr_col.prop(props, "quad_remesh_target_faces", text="Target Faces")
            qr_col.prop(props, "quad_remesh_preserve_boundary", text="Preserve Boundary (rim)")
            qr_col.scale_y = 1.2
            op = qr_col.operator("dynax.quad_remesh", text="Quad Remesh", icon='MOD_REMESH')
            op.target_faces = props.quad_remesh_target_faces
            op.preserve_boundary = props.quad_remesh_preserve_boundary
            qr_col.operator("dynax.quad_remesh_restore",
                            text="Restore pre-remesh mesh", icon='LOOP_BACK')

        # ── ALIGN ─────────────────────────────────────────────────────────────
        elif step == 'align':
            # Auto + quick rotate
            a_box = layout.box()
            a_box.label(text="Auto-align", icon='ORIENTATION_GLOBAL')
            col = a_box.column(align=True)
            col.scale_y = 1.15
            col.operator("dynax.align_scan",
                         text="Auto-align (longest → Z)", icon='ORIENTATION_GLOBAL')
            row = col.row(align=True)
            row.operator("dynax.rotate_x90", text="X+90°")
            row.operator("dynax.rotate_y90", text="Y+90°")
            row.operator("dynax.rotate_z90", text="Z+90°")

            # Gizmo controls
            g_box = layout.box()
            g_box.label(text="Gizmo controls", icon='ORIENTATION_GIMBAL')
            gcol = g_box.column(align=True)
            gcol.scale_y = 1.1
            grow = gcol.row(align=True)
            grow.operator("dynax.align_gizmo_move",   text="Move",   icon='ORIENTATION_GLOBAL')
            grow.operator("dynax.align_gizmo_rotate", text="Rotate", icon='ORIENTATION_GIMBAL')

            # Numeric controls (uFit style)
            n_box = layout.box()
            n_box.label(text="Precise rotation (degrees)", icon='DRIVER_ROTATIONAL_DIFFERENCE')
            ncol = n_box.column(align=True)
            ncol.prop(props, "align_flexion",   text="Flexion/Extension")
            ncol.prop(props, "align_abduction", text="Adduction/Abduction")
            ncol.prop(props, "align_rotation",  text="Rotation")
            nrow = ncol.row(align=True)
            nrow.scale_y = 1.2
            nrow.operator("dynax.apply_numeric_rotation", text="Apply", icon='CHECKMARK')
            nrow.operator("dynax.align_reset",            text="Reset", icon='LOOP_BACK')

        # ── CROP (own step, separated from Align in v2.6.10) ────────────────────
        elif step == 'crop':
            if _draw_instructions_header(context, layout):
                intro = layout.box()
                intro.label(text="Trim away unwanted geometry", icon='MOD_BOOLEAN')
                intro.label(text="Use a box to keep only what's inside it.")

            b_box = layout.box()
            b_box.label(text="Box Crop", icon='MESH_CUBE')
            bcol = b_box.column(align=True)
            bcol.scale_y = 1.15
            bcol.operator("dynax.crop_box", text="1. Place Crop Box", icon='MESH_CUBE')
            bcol.label(text="2. Resize/move the box to cover")
            bcol.label(text="   the region you want to KEEP.")
            bcol.operator("dynax.crop_box_apply", text="Apply Box Crop", icon='CHECKMARK')

        # ── MEASURE ───────────────────────────────────────────────────────────
        elif step == 'measure':
            from ..operators.circumference import _detect_unit, _get_world_bounds
            if obj:
                unit_guess, _ = _detect_unit(obj)
                if "✓" not in unit_guess:
                    w = layout.box()
                    w.label(text=f"⚠ Scale: {unit_guess}", icon='ERROR')
                    w.label(text="Scale first in Import step!")

            # Auto rings
            auto = layout.box()
            auto.label(text="Circumference auto ring", icon='DRIVER_DISTANCE')
            col = auto.column(align=True)
            col.scale_y = 1.2
            col.operator("dynax.rings_auto", text="Generate auto rings", icon='DRIVER_DISTANCE')

            # Click-to-measure (v1.20.8). Uses the shared measurement engine
            # (utils/measurement_helpers.py) that ParaFly AFO also measures
            # with — one engine, not two.
            # The three states are always explicit (measure-click fix): the button used
            # to look idle while the tool was still armed and eating clicks.
            from ..operators.circumference import measure_click_is_active
            click_box = layout.box()
            click_box.label(text="Click Point to Measure", icon='RESTRICT_SELECT_OFF')
            last_circ = context.scene.get("dynax_last_measure_circ_mm")
            if measure_click_is_active(context):
                arm = click_box.box()
                arm.label(text="Measuring — click the limb", icon='RESTRICT_SELECT_OFF')
                arm.label(text="Esc or right-click to cancel")
                click_box.operator("dynax.measure_click_cancel",
                                   text="Cancel", icon='X')
            elif last_circ is not None:
                z = context.scene.get("dynax_last_measure_z", 0.0)
                diam = context.scene.get("dynax_last_measure_diam_mm",
                                         last_circ / math.pi)
                res = click_box.box()
                res.label(text="Measurement complete", icon='CHECKMARK')
                res.label(text=f"Circumference: {last_circ:.0f} mm")
                res.label(text=f"Equivalent diameter: ⌀{diam:.0f} mm")
                res.label(text=f"at Z = {z:.1f} mm")
                row_c = click_box.row(align=True)
                row_c.scale_y = 1.2
                row_c.operator("dynax.measure_click",
                               text="Measure Again", icon='DRIVER_DISTANCE')
                row_c.operator("dynax.measure_click_clear",
                               text="Clear Measurement", icon='X')
            else:
                col_c = click_box.column(align=True)
                col_c.scale_y = 1.2
                col_c.operator("dynax.measure_click",
                               text="Click Point to Measure", icon='DRIVER_DISTANCE')

            # Manual ring with live slider gizmo
            man = layout.box()
            man.label(text="Place ring manually", icon='ADD')
            col_m = man.column(align=True)
            col_m.scale_y = 1.1
            col_m.operator("dynax.ring_gizmo_start", text="Start placing ring", icon='ADD')
            col_m.prop(props, "ring_height_pct", text="Ring height", slider=True)
            col_m.operator("dynax.ring_gizmo_confirm", text="✓ Confirm this ring", icon='CHECKMARK')

            # Clear
            clr = layout.column(align=True)
            clr.operator("dynax.rings_clear", text="Clear all rings", icon='X')
            clr.separator()
            clr.operator("dynax.ruler_toggle",       text="Manual ruler",   icon='EMPTY_SINGLE_ARROW')
            clr.operator("dynax.clear_measurements", text="Clear ruler",    icon='X')

            # Ring report
            rings = get_ring_data()
            if rings:
                rbox = layout.box()
                rbox.label(text="Ring measurements", icon='LINENUMBERS_ON')
                for r in rings:
                    label = "●" if r.get("manual") else "○"
                    rbox.label(
                        text=f"  {label} {r['pct']:.0f}%: "
                             f"{r['circ_mm']:.0f} mm circ / "
                             f"∅{r['diam_mm']:.0f} mm"
                    )

        # ── SCULPT ────────────────────────────────────────────────────────────
        elif step == 'sculpt':
            # v1.20.8 — Select & Transform lifecycle fix.
            #
            # This section used to be gated on `context.mode == 'SCULPT'` alone.
            # Every selection tool (Box/Lasso/Circle, operators/select_tools.py)
            # deliberately switches into EDIT mode, so choosing one made the mode
            # test fail and the whole section was replaced by "Enter sculpt
            # mode" — the workflow appeared to exit the instant the user picked a
            # tool, which is exactly the reported bug.
            #
            # The step is now in-workflow while EITHER Blender is in a mode this
            # workflow legitimately uses (SCULPT for brushes, EDIT for region
            # select), OR the region-edit session flag that select_tools.py owns
            # is set. The flag is authoritative: it is cleared only by an
            # explicit Confirm/Cancel, so a transient mode change the workflow
            # performs itself can never look like the user leaving.
            region_active = bool(context.scene.get("dynax_region_edit_active", False))
            in_workflow = (context.mode in {'SCULPT', 'EDIT'}) or region_active

            if not in_workflow:
                col = layout.column()
                col.scale_y = 1.4
                col.operator("dynax.sculpt_start",
                             text="Enter sculpt mode", icon='SCULPTMODE_HLT')
            else:
                # Selection tools — box / lasso / circle (moved here from
                # Align & Rotate in v2.6.12, since adjusting part of the
                # mesh fits better alongside sculpting/shaping tools)
                sel = layout.box()
                sel.label(text="Select & transform region", icon='MOD_MASK')
                cc = sel.column(align=True)
                cc.label(text="1. Select:")
                tip3 = cc.box()
                tip3.scale_y = 0.85
                tip3.label(text="SHIFT = add · CTRL = subtract", icon='INFO')
                warn3 = cc.box()
                warn3.scale_y = 0.85
                warn3.alert = props.selection_through
                warn3.label(text="Select through ON picks both sides", icon='ERROR')
                cc.prop(props, "selection_through", text="Select through (off = front only)")
                selrow = cc.row(align=True)
                selrow.operator("dynax.select_box",    text="Box",    icon='MESH_PLANE')
                selrow.operator("dynax.select_lasso",  text="Lasso",  icon='GREASEPENCIL')
                selrow.operator("dynax.select_circle", text="Circle", icon='BRUSH_DATA')
                cc.prop(props, "select_brush_radius", text="Brush Radius", slider=True)
                selrow2 = cc.row(align=True)
                selrow2.operator("dynax.select_clear",  text="Clear",  icon='X')
                selrow2.operator("dynax.select_invert", text="Invert", icon='ARROW_LEFTRIGHT')
                cc.separator()
                cc.label(text="2. Lock & transform:")
                cc.operator("dynax.lock_selection", text="Lock selection", icon='LOCKED')
                from ..operators.select_tools import selection_is_fresh
                sculpt_fresh, _r = selection_is_fresh(context, obj, 'sculpt')
                cnt = context.scene.get("dynax_selection_count")
                if sculpt_fresh and cnt:
                    cc.label(text=f"  Locked: {cnt:,} verts", icon='CHECKMARK')
                cc.prop(props, "region_transform_mode", text="")
                grow = cc.row(align=True)
                grow.scale_y = 1.15
                grow.operator("dynax.move_region",   text="Move",   icon='ORIENTATION_GLOBAL')
                grow.operator("dynax.rotate_region", text="Rotate", icon='ORIENTATION_GIMBAL')
                # Explicit confirm/cancel (v1.20.8): the tool now ends only when
                # the user says so. Confirm keeps the edit; Cancel restores the
                # baseline captured when the session opened.
                cc.separator(factor=0.3)
                endrow = cc.row(align=True)
                endrow.scale_y = 1.15
                endrow.operator("dynax.finish_region", text="✓ Confirm", icon='CHECKMARK')
                cancel = endrow.row(align=True)
                cancel.alert = True
                cancel.operator("dynax.cancel_region", text="Cancel", icon='X')
                if region_active:
                    hint = cc.box()
                    hint.scale_y = 0.85
                    hint.label(text="Region edit open — Confirm or Cancel to close",
                               icon='INFO')

                # Push / Pull
                pp = layout.box()
                pp.label(text="Push / Pull", icon='CURVE_BEZCURVE')
                c2 = pp.column(align=True)
                c2.prop(props, "pushpull_amount_mm", text="Amount (mm)")
                c2.prop(props, "pushpull_circular",  text="Circular falloff")
                row_p = c2.row(align=True)
                row_p.scale_y = 1.2
                op_pull = row_p.operator("dynax.push_pull", text="Pull ↑", icon='TRIA_UP')
                op_pull.direction = 'PULL'
                op_pull.amount_mm = props.pushpull_amount_mm
                op_pull.circular  = props.pushpull_circular
                op_push = row_p.operator("dynax.push_pull", text="Push ↓", icon='TRIA_DOWN')
                op_push.direction = 'PUSH'
                op_push.amount_mm = props.pushpull_amount_mm
                op_push.circular  = props.pushpull_circular

                # 9 brushes (WASP Med style — clean buttons)
                br = layout.box()
                active_brush = context.scene.get("dynax_active_brush", "")
                br.label(text=f"Brush: {active_brush}" if active_brush else "Brushes",
                         icon='BRUSH_DATA')
                col_b = br.column(align=True)
                col_b.scale_y = 1.05
                from ..operators.sculpt_brushes import BRUSHES
                # Two-column grid for compactness
                grid = col_b.grid_flow(row_major=True, columns=2,
                                       even_columns=True, align=True)
                for op_id, label, icon, _, _ in BRUSHES:
                    is_active = (label == active_brush)
                    grid.operator(op_id, text=label, icon=icon, depress=is_active)

                # Live brush controls — bound directly to the active sculpt brush
                # so the sliders move the real brush with no Apply step.
                if context.mode == 'SCULPT':
                    sculpt = context.tool_settings.sculpt
                    if sculpt and sculpt.brush:
                        rs = layout.box()
                        rscol = rs.column(align=True)
                        rscol.label(text="Brush Controls", icon='BRUSH_DATA')
                        rscol.prop(sculpt.brush, "size", text="Radius", slider=True)
                        rscol.prop(sculpt.brush, "strength", text="Strength", slider=True)
                        if hasattr(sculpt.brush, "auto_smooth_factor"):
                            rscol.prop(sculpt.brush, "auto_smooth_factor",
                                       text="Auto-Smooth", slider=True)

                # Done
                layout.separator(factor=0.3)
                done = layout.row()
                done.scale_y = 1.6
                done.operator("dynax.sculpt_end",
                              text="✓  Done sculpting", icon='CHECKMARK')

        # ── TRIM LINE ─────────────────────────────────────────────────────────
        elif step == 'trimline':
            # ── Paint & separate — the ONLY trimline method ─────────────────────
            # The old "Method B — Spline cut" (click-to-place points → close loop
            # → knife-ribbon cut) was REMOVED from the UI for pilot testing: it
            # never became reliable on real flared/scalloped brims (see the
            # v1.20.8 "Known limitation" in CLAUDE.md — an encircling ring above
            # ~75% of socket height self-crosses and is correctly refused, which
            # reads to a clinician as "it doesn't work"). The operators in
            # operators/trimline.py are still registered — `dynax.trimline_clear`
            # is shared with this method's Start-over button, and
            # `dynax.trimline_quick_slice` is kept below as its own tool — but
            # nothing draws the spline stage machine any more.
            paint_parts = [o for o in bpy.data.objects
                           if o.name.startswith(("DynaX_Selected", "DynaX_Remainder"))]
            mbox = layout.box()
            mbox.label(text="Paint & separate", icon='BRUSH_DATA')
            if not paint_parts:
                s = mbox.column(align=True)
                s.label(text="1. Select the region to keep:", icon='RESTRICT_SELECT_OFF')
                tip = s.box()
                tip.label(text="Hold SHIFT while selecting to ADD", icon='INFO')
                tip.label(text="to the existing selection. Hold CTRL")
                tip.label(text="to REMOVE from the selection.")
                tip.label(text="  1. Paint the front side")
                tip.label(text="  2. Rotate view (middle mouse)")
                tip.label(text="  3. SHIFT + paint the back side")
                tip.label(text="  4. Lock selection when done")
                tip.label(text="(or use Invert to grab the other side)")
                warn = s.box()
                warn.alert = props.selection_through
                warn.label(text="Select through ON = picks BOTH sides", icon='ERROR')
                warn.label(text="at once. Leave OFF unless you mean to.")
                s.prop(props, "selection_through", text="Select through (off = front only)")
                r = s.row(align=True)
                r.operator("dynax.select_box",    text="Box",   icon='MESH_PLANE')
                r.operator("dynax.select_lasso",  text="Lasso", icon='GREASEPENCIL')
                r.operator("dynax.select_circle", text="Paint", icon='BRUSH_DATA')
                s.prop(props, "select_brush_radius", text="Brush Radius", slider=True)
                r2 = s.row(align=True)
                r2.operator("dynax.select_clear",  text="Clear",  icon='X')
                r2.operator("dynax.select_invert", text="Invert", icon='ARROW_LEFTRIGHT')
                s.separator()
                s.label(text="2. Lock & separate:", icon='LOCKED')
                s.operator("dynax.lock_selection", text="Lock selection", icon='LOCKED')
                # Only a region locked in THIS step counts. A region left over
                # from Sculpt is not a trimline region and must not read as one.
                from ..operators.select_tools import selection_is_fresh
                fresh, _reason = selection_is_fresh(context, obj, 'trimline')
                cnt = context.scene.get("dynax_selection_count", 0)
                if fresh and cnt:
                    s.label(text=f"  ✓ {cnt:,} verts locked for this trimline",
                            icon='CHECKMARK')
                else:
                    note = s.box()
                    note.scale_y = 0.85
                    note.label(text="No trimline region locked yet", icon='INFO')
                sep = s.row()
                sep.scale_y = 1.5
                sep.alert = True
                sep.enabled = fresh
                sep.operator("dynax.separate_selected",
                             text="Separate region", icon='UNLINKED')
            else:
                d = mbox.column(align=True)
                d.label(text="✓ Region separated!", icon='CHECKMARK')
                d.label(text="3. Pick the part to keep (delete the red remainder):",
                        icon='OBJECT_DATA')
                active_name = context.active_object.name if context.active_object else ""
                for p in sorted(paint_parts, key=lambda o: o.name):
                    prow = d.row(align=True)
                    op = prow.operator(
                        "dynax.pick_part", text=p.name.replace("DynaX_", ""),
                        icon='RADIOBUT_ON' if p.name == active_name else 'RADIOBUT_OFF',
                        depress=(p.name == active_name))
                    op.part_name = p.name
                    if "Remainder" in p.name or "Part_" in p.name:
                        dop = prow.operator("dynax.delete_part", text="", icon='TRASH')
                        dop.part_name = p.name
                d.separator()
                d.label(text="→ Smooth the rim below, then Add thickness", icon='FORWARD')
                d.operator("dynax.trimline_clear", text="Start over", icon='X')

            layout.separator()

            # ── Quick flat slice ────────────────────────────────────────────────
            # Kept when the spline cut was removed: a straight horizontal plane
            # cut at a given height is a different, self-contained tool and does
            # not touch the retired spline stage machine.
            alt = layout.box()
            alt.label(text="Quick flat slice", icon='MESH_PLANE')
            alt.operator("dynax.trimline_quick_slice",
                         text="Slice at height…", icon='MESH_PLANE')

            # Edge finishing — always visible, works on any separated/sliced part
            edge = layout.box()
            edge.label(text="Edge finishing (run on each part)", icon='MOD_EDGESPLIT')
            c3 = edge.column(align=True)
            c3.operator("dynax.smooth_cut_boundary",
                        text="Smooth cut boundary",         icon='MOD_SMOOTH')
            c3.operator("dynax.fill_boundary",
                        text="Fill cut boundary (optional)", icon='MESH_PLANE')
            c3.operator("dynax.flare_edge",  text="Flare open rim",  icon='MOD_SMOOTH')
            c3.operator("dynax.clean_slice", text="Clean cut edges", icon='BRUSH_DATA')

        # ── THICKNESS ─────────────────────────────────────────────────────────
        elif step == 'thickness':
            instr_open = _draw_instructions_header(context, layout)

            col = layout.column(align=True)
            col.prop(props, "solidify_thickness_mm", text="Thickness (mm)")
            col.prop(props, "offset_direction",       text="Direction")
            col.prop(props, "offset_cap_rim",         text="Cap open edges")
            col.separator()
            col.scale_y = 1.3
            col.operator("dynax.offset_add_update",
                         text="Add / update thickness", icon='MOD_SOLIDIFY')
            col.separator()
            if instr_open:
                info = col.column(align=True)
                info.scale_y = 0.8
                info.label(text="Bake locks thickness into the mesh.", icon='INFO')
                info.label(text="Required before Export.")
            if context.active_object and context.active_object.get("dynax_thickness_baked", False):
                warn = col.column(align=True)
                warn.scale_y = 0.8
                warn.alert = True
                warn.label(text="Already baked — Bake again ADDS more", icon='ERROR')
                warn.label(text="thickness on top (does not replace it).")
            row = col.row(align=True)
            row.operator("dynax.offset_apply",  text="Bake",   icon='CHECKMARK')
            row.operator("dynax.offset_remove", text="Remove", icon='X')

            # Manual smooth, available right here so any spikes/offshoots left
            # by Solidify at the rim or on thin/sharp areas can be smoothed
            # immediately after baking, without switching tabs.
            sm_box = layout.box()
            sm_box.label(text="Smooth the baked wall", icon='SCULPTMODE_HLT')
            sm_col = sm_box.column(align=True)
            if context.mode == 'SCULPT':
                sm_col.label(text="Smooth brush active — paint to smooth", icon='BRUSH_DATA')
                sm_col.separator()
                sm_col.prop(props, "smooth_brush_radius",   text="Radius (px)")
                sm_col.prop(props, "smooth_brush_strength", text="Strength")
                sm_col.operator("dynax.update_smooth_brush",
                                 text="Apply brush settings", icon='FILE_REFRESH')
                sm_col.separator()
                done = sm_col.row()
                done.scale_y = 1.3
                done.operator("dynax.sculpt_end", text="✓ Done smoothing", icon='CHECKMARK')
            else:
                if instr_open:
                    tip = sm_col.box()
                    tip.scale_y = 0.8
                    tip.label(text="Spikes/offshoots at the rim usually come", icon='INFO')
                    tip.label(text="from sharp/non-manifold edges before baking.")
                    tip.label(text="Smoothing here fixes them after the fact.")
                sm_col.scale_y = 1.15
                sm_col.prop(props, "smooth_brush_radius",   text="Radius (px)")
                sm_col.prop(props, "smooth_brush_strength", text="Strength")
                sm_col.operator("dynax.sculpt_start_smooth",
                                 text="Enter smooth mode", icon='SCULPTMODE_HLT')

            box2 = layout.box()
            box2.label(text="Partial (selected faces)", icon='FACE_MAPS')
            c2 = box2.column(align=True)
            c2.prop(props, "extrude_distance_mm", text="Distance (mm)")
            c2.operator("dynax.extrude_faces",
                        text="Extrude selected faces", icon='FACE_MAPS')

        # ── COMPONENTS ────────────────────────────────────────────────────────
        elif step == 'components':
            # Automatic Component Bridge (SPEC_component_bridge_correct.md).
            # Replaces the v1.6.0-v1.9.x manual zone-selection workflow
            # (operators/manual_bridge.py, kept on disk but no longer
            # registered) — confirmed with the user before rebuilding this,
            # given CLAUDE.md's explicit "do not re-attempt automatic bridge
            # generation without being asked" note from when it was abandoned
            # the first time. See component_bridge.py's module docstring for
            # the specific bugs found and fixed vs. this reference spec.
            # The full Component Connection UI (Load, Position, Quick Bridge,
            # Smart Transition, ParaLink) now lives in the shared
            # panels/components_section.py so ParaForm and ParaFly TT can reuse
            # exactly the same tooling — see that module's docstring.
            draw_component_connection(context, layout, props, export_step='export')

        # ── EXPORT ────────────────────────────────────────────────────────────
        elif step == 'export':
            note = layout.box()
            note.label(text="Slicer tip:", icon='INFO')
            note.label(text="Leave 'Export in mm' OFF for")
            note.label(text="Chitubox / Lychee / Bambu / Cura")

            col = layout.column(align=True)
            col.prop(props, "export_filename", text="File Name")
            col.prop(context.scene, "dynax_export_path", text="Custom folder (optional)")
            col.label(text="Empty folder → saves to Downloads", icon='INFO')
            col.prop(props, "export_apply_modifiers", text="Apply modifiers")
            col.prop(props, "export_validate_mesh",   text="Validate first")
            col.prop(props, "export_scale_to_mm",     text="Export in mm (advanced)")
            col.separator()
            col.scale_y = 1.5
            col.operator("dynax.export_stl", text="Export STL", icon='EXPORT')

            j = layout.box()
            j.label(text="Merge before export", icon='MOD_BOOLEAN')
            c3 = j.column(align=True)
            c3.operator("dynax.boolean_join", text="Boolean join", icon='AUTOMERGE_ON')
            c3.operator("dynax.join_objects",  text="Simple join",  icon='AUTOMERGE_OFF')
            c3.prop(props, "fuse_voxel_size")
            c3.operator("dynax.fuse_voxel",    text="Fuse (voxel)", icon='MOD_REMESH')

            cost_box = layout.box()
            cost_box.label(text="Material & Cost Estimate", icon='PACKAGE')
            cc2 = cost_box.column(align=True)
            cc2.prop(props, "print_infill_percent", text="Infill %", slider=True)
            cc2.operator("dynax.estimate_cost", text="Calculate", icon='FILE_REFRESH')

            vol = context.scene.get("dynax_est_volume_cm3")
            if vol is not None:
                weight = context.scene.get("dynax_est_weight_g", 0)
                cost = context.scene.get("dynax_est_cost", 0)
                result = cost_box.box()
                result.label(text=f"Volume: {vol} cm³")
                result.label(text=f"Est. Weight: {weight} g")
                result.label(text=f"Est. Cost: {props.material_currency_symbol}{cost}")

        # ── DEVELOPER TOOLS (only visible when get_dev_mode() is True) ─────────
        # Houses the Phase-1 height-band creation operators, used ONLY to
        # re-rig a template mesh. Invisible unless Developer Mode is enabled
        # in the add-on's Preferences panel.
        from ..preferences import get_dev_mode
        if get_dev_mode():
            layout.separator()
            dev = layout.box()
            dev.alert = True
            dev.label(text="Developer Tools — NOT for clinical use", icon='ERROR')
            dc = dev.column(align=True)
            dc.label(text="Height-Band Vertex Groups", icon='GROUP_VERTEX')
            dc.prop(props, "height_band_count", text="Number of Bands")
            dc.prop(props, "height_band_blend_mm", text="Blend Zone (mm)")
            op = dc.operator("dynax.create_height_band_groups",
                             text="Create Height-Band Groups", icon='GROUP_VERTEX')
            op.num_bands = props.height_band_count
            op.blend_mm = props.height_band_blend_mm
            dc.operator("dynax.clear_height_band_groups",
                        text="Clear Height-Band Groups", icon='X')
