# panels/parafly_afo_panel.py - ParaFly AFO workflow panel
# (SPEC_parafly_afo_complete.md Section 11).
#
# Drawn from paraforge_panel.py's draw_paraforge_zones_panel() when
# scene.parafly_device_type == 'AFO' - same "plain module of draw functions,
# no second bpy.types.Panel" pattern as parafly_tlso_panel.py/paraforge_panel.py
# (see paraforge_panel.py's module docstring).
#
# Corrections vs. the spec's Section 11 code, found by checking against the
# real codebase rather than trusting the spec's code (same class of bugs
# already documented once for TLSO - see tlso_alignment.py's module
# docstring):
#
# 1. scene.parafly_active_object -> scene.paraforge_active_object.
#
# 2. Every button's operator idname parafly.afo_* -> paraforge.afo_* (this
#    addon's real, consistent operator namespace throughout - paraforge.tlso_*
#    for TLSO, paraforge.afo_* for AFO. paraforge.afo_reset_all_zones (spec)
#    is also just wrong on its own terms - the real operator this file
#    registers is PARAFORGE_OT_afo_reset_all / paraforge.afo_reset_all,
#    matching paraforge.tlso_reset_all exactly, not "_reset_all_zones").
#
# 3. `from preferences import get_dev_mode` is not a valid import from this
#    file's location (dynax_addon/panels/) - fixed to the same relative
#    import parafly_tlso_panel.py already uses: `from ..preferences import
#    get_dev_mode`, at module level rather than re-imported inside a draw
#    function.
#
# 4. draw_zone_image(box, zone_id) is dropped - image_loader.py's preview
#    collection is hard-wired to TLSO's own "tlso" key and asset folder (see
#    image_loader.py), so it would never find anything for an AFO zone id
#    even wrapped in try/except, and no AFO reference PNGs exist to show
#    anyway. Matches TT's own _draw_clinical_mapping (paraforge_panel.py),
#    which never called draw_zone_image at all - AFO's mapping step simply
#    has no reference image yet, same as TT's.
#
# 5. _draw_afo_alignment's `__import__('dynax_addon.paraforge.operators.
#    afo_landmarks', fromlist=['LANDMARK_SEQUENCE'])` string-based import
#    hack is replaced with a normal relative import - there's no circular
#    import between this panel module and afo_landmarks.py that would need
#    the indirection, and every other section in this file already imports
#    afo_landmarks normally.
#
# 6. `import json` was missing entirely from the spec's own import block,
#    even though _draw_afo_measurements calls json.loads() - added.

import bpy
import json

from ..paraforge.afo_zone_reader import get_afo_zone_names
from ..paraforge.afo_zone_definitions import get_afo_zone_meta
from ..paraforge.operators.afo_correction import _compute_sva, _compute_calcaneal
from ..paraforge.operators.afo_slider_engine import AFO_BASELINE_KEY, has_afo_baseline
from ..preferences import get_dev_mode
from .paraforge_panel import (
    _wrap, _draw_smooth_standalone, _draw_thickness_section,
    _draw_export, _dispatch_op,
)
from .ui_helpers import draw_stage_progress, draw_workflow_header


AFO_STAGES = [
    "Input", "Landmarks", "Alignment", "Correction", "Mapping", "Adjustment",
]
AFO_STAGE_INDEX = {
    'INPUT': 0,
    'LANDMARKS': 1,
    'ALIGNMENT': 2,
    'CORRECTION': 3,
    'MAPPING': 4,
    'ADJUSTMENT': 5,
    'MEASUREMENT': 5,
}


# ── Accordion helpers ─────────────────────────────────────────────
# One stage is expanded at a time; the rest collapse to a single clickable
# header row. The expanded stage defaults to the workflow's current stage
# (parafly_afo_stage) and follows it forward (the stage enum's update callback
# clears parafly_afo_ui_stage on every advance), but the clinician can click any
# header to peek at another stage without losing their place.

def _afo_open_stage(scene):
    return getattr(scene, "parafly_afo_ui_stage", "") or getattr(scene, "parafly_afo_stage", "INPUT")


def _afo_stage(layout, scene, key, title, icon, done=False, active=False):
    """Draw a collapsible stage header; return the body box if it's open, else
    None so the caller skips drawing that stage's contents."""
    is_open = (_afo_open_stage(scene) == key)
    box = layout.box()
    row = box.row(align=True)
    op = row.operator("paraforge.afo_ui_set_stage", text="",
                      icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT', emboss=False)
    op.stage = key
    row.label(text=title, icon=icon)
    tag = row.row()
    tag.alignment = 'RIGHT'
    if active:
        tag.label(text="", icon='PLAY')
    elif done:
        tag.label(text="", icon='CHECKMARK')
    return box if is_open else None


def draw_afo_panel(context, layout):
    scene = context.scene
    stage = getattr(scene, "parafly_afo_stage", 'INPUT')
    obj = scene.paraforge_active_object

    from ..paraforge.operators.afo_landmarks import LANDMARK_SEQUENCE, _get_landmarks
    lm = _get_landmarks(scene)
    all_placed = bool(lm) and all(l["id"] in lm for l in LANDMARK_SEQUENCE)
    aligned = bool(lm.get("_axes"))
    past_corr = stage in ('MAPPING', 'ADJUSTMENT', 'MEASUREMENT')

    current_index = AFO_STAGE_INDEX.get(stage, 0)
    draw_workflow_header(
        layout, "AFO Orthosis", current_index + 1, len(AFO_STAGES))
    draw_stage_progress(layout, AFO_STAGES, current_index)

    # 1 · Input (always available)
    b = _afo_stage(layout, scene, 'INPUT', "1 · Input", 'IMPORT',
                   done=obj is not None, active=stage == 'INPUT')
    if b is not None:
        _draw_afo_input(context, b)

    if stage in ('LANDMARKS', 'ALIGNMENT', 'CORRECTION',
                 'MAPPING', 'ADJUSTMENT', 'MEASUREMENT'):
        b = _afo_stage(layout, scene, 'LANDMARKS', "2 · Landmarks", 'EMPTY_AXIS',
                       done=all_placed, active=stage == 'LANDMARKS')
        if b is not None:
            _draw_afo_landmarks(context, b)

    if stage in ('ALIGNMENT', 'CORRECTION', 'MAPPING',
                 'ADJUSTMENT', 'MEASUREMENT'):
        b = _afo_stage(layout, scene, 'ALIGNMENT', "3 · Alignment",
                       'ORIENTATION_GLOBAL',
                       done=aligned, active=stage == 'ALIGNMENT')
        if b is not None:
            _draw_afo_alignment(context, b)

    if stage in ('CORRECTION', 'MAPPING', 'ADJUSTMENT', 'MEASUREMENT'):
        b = _afo_stage(layout, scene, 'CORRECTION', "4 · Angular Correction",
                       'DRIVER_ROTATIONAL_DIFFERENCE',
                       done=past_corr, active=stage == 'CORRECTION')
        if b is not None:
            _draw_afo_correction(context, b)

    if stage == 'MAPPING':
        b = _afo_stage(layout, scene, 'MAPPING', "5 · Zone Mapping",
                       'GROUP_VERTEX', active=True)
        if b is not None:
            _draw_afo_mapping(context, b)

    if stage in ('ADJUSTMENT', 'MEASUREMENT'):
        b = _afo_stage(layout, scene, 'ADJUSTMENT', "6 · Clinical Adjustment",
                       'PREFERENCES', active=stage == 'ADJUSTMENT')
        if b is not None:
            _draw_afo_adjustment(context, b)

    # Cross-cutting tools stay below the staged accordion, each already its own
    # collapsed-by-default box so they add no scrolling until opened.
    if obj is not None:
        _draw_afo_measurements(context, layout)
        _draw_smooth_standalone(context, layout)
        _draw_afo_advanced(context, layout)
        _draw_export(context, layout)
        layout.separator(factor=0.5)
        layout.operator("paraforge.save_project", text="Save Project",
                        icon='FILE_TICK')


# ── Section draw functions (draw into the accordion body box) ──────

def _draw_afo_input(context, box):
    scene = context.scene
    obj = scene.paraforge_active_object
    if obj is None:
        box.operator("paraforge.import_scan", text="Import Foot/Leg Scan",
                     icon='IMPORT')
        box.operator("paraforge.load_project", text="Load Saved Project",
                     icon='FILE_FOLDER')
    else:
        row = box.row(align=True)
        row.label(text=obj.name, icon='CHECKMARK')
        row.operator("paraforge.import_scan", text="New Scan",
                     icon='FILE_REFRESH')
        # Remesh the raw scan to clean, even topology before landmarking. Raw
        # foot scans are noisy/uneven; a voxel remesh gives reliable ray-casts,
        # smoother trimlines and predictable thickening downstream.
        remesh = box.column(align=True)
        remesh.prop(scene, "paraforge_remesh_voxel_size", text="Remesh Voxel (mm)")
        remesh.operator("paraforge.remesh", text="Remesh Scan", icon='MOD_REMESH')


def _draw_afo_landmarks(context, box):
    from ..paraforge.operators.afo_landmarks import (
        LANDMARK_SEQUENCE, _get_landmarks
    )
    scene = context.scene
    lm = _get_landmarks(scene)
    placed_count = len([l for l in LANDMARK_SEQUENCE if l["id"] in lm])
    box.label(text=f"Placed {placed_count}/6")

    # Progress dots
    dots = ""
    for ldef in LANDMARK_SEQUENCE:
        dots += "● " if ldef["id"] in lm else "○ "
    box.label(text=dots.strip())

    # Current landmark instruction
    current = scene.parafly_afo_current_landmark
    if current:
        for ldef in LANDMARK_SEQUENCE:
            if ldef["id"] == current:
                inst_box = box.box()
                inst_box.label(text=ldef["display_name"], icon='PIVOT_CURSOR')
                for line in _wrap(ldef["description"]):
                    inst_box.label(text=line)
                break

    row2 = box.row(align=True)
    row2.operator("paraforge.afo_place_landmarks",
                  text="Place Landmarks", icon='CURSOR')
    row2.operator("paraforge.afo_clear_landmarks",
                  text="", icon='X')


def _draw_afo_alignment(context, box):
    from ..paraforge.operators.afo_landmarks import LANDMARK_SEQUENCE, _get_landmarks
    scene = context.scene
    lm = _get_landmarks(scene)
    all_placed = all(ldef["id"] in lm for ldef in LANDMARK_SEQUENCE)

    if not all_placed:
        box.label(text="Place all 6 landmarks first.", icon='INFO')
        return

    box.label(
        text="Heel → origin  |  Toes → −Y  |  Sole flat",
        icon='INFO'
    )
    row = box.row()
    row.scale_y = 1.3
    row.operator("paraforge.afo_auto_align",
                 text="Align Scan to Standard Pose",
                 icon='ORIENTATION_GLOBAL')

    # ── Manual pose adjustment ────────────────────────────────────
    # Nudges re-derive the anatomical axes, so Angular Correction stays
    # consistent with whatever the clinician dials in by hand.
    manual = box.box()
    manual.label(text="Manual Adjust", icon='ORIENTATION_GIMBAL')
    manual.prop(scene, "parafly_afo_manual_rotate_step", text="Step (°)")

    def _nudge_pair(label, axis, minus_icon, plus_icon):
        r = manual.row(align=True)
        r.label(text=label)
        op = r.operator("paraforge.afo_manual_nudge", text="", icon=minus_icon)
        op.axis = axis
        op.direction = -1.0
        op = r.operator("paraforge.afo_manual_nudge", text="", icon=plus_icon)
        op.axis = axis
        op.direction = 1.0

    _nudge_pair("Pitch (X)", 'X', 'TRIA_DOWN', 'TRIA_UP')
    _nudge_pair("Roll (Y)", 'Y', 'LOOP_BACK', 'LOOP_FORWARDS')
    _nudge_pair("Yaw (Z)", 'Z', 'TRIA_LEFT', 'TRIA_RIGHT')

    manual.operator("paraforge.afo_drop_sole_flat",
                    text="Drop Sole Flat", icon='SNAP_FACE')
    manual.operator("paraforge.afo_snap_heel_origin",
                    text="Snap Heel to Origin", icon='SNAP_ON')


def _draw_afo_correction(context, box):
    scene = context.scene

    # Store baseline on first entry. The baseline lives in a mesh attribute
    # (v1.20.6 perf fix), so it must be probed with has_afo_baseline(), NOT
    # obj.get(AFO_BASELINE_KEY) — the latter is an object custom-property lookup
    # that store_afo_original_positions() actively deletes, so it was ALWAYS
    # None here, leaving the panel permanently stuck on "Initialise Correction"
    # and never drawing the sliders (the "just shows baseline stored" bug).
    obj = scene.paraforge_active_object
    if obj and not has_afo_baseline(obj):
        box.operator("paraforge.afo_store_correction_baseline",
                     text="Initialise Correction", icon='FILE_REFRESH')
        return

    # Live angle display
    sva = _compute_sva(scene)
    cal = _compute_calcaneal(scene)
    if sva:
        row = box.row()
        row.label(text=f"SVA: {sva[0]:.1f}° {sva[1]}", icon='DRIVER_ROTATIONAL_DIFFERENCE')
    if cal:
        row = box.row()
        row.label(text=f"Calcaneal: {cal[0]:.1f}° {cal[1]}", icon='DRIVER_ROTATIONAL_DIFFERENCE')

    box.separator(factor=0.2)

    # Ideal alignment preset
    ideal_row = box.row()
    ideal_row.operator("paraforge.afo_ideal_alignment",
                       text="★ Ideal Alignment (4° dorsiflexion)",
                       icon='SOLO_ON')

    box.separator(factor=0.2)

    # Correction sliders
    col = box.column(align=True)
    col.prop(scene, "parafly_afo_ankle_angle", slider=True)
    col.label(text="  ← Plantarflex    Dorsiflex →", icon='BLANK1')
    col.separator(factor=0.3)
    col.prop(scene, "parafly_afo_footroll_angle", slider=True)
    col.label(text="  ← Pronate    Supinate →", icon='BLANK1')
    col.separator(factor=0.3)
    col.prop(scene, "parafly_afo_forefoot_angle", slider=True)
    col.label(text="  ← Abduct    Adduct →", icon='BLANK1')
    col.separator(factor=0.3)
    col.prop(scene, "parafly_afo_forefoot_vertical_angle", slider=True)
    col.label(text="  ← Plantarflex    Dorsiflex →", icon='BLANK1')
    col.separator(factor=0.3)
    col.prop(scene, "parafly_afo_heeltilt_angle", slider=True)
    col.label(text="  ← Valgus    Varus →", icon='BLANK1')

    box.separator(factor=0.3)
    row = box.row(align=True)
    row.scale_y = 1.3
    row.operator("paraforge.afo_apply_corrections",
                 text="✓ Apply", icon='CHECKMARK')
    row.operator("paraforge.afo_reset_corrections",
                 text="Reset", icon='LOOP_BACK')


def _draw_afo_mapping(context, box):
    scene = context.scene
    zone_names = get_afo_zone_names()
    total = len(zone_names)
    if total == 0:
        box.label(text="No AFO zones found.", icon='ERROR')
        return

    step = min(scene.parafly_afo_mapping_step, total - 1)
    if step < 0:
        return

    zone_id = zone_names[step]
    meta = get_afo_zone_meta(zone_id)

    box.label(text=f"Step {step+1} of {total}")

    dots = "● " * (step + 1) + "○ " * (total - step - 1)
    box.label(text=dots.strip())
    box.separator(factor=0.2)

    box.label(text=meta.get("category", "").upper(), icon='INFO')
    box.label(text=meta["display_name"], icon='MESH_CIRCLE')

    box.separator(factor=0.2)

    paint_row = box.row()
    paint_row.scale_y = 1.4
    paint_row.operator("paraforge.afo_start_painting", icon='PLAY')

    action_row = box.row(align=True)
    action_row.operator("paraforge.afo_confirm_zone", icon='CHECKMARK')
    if meta.get("skippable", True):
        action_row.operator("paraforge.afo_skip_zone", icon='FORWARD')
    action_row.operator("paraforge.afo_back_zone", icon='BACK')

    desc = meta.get("description", "")
    if desc:
        box.separator(factor=0.2)
        desc_col = box.column(align=True)
        desc_col.scale_y = 0.8
        for line in _wrap(desc):
            desc_col.label(text=line)

    if get_dev_mode():
        box.separator(factor=0.2)
        box.operator("paraforge.afo_skip_all_dev",
                     text="Skip All — Dev", icon='GHOST_ENABLED')


def _draw_afo_adjustment(context, box):
    scene = context.scene
    obj = scene.paraforge_active_object
    zone_names = get_afo_zone_names()

    any_shown = False
    current_cat = None
    for zone_id in zone_names:
        if obj and obj.vertex_groups.get(zone_id):
            meta = get_afo_zone_meta(zone_id)
            cat = meta.get("category", "")
            if cat != current_cat:
                box.separator(factor=0.2)
                box.label(text=cat.upper())
                current_cat = cat

            prop_name = f"parafly_afo_slider_{zone_id}"
            if not hasattr(scene, prop_name):
                continue
            any_shown = True
            zone_box = box.box()
            header = zone_box.row(align=True)
            header.label(text=meta.get("display_name", zone_id))
            op = header.operator("paraforge.afo_reset_zone",
                                 text="", icon='LOOP_BACK')
            op.zone_id = zone_id
            zone_box.prop(scene, prop_name, slider=True, text="")

    if not any_shown:
        box.label(text="No clinical zones mapped yet")

    box.separator(factor=0.2)
    box.operator("paraforge.afo_reset_all",
                 text="↺ Reset All Zones", icon='LOOP_BACK')


def _draw_afo_measurements(context, layout):
    scene = context.scene
    meas_open = scene.parafly_afo_meas_open

    header = layout.row()
    header.prop(
        scene, "parafly_afo_meas_open",
        text="Measurements",
        icon='TRIA_DOWN' if meas_open else 'TRIA_RIGHT',
        emboss=False
    )
    if not meas_open:
        return

    box = layout.box()

    # Mode selector
    row = box.row(align=True)
    row.prop(scene, "parafly_afo_measure_mode", expand=True)

    box.operator("paraforge.afo_measure_click",
                 text="Click to Measure", icon='DRIVER_DISTANCE')

    # Saved measurements
    try:
        measurements = json.loads(scene.parafly_afo_measurements)
    except Exception:
        measurements = []

    if measurements:
        box.separator(factor=0.2)
        box.label(text=f"Saved ({len(measurements)}):")
        for i, m in enumerate(measurements, 1):
            row = box.row()
            row.label(text=f"#{i} {m['label']}: {m['value_mm']:.1f} mm")

        row2 = box.row(align=True)
        row2.operator("paraforge.afo_export_csv", text="Export CSV",
                      icon='EXPORT')
        row2.operator("paraforge.afo_clear_measurements",
                      text="Clear All", icon='X')


def _draw_afo_advanced(context, layout):
    """AFO-only advanced tools. (The spline cut this note used to say was
    still available in Creator/TT/TLSO has since been removed everywhere.)"""
    scene = context.scene
    header = layout.row()
    header.prop(
        scene, "parafly_advanced_open", text="Advanced Tools",
        icon='TRIA_DOWN' if scene.parafly_advanced_open else 'TRIA_RIGHT',
        emboss=False,
    )
    if not scene.parafly_advanced_open:
        return

    box = layout.box()

    push = box.box()
    push.label(text="Mask Push / Pull", icon='MOD_DISPLACE')
    push.operator("paraforge.afo_pushpull_paint", text="Paint Region", icon='BRUSH_DATA')
    brush = push.column(align=True)
    brush.prop(scene, "parafly_afo_pushpull_brush_size")
    brush.prop(scene, "parafly_afo_pushpull_brush_strength", slider=True)
    push.prop(scene, "parafly_afo_pushpull_direction", expand=True)
    push.prop(scene, "parafly_afo_pushpull_amount", slider=True)
    push.prop(scene, "parafly_afo_pushpull_falloff", slider=True)
    push.label(text="Live preview updates after slider movement", icon='HIDE_OFF')
    row = push.row(align=True)
    row.operator("paraforge.afo_pushpull_reset", text="Reset", icon='LOOP_BACK')
    row.operator("paraforge.afo_pushpull_clear_mask", text="Clear Paint", icon='X')

    # Paint & Separate — mirrors Creator's Method A: paint the region to keep,
    # lock it, separate. No Keep/Remove toggle, no preview step.
    trim = box.box()
    trim.label(text="Paint & Separate", icon='BRUSH_DATA')
    trim.label(text="Paint the AFO region you want to keep.", icon='INFO')
    tools = trim.row(align=True)
    op = tools.operator("paraforge.afo_trimline_paint", text="Box", icon='MESH_PLANE')
    op.tool = 'BOX'
    op = tools.operator("paraforge.afo_trimline_paint", text="Lasso", icon='GREASEPENCIL')
    op.tool = 'LASSO'
    op = tools.operator("paraforge.afo_trimline_paint", text="Paint", icon='BRUSH_DATA')
    op.tool = 'CIRCLE'
    trim.prop(scene.dynax_props, "select_brush_radius", text="Brush Radius", slider=True)
    selection = trim.row(align=True)
    selection.operator("paraforge.afo_trimline_clear", text="Clear Paint", icon='X')
    _dispatch_op(selection, "dynax.select_invert", "Invert", 'ARROW_LEFTRIGHT')
    trim.operator("paraforge.afo_trimline_lock", text="Lock Trimline Paint", icon='LOCKED')
    count = scene.get("parafly_afo_trimline_selection_count", 0)
    if count:
        trim.label(text=f"{count:,} vertices locked", icon='CHECKMARK')
    trim.operator("paraforge.afo_trimline_separate",
                  text="Cut Trimline", icon='UNLINKED')
    # Once cut, offer to discard the split-off remainder.
    if bpy.data.objects.get("ParaFly_AFO_Remove") is not None:
        trim.operator("paraforge.afo_trimline_delete_removed",
                      text="Delete Removed Part", icon='TRASH')
    smooth = trim.column(align=True)
    smooth.prop(scene, "parafly_afo_trimline_smooth_passes")
    smooth.prop(scene, "parafly_afo_trimline_smooth_strength", slider=True)
    smooth.operator("paraforge.afo_trimline_smooth", text="Smooth Boundary Edge", icon='MOD_SMOOTH')
    trim.operator("paraforge.afo_trimline_reset", text="Reset Trimline", icon='LOOP_BACK')

    box.separator(factor=0.3)
    _draw_thickness_section(context, box)

    remesh = box.box()
    remesh.label(text="Remesh", icon='MOD_REMESH')
    auto = remesh.operator("paraforge.trimline_dispatch", text="Auto Remesh", icon='MOD_REMESH')
    auto.real_op = "dynax.auto_remesh"
    auto.skip_if_parts_exist = True
    quad = remesh.operator("paraforge.trimline_dispatch", text="Quad Remesh", icon='MOD_REMESH')
    quad.real_op = "dynax.quad_remesh"
    quad.skip_if_parts_exist = True
