# panels/ai_assistant.py - "DynaX AI" sidebar tab (v1.21.0).
#
# CRITICAL: the add-on must work fully offline. DYNAX_OT_ai_query never blocks
# Blender - the network call runs on a daemon thread, and a bpy.app.timers
# poll (the standard Blender idiom for moving background-thread results back
# onto the main thread, since bpy.types/Scene properties may only be written
# from the main thread) picks up the result and writes it into Scene
# properties. Any failure - timeout, connection error, bad JSON, anything -
# falls back to a small local keyword-matching rule set that needs no
# network at all, so the panel degrades gracefully with no internet.
#
# Same "add-on performing its own network I/O" deviation as
# utils/session_recorder.py - see that file's module docstring for why.

from __future__ import annotations

import json
import re
import textwrap
import threading
import urllib.error
import urllib.request

import bpy
from bpy.types import Operator, Panel, PropertyGroup, UIList

try:
    from ..utils.session_recorder import get_recorder
except ImportError:
    def get_recorder():
        class _NullRecorder:
            def __getattr__(self, _name):
                return lambda *a, **k: None
        return _NullRecorder()

from ..ai.context import collect_context, context_to_prompt_text, context_to_dict
from ..ai.dispatcher import dispatch, has_pending_action
from ..ai.tools import list_tools
from ..ai.conversation import get_session, reset_session
from ..ai.intent import (
    classify_intent, GUIDANCE_MESSAGE, DEFAULT_QUICK_ACTIONS, how_to_response,
    GENERAL_GUIDANCE as GENERAL_GUIDANCE_INTENT, HOW_TO as HOW_TO_INTENT,
    MESH_ACTION as MESH_ACTION_INTENT, STATUS as STATUS_INTENT,
    TASK as TASK_INTENT,
    SELECT_DYNAX_ENVIRONMENT as SELECT_ENVIRONMENT_INTENT,
    DYNAX_PLATFORM_EXPLANATION as PLATFORM_EXPLANATION_INTENT,
    GREETING as GREETING_INTENT,
    platform_explanation_response, greeting_response,
)
from ..ai.modules import detect_active_module
from ..ai.environments import detect_device, recommend_environment
from ..ai.task_state import (
    get_task_state, reset_task_state, start_task, apply_extraction,
    resolve_scan_availability, next_missing_slot, build_question,
    get_task_schema, DEVICE_KEYWORDS,
)
from ..spatial_agent.landmark_manager import (
    get_stored_zones, get_target_mesh, get_zone_meta,
    REQUIRED_ZONE_IDS, RECOMMENDED_ZONE_IDS, OPTIONAL_ZONE_IDS,
)
from ..spatial_agent.displacement_engine import zone_current_offset_mm

# Three-tier landmark quick-select, straight from the ruleset's own
# required_landmarks / recommended_landmarks / optional_landmarks lists
# (transtibial_ruleset.json) — Required and Recommended are shown directly
# in the panel; Optional lives behind the "Advanced" toggle along with the
# full dropdown.
REQUIRED_LANDMARKS = REQUIRED_ZONE_IDS

AI_ENDPOINT = "https://ai.dynax.app/api/socket-assist"
AI_TIMEOUT_SECONDS = 15
ADDON_PACKAGE_NAME = "dynax_addon"

# ── Local fallback rule set — no network required ──────────────────────────
#
# CRITICAL grounding fix: this table used naive `keyword in text` substring
# matching. Its short clinical abbreviations ("tf", "ak", "bk", "tt") are
# themselves substrings of completely unrelated ordinary words - "platform"
# contains "tf" (pla-TF-orm), which is exactly why "how does the platform
# works" was answered with the above-knee/quadrilateral-socket/ischial-
# seat/Scarpa's-triangle response: the substring match fired on "tf" with
# nothing to do with transfemoral sockets at all. Traced, not guessed - see
# ai/intent.py's DYNAX_PLATFORM_EXPLANATION docstring for the full account.
# Fixed at the root two ways: (1) _keyword_matches() below requires a real
# word/phrase boundary, not a bare substring; (2) product/platform
# questions are now resolved by ai.intent.platform_explanation_response()
# BEFORE this table is ever reached at all (see local_fallback()'s
# PLATFORM_EXPLANATION_INTENT branch) - RULES is now only ever reached for
# genuinely unclassified text, and even then only fires on a real match.
_KEYWORD_BOUNDARY_CACHE: dict = {}


def _keyword_matches(keyword: str, text: str) -> bool:
    """Word/phrase-boundary match - `keyword` must appear in `text` as a
    whole word or whole phrase, not as an arbitrary substring inside a
    longer unrelated word. Compiled patterns are cached (module-level,
    process-lifetime) since RULES is static and re-matched on every
    query."""
    pattern = _KEYWORD_BOUNDARY_CACHE.get(keyword)
    if pattern is None:
        pattern = re.compile(r"\b" + re.escape(keyword) + r"\b")
        _KEYWORD_BOUNDARY_CACHE[keyword] = pattern
    return pattern.search(text) is not None


RULES = [

    # ── Transtibial / Below Knee ──────────────
    {
        "keywords": ["below knee", "transtibial",
                     "bk", "below-knee", "tt",
                     "tibial", "ptb"],
        "response": {
            "socket_type": "PTB (Patellar Tendon Bearing)",
            "wall_thickness_mm": 4,
            "paralink_mode": "guided",
            "clinical_notes": (
                "PTB socket — standard for below-knee "
                "amputees. Key relief areas: tibial crest, "
                "fibular head, distal tibia. Patellar tendon "
                "bar should sit 1-2cm below patella. Check "
                "trim line height for activity level."
            )
        }
    },

    # ── Transfemoral / Above Knee ─────────────
    {
        "keywords": ["above knee", "transfemoral",
                     "ak", "above-knee", "tf",
                     "femoral", "quadrilateral"],
        "response": {
            "socket_type": "Quadrilateral TF Socket",
            "wall_thickness_mm": 5,
            "paralink_mode": "auto",
            "clinical_notes": (
                "Quadrilateral socket — verify ischial "
                "seat position and Scarpa's triangle. "
                "Medial brim should be at adductor "
                "longus tendon level. Check ML and AP "
                "dimensions carefully. Consider flexible "
                "inner socket for comfort."
            )
        }
    },

    # ── AFO ───────────────────────────────────
    {
        "keywords": ["afo", "ankle foot",
                     "ankle-foot", "ankle orthosis",
                     "drop foot", "foot drop"],
        "response": {
            "socket_type": "AFO (Ankle Foot Orthosis)",
            "wall_thickness_mm": 3,
            "paralink_mode": "none",
            "clinical_notes": (
                "AFO design — check malleolus relief "
                "bilaterally. Trim line should clear "
                "metatarsal heads anteriorly. For "
                "spastic patients increase wall to 4mm. "
                "Consider articulated joint for active "
                "dorsiflexion assist."
            )
        }
    },

    # ── KAFO ──────────────────────────────────
    {
        "keywords": ["kafo", "knee ankle foot",
                     "knee orthosis", "full leg"],
        "response": {
            "socket_type": "KAFO",
            "wall_thickness_mm": 4,
            "paralink_mode": "none",
            "clinical_notes": (
                "KAFO — measure thigh and calf separately. "
                "Align knee joint with medial/lateral "
                "femoral condyles. Check patella relief. "
                "Consider offset knee joint for stability. "
                "Ensure distal trim line clears metatarsals."
            )
        }
    },

    # ── TLSO ──────────────────────────────────
    {
        "keywords": ["tlso", "thoracic",
                     "spinal", "trunk", "scoliosis",
                     "lumbar", "spinal orthosis"],
        "response": {
            "socket_type": "TLSO",
            "wall_thickness_mm": 3,
            "paralink_mode": "none",
            "clinical_notes": (
                "TLSO — verify thoracic and iliac crest "
                "trim lines. Check axillary clearance. "
                "For scoliosis ensure three-point pressure "
                "system is correct. Xiphoid process must "
                "be relieved. Patient must be measured "
                "in corrected posture."
            )
        }
    },

    # ── Paediatric ────────────────────────────
    {
        "keywords": ["child", "paediatric",
                     "pediatric", "youth", "juvenile",
                     "growing", "adolescent"],
        "response": {
            "socket_type": "Paediatric Socket",
            "wall_thickness_mm": 3,
            "paralink_mode": "guided",
            "clinical_notes": (
                "Paediatric fitting — reduce wall thickness "
                "to 3mm. Account for growth — build in "
                "adjustment room. Check bony prominences "
                "carefully (growing bone). Plan for "
                "replacement in 6-12 months. Involve "
                "parents in fitting assessment."
            )
        }
    },

    # ── Active / High activity ────────────────
    {
        "keywords": ["active", "runner", "sport",
                     "athletic", "high activity",
                     "running", "football", "exercise"],
        "response": {
            "socket_type": "High-Activity Socket",
            "wall_thickness_mm": 5,
            "paralink_mode": "guided",
            "clinical_notes": (
                "High-activity patient — increase wall "
                "thickness to 5mm for durability. Consider "
                "carbon fibre reinforcement at high-stress "
                "zones. Trimline may need raising for "
                "activity range. Check suspension system "
                "suitability for dynamic loading."
            )
        }
    },

    # ── Elderly / Frail ───────────────────────
    {
        "keywords": ["elderly", "old", "frail",
                     "diabetic", "vascular", "geriatric",
                     "sedentary", "low activity"],
        "response": {
            "socket_type": "Low-Activity Socket",
            "wall_thickness_mm": 3,
            "paralink_mode": "guided",
            "clinical_notes": (
                "Low-activity or vascular patient — reduce "
                "wall thickness to 3mm for lighter weight. "
                "Extra padding relief areas for fragile "
                "skin. Check distal end bearing carefully. "
                "Softer liner recommended. Diabetic patients: "
                "total contact essential, no pressure points."
            )
        }
    },

    # ── Volume fluctuation ────────────────────
    {
        "keywords": ["volume", "fluctuation",
                     "oedema", "edema", "swelling",
                     "shrinkage", "changing limb"],
        "response": {
            "socket_type": "Adjustable Socket",
            "wall_thickness_mm": 4,
            "paralink_mode": "semi",
            "clinical_notes": (
                "Volume-fluctuating limb — consider "
                "adjustable socket design or flexible "
                "inner socket with rigid frame. Build "
                "in sock management protocol. Measure "
                "at consistent time of day. Silicone "
                "liner can help manage minor fluctuation."
            )
        }
    },

    # ── Skin / Wound issues ───────────────────
    {
        "keywords": ["wound", "scar", "skin",
                     "ulcer", "breakdown", "sensitive",
                     "fragile skin", "pressure sore"],
        "response": {
            "socket_type": "Total Contact Socket",
            "wall_thickness_mm": 4,
            "paralink_mode": "guided",
            "clinical_notes": (
                "Skin integrity concern — total contact "
                "socket essential to distribute pressure. "
                "Map all scars and sensitive areas before "
                "design. Build relief bubbles over bony "
                "prominences. Softer liner mandatory. "
                "Monitor skin at every fitting check."
            )
        }
    },

    # ── Partial foot ──────────────────────────
    {
        "keywords": ["partial foot", "chopart",
                     "lisfranc", "syme", "toe",
                     "forefoot", "partial"],
        "response": {
            "socket_type": "Partial Foot Prosthesis",
            "wall_thickness_mm": 3,
            "paralink_mode": "none",
            "clinical_notes": (
                "Partial foot — assess remaining foot "
                "carefully. Total contact for remaining "
                "plantar surface. Fill-in prosthesis "
                "or toe filler depending on level. "
                "Check shoe fitting. Consider carbon "
                "foot plate for push-off assistance."
            )
        }
    },

    # ── Bilateral ─────────────────────────────
    {
        "keywords": ["bilateral", "both legs",
                     "double amputee", "both sides",
                     "two limbs"],
        "response": {
            "wall_thickness_mm": 4,
            "paralink_mode": "guided",
            "clinical_notes": (
                "Bilateral amputee — design both sockets "
                "consistently. Consider height reduction "
                "for bilateral transfemoral. Energy return "
                "feet important for bilateral TT. Check "
                "sitting balance and transfers. Shorter "
                "prosthetic height may aid stability."
            )
        }
    },

    # ── Transtibial + specific trim concerns ──
    {
        "keywords": ["fibular", "fibula",
                     "peroneal", "nerve"],
        "response": {
            "clinical_notes": (
                "Fibular head area — ensure adequate "
                "relief over fibular head and peroneal "
                "nerve. Common cause of lateral knee "
                "pain in TT amputees. Palpate and mark "
                "before trimming."
            )
        }
    },

    # ── Congenital ────────────────────────────
    {
        "keywords": ["congenital", "born without",
                     "limb difference", "aplasia",
                     "hypoplasia"],
        "response": {
            "wall_thickness_mm": 3,
            "paralink_mode": "guided",
            "clinical_notes": (
                "Congenital limb difference — residual "
                "limb may have unusual shape. No post-"
                "surgical oedema to account for. Skin "
                "usually healthy. Family education "
                "essential. Plan for growth in children. "
                "Functional goals should guide design."
            )
        }
    },

]

_NO_MATCH_RESPONSE = {
    "clinical_notes": (
        "Please describe the device type (e.g. "
        "below-knee, AFO, above-knee) and any "
        "relevant patient factors (activity level, "
        "skin condition, age). The more specific "
        "you are, the better the suggestion."
    )
}

# ── Answer relevance gate (behaviour spec point 8) ───────────────────────
# Defense-in-depth, not the primary fix - the primary fix is structural
# (word-boundary RULES matching + the DYNAX_PLATFORM_EXPLANATION category
# resolving product questions before RULES is ever reached at all). This
# is the safety net for whatever a future RULES edit doesn't catch: a
# response should never contain clinical anatomy terminology when the
# user's own message named no device at all.
_CLINICAL_ANATOMY_TERMS = (
    "ischial", "scarpa", "patellar tendon", "malleolus", "malleoli",
    "metatarsal", "xiphoid", "femoral condyle", "adductor longus",
    "fibular head", "peroneal nerve", "iliac crest",
)


def _relevance_gate(description: str, result: dict) -> dict:
    """Rejects a RULES-matched response if the user's message named no
    recognisable device at all but the response leaked clinical anatomy
    terminology anyway - regenerates as the plain clarifying response
    instead. Only ever applied to the RULES fallback path (every other
    category branch in local_fallback returns before this point, so it
    can't accidentally suppress an intentional clinical answer). Never
    raises - a failure here degrades to returning the original result
    unchanged, not to blocking a real answer."""
    try:
        notes = (result.get("clinical_notes") or "").lower()
        if not notes or not any(term in notes for term in _CLINICAL_ANATOMY_TERMS):
            return result
        from ..ai.environments import detect_device
        if detect_device(description) is not None:
            return result
        text_l = (description or "").lower()
        if any(_keyword_matches(k, text_l)
               for kws in DEVICE_KEYWORDS.values() for k in kws):
            return result
        return dict(_NO_MATCH_RESPONSE)
    except Exception:
        return result


def _handle_task_turn(description, context, trigger_task_name, module):
    """Progressive slot-filling turn for the two concrete task flows the
    behaviour spec worked through (import_scan, create_device). Returns a
    response dict (same shape as every other local_fallback branch) or
    None if there's nothing for the task engine to do this turn - callers
    fall through to the flat category branches in that case.

    Deliberately scoped: this does NOT invent a "generate device" action
    that doesn't exist in ai.tools.TOOL_REGISTRY. Once every required slot
    is filled, the response hands off to real, existing capabilities
    (opening the import file picker, a real dispatched tool, or module
    knowledge) - it never claims to execute something this add-on can't
    actually do."""
    state = get_task_state()
    scene_dict = (context or {}).get("dynax") or {}
    scene_state = (context or {}).get("scene") or {}

    # Start a new task if none is in progress/complete, or if an explicit
    # trigger phrase names a DIFFERENT task than the one already running.
    if trigger_task_name is not None and (
            not state.is_relevant() or state.task_name != trigger_task_name):
        start_task(state, trigger_task_name)

    # Change of direction within the SAME task type (behaviour spec point
    # 9): a device keyword anywhere in this message that contradicts the
    # one already stored means the user redirected, not that they're
    # re-answering the same question. Checked unconditionally - the
    # caller (local_fallback) already decided this message is worth
    # routing here at all, whether or not it happened to contain an
    # explicit "create a"/"make a" trigger phrase.
    if state.task_name == "create_device" and state.is_relevant():
        new_device = None
        for device, keywords in DEVICE_KEYWORDS.items():
            if any(k in description.lower() for k in keywords):
                new_device = device
                break
        if new_device and state.slots.get("device") not in (None, new_device):
            start_task(state, "create_device")
            state.slots["device"] = new_device

    if not state.is_relevant():
        return None

    schema = get_task_schema(state.task_name)
    if schema is None:
        state.reset()
        return None

    newly_filled = apply_extraction(state, description, schema)
    if "scan_available" in (schema.required_slots + schema.optional_slots):
        resolve_scan_availability(state, scene_state)

    missing = next_missing_slot(state, schema)
    ack = "Got it. " if newly_filled else ""

    if missing:
        question = build_question(state, schema, missing)
        return {"clinical_notes": (ack + question).strip(), "quick_actions": []}

    # Every required slot is filled - hand off to a real capability.
    state.status = "complete"

    if state.task_name == "import_scan":
        if scene_state.get("all_mesh_names"):
            name = scene_state.get("active_object_name") or scene_state["all_mesh_names"][0]
            state.last_object_name = name
            return {
                "clinical_notes": f"I found {name} already in the scene. Would you like me to inspect it?",
                "quick_actions": [{"label": "Inspect it", "tool": "inspect_mesh"}],
            }
        return {
            "clinical_notes": (
                "I don't see a scan loaded yet. Would you like me to open the import workflow?"
            ),
            "quick_actions": [{"label": "Open Import", "tool_op": "dynax.ai_open_import"}],
        }

    if state.task_name == "create_device":
        device = state.slots.get("device", "device")
        laterality = state.slots.get("laterality")
        side_txt = f" ({laterality})" if laterality else ""
        scan_txt = "a scan is available" if state.slots.get("scan_available") else "starting from measurements"
        summary = f"Ready — {device}{side_txt}, {scan_txt}. Want me to walk you through the workflow?"
        return {
            "clinical_notes": summary,
            "quick_actions": [
                {"label": "Guide me", "query": f"How do I create a {device}?"},
            ],
        }

    return None


def local_fallback(description: str, context: dict | None = None) -> dict:
    """Pure, network-free keyword match. If multiple rules match, use the
    first match's fields but merge clinical_notes from every match.

    Phase 1 (DynaX CAD Agent, real-context enrichment): `context` is the
    dict from ai.context.context_to_dict() - optional and read-only here
    too, this function only reads it to append clinical_notes, never
    mutates it. A missing/empty context degrades gracefully to the
    pre-Phase-1 keyword-only behaviour.

    UI/conversation redesign fix: intent is classified BEFORE checking for
    a mesh - "no mesh selected" used to fire for every query when nothing
    was selected, including general questions like "can you guide me?"
    that have nothing to do with a specific mesh. See ai/intent.py."""
    mesh = (context or {}).get("mesh")
    intent = classify_intent(description)
    category = intent["category"]

    # AI Agent Core / capability-module seam: detect which module (Creator/
    # ParaForm/ParaFly-AFO/etc.) is active from the shared DynaXState the
    # core already collects, then let that module supply its own knowledge
    # and quick actions - this function never branches on a workflow name
    # itself, it only ever asks the module registry.
    module = None
    try:
        module = detect_active_module((context or {}).get("dynax") or {})
    except Exception:
        module = None
    module_quick_actions = module.quick_actions if (module and module.quick_actions) else DEFAULT_QUICK_ACTIONS

    # AI Agent Core / progressive task state: a TASK-triggering message, OR
    # any message while a task is already in progress (e.g. the user's
    # one-word answer to a slot question, which has no trigger phrase of
    # its own), routes through the structured slot-filling engine instead
    # of the flat category branches below. See ai/task_state.py.
    task_state = get_task_state()
    # Grounding fix (behaviour spec point 6): a task in progress must not
    # hijack a message that is unambiguously about something else - "how
    # does DynaX work?" mid-way through building a socket should answer
    # the product question, not silently continue the create_device
    # slot-filling flow as if the user were still answering it. Only
    # categories the classifier is CONFIDENT are unrelated to task
    # continuation are excluded here; anything else (including UNKNOWN,
    # which is where a bare one-word slot answer like "yes" or "AFO"
    # usually lands) still routes to the task engine as before.
    route_to_task = category == TASK_INTENT or (
        task_state.status == "active"
        and category not in (
            STATUS_INTENT, GENERAL_GUIDANCE_INTENT,
            SELECT_ENVIRONMENT_INTENT, PLATFORM_EXPLANATION_INTENT,
            GREETING_INTENT,
        )
    )
    if not route_to_task and task_state.status == "complete":
        # A completed task stays reachable for redirection (behaviour spec
        # point 9), but must NOT swallow every unrelated later message
        # forever - only route back in when this message actually looks
        # like a redirect, not for arbitrary small talk.
        text_l = (description or "").lower()
        stored_device = task_state.slots.get("device")
        redirect_words = ("actually", "instead", "let's work on",
                           "lets work on", "switch to", "work on the")
        mentions_other_device = any(
            d != stored_device and any(k in text_l for k in kws)
            for d, kws in DEVICE_KEYWORDS.items()
        )
        if any(w in text_l for w in redirect_words) or mentions_other_device:
            route_to_task = True

    if route_to_task:
        task_result = _handle_task_turn(description, context, intent.get("task_name"), module)
        if task_result is not None:
            return task_result

    if category == GREETING_INTENT:
        return {
            "clinical_notes": greeting_response(
                description, is_appreciation=intent.get("is_appreciation", False),
                module=module,
            ),
            "quick_actions": module_quick_actions,
        }

    if category == SELECT_ENVIRONMENT_INTENT:
        device_key = detect_device(description)
        if device_key is None:
            return {
                "clinical_notes": (
                    "Which device are you working on — insole, AFO, KAFO, "
                    "TLSO, or a prosthetic socket? I'll point you to the "
                    "right DynaX environment for it."
                ),
                "quick_actions": [],
            }
        return recommend_environment(device_key)

    if category == PLATFORM_EXPLANATION_INTENT:
        # DYNAX_PRODUCT domain - deliberately answered from
        # ai.intent.platform_explanation_response() only, never RULES/
        # how_to_response(). This is the fix for the reported grounding
        # bug: "how does the platform works" must never be able to reach
        # clinical/device content, structurally, not just by luck of
        # keyword matching.
        return {
            "clinical_notes": platform_explanation_response(description),
            "quick_actions": module_quick_actions,
        }

    if category == STATUS_INTENT:
        return {
            "clinical_notes": GUIDANCE_MESSAGE,
            "quick_actions": module_quick_actions,
        }

    if category == GENERAL_GUIDANCE_INTENT:
        message = GUIDANCE_MESSAGE
        if module is not None:
            message = f"You're working in {module.label}. " + GUIDANCE_MESSAGE
        return {
            "clinical_notes": message,
            "quick_actions": module_quick_actions,
        }

    if category == HOW_TO_INTENT:
        return {
            "clinical_notes": how_to_response(description, module=module),
            "quick_actions": module_quick_actions,
        }

    if category == MESH_ACTION_INTENT and mesh is None:
        return {
            "clinical_notes": (
                "I can do that. First, import your scan or select the "
                "mesh you want me to work with."
            ),
            "quick_actions": [
                {"label": "Work with a scan", "query": "How do I import and prepare a scan?"},
            ],
        }

    if category == MESH_ACTION_INTENT and mesh is not None:
        # Action-oriented, not a generic clinical suggestion: name the real
        # object and offer real tools (dispatched directly via
        # dynax.ai_quick_tool, not another local_fallback round-trip).
        name = mesh.get("name") or "the active object"
        verts = mesh.get("vertex_count")
        watertight = mesh.get("is_watertight")
        stats = f" ({verts:,} verts)" if isinstance(verts, int) else ""
        status_note = ""
        if watertight is False:
            status_note = " It currently has open edges."
        return {
            "clinical_notes": f"I can see {name}{stats}.{status_note} What would you like me to check?",
            "quick_actions": [
                {"label": "Inspect mesh", "tool": "inspect_mesh"},
                {"label": "Get dimensions", "tool": "get_dimensions"},
            ],
        }

    text = (description or "").lower()
    matches = [rule["response"] for rule in RULES
               if any(_keyword_matches(keyword, text) for keyword in rule["keywords"])]
    result = dict(matches[0]) if matches else dict(_NO_MATCH_RESPONSE)
    if matches:
        notes = " ".join(m["clinical_notes"] for m in matches if m.get("clinical_notes"))
        result["clinical_notes"] = notes

    extra_notes = []
    try:
        if mesh is not None:
            if not mesh.get("is_watertight", True):
                extra_notes.append(
                    "Note: active mesh has open edges — consider running "
                    "mesh repair first."
                )
            if (mesh.get("vertex_count") or 0) > 100000:
                extra_notes.append(
                    "High-poly mesh detected — consider decimating before "
                    "export."
                )
    except Exception:
        pass

    if extra_notes:
        result["clinical_notes"] = (
            result.get("clinical_notes", "") + " " + " ".join(extra_notes)
        ).strip()

    return _relevance_gate(description, result)


# ── Background query + main-thread result handoff ──────────────────────────
# _pending_result is written on the daemon thread and read/cleared by the
# bpy.app.timers poll on the main thread - the only two things ever touching
# it, guarded by a plain lock since both sides only do a quick dict swap.

_result_lock = threading.Lock()
_pending_result = None  # None, or {"suggestion": dict, "offline": bool}

# Real bug found in the redraw fix's own execution: DYNAX_PT_ai_section is a
# POPOVER (bl_region_type='WINDOW', no bl_category - only reachable via
# layout.popover()), and an open popover's region is NOT part of
# window.screen.areas[*].regions - it is a separate floating overlay region
# that Blender's public API has no way to enumerate from outside. The
# existing "force every VIEW_3D UI region to redraw" loop in
# _poll_ai_result() therefore redraws the SIDEBAR (where the DynaX AI
# launcher button lives), never the open popover itself - a landed response
# sat in session/scene data with the popover frozen on "Thinking..." until
# the user closed and reopened it (draw() reads live session data, so a
# reopen always showed it correctly - the bug was purely "no live update
# while still open"). Fixed by capturing the REAL region object at the
# moment the operator runs (context.region, valid because the operator is
# invoked by clicking a button inside that exact popover) and calling
# .tag_redraw() on that captured reference later, from the timer - a plain
# Python object reference to the region still works even though the region
# was never discoverable via window.screen.areas.
_active_query_region = None


def _capture_active_query_region(context):
    global _active_query_region
    try:
        _active_query_region = context.region
    except Exception:
        _active_query_region = None


def _query_thread(description, workflow, device_type, online, context_dict, history):
    """online=False skips the API entirely and always uses the local rule
    set (dynax_ai_online_mode toggle); online=True tries the API first and
    falls back to the same rule set on ANY failure.

    Phase 1 (DynaX CAD Agent): context_dict is collected on the MAIN thread
    by the caller (ai.context.collect_context() reads bpy.context/bpy.data,
    which is not safe to touch from a background thread) and handed to this
    function as a plain, already-serialisable dict - this function only
    reads it, never calls back into bpy.

    Phase 3: history is collected the same way, via get_session().get_history()
    on the main thread before this thread starts - that call is pure Python
    (no bpy access), so it would technically be safe to call here too, but
    passing it down keeps every background-thread input built the same way,
    with no special-cased exception to remember later."""
    global _pending_result
    if not online:
        with _result_lock:
            _pending_result = {
                "suggestion": local_fallback(description, context_dict),
                "offline": True, "query_text": description,
            }
        return

    result = None
    try:
        body = json.dumps({
            "description": description,
            "workflow": workflow,
            "device_type": device_type,
            "addon_version": "1.21.0",
            "context": context_dict,
            "history": history,
            "intent": classify_intent(description),
        }, ensure_ascii=True).encode("utf-8")
        request = urllib.request.Request(
            AI_ENDPOINT, data=body, method="POST",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(request, timeout=AI_TIMEOUT_SECONDS) as response:
            status = getattr(response, "status", None) or response.getcode()
            raw = response.read()
        if status != 200:
            raise ValueError(f"unexpected status {status}")
        suggestion = json.loads(raw.decode("utf-8"))
        if not isinstance(suggestion, dict):
            raise ValueError("response was not a JSON object")
        result = {"suggestion": suggestion, "offline": False, "query_text": description}
    except Exception:
        result = {
            "suggestion": local_fallback(description, context_dict),
            "offline": True, "query_text": description,
        }

    with _result_lock:
        _pending_result = result


_SUGGESTION_FIELD_KEYS = (
    "socket_type", "trimline_height_mm", "wall_thickness_mm", "paralink_mode",
)


def _log_ai_outcome(query_text, suggestion, tool_name, tool_result_dict, offline):
    """Phase 4: classify one AI turn as resolved / failed and log it via
    get_recorder(). Fire-and-forget - get_recorder()'s own methods are
    already no-ops when analytics_enabled is False and never raise, so no
    extra guard is needed here beyond the outer try/except.

    Deviation from the literal spec, flagged: the spec's failed-intent
    trigger checked clinical_notes for the substring "No matching profile",
    but local_fallback()'s actual _NO_MATCH_RESPONSE text was changed in an
    earlier session and no longer contains that phrase. Detecting "no real
    suggestion" by checking for the presence of any of the substantive
    suggestion fields is more robust than matching against wording that can
    (and did) drift."""
    try:
        if not isinstance(suggestion, dict):
            return

        if tool_result_dict is not None:
            if tool_result_dict.get("success"):
                get_recorder().log_ai_interaction(
                    user_input=query_text, intent_resolved=True,
                    tool_called=tool_name, tool_success=True,
                    outcome="applied", was_online=not offline,
                )
            else:
                get_recorder().log_failed_intent(
                    user_input=query_text,
                    reason=tool_result_dict.get("error") or "Tool call failed",
                    closest_tool=tool_name,
                )
            return

        has_suggestion = any(suggestion.get(k) is not None for k in _SUGGESTION_FIELD_KEYS)
        if has_suggestion:
            get_recorder().log_ai_interaction(
                user_input=query_text, intent_resolved=True,
                tool_called="", tool_success=False,
                outcome="suggested", was_online=not offline,
            )
        else:
            get_recorder().log_failed_intent(
                user_input=query_text,
                reason="No matching tool or rule found",
                closest_tool="",
            )
    except Exception:
        pass


def _force_redraw():
    """Redraw every VIEW_3D sidebar ('UI') region, via window_manager.windows
    - NOT via bpy.context.screen/bpy.context.area, which are not guaranteed
    valid inside a bpy.app.timers callback (no operator/window is
    necessarily "current" there)."""
    try:
        wm = bpy.context.window_manager
        if not wm:
            return
        for window in wm.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    for region in area.regions:
                        if region.type == 'UI':
                            region.tag_redraw()
    except Exception:
        pass


def _poll_ai_result():
    """bpy.app.timers callback - the established pattern this add-on already
    uses elsewhere for deferred/background work (see __init__.py's
    _register_sliders_deferred and afo_correction.py's debounced recompute).

    Timer-context fix: a bpy.app.timers callback has no guaranteed "current"
    window/screen/scene - bpy.context.scene inside a timer is not reliably
    the active scene (it can even be None), the same class of restricted-
    context issue __init__.py's register() already works around for
    bpy.data during Blender's own startup auto-load. The scene is now
    resolved explicitly from window_manager.windows[0].scene instead of
    bpy.context.scene, and the poll retries (rather than silently using a
    wrong/no scene) if no window is available yet."""
    global _pending_result
    with _result_lock:
        result = _pending_result
        _pending_result = None

    if result is not None:
        try:
            scene = None
            try:
                if (bpy.context and bpy.context.window_manager
                        and bpy.context.window_manager.windows):
                    win = bpy.context.window_manager.windows[0]
                    scene = win.scene
            except Exception:
                pass

            if scene is None:
                # Put the result back so the next tick can still pick it up
                # - a missing window this tick doesn't mean the response is
                # lost, just that there's nowhere to write it yet.
                with _result_lock:
                    _pending_result = result
                return 0.1

            suggestion = result["suggestion"]
            # Phase 2 (DynaX CAD Agent tool registry): if the online API's
            # response includes a tool_call, dispatch it HERE - on the main
            # thread, via the poll callback - never inside _query_thread's
            # background thread, which must never touch bpy. Runs after
            # dynax_ai_busy would otherwise be cleared, same as every other
            # write in this block.
            tool_name = ""
            tool_result_dict = None
            if isinstance(suggestion, dict) and "tool_call" in suggestion:
                tc = suggestion.get("tool_call") or {}
                tool_name = tc.get("name", "") or ""
                tool_result = dispatch(tool_name, tc.get("params", {}) or {}, bpy.context)
                tool_result_dict = {
                    "summary": tool_result.summary,
                    "data": tool_result.data,
                    "success": tool_result.success,
                    "error": tool_result.error,
                }
                suggestion["tool_result"] = tool_result_dict

            scene.dynax_ai_suggestion = json.dumps(suggestion, ensure_ascii=True)
            scene.dynax_ai_offline = bool(result["offline"])
            scene.dynax_ai_busy = False

            # Phase 3: log the assistant's turn now that the real response
            # (online or offline-fallback) is actually known - this callback
            # is where that happens, not in DYNAX_OT_ai_query.execute(),
            # which only knows the question at the time it fires.
            response_text = (
                suggestion.get("clinical_notes") if isinstance(suggestion, dict) else None
            ) or ""
            _poll_session = get_session()
            _poll_session.add_turn(
                "assistant", response_text,
                tool_used=tool_name, tool_result=tool_result_dict,
            )
            scene.dynax_ai_history_text = _poll_session.get_history_text()
            _sync_conversation_lines(scene, _poll_session)

            # Bug fix: the DynaX AI panel is a popover (DYNAX_PT_ai_section)
            # that only redraws on its own input events - writing scene
            # properties here from a bpy.app.timers callback does not by
            # itself repaint an already-open popover, so a landed response
            # could sit in the session/scene data without ever appearing
            # on screen until some unrelated redraw happened to occur.
            # Force every VIEW_3D UI region to redraw so an open popover
            # picks up the new conversation turn immediately.
            _force_redraw()

            # The fix: redraw the actual open popover via the region
            # reference captured when the query was sent (see the
            # _active_query_region comment above - this is the only region
            # object that genuinely represents an open DynaX AI popover).
            try:
                if _active_query_region is not None:
                    _active_query_region.tag_redraw()
            except Exception:
                # Freed/invalid region (popover already closed) - harmless.
                pass

            # Phase 4: feedback-capture bookkeeping - same reasoning as the
            # conversation log above, this is where the real outcome is
            # known, not in execute(). See _log_ai_outcome()'s own docstring
            # for the "no matching profile" text-matching deviation.
            _log_ai_outcome(
                result.get("query_text", ""), suggestion,
                tool_name, tool_result_dict, bool(result["offline"]),
            )
        except Exception as e:
            # Diagnostic fix: this was `except Exception: pass` - a silent
            # swallow that made real failures (a `result["suggestion"]`
            # KeyError, the tool_call dispatch() call, json.dumps on a
            # non-serialisable suggestion, etc.) invisible. This is a
            # background bpy.app.timers callback with no UI to report to,
            # so the console is the only place a real bug here can surface.
            import traceback
            print(f"[DynaX AI] EXCEPTION in _poll_ai_result: {e}")
            traceback.print_exc()
        return None  # stop polling until the next query

    return 0.25  # keep polling


def _build_auto_context(context) -> str:
    """Best-effort description built from current scene state, used when the
    clinician hasn't typed anything - so "Ask" (and the auto-trigger in
    workflow_nav.py) still has something meaningful to send.

    Phase 1 (DynaX CAD Agent): replaces the old 3-enum-string concatenation
    with the real, structured DynaXContext from ai.context - real mesh
    stats, scene state and DynaX workflow state, not just a guessed
    one-line sentence."""
    ctx = collect_context(context)
    return context_to_prompt_text(ctx)


def trigger_auto_query(context):
    """Called from operators/workflow_nav.py on a step change. If Online AI
    is on and a workflow is active, kicks off a fresh background query built
    from the auto context - without touching whatever the clinician may have
    typed into the input box, so a manual question in progress is never
    overwritten. Never blocks, never raises: any failure here is a silent
    no-op, same as every other network-adjacent entry point in this file."""
    try:
        scene = context.scene
        if not getattr(scene, "dynax_ai_online_mode", False):
            return
        if getattr(scene, "dynax_ai_busy", False):
            return
        query_text = _build_auto_context(context)
        if not query_text:
            return

        workflow = None
        device_type = None
        try:
            props = getattr(scene, "dynax_props", None)
            workflow = props.dynax_mode if props else None
            device_type = getattr(scene, "parafly_device_type", None)
        except Exception:
            pass

        _capture_active_query_region(context)

        scene.dynax_ai_busy = True
        scene.dynax_ai_suggestion = ""
        scene.dynax_ai_offline = False

        context_dict = context_to_dict(collect_context(context))
        get_session().add_turn("user", query_text)
        history = get_session().get_history()
        scene.dynax_ai_history_text = get_session().get_history_text()
        _sync_conversation_lines(scene, get_session())

        thread = threading.Thread(
            target=_query_thread,
            args=(query_text, workflow, device_type, True, context_dict, history),
            daemon=True,
        )
        thread.start()
        if not bpy.app.timers.is_registered(_poll_ai_result):
            bpy.app.timers.register(_poll_ai_result, first_interval=0.1)
    except Exception:
        pass


# ── Conversation display list (scroll fix) ───────────────────────────────
# See _draw_conversation's own comment for why this exists: template_list
# is the only genuinely scrollable widget the UILayout API offers, and it
# needs its content as a real CollectionProperty, one item per wrapped
# DISPLAY LINE (not per turn - a list row is one line).

class DynaXAIConversationLine(PropertyGroup):
    text: bpy.props.StringProperty()
    is_user: bpy.props.BoolProperty(default=False)
    is_header: bpy.props.BoolProperty(default=False)


class DYNAX_UL_ai_conversation(UIList):
    bl_idname = "DYNAX_UL_ai_conversation"

    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname, index):
        row = layout.row()
        row.scale_y = 0.8 if not item.is_header else 1.0
        if item.is_user:
            row.alignment = 'RIGHT'
        if item.is_header:
            row.label(text=item.text,
                       icon='SHADERFX' if not item.is_user else 'NONE')
        else:
            row.label(text=item.text)


# Redraw-cost guard: rebuilding the collection is cheap (conversation is
# capped at 20 turns, a handful of wrapped lines each) but there is no
# reason to do it on every single panel redraw (mouse-move, unrelated
# property change) when the underlying conversation hasn't changed at all
# since the last build. Keyed by id(session) so a session reset/reassignment
# (ai.conversation.reset_session) always forces a rebuild.
_conversation_lines_signature = None


def _sync_conversation_lines(scene, session):
    global _conversation_lines_signature
    try:
        turns = session.get_turns(20)
        signature = (id(session), len(turns),
                     turns[-1].text if turns else None)
        if signature == _conversation_lines_signature:
            return
        _conversation_lines_signature = signature

        lines = scene.dynax_ai_conversation_lines
        lines.clear()
        for turn in turns:
            is_user = turn.role == "user"
            header = lines.add()
            header.is_header = True
            header.is_user = is_user
            header.text = "You" if is_user else "DynaX"
            for wrapped in (textwrap.wrap(turn.text, width=52) or [""]):
                item = lines.add()
                item.is_user = is_user
                item.text = wrapped
            if turn.tool_used:
                tool_item = lines.add()
                tool_item.is_user = is_user
                tool_item.text = f"[tool: {turn.tool_used}]"
        scene.dynax_ai_conversation_lines_index = max(0, len(lines) - 1)
    except Exception:
        pass


def dynax_ai_input_update(self, context):
    """Enter-to-send for the Scene.dynax_ai_input text field. Blender's
    property `update` callback fires when a text-field edit is CONFIRMED -
    Enter pressed, or focus lost by clicking/tabbing away - and there is
    no public API to tell those two apart from inside `update`. This fires
    the query on any confirmed edit of non-empty text, matching the
    standard Blender addon "search box"/"rename field" convention (the
    same trade-off those widgets already make). Re-entrancy is naturally
    guarded: DYNAX_OT_ai_query.execute() clears dynax_ai_input on success,
    and an empty string never re-triggers this callback."""
    try:
        scene = context.scene
        text = (getattr(scene, "dynax_ai_input", "") or "").strip()
        if text and not getattr(scene, "dynax_ai_busy", False):
            bpy.ops.dynax.ai_query('INVOKE_DEFAULT')
    except Exception:
        pass


class DYNAX_OT_ai_query(Operator):
    """Ask DynaX AI a design question. Always non-blocking: the network call
    (when Online is on) runs on a daemon thread with a 15s timeout, and ANY
    failure falls back to the local rule set - the panel never freezes and
    never crashes. When Online is off, the API is skipped entirely."""
    bl_idname = "dynax.ai_query"
    bl_label = "Ask DynaX AI"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        query_text = (getattr(scene, "dynax_ai_input", "") or "").strip()
        if not query_text:
            query_text = _build_auto_context(context)
        if not query_text:
            self.report({'INFO'}, "Enter a description or start a workflow first")
            return {'CANCELLED'}

        workflow = None
        device_type = None
        try:
            props = getattr(scene, "dynax_props", None)
            workflow = props.dynax_mode if props else None
            device_type = getattr(scene, "parafly_device_type", None)
        except Exception:
            pass

        online = bool(getattr(scene, "dynax_ai_online_mode", False))

        _capture_active_query_region(context)

        scene.dynax_ai_busy = True
        scene.dynax_ai_suggestion = ""
        scene.dynax_ai_offline = not online
        # Clear the composer now that the question has been captured into
        # query_text above - matches standard chat UX, and (paired with
        # dynax_ai_input_update's `if text` guard) means clearing it here
        # can never re-trigger the Enter-to-send callback.
        scene.dynax_ai_input = ""

        # Collected here, on the main thread - ai.context reads bpy.context/
        # bpy.data, which is not safe to do from the background thread below.
        context_dict = context_to_dict(collect_context(context))

        # Phase 3: log the user's turn immediately (the assistant turn is
        # logged later, in _poll_ai_result, once the real response is
        # known), and hand the history array down for the online payload.
        get_session().add_turn("user", query_text)
        history = get_session().get_history()
        scene.dynax_ai_history_text = get_session().get_history_text()
        _sync_conversation_lines(scene, get_session())

        try:
            thread = threading.Thread(
                target=_query_thread,
                args=(query_text, workflow, device_type, online, context_dict, history),
                daemon=True,
            )
            thread.start()
            if not bpy.app.timers.is_registered(_poll_ai_result):
                bpy.app.timers.register(_poll_ai_result, first_interval=0.1)
        except Exception:
            # Could not even start the background attempt - fall back inline,
            # still without ever raising into Blender.
            try:
                fallback = local_fallback(query_text, context_dict)
                scene.dynax_ai_suggestion = json.dumps(fallback)
                scene.dynax_ai_offline = True
                get_session().add_turn("assistant", fallback.get("clinical_notes", ""))
                scene.dynax_ai_history_text = get_session().get_history_text()
                _sync_conversation_lines(scene, get_session())
            except Exception:
                pass
            scene.dynax_ai_busy = False

        return {'FINISHED'}


class DYNAX_OT_ai_apply(Operator):
    """Apply the current AI suggestion to whichever scene properties exist.
    Never restructures existing operators - only sets properties that are
    already registered, and skips (silently) anything that isn't."""
    bl_idname = "dynax.ai_apply"
    bl_label = "Apply to Design"
    bl_options = {'REGISTER', 'UNDO'}

    _PARALINK_MODE_MAP = {
        "auto": "AUTO", "guided": "GUIDED", "semi": "SEMI", "manual": "MANUAL",
        "none": "AUTO",
    }

    def execute(self, context):
        scene = context.scene
        raw = getattr(scene, "dynax_ai_suggestion", "") or ""
        try:
            suggestion = json.loads(raw)
        except Exception:
            self.report({'ERROR'}, "No valid AI suggestion to apply.")
            return {'CANCELLED'}
        if not isinstance(suggestion, dict):
            self.report({'ERROR'}, "No valid AI suggestion to apply.")
            return {'CANCELLED'}

        applied, skipped = [], []

        socket_type = suggestion.get("socket_type")
        if socket_type:
            applied.append(f"Socket type: {socket_type} (informational only)")

        if "trimline_height_mm" in suggestion:
            if hasattr(scene, "dynax_trimline_height"):
                try:
                    scene.dynax_trimline_height = float(suggestion["trimline_height_mm"])
                    applied.append("Trimline height")
                except Exception:
                    skipped.append("Trimline height")
            else:
                skipped.append("Trimline height")

        if "wall_thickness_mm" in suggestion:
            if hasattr(scene, "dynax_thickness"):
                try:
                    scene.dynax_thickness = float(suggestion["wall_thickness_mm"])
                    applied.append("Wall thickness")
                except Exception:
                    skipped.append("Wall thickness")
            else:
                skipped.append("Wall thickness")

        if "paralink_mode" in suggestion:
            mapped = self._PARALINK_MODE_MAP.get(str(suggestion["paralink_mode"]).lower())
            if mapped and hasattr(scene, "dynax_paralink_mode"):
                try:
                    scene.dynax_paralink_mode = mapped
                    applied.append(f"ParaLink mode ({mapped.title()})")
                except Exception:
                    skipped.append("ParaLink mode")
            else:
                skipped.append("ParaLink mode")

        msg = f"Applied: {', '.join(applied) if applied else 'nothing'}."
        if skipped:
            msg += f" Skipped (not available): {', '.join(skipped)}."
        self.report({'INFO'}, msg)

        try:
            get_recorder().log_ai(applied=True)
        except Exception:
            pass

        return {'FINISHED'}


class DYNAX_OT_ai_clear(Operator):
    """Clear the AI Assistant panel back to its empty state."""
    bl_idname = "dynax.ai_clear"
    bl_label = "Clear"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        scene.dynax_ai_input = ""
        scene.dynax_ai_suggestion = ""
        scene.dynax_ai_response = ""
        scene.dynax_ai_offline = False
        reset_session()
        reset_task_state()
        scene.dynax_ai_history_text = ""
        # Explicit clear (not just the signature-diff rebuild in
        # _sync_conversation_lines) - a 0-turn session's signature could
        # coincidentally match a still-cached 0-turn signature from before,
        # and this operator's whole point is guaranteeing an empty list.
        scene.dynax_ai_conversation_lines.clear()
        global _conversation_lines_signature
        _conversation_lines_signature = None
        return {'FINISHED'}


class DYNAX_OT_ai_confirm_action(Operator):
    """Execute a Phase 3 write tool staged by dispatcher.stage_action()."""
    bl_idname = "dynax.ai_confirm_action"
    bl_label = "Confirm"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from ..ai.dispatcher import confirm_action
        result = confirm_action(context)
        try:
            get_session().add_turn(
                "assistant", f"Done: {result.summary or result.error}",
                tool_used=result.tool_name, tool_result=result.data,
            )
            context.scene.dynax_ai_history_text = get_session().get_history_text()
            _sync_conversation_lines(context.scene, get_session())
        except Exception:
            pass
        if not result.success:
            self.report({'ERROR'}, result.error or "Action failed.")
        return {'FINISHED'}


class DYNAX_OT_ai_cancel_action(Operator):
    """Cancel a Phase 3 write tool staged by dispatcher.stage_action()."""
    bl_idname = "dynax.ai_cancel_action"
    bl_label = "Cancel"
    bl_options = {'REGISTER'}

    def execute(self, context):
        from ..ai.dispatcher import cancel_action
        cancel_action()
        try:
            get_session().add_turn("assistant", "Action cancelled.")
            context.scene.dynax_ai_history_text = get_session().get_history_text()
            _sync_conversation_lines(context.scene, get_session())
        except Exception:
            pass
        return {'FINISHED'}


class DYNAX_OT_ai_feedback(Operator):
    """Thumbs up/down on the most recent assistant turn. Fire-and-forget:
    get_recorder().set_ai_feedback() is already a no-op when analytics is
    off and never raises, so there is nothing else to guard here."""
    bl_idname = "dynax.ai_feedback"
    bl_label = "AI Feedback"
    bl_options = {'REGISTER'}

    feedback: bpy.props.StringProperty()

    def execute(self, context):
        scene = context.scene
        session = get_session()
        turn_idx = session.turn_count() - 1

        scene.dynax_ai_last_feedback = self.feedback
        scene.dynax_ai_feedback_turn = turn_idx

        try:
            get_recorder().set_ai_feedback(turn_idx, self.feedback)
        except Exception:
            pass

        try:
            emoji = "👍" if self.feedback == "positive" else "👎"
            session.add_turn("user", f"[Feedback: {emoji}]")
            scene.dynax_ai_history_text = session.get_history_text()
            _sync_conversation_lines(scene, session)
        except Exception:
            pass

        return {'FINISHED'}


class DYNAX_OT_ai_submit_expectation(Operator):
    """Follow-up free-text capture after negative feedback - "What were you
    expecting?". See utils/session_recorder.py's module-level flag: this
    stores the clinician's own words as a failed intent, a deliberate,
    flagged exception to the closed-vocabulary rule everywhere else."""
    bl_idname = "dynax.ai_submit_expectation"
    bl_label = "Submit Expectation"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        expectation = (getattr(scene, "dynax_ai_expectation", "") or "").strip()
        if not expectation:
            return {'CANCELLED'}

        try:
            get_recorder().log_failed_intent(
                user_input=expectation,
                reason="User reported unmet expectation",
                closest_tool="",
            )
        except Exception:
            pass

        try:
            get_session().add_turn("user", f"[Expected: {expectation}]")
            scene.dynax_ai_history_text = get_session().get_history_text()
            _sync_conversation_lines(scene, get_session())
        except Exception:
            pass

        scene.dynax_ai_expectation = ""
        scene.dynax_ai_last_feedback = ""
        return {'FINISHED'}


class DYNAX_OT_show_context(Operator):
    """Show what DynaX AI can currently see in the scene - the exact
    DynaXContext text block (ai.context.context_to_prompt_text) that would
    be sent as the auto-built question / attached to a real query. Purely
    read-only, same as ai.context itself - collects and displays, changes
    nothing."""
    bl_idname = "dynax.show_ai_context"
    bl_label = "Show Scene Context"
    bl_description = "Show what DynaX AI can currently see in the scene"
    bl_options = {'REGISTER'}

    _lines: list = []

    def invoke(self, context, event):
        try:
            ctx = collect_context(context)
            text = context_to_prompt_text(ctx)
        except Exception:
            ctx = None
            text = "=== DynaX Scene Context ===\n(unavailable)\n==========================="

        try:
            if ctx is not None:
                ctx_dict = context_to_dict(ctx)
                tools = list_tools(context_dict=ctx_dict)
                # AI Agent Core: scope to the active capability module's own
                # tool set when one is detected, rather than showing every
                # registered tool from every workflow at once. A tool with
                # no owning module still shows (module=None -> no filter).
                module = detect_active_module(ctx_dict.get("dynax") or {})
                if module is not None and module.tool_names:
                    tools = [t for t in tools if t["name"] in module.tool_names]
                    text += f"\n\nModule: {module.label}"
                if tools:
                    text += "\n\nAvailable actions:\n" + "\n".join(
                        f"• {t['name']}: {t['description']}" for t in tools)
        except Exception:
            pass

        self._lines = text.split("\n")
        return context.window_manager.invoke_popup(self, width=340)

    def draw(self, context):
        col = self.layout.column(align=True)
        for line in self._lines:
            col.label(text=line if line else " ")

    def execute(self, context):
        return {'FINISHED'}


class DYNAX_OT_ai_quick_tool(Operator):
    """Run one read-only Phase 2 tool directly, no typed question needed.
    Same display path as an AI suggestion (writes dynax_ai_suggestion),
    always offline-labelled since this never touches the network."""
    bl_idname = "dynax.ai_quick_tool"
    bl_label = "Quick Tool"
    bl_options = {'REGISTER'}

    tool_name: bpy.props.StringProperty()

    def execute(self, context):
        result = dispatch(self.tool_name, {}, context)
        try:
            context.scene.dynax_ai_suggestion = json.dumps({
                "tool_result": {
                    "summary": result.summary,
                    "data": result.data,
                    "success": result.success,
                },
                "clinical_notes": result.summary or result.error,
            })
            context.scene.dynax_ai_offline = True
        except Exception:
            pass
        return {'FINISHED'}


class DYNAX_OT_ai_quick_prompt(Operator):
    """Fill the input with a suggested/contextual question and ask it
    immediately - backs the empty-state quick-start buttons, the
    contextual quick_actions shown under a guidance response, and the
    "this session" recent-questions list below the input."""
    bl_idname = "dynax.ai_quick_prompt"
    bl_label = "Quick Prompt"
    bl_options = {'REGISTER'}

    query_text: bpy.props.StringProperty()

    def execute(self, context):
        context.scene.dynax_ai_input = self.query_text
        try:
            bpy.ops.dynax.ai_query()
        except Exception:
            pass
        return {'FINISHED'}


class DYNAX_OT_ai_open_import(Operator):
    """Open the real Import STL file picker (dynax.import_stl invoked with
    INVOKE_DEFAULT shows Blender's native file browser - this does not
    silently import anything; the clinician still picks the file). Backs
    the task-state engine's "Open Import" quick action for the import_scan
    task - see ai/task_state.py."""
    bl_idname = "dynax.ai_open_import"
    bl_label = "Open Import"
    bl_options = {'REGISTER'}

    def execute(self, context):
        try:
            bpy.ops.dynax.import_stl('INVOKE_DEFAULT')
        except Exception as e:
            self.report({'ERROR'}, f"Could not open import: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}


class DYNAX_OT_ai_switch_environment(Operator):
    """Jump straight into the DynaX environment recommended for a device
    (AI platform-selection quick action, ai.environments.recommend_
    environment) - sets the same scene properties dynax.set_mode /
    paraforge.set_device_type do, skipping the New Case / ParaForge-menu
    intermediate screens since the user already told the AI exactly which
    workflow they want."""
    bl_idname = "dynax.ai_switch_environment"
    bl_label = "Open Environment"
    bl_options = {'REGISTER'}

    module_id: bpy.props.StringProperty()

    def execute(self, context):
        from ..ai.environments import switch_to_environment
        if not switch_to_environment(context.scene, self.module_id):
            self.report({'ERROR'}, f"Unknown environment: {self.module_id}")
            return {'CANCELLED'}
        return {'FINISHED'}


# ── Panel ────────────────────────────────────────────────────────────────
# Single-popover redesign: DynaX AI is now ONE surface, not three. Earlier
# this session added both a real second OS window (screen.area_dupli) and
# a same-window popover as separate options alongside an inline accordion
# sub-panel - explicit user feedback was that the popover alone is "the
# perfect one" and asked for the window and the inline accordion ("the
# dropdown") to be removed, leaving the popover as the only DynaX AI view.
#
# So there are now exactly two DynaX AI panel classes:
#   DYNAX_PT_ai_section  - the actual content (this class). bl_region_type
#       is 'WINDOW', not 'UI', and it has no bl_category/bl_parent_id - it
#       is NOT a sidebar tab/sub-panel at all anymore, only reachable via
#       layout.popover(panel="DYNAX_PT_ai_section"), Blender's own native
#       floating-panel mechanism (same one behind the color/material
#       popovers). It floats over the viewport in the SAME window, closing
#       the instant the user clicks elsewhere - a genuine Blender/OS UI
#       constraint, not a corner cut here: there is no floating-overlay
#       surface available to an add-on that stays open regardless of
#       clicks, and none that can be dragged to a new position either
#       (only a real second OS window can be dragged, and that option was
#       just explicitly removed in favour of this one).
#   DYNAX_PT_ai_launcher  - the actual sidebar entry (defined further
#       below), a single-row HIDE_HEADER panel with no collapsible content
#       of its own - just the DynaX AI icon and a popover-trigger button.
#       Clicking it is the only interaction; there is nothing to expand.

class DYNAX_PT_ai_section(Panel):
    bl_label = "DynaX AI"
    bl_idname = "DYNAX_PT_ai_section"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 24

    def draw(self, context):
        # UI/conversation redesign. Blender constraints, stated plainly
        # rather than silently worked around: an N-panel sub-panel cannot
        # be forced wider than the sidebar the user has dragged, and
        # cannot render colored chat bubbles (box() has no per-instance
        # colour from Python without a full UI theme change) - word-wrapped
        # text rows stand in for bubbles. The DynaX AI robot avatar
        # (utils/branding.get_ai_avatar_icon_id()) is real, not a
        # placeholder, and is used in the header and next to every
        # assistant turn.
        #
        # Layout order: header -> chat input -> conversation (below the
        # input, per explicit instruction) -> secondary tools -> this-
        # session recent questions.
        layout = self.layout
        scene = context.scene

        # v1.23.1: mode toggle between the existing chat UI and the Spatial
        # Agent (landmark-based transtibial socket design), so the latter
        # lives inside this already-reachable popover instead of a separate
        # standalone N-panel entry that clinicians had no obvious way to find.
        row = layout.row(align=True)
        row.prop_enum(scene, "dynax_ai_mode", "CHAT")
        row.prop_enum(scene, "dynax_ai_mode", "SPATIAL")
        layout.separator(factor=0.3)

        if getattr(scene, "dynax_ai_mode", "CHAT") == "SPATIAL":
            self._draw_spatial_agent(context, layout, scene)
            return

        # Mini-workspace redesign: the header/context-strip need to know
        # which environment (Creator/ParaForm/ParaFly-AFO/TT/TLSO) and
        # device are active right now - the same DynaXState the query path
        # already collects, computed once per redraw and threaded through
        # rather than re-collected per section. Cheap and read-only
        # (collect_context never writes scene state); falls back to an
        # empty dict on any failure so a bad context read degrades the
        # header, not the whole panel.
        ctx_dict = {}
        try:
            ctx_dict = context_to_dict(collect_context(context))
        except Exception:
            ctx_dict = {}
        module = None
        try:
            module = detect_active_module(ctx_dict.get("dynax") or {})
        except Exception:
            module = None

        self._draw_header(context, layout, module)
        self._draw_context_strip(context, layout, ctx_dict, module)

        session = None
        try:
            session = get_session()
        except Exception:
            pass

        self._draw_pending_confirmation(layout)
        self._draw_input(context, layout, scene)

        if session is None or session.turn_count() == 0:
            self._draw_empty_state(layout)
        else:
            self._draw_conversation(context, layout, session)

        self._draw_secondary_tools(layout)
        self._draw_recent_session_questions(layout, session)

    # ── Spatial Agent (v1.23.1): landmark-based transtibial socket design,
    # moved here from the removed standalone DYNAX_PT_spatial_agent panel so
    # it lives inside the one DynaX AI entry point clinicians already know.
    # v1.23.5: zone marking switched from grease-pencil strokes (fragile
    # across GP versions/materials/frames) to this add-on's own proven
    # mesh face-selection system — the same Box/Lasso/Circle tools already
    # used by Sculpt & Modify and Manual Bridge. ────────────────────────────
    def _draw_spatial_agent(self, context, layout, scene):
        layout.label(text="Transtibial Socket", icon='ARMATURE_DATA')
        layout.prop(scene, "dynax_spatial_concept", expand=True)

        # Patient Constraints — v3.2.0's "ASK FIRST" agent_rule: both
        # answers must be set before Apply Landmark Rules will run (see
        # DYNAX_OT_apply_landmark_rules.execute's blocking check) and they
        # scale every zone's target_mm via patient_covariates (see
        # displacement_engine.apply_all_zones). Always-visible section, not
        # a modal dialog — a clinician revisiting the case later can change
        # either answer and re-run Apply Rules to get a re-scaled result.
        layout.separator()
        cbox = layout.box()
        cbox.label(text="Patient Constraints", icon='USER')
        cbox.label(text="Stump type:")
        cbox.row(align=True).prop(scene, "dynax_stump_type", expand=True)
        cbox.label(text="Prominence depth:")
        cbox.row(align=True).prop(scene, "dynax_prominence_depth", expand=True)
        if scene.dynax_stump_type == "BONY":
            cbox.label(text="Bony limb — less force, more buildup applied", icon='INFO')
        elif scene.dynax_stump_type == "FLESHY":
            cbox.label(text="Fleshy limb — more force, less buildup applied", icon='INFO')
        if scene.dynax_stump_type == "NONE" or scene.dynax_prominence_depth == "NONE":
            cbox.label(text="Set both before applying rules", icon='ERROR')

        layout.separator()
        box = layout.box()
        box.label(text="Landmark Zones", icon='MESH_DATA')

        box.label(text="Required:")
        req_row = box.row(align=True)
        for zone_id in REQUIRED_LANDMARKS:
            req_row.prop_enum(scene, "dynax_spatial_landmark_id", zone_id)

        box.label(text="Recommended:")
        rec_row = box.row(align=True)
        for zone_id in RECOMMENDED_ZONE_IDS:
            rec_row.prop_enum(scene, "dynax_spatial_landmark_id", zone_id)

        adv_icon = 'TRIA_DOWN' if scene.dynax_spatial_show_advanced else 'TRIA_RIGHT'
        box.prop(scene, "dynax_spatial_show_advanced", icon=adv_icon,
                 text="Optional / all landmarks", emboss=False)
        if scene.dynax_spatial_show_advanced:
            opt_row = box.row(align=True)
            for zone_id in OPTIONAL_ZONE_IDS:
                opt_row.prop_enum(scene, "dynax_spatial_landmark_id", zone_id)
            box.prop(scene, "dynax_spatial_landmark_id", text="")

        # Category + clinical description (v3.2.0's per-landmark
        # `description` field — plain-language anatomy + why it matters,
        # shown to the clinician BEFORE they paint the zone) for whichever
        # zone is currently selected. The confirmed zone's own color, baked
        # by apply_zone_vertex_color, is what marks it afterward. There is
        # no separate signed push/pull direction to show here — see
        # displacement_engine.py's apply_all_zones docstring for why.
        meta = get_zone_meta(scene.dynax_spatial_landmark_id)
        icon = 'ERROR' if meta.get("category") == "Pressure Sensitive" else 'CHECKMARK'
        desc_box = box.box()
        desc_box.label(text=f"{meta.get('category', 'General')}", icon=icon)
        col = desc_box.column(align=True)
        col.scale_y = 0.85
        desc_lines = textwrap.wrap(meta.get("description", ""), width=48) or [""]
        for i, line in enumerate(desc_lines):
            col.label(text=line, icon='INFO' if i == 0 else 'BLANK1')

        box.operator("dynax.landmark_start_zone", text="Start Zone Selection", icon='EDITMODE_HLT')

        selrow = box.row(align=True)
        selrow.operator("dynax.select_box",    text="Box",    icon='MESH_PLANE')
        selrow.operator("dynax.select_lasso",  text="Lasso",  icon='GREASEPENCIL')
        selrow.operator("dynax.select_circle", text="Circle", icon='BRUSH_DATA')

        box.operator("dynax.landmark_confirm_zone", text="Confirm Zone", icon='CHECKMARK')

        zones = get_stored_zones(scene)
        if zones:
            box.label(text="Placed zones:")
            col = box.column(align=True)
            for zone in zones:
                row = col.row(align=True)
                row.label(text=f"• {zone.landmark_name}", icon='LAYER_ACTIVE')
                # Selects this landmark in the dropdown, then reuses Start
                # Zone Selection's own pre-select-existing-vertices logic —
                # editing an already-placed zone means picking it here and
                # clicking Start Zone Selection above, not a separate flow.
                pick = row.operator("wm.context_set_string", text="", icon='EYEDROPPER')
                pick.data_path = "scene.dynax_spatial_landmark_id"
                pick.value = zone.landmark_id
                del_op = row.operator("dynax.landmark_delete_zone", text="", icon='X')
                del_op.landmark_id = zone.landmark_id

        box.operator("dynax.landmark_clear_all", icon='TRASH')

        layout.separator()
        layout.operator("dynax.apply_landmark_rules", text="Apply Landmark Rules",
                         icon='MOD_DISPLACE')

        if scene.dynax_spatial_rules_applied:
            layout.separator()
            layout.operator("dynax.toggle_spatial_compare",
                             text="Compare to Pre-Adjustment", icon='MOD_WIREFRAME')

            layout.separator()
            box = layout.box()
            box.label(text="Adjust Zones", icon='MODIFIER')

            zones = get_stored_zones(scene)
            # Self-heal: the dynax_zone_adjust_<id> sliders are registered by
            # a deferred bpy.app.timers callback (see __init__.py), not
            # synchronously at addon-enable — a real bug found here: if that
            # timer hadn't fired yet (or the JSON changed and added new
            # zones after the timer already ran once this session), every
            # zone's row below was silently `continue`d with NO feedback,
            # so this whole box rendered with just its title and nothing
            # else — exactly "I can't see the sliders". Registering here is
            # cheap (plain JSON read, no restricted bpy.data call) and
            # idempotent, so it's safe to call from draw().
            if zones and not hasattr(scene, f"dynax_zone_adjust_{zones[0].landmark_id.lower()}"):
                from ..spatial_agent.displacement_engine import register_zone_adjust_properties
                register_zone_adjust_properties()

            obj = get_target_mesh(context)
            for zone in zones:
                prop_name = f"dynax_zone_adjust_{zone.landmark_id.lower()}"
                if not hasattr(scene, prop_name):
                    box.label(text=f"{zone.landmark_name}: slider not ready — reopen this panel", icon='ERROR')
                    continue
                meta = get_zone_meta(zone.landmark_id)
                icon = 'ERROR' if meta.get("category") == "Pressure Sensitive" else 'CHECKMARK'

                zbox = box.box()
                row = zbox.row()
                row.label(text=zone.landmark_name, icon=icon)

                # Clinical range comes from the ruleset's own min_mm/max_mm
                # span for this zone (this add-on's mm-space convention),
                # shown small below the name — NOT the slider's own ±10mm
                # bound, which is a fine-tune DELTA on top of the ruleset's
                # (patient-covariate-scaled) target, not the zone's absolute
                # displacement. Labeling the field "Adjust (mm)" rather than
                # "Target" keeps that distinction visible.
                sub = zbox.row()
                sub.scale_y = 0.6
                sub.label(text=f"Clinical range: {meta['minimum']:.1f} to {meta['maximum']:.1f}mm")

                # slider=False -> a numeric input field (click-to-type or
                # arrow-nudge) instead of a drag bar, so a clinician can
                # enter an exact mm value.
                zbox.prop(scene, prop_name, text="Adjust (mm)", slider=False)

                if obj is not None:
                    measured = zone_current_offset_mm(obj, zone)
                    zbox.label(text=f"Currently measured: {measured:.1f}mm from pre-adjustment")

            box.operator("dynax.reset_zone_adjustments", text="Reset All Zones",
                         icon='LOOP_BACK')

        layout.separator()
        box = layout.box()
        box.label(text="Trimline")
        box.label(text="(placeholder — v1.24)")

        layout.separator()
        box = layout.box()
        box.label(text="Export")
        box.label(text="(placeholder — v1.24)")

    # ── Header: identity + online/offline/thinking status ───────────────
    def _draw_header(self, context, layout, module=None):
        header = layout.box()
        row = header.row(align=True)
        try:
            from ..utils.branding import get_ai_avatar_icon_id
            avatar_id = get_ai_avatar_icon_id()
        except Exception:
            avatar_id = 0
        if avatar_id:
            row.template_icon(icon_value=avatar_id, scale=2.2)
        else:
            row.label(text="", icon='SHADERFX')
        title_col = row.column(align=True)
        title_col.label(text="DynaX AI")
        sub = title_col.row()
        sub.scale_y = 0.7
        # Mini-workspace: the subtitle names the active environment once
        # one is detected, instead of always reading the same static
        # tagline - the whole point of this redesign is that the header
        # always shows the clinician which workspace they're talking to.
        sub.label(text=(module.label if module else "CAD & clinical design assistant"))

        busy = bool(getattr(context.scene, "dynax_ai_busy", False))
        online_mode = bool(getattr(context.scene, "dynax_ai_online_mode", False))
        status_row = row.row()
        status_row.alignment = 'RIGHT'
        if busy:
            status_row.label(text="Thinking...", icon='SORTTIME')
        elif online_mode:
            status_row.label(text="Online", icon='WORLD')
        else:
            status_row.label(text="Offline", icon='INTERNET_OFFLINE')

        header.prop(context.scene, "dynax_ai_online_mode",
                    text="Use online AI (ai.dynax.app)", toggle=True)

    # ── Context strip: Environment / Device / Task / Scan at a glance ────
    # Mini-workspace redesign - the AI section reads as its own small
    # workspace, not just a chat box: this strip is always visible (not
    # hidden behind a "what can you see" query) and mirrors exactly what
    # ai.context.DynaXState / ai.modules.detect_active_module already
    # compute for every query, so it can never disagree with an answer the
    # AI gives about the same state.
    def _draw_context_strip(self, context, layout, ctx_dict, module):
        dynax = ctx_dict.get("dynax") or {}
        mesh = ctx_dict.get("mesh")
        device_type = dynax.get("device_type")

        strip = layout.box()
        strip.scale_y = 0.85

        row = strip.row(align=True)
        row.label(text="Environment:", icon='WORKSPACE')
        row.label(text=module.label if module else "None selected")

        if device_type and device_type not in ("NONE", "UNKNOWN"):
            row = strip.row(align=True)
            row.label(text="Device:", icon='MOD_ARMATURE')
            row.label(text=device_type)

        row = strip.row(align=True)
        row.label(text="Scan:", icon='MESH_DATA')
        row.label(text=(mesh.get("name") if mesh else "None loaded"))

        try:
            task_state = get_task_state()
            if task_state.is_active():
                row = strip.row(align=True)
                row.label(text="Task:", icon='CHECKMARK')
                device = task_state.slots.get("device", task_state.task_name)
                row.label(text=str(device))
        except Exception:
            pass

    # ── Empty state: quick-start suggestions ─────────────────────────────
    def _draw_empty_state(self, layout):
        try:
            from ..utils.branding import get_ai_avatar_icon_id
            avatar_id = get_ai_avatar_icon_id()
        except Exception:
            avatar_id = 0

        box = layout.box()
        head = box.row(align=True)
        if avatar_id:
            head.template_icon(icon_value=avatar_id, scale=1.0)
        else:
            head.label(text="", icon='SHADERFX')
        head.label(text="What would you like to do?")
        col = box.column(align=True)
        for action in DEFAULT_QUICK_ACTIONS:
            op = col.operator("dynax.ai_quick_prompt", text=action["label"])
            op.query_text = action["query"]

    # ── Active conversation ───────────────────────────────────────────────
    # Scroll fix: everything else in this popover (header, context strip,
    # composer, quick actions, secondary tools, recent-questions list) is a
    # plain column - Blender has no per-widget scroll region in the
    # UILayout API, so a plain column can only ever grow, never scroll on
    # its own (that's why the whole popover was overflowing off-screen).
    # `template_list` is the one real bounded/scrollable widget Blender
    # gives an add-on - it renders a fixed number of rows (`rows=`) with
    # its own scrollbar, independent of the layout around it. Reusing it
    # here means the conversation - and ONLY the conversation - scrolls;
    # everything else stays a normal fixed-height column, exactly as
    # asked. It requires the content to live in a real CollectionProperty
    # (Scene.dynax_ai_conversation_lines, one item per WRAPPED DISPLAY
    # LINE, not per turn, since a template_list row is a single line) -
    # _sync_conversation_lines() keeps that collection in sync with the
    # real ai.conversation session data.
    def _draw_conversation(self, context, layout, session):
        conv_box = layout.box()
        head = conv_box.row(align=True)
        try:
            from ..utils.branding import get_ai_avatar_icon_id
            avatar_id = get_ai_avatar_icon_id()
        except Exception:
            avatar_id = 0
        if avatar_id:
            head.template_icon(icon_value=avatar_id, scale=1.0)
        else:
            head.label(text="", icon='SHADERFX')
        head.label(text="Conversation")

        # Real bug found via console diagnostics: this used to call
        # _sync_conversation_lines() right here, inside Panel.draw() -
        # Blender raises "Writing to ID classes in this context is not
        # allowed" for ANY scene data mutation (including
        # CollectionProperty.clear()/.add()) attempted from draw(), which
        # is a read-only callback. The old bare `except Exception: pass`
        # silently swallowed that AttributeError on every single redraw,
        # so dynax_ai_conversation_lines was NEVER populated, ever - this
        # was the actual cause of "the conversation tab never shows a
        # response" (not the popover, not mouse movement - those were
        # coincidental). Fixed by moving every _sync_conversation_lines()
        # call to operator/timer contexts (see _poll_ai_result and each
        # DYNAX_OT_ai_* operator below), where scene writes are legal;
        # draw() now only READS the already-populated collection.
        conv_box.template_list(
            "DYNAX_UL_ai_conversation", "", context.scene,
            "dynax_ai_conversation_lines", context.scene,
            "dynax_ai_conversation_lines_index", rows=16,
        )
        conv_box.operator("dynax.ai_clear", text="Clear conversation", icon='TRASH')

        # Contextual quick actions from the most recent assistant response
        # (guidance/how-to suggestions, or a real tool_call's follow-up).
        try:
            raw = getattr(context.scene, "dynax_ai_suggestion", "") or ""
            data = json.loads(raw) if raw else {}
        except Exception:
            data = {}
        quick_actions = data.get("quick_actions") if isinstance(data, dict) else None
        if quick_actions:
            qa_row = conv_box.column(align=True)
            for action in quick_actions[:4]:
                if action.get("env"):
                    op = qa_row.operator("dynax.ai_switch_environment", text=action.get("label", "..."))
                    op.module_id = action["env"]
                elif action.get("tool_op"):
                    qa_row.operator(action["tool_op"], text=action.get("label", "..."))
                elif action.get("tool"):
                    op = qa_row.operator("dynax.ai_quick_tool", text=action.get("label", "..."))
                    op.tool_name = action["tool"]
                else:
                    op = qa_row.operator("dynax.ai_quick_prompt", text=action.get("label", "..."))
                    op.query_text = action.get("query", "")

        self._draw_feedback_row(context, layout, session)
        self._draw_tool_result(context, layout, data)

    def _draw_feedback_row(self, context, layout, session):
        # Phase 4: thumbs up/down on the most recent assistant turn only.
        # Analytics-gated and hidden once feedback has already been given
        # for this turn - never shown more than once, never interrupts.
        scene = context.scene
        try:
            prefs = context.preferences.addons.get('dynax_addon')
            analytics_on = bool(prefs and prefs.preferences.analytics_enabled)
        except Exception:
            analytics_on = False

        last_feedback = getattr(scene, "dynax_ai_last_feedback", "")
        feedback_turn = getattr(scene, "dynax_ai_feedback_turn", -1)
        try:
            current_turn = session.turn_count() - 1
        except Exception:
            current_turn = -1

        if analytics_on and current_turn >= 0 and feedback_turn != current_turn:
            row = layout.row(align=True)
            row.scale_x = 0.6
            op = row.operator("dynax.ai_feedback", text="👍", icon='FUND')
            op.feedback = "positive"
            op = row.operator("dynax.ai_feedback", text="👎", icon='CANCEL')
            op.feedback = "negative"

        if last_feedback == "negative" and feedback_turn == current_turn:
            box = layout.box()
            box.label(text="What were you expecting?")
            box.prop(scene, "dynax_ai_expectation", text="")
            box.operator("dynax.ai_submit_expectation", text="Submit", icon='EXPORT')

    def _draw_tool_result(self, context, layout, data):
        if isinstance(data, dict) and data.get("tool_result"):
            tr = data["tool_result"]
            tbox = layout.box()
            icon = 'CHECKMARK' if tr.get("success") else 'ERROR'
            tbox.label(text=tr.get("summary") or "", icon=icon)

    def _draw_pending_confirmation(self, layout):
        if has_pending_action():
            cbox = layout.box()
            cbox.alert = True
            cbox.label(text="Confirm action?", icon='QUESTION')
            row = cbox.row(align=True)
            row.operator("dynax.ai_confirm_action", text="Yes, do it", icon='CHECKMARK')
            row.operator("dynax.ai_cancel_action", text="Cancel", icon='X')

    # ── Input: the primary interaction ───────────────────────────────────
    # Mini-workspace composer. Blender constraint, stated plainly rather
    # than silently worked around (see the draw() docstring above): a
    # Scene StringProperty has no true multi-line editing widget in the
    # UILayout API - there is no way to give it real line wrapping/Enter-
    # for-newline inside an N-panel. What this CAN do, and does, is read as
    # a deliberately larger composer rather than a cramped one-line search
    # box: a taller field (scale_y) with a longer placeholder, its own row
    # so Send/Clear don't crowd it, and platform-selection questions
    # explicitly hinted at in the placeholder now that they're a real,
    # answered category (see ai.intent.SELECT_DYNAX_ENVIRONMENT).
    def _draw_input(self, context, layout, scene):
        layout.separator(factor=0.3)
        col = layout.column(align=True)
        field = col.row(align=True)
        field.scale_y = 1.7
        field.prop(scene, "dynax_ai_input", text="",
                   icon='OUTLINER_OB_FONT',
                   placeholder="Ask DynaX anything - a device, a measurement, "
                               "or which platform to use...")
        btn_row = col.row(align=True)
        send = btn_row.row(align=True)
        send.enabled = not getattr(scene, "dynax_ai_busy", False)
        send.operator("dynax.ai_query", text="Send", icon='PLAY')
        btn_row.operator("dynax.ai_clear", text="", icon='X')

    # ── Secondary actions (Phase 2 tool registry) - no longer the primary
    # interaction; natural language is. ───────────────────────────────────
    def _draw_secondary_tools(self, layout):
        box = layout.box()
        row = box.row(align=True)
        row.scale_y = 0.9
        row.operator("dynax.ai_quick_tool", text="Inspect",
                     icon='ZOOM_ALL').tool_name = "inspect_mesh"
        row.operator("dynax.ai_quick_tool", text="Measure",
                     icon='DRIVER_DISTANCE').tool_name = "get_dimensions"
        row.operator("dynax.ai_quick_tool", text="Status",
                     icon='INFO').tool_name = "get_dynax_state"
        row2 = box.row()
        row2.scale_y = 0.8
        row2.operator("dynax.show_ai_context", text="What can AI see?", icon='HIDE_OFF')

    # ── Chat history, BELOW the active conversation/input, per the redesign
    # brief. Session-only (no cross-restart persistence exists in this
    # add-on - not fabricated here either): the distinct questions asked
    # THIS Blender session, most recent first. Clicking re-asks it fresh
    # rather than restoring branched conversation state, which the current
    # single-session architecture doesn't model. ─────────────────────────
    def _draw_recent_session_questions(self, layout, session):
        if session is None:
            return
        try:
            seen = []
            for turn in reversed(session.get_turns()):
                if turn.role != "user":
                    continue
                text = turn.text.strip()
                if not text or text.startswith("[") or text in seen:
                    continue
                seen.append(text)
                if len(seen) >= 5:
                    break
        except Exception:
            seen = []

        if not seen:
            return

        layout.separator(factor=0.3)
        box = layout.box()
        box.label(text="This session", icon='RECOVER_LAST')
        col = box.column(align=True)
        col.scale_y = 0.85
        for text in seen:
            short = text if len(text) <= 40 else text[:37] + "..."
            op = col.operator("dynax.ai_quick_prompt", text=short, emboss=False)
            op.query_text = text


# ── Launcher: the actual sidebar entry ───────────────────────────────────
# The only thing shown in the DynaX sidebar for AI. No collapsible content,
# no accordion, nothing to expand - a single icon + button row that pops
# DYNAX_PT_ai_section open (see that class's own comment above for exactly
# what Blender's popover mechanism does and doesn't support). bl_options
# HIDE_HEADER means Blender draws no title bar or collapse-triangle for
# this panel at all - it renders as one plain row directly inside
# DYNAX_PT_tools's own body, on every screen DYNAX_PT_tools draws on
# (including the Start Menu, since child panels render regardless of the
# parent's own draw() branching - see dynax_panel.py).
class DYNAX_PT_ai_launcher(Panel):
    bl_label = "DynaX AI"
    bl_idname = "DYNAX_PT_ai_launcher"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'DynaX'
    bl_parent_id = 'DYNAX_PT_tools'
    bl_options = {'HIDE_HEADER'}

    def draw(self, context):
        row = self.layout.row(align=True)
        try:
            from ..utils.branding import get_ai_avatar_icon_id
            avatar_id = get_ai_avatar_icon_id()
        except Exception:
            avatar_id = 0
        if avatar_id:
            row.template_icon(icon_value=avatar_id, scale=1.4)
        else:
            row.label(text="", icon='SHADERFX')
        row.popover(panel="DYNAX_PT_ai_section", text="DynaX AI", icon='NONE')
