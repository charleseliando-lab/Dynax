# panels/parafly_tlso_panel.py - ParaFly TLSO workflow panel
# (SPEC_parafly_tlso_complete.md).
#
# Drawn from paraforge_panel.py's draw_paraforge_zones_panel() when
# scene.parafly_device_type == 'TLSO' - a plain module of draw functions, same
# "no second bpy.types.Panel" pattern as the rest of ParaFly/ParaForm/Creator
# (see paraforge_panel.py's module docstring). The reference spec assumed
# separate Panel classes gated by a poll() checking scene.dynax_active_workflow
# - that property doesn't exist in this addon (see the ParaFly menu-restructure
# conversation for why: the actual nav model is props.dynax_mode, and ParaFly's
# device split is a scene.parafly_device_type sub-state within
# dynax_mode == 'PARAFORGE_ZONES', not a separate top-level workflow value).

import bpy

from ..paraforge.tlso_zone_reader import get_tlso_zone_names, find_tlso_vertex_group
from ..paraforge.tlso_zone_definitions import get_tlso_zone_meta
from ..paraforge.image_loader import draw_zone_image
from ..preferences import get_dev_mode
from .paraforge_panel import _wrap, _draw_advanced, _draw_export, _draw_smooth_standalone
from .ui_helpers import (
    draw_completion_status,
    draw_stage_instructions,
    draw_stage_progress,
    draw_warning,
    draw_workflow_header,
)


TLSO_STAGES = ["Input", "Alignment", "Mapping", "Adjustment", "Finish"]
TLSO_STAGE_INDEX = {
    'INPUT': 0,
    'ALIGNMENT': 1,
    'MAPPING': 2,
    'ADJUSTMENT': 3,
    'ADVANCED': 4,
}

# SPEC_tlso_zone_update_7zones.md removed the 3 Trim Line zones (and the
# 2 remaining "_right"-suffixed single-side zones) entirely, leaving only
# Pressure Zone and Relief Zone categories (4 + 3 = 7 total) - "Trim Line"
# dropped from both CATEGORY_ORDER and CATEGORY_LABELS since no zone can
# produce that category anymore.
CATEGORY_ORDER = ["Pressure Zone", "Relief Zone"]
CATEGORY_LABELS = {
    "Pressure Zone": "PRESSURE ZONES",
    "Relief Zone": "RELIEF ZONES",
    "General": "OTHER ZONES",
}


def _draw_input(context, layout):
    # SPEC_tlso_image_spacing_and_import_hide.md Fix 2: hide the Import
    # button once a scan is already loaded, showing the object name + a
    # small refresh icon instead. Adapted to this codebase's real names -
    # the spec assumed scene.parafly_active_object and a TLSO-specific
    # "paraforge.tlso_import_scan"/"parafly.load_project" operator pair;
    # the actual property is scene.paraforge_active_object (see
    # import_scan.py, tlso_mapping_wizard.py etc. - this project's own
    # already-established real name), and paraforge.import_scan /
    # paraforge.load_project are the real, already-shared-by-TT-and-TLSO
    # operator ids (import_scan.py's PARAFORGE_OT_import_scan is
    # device-aware internally via scene.parafly_device_type, not a
    # separate TLSO-only operator).
    scene = context.scene
    box = layout.box()
    box.label(text="Input", icon='IMPORT')

    if scene.paraforge_active_object is None:
        box.operator("paraforge.import_scan", text="Import Torso Scan", icon='IMPORT')
        box.operator("paraforge.load_project", text="Load Saved Project", icon='FILE_FOLDER')
    else:
        # SPEC_parafly_unlock_advanced_export.md "Also Fix": labeled "New
        # Scan" (was an icon-only refresh button) so it reads the same as
        # paraforge_panel.py's matching _draw_input() else branch.
        row = box.row(align=True)
        row.label(text=scene.paraforge_active_object.name, icon='CHECKMARK')
        row.operator("paraforge.import_scan", text="New Scan", icon='FILE_REFRESH')


def _draw_alignment(context, layout):
    scene = context.scene
    box = layout.box()
    box.label(text="Orientation & Alignment", icon='ORIENTATION_GLOBAL')

    draw_stage_instructions(
        box,
        [
            "Axial (Red): waist level",
            "Sagittal (Green): spine midline",
            "Coronal (Blue): front/back centre",
        ],
        scene,
        None,
        collapsed=False,
    )

    box.separator(factor=0.4)
    if scene.parafly_tlso_planes_active:
        box.operator("paraforge.tlso_remove_alignment_planes", text="Remove Alignment Planes", icon='X')
    else:
        box.operator("paraforge.tlso_add_alignment_planes", text="Add Alignment Planes", icon='MESH_PLANE')

    box.separator(factor=0.4)
    pos_col = box.column(align=True)
    pos_col.label(text="Position")
    pos_col.prop(scene, "parafly_tlso_pos_x", text="X")
    pos_col.prop(scene, "parafly_tlso_pos_y", text="Y")
    pos_col.prop(scene, "parafly_tlso_pos_z", text="Z")

    rot_col = box.column(align=True)
    rot_col.label(text="Rotation")
    rot_col.prop(scene, "parafly_tlso_rot_x", text="X")
    rot_col.prop(scene, "parafly_tlso_rot_y", text="Y")
    rot_col.prop(scene, "parafly_tlso_rot_z", text="Z")

    box.separator(factor=0.4)
    apply_row = box.row()
    apply_row.scale_y = 1.3
    apply_row.operator("paraforge.tlso_apply_alignment", text="✓ Apply Alignment & Continue", icon='CHECKMARK')
    box.operator("paraforge.tlso_remove_alignment_planes", text="✗ Remove Planes", icon='TRASH')


def _draw_mapping(context, layout):
    scene = context.scene
    zone_names = get_tlso_zone_names()
    total = len(zone_names)
    box = layout.box()
    if total == 0:
        box.label(text="Clinical Mapping", icon='ERROR')
        draw_warning(box, "No clinical zones are available for this TLSO template.")
        return

    step = min(scene.parafly_tlso_mapping_step, total - 1)
    zone_id = zone_names[step]
    meta = get_tlso_zone_meta(zone_id)

    box.label(text=f"Clinical Mapping — Step {step + 1} of {total}", icon='GROUP_VERTEX')
    dots = box.row()
    dots.alignment = 'CENTER'
    dots.label(text=" ".join("●" if i <= step else "○" for i in range(total)))

    cat_row = box.row()
    cat_row.alignment = 'CENTER'
    cat_row.label(text=CATEGORY_LABELS.get(meta["category"], meta["category"].upper()))

    # SPEC_tlso_mapping_combined_fix.md: the color-swatch block that used to
    # sit here (a read-only COLOR FloatVectorProperty shown via
    # layout.prop(..., text="") with .enabled = False) crashed Blender's draw
    # loop silently in this build the moment it was reached - the panel cut
    # off right after the category label, hiding everything below it
    # (Start Painting, Confirm/Skip/Back) with no traceback. Removed
    # entirely, including scene.parafly_tlso_zone_color itself (see
    # __init__.py - no longer registered). Replaced with a plain
    # icon+label direction indicator - no property, no widget, no crash
    # surface at all.

    name_row = box.row()
    name_row.alignment = 'CENTER'
    name_row.label(text=meta["display_name"])

    category = meta.get("category", "")
    if "Pressure" in category:
        box.label(text="▼ Push In", icon='SORT_DESC')
    elif "Relief" in category:
        box.label(text="▲ Push Out", icon='SORT_ASC')

    # Reference image moved up here, right after the name/direction
    # indicator, so it's visible immediately rather than after scrolling
    # past the description/buttons. Still wrapped in its own outer
    # try/except (SPEC_tlso_mapping_combined_fix.md Fix 3, still in force)
    # on top of draw_zone_image's internal try/except (image_loader.py) -
    # belt and suspenders against a raised exception aborting the rest of
    # the panel draw below it.
    #
    # SPEC_tlso_image_spacing_and_import_hide.md Fix 1: the separators
    # immediately before/after this call were removed - combined with
    # image_loader.py's own scale_y fix, they were adding blank vertical
    # space above/below the image on top of the column-stretch bug itself.
    try:
        draw_zone_image(box, zone_id)
    except Exception as e:
        box.label(text="[ Reference image unavailable ]", icon='IMAGE_DATA')
        print(f"[ParaFly] draw_zone_image raised for {zone_id}: {e}")

    # Action buttons immediately below the image.
    paint_row = box.row()
    paint_row.scale_y = 1.4
    paint_row.operator("paraforge.tlso_start_painting", icon='PLAY')

    action_row = box.row(align=True)
    action_row.operator("paraforge.tlso_confirm_zone", icon='CHECKMARK')
    skip_col = action_row.row()
    skip_col.enabled = meta.get("skippable", True)
    skip_col.operator("paraforge.tlso_skip_zone", icon='FORWARD')
    action_row.operator("paraforge.tlso_back_zone", icon='BACK')

    box.separator(factor=0.3)

    # Description - informational, below the buttons.
    draw_stage_instructions(
        box, meta["description"], scene, None, collapsed=False)

    # SPEC_tlso_zone_update_7zones.md Section 5: "how to map" + optional
    # "tip" text, reusing this file's own _wrap helper (not the spec's own
    # separate _wrap_text reimplementation, which duplicates the same
    # word-wrap logic already proven here for zone descriptions).
    how_to_map = meta.get("how_to_map", "")
    if how_to_map:
        box.separator(factor=0.2)
        how_box = box.box()
        how_box.label(text="How to map:", icon='BRUSH_DATA')
        for line in _wrap(how_to_map):
            how_box.label(text=line)

    tip = meta.get("tip", "")
    if tip:
        tip_box = box.box()
        tip_box.label(text="Tip:", icon='LIGHT')
        for line in _wrap(tip):
            tip_box.label(text=line)

    if get_dev_mode():
        box.separator(factor=0.3)
        dev_row = box.row()
        dev_row.alert = True
        dev_row.operator("paraforge.tlso_skip_all_dev", text="Skip All (Dev)")


def _draw_adjustment(context, layout):
    scene = context.scene
    obj = scene.paraforge_active_object

    box = layout.box()
    box.label(text="Clinical Adjustment", icon='GROUP_VERTEX')

    mapped_zones = []
    if obj is not None:
        for zone_id in get_tlso_zone_names():
            if find_tlso_vertex_group(obj, zone_id) is not None:
                mapped_zones.append(zone_id)

    any_shown = False
    for category in CATEGORY_ORDER:
        zones_in_cat = [z for z in mapped_zones if get_tlso_zone_meta(z)["category"] == category]
        if not zones_in_cat:
            continue
        any_shown = True
        cat_row = box.row()
        cat_row.label(text=CATEGORY_LABELS.get(category, category.upper()))
        for zone_id in zones_in_cat:
            meta = get_tlso_zone_meta(zone_id)
            prop_name = f"parafly_tlso_slider_{zone_id}"
            if not hasattr(scene, prop_name):
                continue
            # SPEC_parafly_slider_and_zone_corrections.md Section 2: the
            # mirror/"Break Mirror" UI that used to sit here was removed
            # entirely (mirror zones caused zone deletion bugs) - Waist Area
            # and Trochanter Pad are now explicit _left/_right zones, so
            # every slider row is identical: just name, reset, slider.
            col = box.column(align=True)
            header = col.row()
            header.label(text=meta["display_name"])
            reset_op = header.operator("paraforge.tlso_reset_zone", text="", icon='LOOP_BACK')
            reset_op.zone_id = zone_id
            col.prop(scene, prop_name, slider=True)

    if not any_shown:
        draw_warning(box, "No clinical zones have been mapped yet.", icon='INFO')

    box.separator(factor=0.5)
    box.operator("paraforge.tlso_reset_all", text="Reset All Zones", icon='LOOP_BACK')


# Real-GUI staged-wizard request: _draw_advanced is now fully shared with TT
# (imported from paraforge_panel.py, like _wrap already was) rather than
# duplicated here - the staged Smooth Brush -> Trimline -> Thickness wizard
# only needs to exist in one place so TT and TLSO can never drift out of
# sync with each other.

_SPINE_LEVELS = ["T8", "T10", "T12", "L1", "L3", "L5", "S1", "Pelvis"]


def _draw_spine_curve(context, layout):
    scene = context.scene
    box = layout.box()
    box.label(text="Spine Curve Adjustment", icon='OUTLINER_OB_LATTICE')

    if not scene.dynax_tlso_lattice_active:
        col = box.column(align=True)
        col.label(text="Adjust for spinal curves:")
        col.operator("dynax.tlso_lattice_create", icon='OUTLINER_OB_LATTICE')
        col.label(text="Moves the TLSO to follow", icon='INFO')
        col.label(text="the patient's spine shape")
    else:
        inner = box.box()
        inner.label(text="Lattice active", icon='OUTLINER_OB_LATTICE')
        instr = inner.column(align=True)
        instr.scale_y = 0.8
        instr.label(text="To move a spinal level:", icon='INFO')
        instr.label(text="1. Select lattice → press Tab (Edit Mode)")
        instr.label(text="2. Press Alt+A to deselect all")
        instr.label(text="3. Click any point on a horizontal row")
        instr.label(text="4. Press Ctrl+L or Alt+Click to select")
        instr.label(text="   the full ring")
        instr.label(text="5. Press G then Z to move up/down")
        instr.label(text="6. Press Tab to exit Edit Mode")

        level_col = inner.column(align=True)
        level_col.separator()
        level_col.label(text="Select a spinal level:")
        for i, level in enumerate(_SPINE_LEVELS):
            op = level_col.operator("dynax.tlso_select_level", text=level)
            op.level = i
        level_col.separator()
        level_col.label(text="Then press G+Z to move")
        level_col.label(text="the selected level")

        inner.separator()
        row = inner.row(align=True)
        row.operator("dynax.tlso_lattice_apply", icon='CHECKMARK')
        row.operator("dynax.tlso_lattice_reset", icon='LOOP_BACK')


def draw_tlso_panel(context, layout):
    scene = context.scene
    stage = getattr(scene, "parafly_tlso_stage", 'INPUT')
    obj = scene.paraforge_active_object

    current_index = TLSO_STAGE_INDEX.get(stage, 0)
    draw_workflow_header(
        layout, "TLSO Orthosis", current_index + 1, len(TLSO_STAGES))
    draw_stage_progress(layout, TLSO_STAGES, current_index)

    draw_completion_status(layout, obj is not None, "Input scan ready")
    if current_index > 1:
        draw_completion_status(layout, True, "Alignment complete")
    if current_index > 2:
        draw_completion_status(layout, True, "Clinical mapping complete")

    _draw_input(context, layout)

    if stage == 'ALIGNMENT':
        _draw_alignment(context, layout)

    # Clinical-testing fix: Spine Curve Adjustment used to only appear once
    # `parafly_tlso_stage` reached ADJUSTMENT, which itself requires every
    # non-skippable zone to be painted first (_check_tlso_completion) -
    # effectively locking spine-curve editing behind finishing zone
    # painting. The two are independent clinical tasks with no real
    # dependency on each other, so both are now offered as parallel options
    # from the MAPPING stage onward - the clinician can do either, both, or
    # neither before advancing, in any order.
    if stage == 'MAPPING':
        layout.separator()
        opt_a = layout.row()
        opt_a.label(text="Option A — Clinical Mapping", icon='MODIFIER')
        _draw_mapping(context, layout)

        layout.separator()
        opt_b = layout.row()
        opt_b.label(text="Option B — Spine Curve Adjustment", icon='OUTLINER_OB_LATTICE')
        _draw_spine_curve(context, layout)

    if stage in ('ADJUSTMENT', 'ADVANCED'):
        _draw_adjustment(context, layout)
        _draw_spine_curve(context, layout)

    # SPEC_parafly_unlock_advanced_export.md: same fix as paraforge_panel.py -
    # Advanced (Trimline/Thickness) and Export no longer require finishing
    # the clinical mapping wizard first; shown as soon as a scan is loaded.
    #
    # Real bug found and fixed: gating on ONLY `obj is not None` made the
    # ENTIRE Advanced+Export+Save section vanish the moment a user finished
    # trimming and deleted the leftover part - see the matching comment in
    # paraforge_panel.py's draw_paraforge_zones_panel for the full mechanism
    # (paraforge_active_object's PointerProperty auto-clears when the
    # original-renamed object it points to gets deleted, even though
    # context.active_object correctly stays on the kept part).
    if obj is not None or context.active_object is not None:
        _draw_smooth_standalone(context, layout)
        _draw_advanced(context, layout)
        _draw_export(context, layout)

        layout.separator(factor=0.5)
        layout.operator("paraforge.save_project", text="Save Project", icon='FILE_TICK')
