# panels/paramold_panel.py - ParaMold: Silicone Mold Design
#
# A plain draw-function module, dispatched from DYNAX_PT_tools.draw() when
# scene.dynax_props.dynax_mode == 'PARAMOLD' - matching the established
# pattern for every other workflow (Creator, ParaForm, ParaFly TT/TLSO/AFO),
# NOT a standalone bpy.types.Panel with its own sidebar tab. ParaMold used to
# be a separate DYNAX_PT_paramold Panel; that class was removed so ParaMold
# lives inside the same New Case → workflow navigation as everything else.
#
# v1.25.1: audited on request ("each stage should have a button to advance
# to the next stage") - each stage's own action button (Align Finger Scan,
# Generate Mold, Apply Keys/Apply Pour, Export) already IS the forward
# trigger: the panel auto-redraws after any operator runs and
# _compute_stage_index() re-derives the current stage fresh from real
# geometry/marker state every draw, so there was never a genuinely "missing"
# Next button in the sense of a wired-but-broken control. What WAS a real
# gap: two of the five stages had no forward path for a clinician who didn't
# want to run that stage's (possibly destructive/optional) action at all -
# Align if the scan is already correctly oriented, and Adjust if no
# registration keys/pour channel are wanted. Both stages now also draw an
# explicit "Next Stage →" button alongside the existing action button,
# covering that skip case. See _draw_align_stage and _draw_adjust_stage.

import bpy

from .ui_helpers import draw_stage_progress, draw_workflow_header

PARAMOLD_STAGES = ["Align", "Trim", "Generate", "Adjust", "Export"]


def _compute_stage_index(context):
    """Clinical-testing FIX 3/4: stages are now driven by real state markers
    (DYNAX_MOLD_ALIGNED custom prop, DynaX_MoldHalf_A existence, whether any
    key/pour-channel object is still unapplied) instead of always drawing
    every section unconditionally - so, in particular, a previous session's
    leftover DynaX_MoldHalf_A can't silently keep the panel stuck showing
    only the Adjust/Export sections with the Import button unreachable
    (the reported "import button missing" symptom). "Start New Mold"
    (dynax.mold_reset) is the always-visible escape hatch back to Stage 1."""
    obj = context.active_object
    has_scan = obj is not None and obj.type == 'MESH'
    has_mold = bpy.data.objects.get("DynaX_MoldHalf_A") is not None
    has_pending = (
        any(bpy.data.objects.get(f"DynaX_Key_{i}") for i in range(1, 4))
        or bpy.data.objects.get("DynaX_PourChannel") is not None
    )
    # Clinical-testing fix: also accept "dynax_mold_processed" (stamped by
    # DynaxMoldApplyCut after a trim cut) as evidence the scan is past
    # Stage 1 - a cut scan should stay in Trim, not fall back to Align,
    # even if something about the redraw context makes DYNAX_MOLD_ALIGNED
    # look momentarily absent.
    is_processed = has_scan and bool(
        obj.get("DYNAX_MOLD_ALIGNED") or obj.get("dynax_mold_processed")
    )
    aligned = is_processed

    # Clinical-testing fix: Add Cut Plane (and other in-stage helper objects,
    # e.g. DynaX_CutPlane) make THEMSELVES the active object on creation,
    # which knocks the aligned scan out of context.active_object and made
    # clicking "Add Cut Plane" send the panel back to Stage 1 (Align) even
    # though the scan is still aligned - it's just not the active object
    # anymore. If the active object isn't itself a recognised aligned scan,
    # fall back to searching the scene for one before giving up and
    # reporting Stage 1.
    if not aligned and not has_mold:
        for candidate in bpy.data.objects:
            if candidate.type != 'MESH' or candidate.name == "DynaX_CutPlane":
                continue
            if candidate.get("DYNAX_MOLD_ALIGNED") or candidate.get("dynax_mold_processed"):
                aligned = True
                break

    if has_mold and not has_pending:
        return 4  # Export - mold exists, keys/pour already applied
    if has_mold:
        # dynax_mold_skip_adjust (v1.25.1 fix): a clinician who decides not
        # to use registration keys / a pour channel had NO forward path out
        # of Adjust - has_pending stays True forever unless the (destructive)
        # Apply buttons are clicked, and _compute_stage_index has no other
        # exit. "Next Stage -> Export" sets this override; DynaxMoldGenerate
        # clears it again on every fresh Generate so a stale skip can't hide
        # adjustments on a NEW mold.
        if context.scene.get("dynax_mold_skip_adjust"):
            return 4
        return 3  # Adjust - mold exists, keys/pour still pending
    if aligned:
        return 1  # Trim - scan aligned, ready to trim/generate
    return 0  # Align - no scan, or scan not yet aligned


def draw_paramold_panel(context, layout):
    scene = context.scene
    obj = context.active_object
    has_scan = obj is not None and obj.type == 'MESH'

    stage_index = _compute_stage_index(context)

    draw_workflow_header(layout, "ParaMold", stage_index + 1, len(PARAMOLD_STAGES))
    draw_stage_progress(layout, PARAMOLD_STAGES, stage_index)

    # Always available, at every stage - the only way back to Stage 1 once
    # a mold/keys/pour objects already exist.
    reset_row = layout.row()
    reset_row.operator("dynax.mold_reset", text="Start New Mold", icon='LOOP_BACK')

    if stage_index == 0:
        _draw_align_stage(layout, obj, has_scan)
    elif stage_index == 1:
        _draw_trim_and_generate_stage(layout, scene)
    elif stage_index == 3:
        _draw_adjust_stage(layout, scene)
    elif stage_index == 4:
        _draw_export_stage(layout)

    if scene.dynax_mold_has_undercuts:
        warn = layout.box()
        warn.alert = True
        warn.label(text="⚠ Undercuts detected", icon='ERROR')
        warn.label(text="Mold may not demold cleanly")
        warn.label(text="Consider adjusting split axis")

    if scene.dynax_mold_volume_ml > 0.0:
        vol_box = layout.box()
        vol_box.label(text=f"Silicone needed: {scene.dynax_mold_volume_ml:.1f} mL")
        vol_box.label(text="(add 10% waste factor)")


def _draw_align_stage(layout, obj, has_scan):
    box = layout.box()
    box.label(text="1. Import finger scan", icon='IMPORT')
    col = box.column(align=True)
    col.label(text="Step 1: Import finger scan")
    # Version-safe, priority order confirmed by direct testing (2026-08-18):
    # wm.stl_import (the native importer, present since Blender 4.0) is
    # checked FIRST. hasattr(bpy.ops.import_mesh, "stl or obj") can be True on
    # Blender 5.0/5.1 while STILL producing no visible/clickable button -
    # confirmed live in a running Blender 5.1 session that import_mesh.stl
    # is registered (hasattr True, no exception) but layout.operator() for
    # it silently draws nothing, while wm.stl_import and an unrelated
    # control operator both draw and work normally in the exact same box.
    # That makes import_mesh.stl a non-functional compat stub on 5.x here -
    # only Blender 4.1 still has it as the real, fully-functional legacy
    # operator. Do not swap this order back without re-testing on 5.x.
    if hasattr(bpy.ops.wm, "stl_import"):
        col.operator("wm.stl_import", text="Import Scan (STL/OBJ)", icon='IMPORT')
    elif hasattr(bpy.ops, "import_mesh") and hasattr(bpy.ops.import_mesh, "stl"):
        col.operator("import_mesh.stl", text="Import Scan (STL/OBJ)", icon='IMPORT')
    else:
        col.label(text="No STL import operator found", icon='ERROR')
    col.separator()
    if has_scan:
        col.label(text="Center the scan on the world origin")
        col.label(text="before aligning (recommended):")
        col.operator("dynax.center_model", text="Center Model", icon='OBJECT_ORIGIN')
        col.separator()
    col.label(text="Step 2: Select the scan mesh")
    col.label(text="then align it:")
    col.operator("dynax.mold_align", text="Align Finger Scan", icon='ORIENTATION_GLOBAL')

    if has_scan:
        col.separator()
        col.label(text="Fine-tune alignment:")
        row = col.row(align=True)
        row.operator("dynax.mold_rotate_90", text="Rotate 90°", icon='LOOP_FORWARDS')
        row.operator("dynax.mold_flip", text="Flip", icon='ARROW_LEFTRIGHT')
        col.label(text="Or use G/R/S to manually")
        col.label(text="adjust in the viewport")

        col.separator()
        col.operator("dynax.mold_skip_align", text="Next Stage: Trim/Generate →",
                      icon='FORWARD')


def _draw_trim_and_generate_stage(layout, scene):
    box = layout.box()
    box.label(text="2. Trim (optional)", icon='MOD_BOOLEAN')
    col = box.column(align=True)
    col.label(text="Remove unwanted parts")
    col.label(text="before generating mold:")
    col.operator("dynax.mold_add_cut_plane", text="Add Cut Plane", icon='MOD_BOOLEAN')
    col.label(text="Position the plane then:")
    col.prop(scene, "dynax_mold_cut_direction", text="")
    col.operator("dynax.mold_apply_cut", text="Apply Cut", icon='CHECKMARK')

    col.separator()
    col.label(text="Refine surface detail:")
    col.operator("dynax.mold_enter_sculpt", text="Enter Sculpt Mode", icon='SCULPTMODE_HLT')
    col.label(text="Use Blender sculpt tools")
    col.label(text="to refine finger detail.")
    col.label(text="Press Tab when done.")

    settings_box = layout.box()
    settings_box.label(text="Mold Settings", icon='PREFERENCES')
    row = settings_box.row(align=True)
    row.prop(scene, "dynax_mold_mode", expand=True)
    settings_box.prop(scene, "dynax_mold_wall_thickness")
    settings_box.prop(scene, "dynax_mold_split_axis")
    settings_box.prop(scene, "dynax_mold_pour_position")

    gen_box = layout.box()
    gen_box.label(text="3. Generate", icon='MOD_BOOLEAN')
    gen_box.operator("dynax.mold_generate", text="Generate Mold — Next Stage →",
                      icon='MESH_CUBE')


def _draw_adjust_stage(layout, scene):
    box = layout.box()
    box.label(text="4. Adjust", icon='TOOL_SETTINGS')

    has_keys = any(bpy.data.objects.get(f"DynaX_Key_{i}") for i in range(1, 4))
    has_pour_early = bpy.data.objects.get("DynaX_PourChannel") is not None
    if has_keys or has_pour_early:
        tip = box.box()
        tip.label(text="Tip: Half A and Half B are locked in", icon='INFO')
        tip.label(text="place so keys/pour line up correctly.")
        tip.label(text="To see behind one half, select it and")
        tip.label(text="press H to hide it (Alt+H to unhide) -")
        tip.label(text="don't move it aside and back.")

    if has_keys:
        key_box = box.box()
        key_box.label(text="Registration keys (orange)", icon='MESH_UVSPHERE')
        key_box.label(text="Move them to preferred positions")
        key_box.label(text="away from the mesh and pour channel")
        key_box.operator("dynax.mold_apply_keys", text="Apply Keys", icon='CHECKMARK')

    has_pour = bpy.data.objects.get("DynaX_PourChannel") is not None
    if has_pour:
        pour_box = box.box()
        pour_box.label(text="Pour channel (red)", icon='MESH_CYLINDER')
        pour_box.label(text="Move and resize it, then apply:")
        pour_box.operator("dynax.mold_apply_pour", text="Apply Pour Channel", icon='CHECKMARK')

    if not has_keys and not has_pour:
        box.label(text="All adjustments applied.", icon='CHECKMARK')
    else:
        box.separator()
        box.operator("dynax.mold_skip_adjust", text="Next Stage: Export →", icon='FORWARD')
        box.label(text="(unapplied keys/pour channel stay as-is)")


def _draw_export_stage(layout):
    box = layout.box()
    box.label(text="5. Export", icon='EXPORT')
    box.operator("dynax.mold_export", text="Export Mold STL Files", icon='FILE_TICK')
