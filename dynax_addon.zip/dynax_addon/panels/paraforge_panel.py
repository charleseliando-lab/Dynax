# panels/paraforge_panel.py - ParaFly workflow panel (SPEC_paraforge_v2_full_rebuild.md,
# scoped to ParaFly only per user clarification — ParaForm is untouched).
#
# Drawn from DYNAX_PT_tools.draw() (panels/dynax_panel.py) when
# props.dynax_mode == 'PARAFORGE_ZONES' (internal identifier kept stable; the
# user-facing name is "ParaFly") — a plain module of draw functions, not a second
# bpy.types.Panel, so it stays inside the single existing DynaX sidebar tab rather
# than opening a second one (matches how _draw_creator_panel / _draw_paraforge_panel
# already work for Creator and ParaForm).
#
# Progressive unlock: each section below is only drawn once its stage requirement
# is met. Preparation and Clinical Mapping additionally disappear once the workflow
# has moved past them — in Preparation's case deliberately so: Remesh rebuilds
# topology from scratch, which would silently destroy any already-painted zone
# vertex groups, so the destructive tools are hidden the moment mapping begins
# rather than left available to be clicked by accident.
#
# v2 changes (SPEC_paraforge_v2_full_rebuild.md, ParaFly only): zone names read
# dynamically via zone_reader.get_zone_names() instead of the old hardcoded
# TRANSTIBIAL_ZONES list; Clean Mesh replaced by a Smooth Brush section (also added
# to Advanced, replacing the old ad-hoc dynax.sculpt_start_smooth pairing); manual
# XYZ rotation fine-tune added after Auto Align; Load Saved Project is now real
# (paraforge.load_project) instead of a stub; Save Project button added to the
# footer. The startup menu now nests ParaForm/ParaFly under a "ParaForge" sub-menu
# (dynax_panel.py's _draw_paraforge_menu_screen) and every workflow, including
# Creator and ParaForm, is session-locked to the Start Menu — see dynax_panel.py.
# ParaForm itself (dynax_mode == 'PARAFORGE') was not touched by any of this.

import textwrap

import bpy

from ..paraforge.zone_reader import get_zone_names, find_vertex_group
from ..paraforge.zone_definitions import get_zone_meta
from ..preferences import get_dev_mode
from ..utils.translations import dx_text
from .components_section import draw_component_connection
from .ui_helpers import (
    draw_completion_status,
    draw_stage_instructions,
    draw_stage_progress,
    draw_warning,
    draw_workflow_header,
)


TT_STAGES = ["Input", "Preparation", "Mapping", "Adjustment", "Finish"]
TT_STAGE_INDEX = {
    'INPUT': 0,
    'PREPARATION': 1,
    'MAPPING': 2,
    'ADJUSTMENT': 3,
    'ADVANCED': 4,
}


def _draw_components(context, layout):
    """Collapsible Component Connection section for ParaFly (shared with TT/TLSO
    /AFO). The socket is scene.paraforge_active_object — DynaxLoadComponent falls
    back to it when the active object isn't a valid socket."""
    scene = context.scene
    is_open = scene.parafly_components_open
    header = layout.row()
    header.prop(
        scene, "parafly_components_open", text="Components",
        icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT', emboss=False,
    )
    if not is_open:
        return
    box = layout.box()
    props = getattr(scene, "dynax_props", None)
    if props is None:
        box.label(text="Component tools unavailable", icon='ERROR')
        return
    draw_component_connection(
        context, box, props, export_step=None,
        collapse_experimental=True,
        advanced_prop_name="parafly_advanced_open",
    )


def _wrap(text, width=42):
    return textwrap.wrap(text, width=width) or [""]


# SPEC_parafly_unlock_advanced_export.md "Also Fix": previously always showed
# Import STL/OBJ Scan / Load Saved Project unconditionally, even with a scan
# already active - now mirrors parafly_tlso_panel.py's already-established
# _draw_input() pattern (object name + a New Scan button once one is loaded).
def _draw_input(context, layout):
    scene = context.scene
    box = layout.box()
    box.label(text="Input", icon='IMPORT')

    obj = scene.paraforge_active_object
    if obj is None:
        box.operator("paraforge.import_scan", text="Import STL/OBJ Scan", icon='IMPORT')
        box.operator("paraforge.load_project", text="Load Saved Project", icon='FILE_FOLDER')
    else:
        name_row = box.row(align=True)
        name_row.label(text=obj.name, icon='CHECKMARK')
        name_row.operator(
            "paraforge.import_scan",
            text="New Scan",
            icon='FILE_REFRESH'
        )


def _draw_smooth_section(context, layout):
    scene = context.scene
    col = layout.column(align=True)
    col.label(text="Smooth Brush", icon='MOD_SMOOTH')
    col.prop(scene, "paraforge_smooth_strength", slider=True, text="Strength")
    col.operator("paraforge.start_smooth", text="Start Smoothing", icon='MOD_SMOOTH')
    if context.mode == 'SCULPT':
        col.operator("paraforge.done_smooth", text="Done Smoothing", icon='CHECKMARK')


# SPEC_parafly_smooth_remesh_collapsible.md: standalone Smooth Brush section
# below Clinical Adjustment, separate from the (now collapsible) Advanced
# Tools section - shown as soon as a scan is loaded, always visible (not
# collapsed), matching how Clinical Adjustment itself is always visible once
# reached. Shared by TT (this file) and TLSO (parafly_tlso_panel.py imports
# it). Uses MOD_SMOOTH, not the reference spec's proposed BRUSH_SMOOTH -
# verified directly that BRUSH_SMOOTH is not a valid icon identifier on
# Blender 5.0 (the version this addon is actually tested against this
# session), while MOD_SMOOTH is confirmed valid on both 5.0 and 5.1 and is
# what _draw_smooth_section above already uses.
def _draw_smooth_standalone(context, layout):
    scene = context.scene
    box = layout.box()
    box.label(text="Smooth Brush", icon='MOD_SMOOTH')
    box.prop(scene, "paraforge_smooth_strength", slider=True, text="Strength")

    info = box.column(align=True)
    info.scale_y = 0.75
    info.label(text="Done Smoothing bakes positions", icon='INFO')
    info.label(text="and resets sliders to zero.")

    if context.mode == 'SCULPT':
        box.operator("paraforge.done_smooth", text="Done Smoothing", icon='CHECKMARK')
    else:
        box.operator("paraforge.start_smooth", text="Start Smoothing", icon='MOD_SMOOTH')


def _draw_preparation(context, layout):
    scene = context.scene
    box = layout.box()
    box.label(text="Preparation", icon='MOD_REMESH')

    _draw_smooth_section(context, box)

    box.separator(factor=0.4)
    remesh_col = box.column(align=True)
    remesh_col.prop(scene, "paraforge_remesh_voxel_size", text="Voxel Size (mm)")
    remesh_col.operator("paraforge.remesh", text="Remesh", icon='MOD_REMESH')

    box.separator(factor=0.4)
    align_col = box.column(align=True)
    align_col.label(text="Align", icon='ORIENTATION_GLOBAL')
    align_col.operator("dynax.align_scan", text="Auto Align (longest → Z)", icon='ORIENTATION_GLOBAL')

    rot_col = box.column(align=True)
    rot_col.label(text="Fine-tune Rotation")
    rot_col.prop(scene, "paraforge_manual_rot_x", slider=True, text="X")
    rot_col.prop(scene, "paraforge_manual_rot_y", slider=True, text="Y")
    rot_col.prop(scene, "paraforge_manual_rot_z", slider=True, text="Z")
    rot_col.operator("paraforge.apply_rotation", text="Apply Rotation", icon='CHECKMARK')

    box.separator(factor=0.5)
    ready = box.row()
    ready.scale_y = 1.3
    ready.operator("paraforge.ready_begin_mapping",
                    text="✓ Ready — Begin Clinical Mapping", icon='CHECKMARK')


def _draw_clinical_mapping(context, layout):
    scene = context.scene
    zone_names = get_zone_names()
    total = len(zone_names)
    if total == 0:
        box = layout.box()
        box.label(text="Clinical Mapping", icon='ERROR')
        draw_warning(box, "No clinical zones are available for this TT template.")
        return

    step = min(scene.paraforge_mapping_step, total - 1)
    zone_id = zone_names[step]
    meta = get_zone_meta(zone_id)

    box = layout.box()
    box.label(text=f"Clinical Mapping — Step {step + 1} of {total}", icon='GROUP_VERTEX')

    dots = box.row()
    dots.alignment = 'CENTER'
    dots.label(text=" ".join("●" if i <= step else "○" for i in range(total)))

    name_row = box.row()
    name_row.alignment = 'CENTER'
    name_row.label(text=meta["display_name"])

    draw_stage_instructions(
        box, meta["description"], scene, None, collapsed=False)

    box.separator(factor=0.5)
    paint_row = box.row()
    paint_row.scale_y = 1.3
    paint_row.operator("paraforge.start_painting", icon='PLAY')

    action_row = box.row(align=True)
    action_row.operator("paraforge.confirm_zone", icon='CHECKMARK')
    action_row.operator("paraforge.wizard_back", icon='BACK')

    if get_dev_mode():
        box.separator(factor=0.3)
        dev_row = box.row()
        dev_row.alert = True
        dev_row.operator("paraforge.skip_all_dev", text="Skip All (Dev)")


def _draw_clinical_adjustment(context, layout):
    scene = context.scene
    obj = scene.paraforge_active_object

    box = layout.box()
    box.label(text="Clinical Adjustment", icon='GROUP_VERTEX')

    any_shown = False
    if obj is not None:
        for zone_id in get_zone_names():
            if find_vertex_group(obj, zone_id) is None:
                continue
            prop_name = f"parafly_slider_{zone_id}"
            if not hasattr(scene, prop_name):
                # Slider properties register via a deferred timer (see
                # __init__.py's _register_sliders_deferred) so they may not
                # exist yet for one redraw right after enabling the addon, or
                # not at all if the reference blend couldn't be read. Skip
                # rather than crash the whole panel's draw() on a missing prop.
                continue
            any_shown = True
            meta = get_zone_meta(zone_id)

            col = box.column(align=True)
            header = col.row()
            header.label(text=meta["display_name"])
            reset_op = header.operator("paraforge.reset_zone", text="", icon='LOOP_BACK')
            reset_op.zone_id = zone_id
            # subtype='DISTANCE' (slider_engine.py) already renders its own
            # "N.N mm" readout, so no separate manual unit label is needed here.
            col.prop(scene, prop_name, slider=True)

    if not any_shown:
        box.label(text="No clinical zones mapped yet")

    box.separator(factor=0.5)
    box.operator("paraforge.reset_all_zones", text="Reset All Zones", icon='LOOP_BACK')


# SPEC_parafly_trimline_thickness_borrow_creator.md: the custom ParaFly
# trimline.py/thickness.py operators (mirror_zone-adjacent additions from an
# earlier spec) were deleted entirely - Creator already has fully working,
# battle-tested Trimline (operators/trimline.py's "Method B" spline cut) and
# Thickness (operators/offset.py's Solidify wrapper) tools, so ParaFly's
# Advanced section now calls those REAL operators directly instead of
# maintaining a second, less-proven implementation.
#
# Two real corrections vs. the spec, both found by checking against the
# actual operators/panel code before writing anything new:
#
# 1. STAGE KEY/VALUES: the spec assumed scene.get("dynax_trimline_stage",
#    "idle") with lowercase values ("idle"/"placing"/"loop_closed"/"editing"/
#    "cut_done"). The real key trimline.py's own operators write is
#    "dynax_trim_stage" (not "dynax_trimline_stage"), with UPPERCASE values
#    IDLE / PLACING / PLACED / CLOSED / CUT (no separate "editing"/"cut_done"
#    state - "PLACED"/"CLOSED" cover the optional Tab-to-edit step, and "CUT"
#    is the real done-state). Confirmed directly against trimline.py's
#    TARGET_KEY/DynaxTrimlinePlacePoints._finish()/DynaxTrimlineCloseLoop /
#    DynaxTrimlineCut, and mirrored dynax_panel.py's own real Method-B stage
#    machine (condensed for this Advanced sub-section rather than
#    reproducing every instructional line).
#
# 2. THICKNESS OPERATES ON context.active_object, NOT A PARAFLY PROPERTY:
#    operators/offset.py's OffsetAddUpdate/OffsetApply/OffsetRemove all read
#    `context.active_object` directly - there's no scene-key override like
#    trimline's TARGET_KEY. Creator's OWN thickness step has this same
#    property (it never force-selects anything either) and relies on
#    dynax.pick_part (already used after a Creator cut) to make the right
#    piece active first - reused that exact, already-proven handoff here
#    rather than inventing a new auto-activation mechanism. Before any cut
#    has happened, the ParaFly object is quietly made active on first draw
#    so a direct (no-trimline) thickness pass still works with no extra
#    clicks; after a cut, Pick Part is shown and takes over, matching
#    Creator's real design exactly.
def _dispatch_op(layout, real_op, text, icon, use_invoke=False):
    """Trimline entry-point button: goes through
    paraforge.trimline_dispatch (trimline_bridge.py) so the ParaFly object is
    made active/selected inside a REAL operator call before the real Creator
    operator runs - never during panel draw (see module note below)."""
    op = layout.operator("paraforge.trimline_dispatch", text=text, icon=icon)
    op.real_op = real_op
    op.use_invoke = use_invoke
    return op


# SPEC_parafly_advanced_cleanup_trimline_fix.md / a later real-GUI bug report:
# _draw_trimline_section previously wrote scene["dynax_trimline_target"] and
# set context.view_layer.objects.active / obj.select_set(True) directly in
# its own DRAW-TIME code. Verified against a real GUI session's own error
# console: Blender raises `AttributeError: Writing to ID classes in this
# context is not allowed` the instant a panel's draw() writes ANY ID data -
# a real, hard restriction headless mock-layout tests never exercise (they
# don't trigger Blender's "currently drawing UI" restricted-context flag).
# That exception aborted the rest of _draw_advanced()'s draw() call, which is
# why Thickness and Export (drawn right after Trimline) vanished too, not
# just Trimline's own buttons.
#
# Fix: this function now ONLY READS state - see trimline_bridge.py's
# PARAFORGE_OT_trimline_dispatch, which every active-object-dependent entry
# point (both methods below) goes through instead of a bare
# col.operator("dynax....") call. Also adds Creator's paint-and-separate
# (brush/box/lasso select -> lock -> separate), which ParaFly didn't have
# before - only the click-to-place-points spline cut had been ported - per
# explicit request for a paint/brush trimline tool. The spline cut has since
# been removed from the UI entirely (see the note above the Quick Flat Slice
# box below), so paint-and-separate is now the primary trimline method.
def _draw_trimline_section(context, layout):
    scene = context.scene
    obj = scene.paraforge_active_object
    box = layout.box()
    box.label(text="Trimline", icon='EDGESEL')

    paint_parts = [o for o in bpy.data.objects
                   if o.name.startswith(("DynaX_Selected", "DynaX_Remainder"))]
    cut_parts = [o for o in bpy.data.objects
                 if o.name.startswith(("DynaX_Proximal", "DynaX_Distal", "DynaX_Part_"))]

    if obj is None and not cut_parts and not paint_parts:
        box.label(text="Import a scan first.", icon='INFO')
        return

    # ── Paint & separate (brush/box/lasso select) ───────────────────────────
    a_box = box.box()
    a_box.label(text="Paint & Separate", icon='BRUSH_DATA')
    if not paint_parts:
        dynax_props = scene.dynax_props
        a_box.prop(dynax_props, "selection_through", text="Select through (off = front only)")
        row = a_box.row(align=True)
        _dispatch_op(row, "dynax.select_box", "Box", 'MESH_PLANE')
        _dispatch_op(row, "dynax.select_lasso", "Lasso", 'GREASEPENCIL')
        _dispatch_op(row, "dynax.select_circle", "Paint", 'BRUSH_DATA')
        a_box.prop(dynax_props, "select_brush_radius", text="Brush Radius", slider=True)
        row2 = a_box.row(align=True)
        row2.operator("dynax.select_clear", text="Clear", icon='X')
        row2.operator("dynax.select_invert", text="Invert", icon='ARROW_LEFTRIGHT')
        _dispatch_op(a_box, "dynax.lock_selection", "Lock Selection", 'LOCKED')
        cnt = scene.get("dynax_selection_count", 0)
        if cnt:
            a_box.label(text=f"✓ {cnt:,} verts locked", icon='CHECKMARK')
        sep_row = a_box.row()
        sep_row.scale_y = 1.4
        sep_row.alert = True
        _dispatch_op(sep_row, "dynax.separate_selected", "Separate Region", 'UNLINKED')
    else:
        a_box.label(text="✓ Region separated!", icon='CHECKMARK')
        active_name = context.active_object.name if context.active_object else ""
        for p in sorted(paint_parts, key=lambda o: o.name):
            prow = a_box.row(align=True)
            pop = prow.operator(
                "dynax.pick_part", text=p.name.replace("DynaX_", ""),
                icon='RADIOBUT_ON' if p.name == active_name else 'RADIOBUT_OFF',
                depress=(p.name == active_name))
            pop.part_name = p.name
            if "Remainder" in p.name:
                dop = prow.operator("dynax.delete_part", text="", icon='TRASH')
                dop.part_name = p.name
        a_box.operator("dynax.trimline_clear", text="Start Over", icon='X')

    box.separator(factor=0.3)

    # ── Quick flat slice ────────────────────────────────────────────────────
    # The "Precise Spline Cut" (Method B - click-to-place points, close loop,
    # knife-ribbon cut) was REMOVED from the UI for pilot testing; see the same
    # note in panels/dynax_panel.py's trimline step. Quick Slice is a separate
    # horizontal-plane cut and is kept, now as its own box rather than nested
    # inside the retired spline stage machine.
    b_box = box.box()
    b_box.label(text="Quick Flat Slice", icon='MESH_PLANE')
    _dispatch_op(b_box, "dynax.trimline_quick_slice", "Slice at Height…", 'MESH_PLANE')

    if cut_parts:
        b_box.separator(factor=0.3)
        b_box.label(text="Pick the part to work on:")
        active_name = context.active_object.name if context.active_object else ""
        pcol = b_box.column(align=True)
        for p in sorted(cut_parts, key=lambda o: o.name):
            is_active = (p.name == active_name)
            pop = pcol.operator(
                "dynax.pick_part", text=p.name.replace("DynaX_", ""),
                icon='RADIOBUT_ON' if is_active else 'RADIOBUT_OFF',
                depress=is_active)
            pop.part_name = p.name
        b_box.operator("dynax.trimline_clear", text="Start Over", icon='X')

    # ── Edge finishing - always visible once a part exists, works on either
    # a separated or a sliced part. Ported from Creator's own Trim Line step
    # (dynax_panel.py), which ParaFly never had at all - real gap the user
    # found via their own testing.
    # All four operators read context.active_object directly (same as
    # Pick Part/Separate already maintain), so no dispatch wrapper is needed
    # here - by this point in the workflow the active object is already
    # correct.
    if cut_parts or paint_parts:
        edge_box = box.box()
        edge_box.label(text="Edge Finishing (run on each part)", icon='MOD_EDGESPLIT')
        col = edge_box.column(align=True)
        col.operator("dynax.smooth_cut_boundary", text="Smooth Cut Boundary", icon='MOD_SMOOTH')
        col.operator("dynax.fill_boundary", text="Fill Cut Boundary (optional)", icon='MESH_PLANE')
        col.operator("dynax.flare_edge", text="Flare Open Rim", icon='MOD_SMOOTH')
        col.operator("dynax.clean_slice", text="Clean Cut Edges", icon='BRUSH_DATA')


# Same root-cause fix as _draw_trimline_section above: this used to set
# context.view_layer.objects.active / obj.select_set(True) directly in its
# own draw-time code, which raised the exact same
# `AttributeError: Writing to ID classes in this context is not allowed`
# and is exactly why Thickness (and Export, drawn right after it) vanished
# from the real GUI along with Trimline. Now read-only during draw; the
# Preview/Confirm/Remove buttons go through paraforge.trimline_dispatch
# (skip_if_parts_exist=True, so it never overrides an already-picked part).
def _draw_thickness_section(context, layout):
    scene = context.scene
    props = scene.dynax_props
    box = layout.box()
    box.label(text="Thickness", icon='MOD_SOLIDIFY')

    col = box.column(align=True)
    col.prop(props, "solidify_thickness_mm", text="Thickness (mm)")
    col.prop(props, "offset_direction", text="Direction")
    col.prop(props, "offset_cap_rim", text="Cap open edges")
    col.separator(factor=0.3)
    prev_op = col.operator("paraforge.trimline_dispatch", text="Preview", icon='MOD_SOLIDIFY')
    prev_op.real_op = "dynax.offset_add_update"
    prev_op.skip_if_parts_exist = True

    active = context.active_object
    if active and active.get("dynax_thickness_baked", False):
        warn = box.column(align=True)
        warn.scale_y = 0.8
        warn.alert = True
        warn.label(text="Already baked — Confirm again ADDS more", icon='ERROR')

    row = box.row(align=True)
    confirm_op = row.operator("paraforge.trimline_dispatch", text="Confirm", icon='CHECKMARK')
    confirm_op.real_op = "dynax.offset_apply"
    confirm_op.skip_if_parts_exist = True
    remove_op = row.operator("paraforge.trimline_dispatch", text="Remove", icon='X')
    remove_op.real_op = "dynax.offset_remove"
    remove_op.skip_if_parts_exist = True


# SPEC_parafly_advanced_cleanup_trimline_fix.md Section 1: the Sculpt/
# Boolean/quick-Trim block that used to sit here was leftover from before
# ParaFly had its own real Trimline section (SPEC_parafly_trimline_thickness_
# borrow_creator.md) - now that Trimline/Thickness both call Creator's real
# operators directly, this trio is redundant (Trim in particular duplicated
# dynax.trimline_quick_slice, which the Trimline section above already
# offers) and out of place in a ParaFly-scoped Advanced section. Removed
# entirely - Advanced is now exactly Smooth Brush, Trimline, Thickness.
#
# SPEC_parafly_smooth_remesh_collapsible.md: replaces the earlier staged
# (Stage 1 of 3, Back/Next) wizard with a collapsible section per explicit
# follow-up direction - Trimline/Thickness/Remesh all show together once
# expanded, rather than one at a time. Collapsed by default via the
# scene.parafly_advanced_open BoolProperty; layout.prop()'s own click
# handling is what changes that property, not this function's Python code,
# so this does NOT hit the "Writing to ID classes... not allowed" draw-time
# restriction fixed elsewhere in this file (that restriction is about this
# function's OWN code assigning to scene[...]/view_layer.objects.active
# during draw - a bound prop() widget's later click is handled by Blender's
# own internal event dispatch, not by code running inside draw()).
# Shared by both TT (this function) and TLSO (parafly_tlso_panel.py imports
# it, like _draw_trimline_section/_draw_thickness_section already were) so
# the two devices can't drift.
def _draw_advanced(context, layout):
    scene = context.scene
    adv_open = scene.parafly_advanced_open

    header = layout.row()
    header.prop(scene, "parafly_advanced_open", text="Advanced Tools",
                icon='TRIA_DOWN' if adv_open else 'TRIA_RIGHT', emboss=False)

    if not adv_open:
        return

    box = layout.box()
    _draw_trimline_section(context, box)
    box.separator(factor=0.3)
    _draw_thickness_section(context, box)
    box.separator(factor=0.3)

    # Auto Remesh / Quad Remesh (operators/auto_remesh.py, operators/
    # quad_remesh.py - Creator's own, real bl_idnames confirmed by grep
    # before wiring, per the spec's own explicit instruction not to guess).
    # Both read context.active_object directly, same as Thickness/Cost -
    # routed through the same safe dispatch used elsewhere in this section.
    remesh_box = box.box()
    remesh_box.label(text="Remesh", icon='MOD_REMESH')
    remesh_box.label(text="Re-smooth mesh after adjustments", icon='INFO')
    col = remesh_box.column(align=True)
    auto_op = col.operator("paraforge.trimline_dispatch", text="Auto Remesh", icon='MOD_REMESH')
    auto_op.real_op = "dynax.auto_remesh"
    auto_op.skip_if_parts_exist = True
    quad_op = col.operator("paraforge.trimline_dispatch", text="Quad Remesh", icon='MOD_REMESH')
    quad_op.real_op = "dynax.quad_remesh"
    quad_op.skip_if_parts_exist = True


# Shared by TT (this file) and TLSO (parafly_tlso_panel.py imports this
# instead of keeping its own separate copy, which had drifted out of sync -
# TLSO's version never got the Material & Cost Estimate section below).
# Collapsible per SPEC_parafly_smooth_remesh_collapsible.md, same technique
# as _draw_advanced above (a bound prop() widget, not a draw-time write).
def _draw_export(context, layout):
    scene = context.scene
    export_open = scene.parafly_export_open

    header = layout.row()
    header.prop(scene, "parafly_export_open", text="Export",
                icon='TRIA_DOWN' if export_open else 'TRIA_RIGHT', emboss=False)

    if not export_open:
        return

    box = layout.box()
    row = box.row()
    row.scale_y = 1.3
    row.operator("paraforge.export", text="Export STL (choose name/folder)", icon='EXPORT')

    # User request: bring in Creator's Material/Print-Cost Estimator
    # (operators/cost_estimator.py's dynax.estimate_cost - unchanged, reused
    # directly) so ParaFly doesn't need its own separate cost math. Same
    # properties Creator's own Export step already exposes
    # (material_density_g_cm3/material_cost_per_kg/material_currency_symbol/
    # print_infill_percent, all on scene.dynax_props) and the same
    # scene["dynax_est_*"] result keys, so Settings' Material Defaults
    # (dynax_panel.py's _draw_settings_panel) apply here unchanged too.
    props = context.scene.dynax_props
    cost_box = layout.box()
    cost_box.label(text="Material & Cost Estimate", icon='PACKAGE')
    cc = cost_box.column(align=True)
    cc.prop(props, "print_infill_percent", text="Infill %", slider=True)
    # dynax.estimate_cost reads context.active_object directly (same as
    # Thickness's real operators) - routed through the same safe dispatch
    # used elsewhere in Advanced so it targets the right object without
    # writing to it from panel draw.
    calc_op = cc.operator("paraforge.trimline_dispatch", text="Calculate", icon='FILE_REFRESH')
    calc_op.real_op = "dynax.estimate_cost"
    calc_op.skip_if_parts_exist = True

    vol = context.scene.get("dynax_est_volume_cm3")
    if vol is not None:
        weight = context.scene.get("dynax_est_weight_g", 0)
        cost = context.scene.get("dynax_est_cost", 0)
        result = cost_box.box()
        result.label(text=f"Volume: {vol} cm³")
        result.label(text=f"Est. Weight: {weight} g")
        result.label(text=f"Est. Cost: {props.material_currency_symbol}{cost}")


def _draw_device_selection(context, layout):
    """ParaFly device picker - reached the moment ParaFly is entered
    (scene.parafly_device_type == 'NONE'). SPEC_parafly_tlso_complete.md put
    this in its own panels/parafly_device_selection_panel.py file with
    poll()-gated Panel classes; folded into this module instead as a plain
    function (consistent with how this whole file works - see the module
    docstring), since it's a small screen tightly coupled to ParaFly's own
    entry dispatch just below."""
    box = layout.box()
    box.label(text="ParaFly — Select Device Type", icon='ARMATURE_DATA')

    tt_box = box.box()
    tt_box.label(text="Transtibial Socket (TT)")
    tt_desc = tt_box.column(align=True)
    tt_desc.scale_y = 0.75
    tt_desc.label(text="For below-knee prosthetic socket")
    tt_desc.label(text="modification.")
    tt_row = tt_box.row()
    tt_row.scale_y = 1.3
    tt_row.operator("paraforge.set_device_type", text="Start TT Workflow", icon='OUTLINER_OB_ARMATURE').device_type = 'TT'

    box.separator(factor=0.3)

    tlso_box = box.box()
    tlso_box.label(text="Thoracolumbosacral Orthosis (TLSO)")
    tlso_desc = tlso_box.column(align=True)
    tlso_desc.scale_y = 0.75
    tlso_desc.label(text="For scoliosis brace modification.")
    tlso_row = tlso_box.row()
    tlso_row.scale_y = 1.3
    tlso_row.operator("paraforge.set_device_type", text="Start TLSO Workflow", icon='ARMATURE_DATA').device_type = 'TLSO'

    box.separator(factor=0.3)

    afo_box = box.box()
    afo_box.label(text="Ankle Foot Orthosis (AFO)")
    afo_desc = afo_box.column(align=True)
    afo_desc.scale_y = 0.75
    afo_desc.label(text="For solid AFO design and correction.")
    afo_row = afo_box.row()
    afo_row.scale_y = 1.3
    afo_row.operator("paraforge.set_device_type", text="Start AFO Workflow", icon='OUTLINER_OB_ARMATURE').device_type = 'AFO'


def draw_paraforge_zones_panel(context, layout):
    scene = context.scene
    device = getattr(scene, "parafly_device_type", 'NONE')

    if device == 'NONE':
        _draw_device_selection(context, layout)
        return

    if device == 'TLSO':
        from .parafly_tlso_panel import draw_tlso_panel
        draw_tlso_panel(context, layout)
        return

    if device == 'AFO':
        from .parafly_afo_panel import draw_afo_panel
        draw_afo_panel(context, layout)
        return

    # device == 'TT' — existing Transtibial workflow, UNCHANGED.
    stage = getattr(scene, "paraforge_stage", 'INPUT')
    obj = getattr(scene, "paraforge_active_object", None)

    current_index = TT_STAGE_INDEX.get(stage, 0)
    draw_workflow_header(
        layout, "TT Socket", current_index + 1, len(TT_STAGES))
    draw_stage_progress(layout, TT_STAGES, current_index)
    draw_completion_status(layout, obj is not None, "Input scan ready")
    if current_index > 1:
        draw_completion_status(layout, True, "Preparation complete")
    if current_index > 2:
        draw_completion_status(layout, True, "Clinical mapping complete")

    _draw_input(context, layout)

    if stage == 'PREPARATION':
        _draw_preparation(context, layout)

    if stage == 'MAPPING':
        _draw_clinical_mapping(context, layout)

    if stage in ('ADJUSTMENT', 'ADVANCED'):
        _draw_clinical_adjustment(context, layout)

    # SPEC_parafly_unlock_advanced_export.md: Advanced (Trimline/Thickness)
    # and Export are useful even before the clinical mapping wizard is
    # finished (e.g. trimming/thickening a scan that doesn't need zone
    # mapping at all) - previously gated behind stage == 'ADJUSTMENT'/
    # 'ADVANCED', which meant a user could never reach them without first
    # completing every mapping step. Now shown as soon as a scan is loaded.
    #
    # Real bug found and fixed: gating on ONLY `obj is not None` (obj =
    # scene.paraforge_active_object) made the ENTIRE Advanced+Export+Save
    # section vanish ("the whole workflow closed") the moment a user
    # finished trimming and deleted the leftover part - paraforge_active_object
    # is a PointerProperty to the ORIGINALLY-imported object, and Creator's
    # Method A "Separate Selected" keeps that exact object alive under a new
    # name (DynaX_Remainder); deleting that leftover part auto-clears the
    # PointerProperty to None even though context.active_object correctly
    # remains the kept part. Falling back to context.active_object keeps
    # this section visible using whatever's actually the current working
    # object, matching the same fallback in PARAFORGE_OT_export.
    if obj is not None or context.active_object is not None:
        _draw_smooth_standalone(context, layout)
        _draw_advanced(context, layout)
        _draw_components(context, layout)
        _draw_export(context, layout)

        layout.separator(factor=0.5)
        layout.operator("paraforge.save_project", text="Save Project", icon='FILE_TICK')
