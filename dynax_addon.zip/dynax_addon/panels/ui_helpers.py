"""Display-only presentation helpers shared by DynaX workflow panels.

The helpers intentionally have no Blender imports, do not mutate scene state,
and never execute operators. They only compose the layout passed by Blender.
"""

from __future__ import annotations

import textwrap


def _has_prop(scene, prop_name):
    return bool(scene is not None and prop_name and hasattr(scene, prop_name))


def draw_workflow_header(layout, workflow_name, current_stage, total_stages):
    """Draw a consistent workflow identity and stage count."""
    if layout is None:
        return None
    box = layout.box()
    box.label(text=str(workflow_name or "DynaX Workflow"), icon='WORKSPACE')
    if total_stages:
        box.label(
            text=f"Stage {current_stage or 1} of {total_stages}",
            icon='FORWARD',
        )
    return box


def draw_stage_progress(layout, stages, current_index):
    """Draw completed, current, and upcoming stage markers."""
    if layout is None:
        return None
    stages = list(stages or [])
    if not stages:
        return None
    try:
        current = max(0, min(int(current_index), len(stages) - 1))
    except (TypeError, ValueError):
        current = 0
    box = layout.box()
    markers = box.row(align=True)
    markers.alignment = 'CENTER'
    for index, stage in enumerate(stages):
        if index < current:
            icon = 'CHECKMARK'
        elif index == current:
            icon = 'RADIOBUT_ON'
        else:
            icon = 'RADIOBUT_OFF'
        markers.label(text="", icon=icon)
    box.label(text=f"{current + 1}. {stages[current]}")
    return box


def draw_stage_instructions(
        layout, text, scene, prop_name, collapsed=True):
    """Draw optional instructions using an existing Boolean property."""
    if layout is None or not text:
        return None
    has_prop = _has_prop(scene, prop_name)
    is_open = not collapsed or (has_prop and bool(getattr(scene, prop_name)))
    box = layout.box()
    header = box.row()
    if has_prop:
        header.prop(
            scene, prop_name, text="Instructions",
            icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT', emboss=False,
        )
    else:
        header.label(text="Instructions", icon='INFO')
        is_open = True
    if is_open:
        body = box.column(align=True)
        body.scale_y = 0.8
        lines = text if isinstance(text, (list, tuple)) else [text]
        for item in lines:
            for line in textwrap.wrap(str(item), width=42) or [""]:
                body.label(text=line)
    return box


def draw_action_button(
        layout, operator_id, label, icon='NONE', primary=True, scale=1.3):
    """Draw and return a consistently sized operator button."""
    if layout is None or not operator_id:
        return None
    row = layout.row()
    row.scale_y = scale if primary else min(scale, 1.0)
    return row.operator(operator_id, text=str(label or "Continue"), icon=icon)


def draw_completion_status(layout, completed, label):
    """Draw a compact completed/pending status row."""
    if layout is None:
        return None
    row = layout.row()
    row.label(
        text=str(label or ("Complete" if completed else "Pending")),
        icon='CHECKMARK' if completed else 'TIME',
    )
    row.active = bool(completed)
    return row


def draw_warning(layout, message, icon='ERROR'):
    """Draw a consistent warning without changing application state."""
    if layout is None or not message:
        return None
    box = layout.box()
    box.alert = True
    lines = textwrap.wrap(str(message), width=42) or [""]
    for index, line in enumerate(lines):
        box.label(text=line, icon=icon if index == 0 else 'NONE')
    return box


def draw_advanced_section(
        layout, scene, prop_name, label, draw_func, context=None):
    """Draw collapsible content using an already-registered Boolean property."""
    if layout is None:
        return None
    has_prop = _has_prop(scene, prop_name)
    is_open = bool(getattr(scene, prop_name)) if has_prop else True
    header = layout.row()
    if has_prop:
        header.prop(
            scene, prop_name, text=str(label or "Advanced"),
            icon='TRIA_DOWN' if is_open else 'TRIA_RIGHT', emboss=False,
        )
    else:
        header.label(text=str(label or "Advanced"), icon='PREFERENCES')
    if not is_open or draw_func is None:
        return None
    body = layout.box()
    if context is None:
        draw_func(body)
    else:
        draw_func(context, body)
    return body


def draw_studio_only(scene, draw_func, layout):
    """Draw content only in a marked DynaX Studio session."""
    if layout is None or scene is None or draw_func is None:
        return None
    if bool(scene.get("dynax_studio_session", False)):
        return draw_func(layout)
    return None


def draw_standalone_only(scene, draw_func, layout):
    """Draw content only when the add-on is running outside DynaX Studio."""
    if layout is None or scene is None or draw_func is None:
        return None
    if not bool(scene.get("dynax_studio_session", False)):
        return draw_func(layout)
    return None
