# panels/components_section.py - the shared "Component Connection" UI.
#
# Extracted verbatim from the Creator Components step (panels/dynax_panel.py) so
# the SAME component tooling — Load, Position, Quick Bridge (+ transition
# profiles), Smart Transition (experimental) and ParaLink (beta) — can be reused
# in ParaForm (parametric transfemoral) and ParaFly TT without duplicating it.
#
# All the underlying operators are workflow-agnostic: DynaxLoadComponent captures
# the socket as the active object (with a paraforge_active_object fallback, see
# component_bridge.py) and stashes it in scene["dynax_bridge_socket_obj"], which
# every downstream operator reads. So this draw function works identically no
# matter which workflow hosts it.

import os

import bpy

from ..operators.component_bridge import _get_components_folder
from ..properties.dynax_properties import discover_component_categories
from .ui_helpers import draw_advanced_section, draw_warning


def _draw_experimental_connection_methods(context, layout):
    """Draw existing Smart Transition and ParaLink controls unchanged."""
    scene = context.scene
    tstage = getattr(scene, 'dynax_transition_stage', 'NONE')

    exp_box = layout.box()
    exp_box.label(text="Smart Transition", icon='EXPERIMENTAL')
    draw_warning(
        exp_box,
        "May be non-watertight. Use Quick Bridge unless evaluating this method.",
    )

    if tstage in ('NONE', 'LOADED', 'ALIGNED'):
        row = exp_box.row()
        row.scale_y = 1.2
        row.operator("dynax.prepare_transition",
                     text="Prepare Transition", icon='MOD_SHRINKWRAP')
    elif tstage == 'INTERACTIVE':
        exp_box.label(text="Preview active - adjust height, then generate", icon='CHECKMARK')
        cutter = bpy.data.objects.get('DynaX_Cutter')
        if cutter:
            exp_box.prop(cutter, "location", index=2, text="Transition Height")
        style_box = exp_box.box()
        style_box.label(text="Connection Style", icon='MOD_SMOOTH')
        style_box.prop(scene, "dynax_connection_style", text="")
        style_box.prop(scene, "dynax_support_count", text="Supports")
        row2 = exp_box.row(align=True)
        row2.scale_y = 1.2
        row2.operator("dynax.generate_transition",
                      text="Generate Transition", icon='CHECKMARK')
        row2.operator("dynax.cancel_transition", text="", icon='X')
    elif tstage == 'COMPLETE':
        exp_box.label(text="Transition complete - verify before export", icon='CHECKMARK')

    _draw_paralink_section(context, layout)


def _draw_paralink_style(box, scene):
    """The one parameter run_paralink() accepts beyond socket_obj/comp_obj/
    user_transition_z: connection_style (real - PARALINK_PROFILES in
    surface_generator.py). Shown in ALL four modes.

    v1.21.0 test-feedback fix #3: EnumProperty row-of-buttons showed blank
    labels with prop_enum(); a single prop(..., expand=True) call renders
    all three items with their labels correctly."""
    box.label(text="Connection style:", icon='OUTLINER_OB_SURFACE')
    row = box.row(align=True)
    row.prop(scene, "dynax_paralink_style", expand=True)


def _draw_boundary_offset(pl_box, scene):
    """Upper boundary control (v1.21.0 test-feedback fix #2) - shown in
    Guided, Semi and Manual only, never Auto. A +/- mm nudge on the
    auto-detected cut height (0 = automatic), NOT an absolute Z - see
    operators/paralink_ops.py's _resolve_user_transition_z()."""
    box = pl_box.box()
    col = box.column(align=True)
    col.label(text="Connection boundary:", icon='EDITMODE_HLT')
    row = col.row(align=True)
    row.prop(scene, "dynax_paralink_boundary_offset", text="Move up/down (mm)")
    if scene.dynax_paralink_boundary_offset != 0.0:
        row.operator("dynax.paralink_reset_boundary", text="", icon='LOOP_BACK')
    col.label(text="+ moves boundary up the socket", icon='TRIA_UP')
    col.label(text="− moves boundary down the socket", icon='TRIA_DOWN')
    col.label(text="0 = automatic detection", icon='AUTO')


def _draw_paralink_section(context, layout):
    """ParaLink Involvement Levels (v1.21.0): a 4-mode Connection Mode
    selector, with only the controls relevant to the selected mode shown
    below it. Mode 1 AUTO is the pre-existing one-click pipeline, byte-for-
    byte unchanged - none of surface_generator.py, join_engine.py,
    boundary_extractor.py, boundary_mapper.py or envelope_analyser.py was
    touched to build this.

    v1.21.0 test-feedback fix: the four Semi-Manual sliders (blend distance,
    transition angle, socket/adapter offset) had no path into the geometry
    engine - verified by reading run_paralink()'s and
    generate_transition_surface()'s real signatures, neither of which
    accepts any of the four. Replaced with connection_style.

    v1.21.0 test-feedback fix #2: the absolute "cut height (mm)" field that
    replaced them is itself replaced by a relative Upper Boundary +/- mm
    control (Guided/Semi/Manual only, never Auto)."""
    scene = context.scene
    mode = getattr(scene, 'dynax_paralink_mode', 'AUTO')

    pl_box = layout.box()
    pl_box.label(text="ParaLink — Connection Mode", icon='MOD_LATTICE')

    mode_row = pl_box.row(align=True)
    for m_id, m_label in (
        ('AUTO', 'Auto'), ('GUIDED', 'Guided'),
        ('SEMI', 'Semi'), ('MANUAL', 'Manual'),
    ):
        op = mode_row.operator(
            "dynax.paralink_set_mode", text=m_label, depress=(mode == m_id))
        op.mode = m_id

    pl_box.separator(factor=0.3)

    if mode == 'AUTO':
        _draw_paralink_style(pl_box, scene)
        row = pl_box.row()
        row.scale_y = 1.4
        row.operator("dynax.paralink_connect",
                      text="Connect Component", icon='MOD_LATTICE')
        sub = pl_box.row()
        sub.scale_y = 0.85
        sub.label(text="Automatic — ParaLink handles the rest", icon='INFO')

    elif mode == 'GUIDED':
        _draw_paralink_style(pl_box, scene)
        _draw_boundary_offset(pl_box, scene)
        pl_box.operator("dynax.paralink_analyse_guided",
                         text="Analyse Boundaries", icon='VIEWZOOM')
        if getattr(scene, 'dynax_paralink_guided_ready', False):
            metrics = pl_box.box()
            metrics.label(
                text=f"Boundary loop length: {scene.dynax_paralink_guided_loop_length:.1f} mm")
            metrics.label(
                text=f"Offset distance: {scene.dynax_paralink_guided_offset_distance:.1f} mm")
            metrics.label(
                text=f"Connection quality: {scene.dynax_paralink_guided_quality:.0f}/100")
            btn_row = pl_box.row(align=True)
            btn_row.operator("dynax.paralink_connect", text="Confirm", icon='CHECKMARK')
            adjust_op = btn_row.operator(
                "dynax.paralink_set_mode", text="Adjust", icon='TOOL_SETTINGS')
            adjust_op.mode = 'SEMI'
            manual_op = btn_row.operator(
                "dynax.paralink_set_mode", text="Manual", icon='VIEW_PAN')
            manual_op.mode = 'MANUAL'

    elif mode == 'SEMI':
        pl_box.label(text="You control the key parameters.")
        _draw_paralink_style(pl_box, scene)
        _draw_boundary_offset(pl_box, scene)
        row = pl_box.row()
        row.scale_y = 1.4
        row.operator("dynax.paralink_connect", text="Connect Component", icon='CHECKMARK')

    elif mode == 'MANUAL':
        pl_box.label(text="Maximum control.")
        _draw_paralink_style(pl_box, scene)
        _draw_boundary_offset(pl_box, scene)
        pl_box.operator("dynax.paralink_diagnostics",
                         text="Visualise Boundaries", icon='VIEWZOOM')
        col = pl_box.column(align=True)
        col.scale_y = 0.85
        col.label(text="Select your transition geometry manually,", icon='INFO')
        col.label(text="then validate.")
        row = pl_box.row()
        row.scale_y = 1.4
        row.operator("dynax.paralink_validate_join",
                      text="Validate and Join", icon='CHECKMARK')

    diag_row = pl_box.row(align=True)
    diag_row.operator("dynax.paralink_clear_diagnostics",
                      text="Clear Boundary Overlay", icon='X')


def draw_component_connection(
        context, layout, props, export_step=None, collapse_experimental=False,
        advanced_prop_name=None):
    """Draw the full Component Connection UI into `layout`.

    export_step: if given (Creator passes 'export'), a "Next → <step>" button is
    shown once the bridge completes. Other workflows pass None and rely on their
    own Export section drawn below this one.
    """
    scene = context.scene

    layout.label(text="Component Connection", icon='OUTLINER_OB_MESH')

    # ── 1. Select + load component ───────────────────────────────────
    #
    # v1.20.8: categories come from the library's own subfolders
    # (properties/dynax_properties.discover_component_categories) rather than
    # this section re-listing the folder itself. Every category that has assets
    # is shown; a category is never invented for assets that don't exist.
    layout.label(text="1. Component")
    comp_folder = _get_components_folder()
    if not os.path.isdir(comp_folder):
        box = layout.box()
        box.label(text="Component library folder not found.", icon='ERROR')
        box.label(text="Reinstall DynaX to restore it.")
    else:
        categories = discover_component_categories(comp_folder)
        if categories:
            total = sum(len(files) for files in categories.values())
            if len(categories) > 1:
                cat_row = layout.row()
                cat_row.scale_y = 0.85
                cat_row.label(
                    text=f"{len(categories)} categories · {total} components",
                    icon='OUTLINER_COLLECTION')
            layout.prop(props, "selected_component", text="")
            row_load = layout.row(align=True)
            row_load.prop(scene, "dynax_component_scale", text="Scale")
            op = row_load.operator("dynax.load_component",
                                   text="Load", icon='IMPORT')
            op.component_name = props.selected_component
        else:
            # Empty state: the folder exists but holds no supported asset.
            # Say what is supported and where, rather than just "not found".
            box = layout.box()
            box.label(text="No components in the library yet.", icon='INFO')
            col = box.column(align=True)
            col.scale_y = 0.85
            col.label(text="Add .stl or .blend parts to:")
            col.label(text=os.path.basename(comp_folder) + os.sep)
            col.label(text="A subfolder becomes a category.")

    if not scene.dynax_component_loaded:
        return

    comp = bpy.data.objects.get("dynax_component")

    layout.separator(factor=0.5)

    # ── 2. Position ─────────────────────────────────────────────────
    layout.label(text="2. Position")
    if comp:
        row_xy = layout.row(align=True)
        row_xy.prop(comp, "location", index=0, text="X")
        row_xy.prop(comp, "location", index=1, text="Y")
        row_pos = layout.row(align=True)
        row_pos.prop(comp, "location", index=2, text="Z")
        row_pos.prop(comp, "rotation_euler", index=2, text="Rotate Z")

    layout.separator(factor=0.5)

    # ── 3. Quick Bridge (primary recommended path) ──────────────────
    layout.label(text="3. Quick Bridge")
    layout.prop(scene, "dynax_transition_profile", text="")

    profile_desc = {
        'SMOOTH_FILLET':     "Organic S-curve — natural, manufactured look",
        'STANDARD':          "Balanced taper with moderate curvature",
        'STRAIGHT_TAPER':    "Linear conical — simple and clean",
        'CURVED_TAPER':      "Wider at socket, tapers quickly",
        'REINFORCED_COLLAR': "Widened collar at component interface",
        'PEDIATRIC':         "Gentle fillet for small components",
        'HEAVY_DUTY':        "Wide collar, reinforced transition",
    }
    desc = profile_desc.get(scene.dynax_transition_profile, "")
    if desc:
        desc_row = layout.row()
        desc_row.scale_y = 0.75
        desc_row.label(text=desc, icon='INFO')

    row_qb = layout.row()
    row_qb.scale_y = 1.4
    row_qb.operator("dynax.build_component_bridge",
                    text="Build Bridge", icon='MOD_LATTICE')

    layout.separator(factor=0.5)

    tstage = getattr(scene, 'dynax_transition_stage', 'NONE')
    if collapse_experimental:
        draw_advanced_section(
            layout,
            scene,
            advanced_prop_name,
            "Advanced Connection Methods (Experimental)",
            _draw_experimental_connection_methods,
            context=context,
        )
    else:
        _draw_experimental_connection_methods(context, layout)

    # ── Done → optional Next button (Creator only) ──────────────────
    if export_step and (tstage == 'COMPLETE' or scene.dynax_bridge_complete):
        layout.separator(factor=0.5)
        row_next = layout.row()
        row_next.scale_y = 1.2
        row_next.operator("dynax.goto_step",
                          text=f"Next → Export STL",
                          icon='EXPORT').step_id = export_step
