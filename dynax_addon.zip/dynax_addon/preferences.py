import bpy

class DynaXPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    dev_mode: bpy.props.BoolProperty(
        name="Developer Mode",
        description="Show experimental and developer-only features (e.g. Parametric Prep in Cleanup step)",
        default=False,
    )

    # Opt-in gate for utils/session_recorder.py — same pattern as the launcher's
    # analytics (analytics/collector.py's analytics_enabled()): disabled by
    # default, no patient data ever recorded. See session_recorder.py's module
    # docstring for why the add-on itself performs this network I/O.
    analytics_enabled: bpy.props.BoolProperty(
        name="Share anonymous usage data",
        description=(
            "Help improve DynaX by sharing anonymous session statistics. "
            "No patient data is ever recorded."
        ),
        default=False,
    )

    # Narrower opt-in, sub-option of analytics_enabled: gates whether the
    # raw text of AI queries/failed intents (utils/session_recorder.py's
    # log_ai_interaction()/log_failed_intent()) is included at all. Default
    # False - closed-vocabulary fields only are stored until a clinician
    # explicitly opts into this too.
    share_ai_conversations: bpy.props.BoolProperty(
        name="Share AI conversation text",
        description=(
            "Allow DynaX to include the text of your AI queries in "
            "anonymous usage data. This helps improve DynaX AI "
            "suggestions. No patient names or measurements are ever "
            "stored. Requires 'Share anonymous usage data' to also be "
            "enabled."
        ),
        default=False,
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "dev_mode", text="Enable Developer Mode")
        if self.dev_mode:
            layout.label(text="⚠ Developer features are visible. Disable before sharing with end users.", icon='ERROR')
        layout.separator(factor=0.5)
        col = layout.column()
        col.prop(self, "analytics_enabled")
        sub = col.column()
        sub.enabled = self.analytics_enabled
        sub.prop(self, "share_ai_conversations")


def get_dev_mode():
    """
    Safe helper used throughout the add-on to check if dev mode is active.
    Returns False if preferences are not yet loaded (e.g. during registration).
    """
    try:
        prefs = bpy.context.preferences.addons[__package__].preferences
        return prefs.dev_mode
    except (KeyError, AttributeError):
        return False
